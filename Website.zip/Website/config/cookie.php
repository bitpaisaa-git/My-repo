<?php
return [
	'ETH' => [
		'address' => 'b2ZxWkVmTllUc2sxTDNYRlZna2p0WlpkYlVYOVhEZEJCR2Yxam45Vy9zcSs1ZDd2WTVQcWJtSk5wMW9YVGQyZg==',
		'key' => 'QythRkR4VXBFcllobHlHblA4SXMrVUdyL2JVQ1g4djNPdGhib3MvZ0FNRT0=',
	],
	'ETH_USR' => [
		'key' => 'eCtOanl2R3lsRFZvSGU0MWtUelZENkdialUrNDI2T3YwakQyM2l6elFiND0=',
	],
	'XRP' => [
		'address' => 'TEdhSnFFbURaL09rUC80cUdLZjJaWWQxU2x1ZmdGQ0NheUFoMGt2YU16UmVSWFlXd254MzdJR3hmQzUrczNIOA==',
		'key' => 'T21SaU1QVnNFOHExRWZvQVowQW9LWFJTaXVNY21nOWZSdUNnYjQ0c2hROD0=',
	], 

];