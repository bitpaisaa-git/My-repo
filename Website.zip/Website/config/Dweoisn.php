<?php 

use Illuminate\Support\Str;


return [
    
   'SITE_PREFIX' => 'BP',
    'PAYPAL_CLIENT_ID' => "",
    'PAYPAL_SECRET' => "",
    'PAYPAL_MODE' => "sandbox",
    'paypal_settings' => array(
    						'mode' => 'sandbox',
    						'http.ConnectionTimeOut' => 30,
    						'log.LogEnabled' => true,
    						'log.LogLevel' => 'DEBUG',
    						'log.FileName' => 'storage/logs/paypal.log',
    						'log.LogLevel' => 'ERROR'
    					),
];