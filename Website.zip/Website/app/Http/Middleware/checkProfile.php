<?php

namespace App\Http\Middleware;

use Closure;
use Redirect;
use Session;

use App\Model\ConsumerVerification;


class checkProfile {
	/**
	 * Handle an incoming request.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \Closure  $next
	 * @return mixed
	 */
	public function handle($request, Closure $next) {
		$userId = session::get('userId');
		$profile_update = ConsumerVerification::where('user_id', $userId)->select('profile_update')->first()->profile_update;
		if ($profile_update != 1) {
			Session::flash('error', trans('app_lang.Please complete your profile details'));
			return Redirect::to('/settings?name=profile');
		}
		return $next($request);
	}
}
