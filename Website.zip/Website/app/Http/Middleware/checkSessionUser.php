<?php

namespace App\Http\Middleware;

use Closure;
use Redirect;
use Session;
use App\Model\User;

class checkSessionUser {
	/**
	 * Handle an incoming request.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \Closure  $next
	 * @return mixed
	 */
	public function handle($request, Closure $next) {
		$user_id = session::get('userId');
		$session = session::get('Randnum');
		$user = User::where('id',$user_id)->select('session_id')->first();
		if ($session != $user->session_id) {
			Session::flush();
			Session::flash('error','Please login to continue!!');
			return Redirect::to('/');
		}
		return $next($request);
	}
}
