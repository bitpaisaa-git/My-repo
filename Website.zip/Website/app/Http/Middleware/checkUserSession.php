<?php

namespace App\Http\Middleware;

use Closure;
use Redirect;
use Session;
use Request;
use App\Model\UserActivity;


class checkUserSession {
	/**
	 * Handle an incoming request.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \Closure  $next
	 * @return mixed
	 */
	public function handle($request, Closure $next) {
		if (Session::get('userId') == "") {
			if(Request::segment(1) == 'confirmWithdraw') {
				$transid =  Request::segment(2);
				$user_id = Request::segment(3);
				$code = Request::segment(4);
				session(['wuserId' => $user_id, 'wtransId' => $transid, 'wcode' => $code, 'type' => 'confirmWithdraw']);				
			} elseif(Request::segment(1) == 'rejectWithdraw') {
				$transid =  Request::segment(2);
				$user_id = Request::segment(3);
				$code = Request::segment(4);
				session(['wuserId' => $user_id, 'wtransId' => $transid, 'wcode' => $code, 'type' => 'rejectWithdraw']);
			}
			Session::flash('error', 'Please login to continue!!');
			return Redirect::to('/');
		} 
		return $next($request);
	}
}
