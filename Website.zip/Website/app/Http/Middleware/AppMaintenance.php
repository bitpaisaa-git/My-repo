<?php

namespace App\Http\Middleware;
use App\Http\Controllers\Controller;
use App\Model\SiteSettings;
use Closure;
use Redirect;


class AppMaintenance {
	/**
	 * Handle an incoming request.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \Closure  $next
	 * @return mixed
	 */
	public function handle($request, Closure $next) {
		$status = SiteSettings::where('id', 1)->select('app_status')->first();
		$ip = Controller::getIpAddress();
		if($ip != '117.254.189.115') {
			if ($status->app_status == "0") {
				echo json_encode(array('status'=>'7','msg'=>'App Under Maintenance') , JSON_FORCE_OBJECT);
				exit;
			}
		}
		return $next($request);
	}
}
