<?php

namespace App\Http\Middleware;

use Closure;
use Session;
use Redirect;
use Request;
use App\Model\SiteSettings;
class checkAdminSession
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */

    public function __construct() {
        $this->Url = ADMINURL;
    }

    public function handle($request, Closure $next)
    {
        if (session('adminId') == '') {
            if(Request::segment(2) == 'confirmWithdraw') {
                $transid =  Request::segment(3);
                $user_id = Request::segment(4);
                session(['wauserId' => $user_id, 'watransId' => $transid, 'atype' => 'confirmWithdraw']);
            } elseif(Request::segment(2) == 'rejectWithdraw') {
                $transid =  Request::segment(3);
                $user_id = Request::segment(4);                
                session(['wauserId' => $user_id, 'watransId' => $transid, 'atype' => 'rejectWithdraw']);
            } elseif(Request::segment(2) == 'confirmDeposit') {
                $transid =  Request::segment(3);
                $user_id = Request::segment(4);
                session(['wauserId' => $user_id, 'watransId' => $transid, 'atype' => 'confirmDeposit']);
            } elseif(Request::segment(2) == 'rejectDeposit') {
                $transid =  Request::segment(3);
                $user_id = Request::segment(4);                
                session(['wauserId' => $user_id, 'watransId' => $transid, 'atype' => 'rejectDeposit']);
            } 
            Session::flash('error','Please login to continue!');
           return Redirect::to($this->Url);
        }
        return $next($request);
    }
}
