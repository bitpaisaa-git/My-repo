<?php

namespace App\Http\Middleware;

use Closure;
use Session;
use Redirect;
use App\Model\User;
use Illuminate\Support\Facades\Input;

class RedirectIfUserActiveApp
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $data = Input::all();
        $userId = isset($data['user_id']) ? $data['user_id'] : '';
        $token  = isset($data['token'])?$data['token']:'';
        if($userId != "" && $token != "") {
            $getUser = User::where('id',$userId)->select('status')->first();
            if($getUser->status != "active") {
                echo json_encode(array('status'=>'0','message'=>'Your account deactivated by Admin') , JSON_FORCE_OBJECT);
                exit;
            }
        }
        return $next($request);
    }
}
