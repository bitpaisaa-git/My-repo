<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;
use Illuminate\Session\TokenMismatchException;
use Closure;
use Redirect;
use Session;

class VerifyCsrfToken extends Middleware {
	/**
	 * The URIs that should be excluded from CSRF verification.
	 *
	 * @var array
	 */
	protected $except = [
		'api/*',
		'trade_hist_aj_sea', 'trade_open_orders', 'careerEmailExists', 'careerMobileExists'
	];


	public function handle($request, Closure $next) {
		try {
			return parent::handle($request, $next);
		}
		catch (TokenMismatchException $exception) {
			Session::flash('error', 'Your Session have expired. Try again.');
			return Redirect::to('/');
		}
	}
}
