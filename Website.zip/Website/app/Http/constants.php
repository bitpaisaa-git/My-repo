<?php
define('PREFIX', 'BP_');
define('SITENAME', 'Bitpaisaa');
define('ADMINURL', 'sBaPsIacTlioNe');
define('WALLETURL', 'BaIdtmpiAniestAllAaw');
define('COINADDRESS', 'PaBiiIstaa_ca');
define('COINORDER', 'PaBiiIstaa_co');
define('COINPROFIT', 'coin_profit');
define('CURRENCY', 'currency');
define('DEPOSIT', 'PaBiiIstaa_de');
define('EXCHANGE', 'exchange');
define('ORDERTEMP', 'PaBiiIstaa_ot');
define('TRADEPAIRS', 'trade_pairs');
define('PAIRFAV', 'pair_favorite'); 
define('PENDINGDEPOSIT', 'pending_deposit');
define('REMOSIS', 'remosis');
define('TRANSFER', 'transfer');
define('USERINFO', 'PaBiiIstaa_us');
define('USERBANK', 'user_bank_details');
define('WALLET', 'PaBiiIstaa_wa');
define('WITHDRAW', 'PaBiiIstaa_wi');
define('TWOFACTORKEY', '13554cb3-a8c3-11eb-80ea-0200cd936042');
define('TWOFACTORSENDER', 'BITPAISAA');
define('DEMOURL', '');
define('LIVEURL', 'bitpaisaa.com');
define('EMAILID', '');
define('FROMMAILID', 'S0x3Zm5CdkcrZy9yRGRQcE5kSlVmMlNCOVdXVndXZUUwUzQxQlIySURTST0=');
?> 