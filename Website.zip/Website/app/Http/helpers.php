<?php
use App\Model\Cms;
use App\Model\CoinOrder;
use App\Model\Currency;
use App\Model\ExchangeModel; 
use App\Model\OrderTemp;
use App\Model\ReferralCommision;
use App\Model\SiteSettings;
use App\Model\TradeModel;
use App\Model\TradePairs;
use App\Model\User;
use App\Model\Wallet;
use App\Model\Withdraw;

function encrypText($string) {
	$encrypt_method = "AES-256-CBC";
	$secret_key = 'FCLdLtanRnbYJDMq secret key';
	$secret_iv = 'FCLdLtanRnbYJDMq secret iv';
	$key = hash('sha256', $secret_key);
	$iv = substr(hash('sha256', $secret_iv), 0, 16);
	$output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
	$output = base64_encode($output);
	return $output;
}

function decrypText($string) {
	$encrypt_method = "AES-256-CBC";
	$secret_key = 'FCLdLtanRnbYJDMq secret key';
	$secret_iv = 'FCLdLtanRnbYJDMq secret iv';
	$key = hash('sha256', $secret_key);
	$iv = substr(hash('sha256', $secret_iv), 0, 16);
	$output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
	return $output;
}

function encrypText_old($string) {
	$encrypt_method = "AES-256-CBC";
	$secret_key = 'hRpbvMnbrMDvYgZs secret key';
	$secret_iv = 'hRpbvMnbrMDvYgZs secret iv';
	$key = hash('sha256', $secret_key);
	$iv = substr(hash('sha256', $secret_iv), 0, 16);
	$output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
	$output = base64_encode($output);
	return $output;
}

function decrypText_old($string) {
	$encrypt_method = "AES-256-CBC";
	$secret_key = 'hRpbvMnbrMDvYgZs secret key';
	$secret_iv = 'hRpbvMnbrMDvYgZs secret iv';
	$key = hash('sha256', $secret_key);
	$iv = substr(hash('sha256', $secret_iv), 0, 16);
	$output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
	return $output;
}

function check_digit($currency) {
	return '9';
}

function getUserName($userId) {
	$username = User::where('id', $userId)->select('consumer_name')->first();
	return ($username) ? $username->consumer_name : "";
}

function getUserId($consumer_name) {
	$userId = User::where('consumer_name', $consumer_name)->select('id')->first();
	return ($userId) ? $userId->id : "";
}

function get_userdetails($userId) {
	if ($userId) {
		$userdetails = User::where('id', $userId)->first();
		if (count($userdetails) > 0) {
			return $userdetails;
		}
	}
}

function get_user_email($userId) {
	$getDetail = get_userdetails($userId);
	return decrypText($getDetail->user_mail_id) . '@' . decrypText($getDetail->unusual_user_key);
}

function finddigt($currency) {
	return 9;
}

function pairDetails($pair, $key) {
	$pairdetails = DB::table(TRADEPAIRS)->where('pair_name', $pair)->select($key)->first();
	if (count($pairdetails) > 0) {
		return $pairdetails->$key;
	}
	return true;
}

function sitesetting_helper($key) {
	return SiteSettings::where('id', 1)->first()->$key;
}

function cms_lang_content($type, $val, $lan, $auto_id) {
	if (!empty($lan)) {
		if ($lan == 'en') {
			$show_res = "content";
		} else {
			$show_res = "content_" . $lan;
		}

		$getContent = Cms::where('id', $auto_id)->select($show_res)->get();
		$result = $getContent[$val]->$show_res;
	} else {
		$show_res = "content";
		$getContent = Cms::whereIn('id', [$auto_id])->select($show_res)->get();
		$result = $getContent[$val]->$show_res;
	}
	return $result;
}

function cms_lang_title($type, $val, $lan, $auto_id) {
	if (!empty($lan)) {
		if ($lan == 'en') {
			$show_res = "title";
		} else {
			$show_res = "title_" . $lan;
		}

		$getContent = Cms::where('id', $auto_id)->select($show_res)->get();
		$result = $getContent[$val]->$show_res;
	} else {
		$show_res = "title";
		$getContent = Cms::whereIn('id', [$auto_id])->select($show_res)->get();
		$result = $getContent[$val]->$show_res;
	}
	return $result;
}

function connectJsonRpc($params, $cmd, $postfields) {
	$data = array();
	$data['jsonrpc'] = 2.0;
	$data['id'] = 1;
	$data['method'] = $cmd;
	$data['params'] = $postfields;
	$url = 'http://' . $params['user'] . ':' . $params['password'] . '@' . $params['ip'] . ':' . $params['port'];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
	curl_setopt($ch, CURLOPT_POST, count($postfields));
	curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	$ret = curl_exec($ch);
	$info = curl_getinfo($ch);
	curl_close($ch);
	$res = json_decode($ret, true);
	return $res;
}

function check_referralstatus($userid) {
	$checkrefer = User::where('id', $userid)->where('referrer_id', '!=', 0)->select('referrer_id')->first();
	if ($checkrefer) {
		if ($checkrefer->referrer_id) {
			$checkrefer_by = User::where('refer_id', $checkrefer->referrer_id)->select('id')->first();
			if ($checkrefer_by) {
				return $checkrefer_by->id;
			} else {
				return "0";
			}
		} else {
			return "0";
		}
	}
	return "0";
}

function referralcommision_update($id, $Type, $amount, $tradePrice, $feePer, $tradefirstCurrency, $tradesecondCurrency, $referby_id, $coin_order_id) {
	if ($Type == "Buy") {
		$fee = ($amount * $feePer) / 100;
	} else {
		$fee = (($amount * $tradePrice) * $feePer) / 100;
	}
	$commision_per = TradePairs::where('to_symbol', $tradesecondCurrency)->where('from_symbol', $tradefirstCurrency)->select('refer_commision_per')->first();
	if ($commision_per->refer_commision_per) {
		$comm = $commision_per->refer_commision_per;
		if ($fee) {
			$fee_comm = ($fee * $comm) / 100;
			$admin_fee = $fee - $fee_comm;
			if ($fee_comm) {

				if ($Type == "Buy") {
					$t_curr = $tradefirstCurrency;
				} else {
					$t_curr = $tradesecondCurrency;
				}

				$data = array(
					'coin_order_id' => $coin_order_id,
					'user_id' => $id,
					'refer_by_id' => $referby_id,
					'type' => $Type,
					'price' => $tradePrice,
					'amount' => $amount,
					'fee_per' => $feePer,
					'fee' => $fee,
					'status' => 1,
					'commision_fee' => $fee_comm,
					'admin_fee' => $admin_fee,
					'first_currency' => $tradefirstCurrency,
					'secound_currency' => $tradesecondCurrency,
					'refer_currency' => $t_curr,
				);
				$ref_fees = $fee_comm;
				$balance = TradeModel::fetchuserbalancebyId($referby_id, $t_curr);
				$updatebalance = $balance + $ref_fees;

				$remarks = 'Referral amount updated ' . $fee_comm . ' ' . $t_curr . ' Old balance: ' . $balance;
				Wallet::where('user_id', $referby_id)->update([$t_curr => $updatebalance, 'remarks' => $remarks]);
				$data['refer_currency'] = $t_curr;
				$resultIns = ReferralCommision::create($data);
				return $admin_fee;
			} else {
				return $fee;
			}
		} else {
			return "0";
		}
	}
	return $fee;
}

//get url contents using curl
function getUrlContents($url) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_HEADER, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13');
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
	curl_setopt($ch, CURLOPT_TIMEOUT, 400);
	$data = curl_exec($ch);
	curl_close($ch);
	return $data;
}

function finddigtTrade($currency) {
	return 9;
}

function bchexdec($hex) {
	if (strlen($hex) == 1) {
		return hexdec($hex);
	} else {
		$remain = substr($hex, 0, -1);
		$last = substr($hex, -1);
		return bcadd(bcmul(16, bchexdec($remain)), hexdec($last));
	}
}

function dashboard_fav($userId) {
	$fav = array();
	if (!empty($userId)) {
		$fav = DB::table(PAIRFAV)->where('user_id', $userId)->where('status', '1')->pluck('pair', 'id')->toArray();
	}
	return $fav;
}

function sitedata() {
	$api = SiteSettings::where('id', 1)->first();
	return $api;
}

function getLocalTime($time, $fromTz = 'UTC', $toTz = 'Asia/Kolkata') {
	$date = new DateTime($time, new DateTimeZone($fromTz));
	$date->setTimezone(new DateTimeZone($toTz));
	$time = $date->format('Y-m-d H:i:s');
	return $time;
}

//To get random referal string
function randomString($length) {
	$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$charactersLength = strlen($characters);
	$randomString = '';
	for ($i = 0; $i < $length; $i++) {
		$randomString .= $characters[rand(0, $charactersLength - 1)];
	}
	return $randomString;
}

function randomInteger($length) {
	$characters = '0123456789';
	$charactersLength = strlen($characters);
	$randomString = '';
	for ($i = 0; $i < $length; $i++) {
		$randomString .= $characters[rand(0, $charactersLength - 1)];
	}
	return $randomString;
}

function trigger_socket($data, $functionname) {
	if ($_SERVER['HTTP_HOST'] == 'localhost') {
		$host = $_SERVER['HTTP_HOST'];
		$port = '2082';
		$protocol = 'http';
	} else {
		$host = DEMOURL;
		$port = '2053';
		$protocol = 'https';
	}
	$host = $protocol . '://' . $host;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $host . ':' . $port . '/' . $functionname);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
	$output = curl_exec($ch);
	curl_close($ch);
	return $output;
}
 

function inorders($symbol, $userId = '') {
	if ($userId == '') {
		$userId = session('userId');
	}
	$digits = 9;
	$btc_value = Currency::where('currency_symbol', $symbol)->select('btc_value')->first()->btc_value;
	 
		$inorders = 0; 
	$btc_equ = $inorders * $btc_value;
	$result['inorders'] = number_format($inorders, $digits, '.', '');
	$result['btc_equ'] = number_format($btc_equ, 9, '.', '');
	return $result;
}

function userInorder($symbol, $userId) {
	$digits = 9;
	$withdraw = Withdraw::where('currency', $symbol)->where('user_id', $userId)->whereIn('status', ['pending', 'in progress'])->sum('amount');
	$buyOrders = CoinOrder::where('Type', 'Buy')->where('user_id', $userId)->where('secondCurrency', $symbol)->whereIn('status', ['active', 'partially', 'stoporder'])->sum('Total');
	$sellOrders = CoinOrder::where('Type', 'Sell')->where('user_id', $userId)->where('firstCurrency', $symbol)->whereIn('status', ['active', 'partially', 'stoporder'])->sum('Amount');
	$swap = ExchangeModel::where('from_symbol', $symbol)->where('user_id', $userId)->where('status', 'pending')->sum('amount');
	$inorders = $withdraw + $buyOrders + $sellOrders + $swap;
	$inorder = number_format($inorders, $digits, '.', '');
	return $inorder;
}

function portfolioInorder($symbol, $userId, $intype = '') {
	if ($intype == 3) {
		$userId = decrypText($userId);
	}
	$digits = 9;
	$btc_value = Currency::where('currency_symbol', $symbol)->select('btc_value')->first()->btc_value;
	$withdraw = Withdraw::where('currency', $symbol)->where('user_id', $userId)->whereIn('status', ['pending', 'in progress'])->sum('amount');
	$buyOrders = CoinOrder::where('Type', 'Buy')->where('user_id', $userId)->where('secondCurrency', $symbol)->whereIn('status', ['active', 'partially', 'stoporder'])->sum('Total');
	$sellOrders = CoinOrder::where('Type', 'Sell')->where('user_id', $userId)->where('firstCurrency', $symbol)->whereIn('status', ['active', 'partially', 'stoporder'])->sum('Amount');
	$swap = ExchangeModel::where('from_symbol', $symbol)->where('user_id', $userId)->where('status', 'pending')->sum('amount');
	 
	$inorders = $withdraw + $buyOrders + $sellOrders + $swap;
	$inorder = number_format($inorders, $digits, '.', '');
	if ($intype == 1) {
		$btc_equ = $inorders * $btc_value;
		$result['inorders'] = number_format($inorders, $digits, '.', '');
		$result['btc_equ'] = number_format($btc_equ, 9, '.', '');
		return $result;
	} else {
		return $inorder;
	}
}

function base58check2HexString($base58add) {
	$address = base58check_de($base58add);
	$hexString = bin2hex($address);
	return $hexString;
}

//decode address from base58check string to byte[]
function base58check_de($base58add) {
	$address = base58_decode($base58add);
	$size = strlen($address);
	if ($size != 25) {
		return false;
	}
	$checksum = substr($address, 21);
	$address = substr($address, 0, 21);
	$hash0 = hash("sha256", $address);
	$hash1 = hash("sha256", hex2bin($hash0));
	$checksum0 = substr($hash1, 0, 8);
	$checksum1 = bin2hex($checksum);
	if (strcmp($checksum0, $checksum1)) {
		return false;
	}
	return $address;
}
function base58_decode($base58) {
	$alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
	$base = strlen($alphabet);
	if (is_string($base58) === false) {
		return false;
	}
	if (strlen($base58) === 0) {
		return '';
	}
	$indexes = array_flip(str_split($alphabet));
	$chars = str_split($base58);
	foreach ($chars as $char) {
		if (isset($indexes[$char]) === false) {
			return false;
		}
	}
	$decimal = $indexes[$chars[0]];
	for ($i = 1, $l = count($chars); $i < $l; $i++) {
		$decimal = bcmul($decimal, $base);
		$decimal = bcadd($decimal, $indexes[$chars[$i]]);
	}
	$output = '';
	while ($decimal > 0) {
		$byte = bcmod($decimal, 256);
		$output = pack('C', $byte) . $output;
		$decimal = bcdiv($decimal, 256, 0);
	}
	foreach ($chars as $char) {
		if ($indexes[$char] === 0) {
			$output = "\x00" . $output;
			continue;
		}
		break;
	}
	return $output;
}

function selectDecimal($from_symbol, $to_symbol) {
	$check = DB::table(TRADEPAIRS)->where('from_symbol', $from_symbol)->where('to_symbol', $to_symbol)->select('select_start', 'select_end')->first();
	if ($check) {
		return $check;
	} else {
		return false;

	}
}

function trade_digit($from_symbol, $to_symbol) {
	$getTrade = TradePairs::where('from_symbol', $from_symbol)->where('to_symbol', $to_symbol)->select('digit_amount', 'digit_price')->first();
	return $getTrade;
}

function getRealIpAddr() {
	if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
		$ip = $_SERVER['HTTP_CLIENT_IP'];
	} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
	} else {
		$ip = $_SERVER['REMOTE_ADDR'];
	}
	return $ip;
}

function get_withdraw_limits($id) {
	$date = date('Y-m-d H:i:s', strtotime("-1 days"));
	$get_data = DB::table(WITHDRAW . ' as w')->leftjoin('currency as c', 'c.currency_symbol', '=', 'w.currency')->where('w.user_id', $id)->where('w.status', '!=', 'cancelled')->where('w.created_at', '>=', $date)->select('w.amount', 'c.inr_value')->get();
	$total_amount = $total_amount_btc = 0;
	if (!empty($get_data)) {
		foreach ($get_data as $key => $value) {
			$total_amount_btc += $value->inr_value * $value->amount;
		}
		return number_format($total_amount_btc, 2, '.', '');
	}
	return 0;
}

function get_tradePrice($curr) {
	if ($curr != 'BTC') {
		$tradePair = TradePairs::where('from_symbol', $curr)->where('to_symbol', 'BTC')->select('last_price')->first();
		if (count($tradePair)) {
			$price = $tradePair->last_price;
		} else {
			$price = 1;
		}
	} else {
		$price = 1;
	}
	return number_format($price, 2, '.', '');
}

function setRandSleep() {
	usleep(rand(1000000, 3999999));
}

function wazirx_conv($convertfrom, $convertto) {
	$pair = $convertfrom . $convertto;
	$url = "https://api.wazirx.com/api/v2/tickers/" . $pair;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	$output = curl_exec($ch);
	curl_close($ch);
	$output = json_decode($output, true);
	if (isset($output['ticker'])) {
		return $output['ticker']['last'];
	} else {
		return 0;
	}
}

function binanceTicker($from, $to) {
	$pair = $from . $to;
	$url = "https://www.binance.com/api/v1/ticker/24hr?symbol=" . $pair;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	$output = curl_exec($ch);
	curl_close($ch);
	$output = json_decode($output, true);
	if (isset($output['lastPrice'])) {
		return $output['lastPrice'];
	} else {
		return 1;
	}
}

function coingecko($name, $curSym, $toSym) {
	$name = strtolower($name);
	$to = strtolower($curSym);
	$convertto = $toSym;
	$price = 1;
	if($curSym == 'INR' && $toSym == 'btc') {
		$name =  'bitcoin';
	}  
	$convertto = ($curSym == 'INR') ? 'inr' : $convertto;

	if(($name == 'indian rupee' && $convertto == 'inr') || ($name == 'bitcoin' && $convertto == 'btc')){
		$price = 1;
	} else {
		$url = "https://api.coingecko.com/api/v3/simple/price?ids=" . $name . "&vs_currencies=" . $convertto;
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		$output = curl_exec($ch);
		curl_close($ch);
		$output = json_decode($output, true);
		if (!empty($output[$name])) {
			if($curSym == 'INR' && $toSym == 'btc') {
				$price = 1 / $output[$name][$convertto];
			} else {
				$price = $output[$name][$convertto];
			}
		}
	}
	return $price;
}

function get_inr_price($cur) {
	$inr_enable = SiteSettings::where('id', '1')->select('inr_enable')->first()->inr_enable;
	$currency = Currency::where('currency_symbol', $cur)->select('inr_value', 'admin_inr_value', 'admin_inr_value1', 'admin_inr_limit')->first();
	$inr_value = $currency->inr_value;
	$admin_inr_value = $currency->admin_inr_value;
	$admin_inr_value1 = $currency->admin_inr_value1;
	$admin_inr_limit = $currency->admin_inr_limit;
	if ($inr_enable == 1) {
		$inr = $inr_value;
	} else {
		$inr = $admin_inr_value;
	}
	return $inr;
}

function getcurrencyname($currency) {
	$result = Currency::where('currency_symbol', $currency)->select('currency_name')->first();
	return $result['currency_name'];
}

function getcurrencyimage($currency) {
	$result = Currency::WHERE('currency_symbol', $currency)->select('image')->first();
	return $result['image'];
}

function coinPairs($to_sym) {
	$response = $coinImg = array();
	$upMarket = URL::to('public/frontend/images/icons/market-green.png');
	$downMarket = URL::to('public/frontend/images/icons/market-red.png');
	$yesterday = date('Y-m-d H:i:s', strtotime("-1 day"));
	$pairDetails = DB::select("select c.image, c.currency_name, c.image, b.id, b.from_symbol, b.to_symbol, (sum(askPrice * filledAmount)) as volume, a.askPrice as yesterday_price, MAX(a.askPrice) as high, MIN(a.askPrice) as low,b.last_price, b.change FROM " . PREFIX . ORDERTEMP . " a right join " . PREFIX . TRADEPAIRS . " b on a.firstCurrency = b.from_symbol and a.secondCurrency = b.to_symbol and a.created_at >= '" . $yesterday . "' and a.cancel_id = 0 left join " . PREFIX . CURRENCY . " c on c.currency_symbol=b.from_symbol where b.site_status = 1 and b.to_symbol =  '" . $to_sym . "' GROUP BY b.id ORDER BY b.id ASC");
	foreach ($pairDetails as $pairs) {
		$fromSymbol = $pairs->from_symbol;
		$toSymbol = $pairs->to_symbol;
		$pairChange = $pairs->change;
		$image = $pairs->image;
		$forName = $fromSymbol . '/' . $toSymbol;
		$forUrl = $fromSymbol . '_' . $toSymbol;
		$coin = $curname = $pairs->currency_name;

		$getTrade = TradePairs::where('from_symbol', $fromSymbol)->where('to_symbol', $toSymbol)->where('site_status', 1)->select('fee_per', 'tfee_per', 'min_price','minamt', 'digit_amount', 'digit_price', 'last_price', 'low', 'high', 'base_volume', 'change')->first();

		$high = ($pairs->high == "") ? "0.00" : $pairs->high;
		$low = ($pairs->low == "") ? "0.00" : $pairs->low;
		$lastPrice = ($pairs->last_price == "" || $pairs->last_price == 0) ? $getTrade->last_price : $pairs->last_price;
		
		// $lastPrice = $pairs->last_price;
		$upArrow = '<i class="fa fa-arrow-up"></i>';
		$downArrow = '<i class="fa fa-arrow-down"></i>';

		$yesterPrice = $pairs->yesterday_price;
		if ($yesterPrice <= 0) {
			$changePer = $pairChange;
			$arrow = $upArrow;
			$market = $upMarket;
			$sym = "+";
			$cls = "plus_value";
		} else {
			$changePrice = ($lastPrice - $yesterPrice) / $yesterPrice;
			$changePer = $changePrice * 100;
			$arrow = ($lastPrice >= $yesterPrice) ? $upArrow : $downArrow;
			$market = ($lastPrice >= $yesterPrice) ? $upMarket : $downMarket;
			$sym = ($lastPrice >= $yesterPrice) ? "+" : "";
			$cls = ($lastPrice >= $yesterPrice) ? "plus_value" : "minus_value";
		}
		$changePer = $arrow . " " . number_format($changePer, 2, '.', '') . '%';

		$lastPrice = number_format($lastPrice, 8, '.', '');
		$volume = ($pairs->volume == "") ? "0.00" : number_format($pairs->volume, 4, '.', '');
		$response[] = array('pair' => $forName, 'pairs' => $forUrl, 'change' => $changePer, 'volume' => $volume, 'price' => $lastPrice, 'coin' => $coin, 'from_symbol' => $fromSymbol, 'to_symbol' => $toSymbol, 'image' => $image, 'market' => $market, 'cls' => $cls);
	}
	return $response;
}

 
function encryptnew($plainText,$key)
{
    $secretKey = hextobin(md5($key));
    $initVector = pack("C*", 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f);
    $encryptedText = openssl_encrypt($plainText, "AES-128-CBC", $secretKey, OPENSSL_RAW_DATA, $initVector);
    $encryptedText = bin2hex($encryptedText);
    return $encryptedText;
}

function decryptnew($encryptedText,$key)
{
    $secretKey         = hextobin(md5($key));
    $initVector         =  pack("C*", 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f);
    $encryptedText      = hextobin($encryptedText);
    $decryptedText         =  openssl_decrypt($encryptedText,"AES-128-CBC", $secretKey, OPENSSL_RAW_DATA, $initVector);
    return $decryptedText;
}
 
 function pkcs5_pad($plainText, $blockSize)
{
    $pad = $blockSize - (strlen($plainText) % $blockSize);
    return $plainText . str_repeat(chr($pad), $pad);
}

// ********** Hexadecimal to Binary function for php 4.0 version ********
function hextobin($hexString)
{
    $length = strlen($hexString);
    $binString = "";
    $count = 0;
    while ($count < $length) {
        $subString = substr($hexString, $count, 2);
        $packedString = pack("H*", $subString);
        if ($count == 0) {
            $binString = $packedString;
        } 
        else {
            $binString .= $packedString;
        }
        
        $count += 2;
    }
    return $binString;
}