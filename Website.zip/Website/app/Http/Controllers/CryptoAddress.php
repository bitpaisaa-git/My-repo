<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Model\AdminTransfer;
use App\Model\CoinAddress;
use App\Model\ContactUs;
use App\Model\Currency;
use App\Model\Deposit;
use App\Model\DepositSettings;
use App\Model\EmailTemplate;
use App\Model\PendingDeposit;
use App\Model\SiteWallet;
use App\Model\Transaction;
use App\Model\TronModel;
use App\Model\User;
use App\Model\UserNotification;
use App\Model\Wallet;
use App\Model\Wallet\ConnectEth; 
use App\Model\WltDeposit;
use Config;
use DB;
use Validator;

class CryptoAddress extends Controller {

	public function __construct() {
	}

	//To generate address
	public static function createAddress($currency, $userId) {
		if ($_SERVER['HTTP_HOST'] != "localhost") {
			if ($currency == "BTC" || $currency == "LTC" || $currency == "BCH" || $currency == "DASH") {
				$encrypt = encrypText($currency);
				$getFile = file_get_contents(app_path('Model/BfuiSGvKthvPYsVa/' . $encrypt . '.php'));
				$data = explode(" || ", $getFile);
				$connParams = array(
					'user' => decrypText($data[0]),
					'password' => decrypText($data[1]),
					'ip' => decrypText($data[2]),
					'port' => decrypText($data[3]),
				);
				$getAddr = connectJsonRpc($connParams, "getnewaddress", array());
				$address = $getAddr['result'];
				$response = array('status' => 1, 'address' => $address, 'tag' => "", 'hex' => "");
			} else if ($currency == "ETH") {
				$key = decrypText(Config::get('cookie.ETH_USR.key'));
				$getAddr = ConnectEth::ethFunctions("createAddr", array('key' => $key));
				if ($getAddr['type'] == "success") {
					$response = array('status' => 1, 'address' => $getAddr['result'], 'tag' => "", 'hex' => "");
				} else {
					$response = array('status' => 0);
				}
			} else if ($currency == "XRP") {
				$address = self::randomstring($currency);
				$response = array('status' => 1, 'address' => '', 'tag' => $address, 'hex' => "");
			} else {
				$response = array('status' => 2, 'address' => $currency . "sampleaddress", 'tag' => "", 'hex' => "");
			}
		} else {
			if ($currency == 'XRP') {
				$address = self::randomstring($currency);
				$response = array('status' => 1, 'address' => '', 'tag' => $address, 'hex' => "");
			} else {
				$address = randomString(25);
				$response = array('status' => 1, 'address' => $address, 'tag' => "", 'hex' => "");
			}
		}
		return $response;
	}

	//get balance for selected currency
	public static function getBalance($currency) {
		if ($_SERVER['HTTP_HOST'] != "localhost") {
			if ($currency == "BTC" || $currency == "LTC" || $currency == "BCH" || $currency == "DASH") {
				$encrypt = encrypText($currency);
				$getFile = file_get_contents(app_path('Model/BfuiSGvKthvPYsVa/' . $encrypt . '.php'));
				$data = explode(" || ", $getFile);
				$connParams = array(
					'user' => decrypText($data[0]),
					'password' => decrypText($data[1]),
					'ip' => decrypText($data[2]),
					'port' => decrypText($data[3]),
				);
				$getInfo = connectJsonRpc($connParams, "getwalletinfo", array());
				$info = $getInfo['result'];
				$balance = $info['balance'];
			} elseif ($currency == "ETH") {
				$encrypt = encrypText($currency);
				$adminAddr = decrypText(Config::get('cookie.ETH.address'));
				$getBalance = ConnectEth::ethFunctions('checkBalance', array('address' => $adminAddr));
				$balance = $getBalance['result'];
			} elseif ($currency == "USDT") {
				$adminAddr = decrypText(Config::get('cookie.ETH.address'));
				$contract = Currency::where('currency_symbol', $currency)->select('contract_address', 'decimal_point')->first();
				$contract_address = $contract->contract_address;
				$decimal_point = $contract->decimal_point;
				$data = array('adminaddress' => $adminAddr, 'contract' => $contract_address);
				$balance = ConnectEth::ethFunctions('tokenBalance', $data);
				$tokenbalance = $balance['result'];
				$balance = $tokenbalance / 1000000;
				$balance = number_format($balance, 8, '.', '');
			} elseif ($currency == "XRP") {
				$xrp_adr = decrypText(Config::get('cookie.XRP.address'));
				$url = "https://data.ripple.com/v2/accounts/" . $xrp_adr . "/balances?currency=XRP";
				$output = Controller::getContents($url);
				$result = json_decode($output, true);
				if ($result['result'] != 'error') {
					$balance = $result['balances'][0]['value'];
				} else {
					$balance = 0;
				}
			}  else {
				$balance = "0.00000000";
			}
		} else {
			$balance = "0.00000000";
		}
		return number_format($balance, 8, '.', '');
	}

	//withdraw crypto
	public static function sendCryptoAmount($currency, $address, $amount, $tag, $phrase = '') {
		$amount = trim($amount);
		$address = trim($address);
		$encrypt = encrypText($currency);
		if ($currency == "BTC" || $currency == "LTC" || $currency == "BCH" || $currency == "DASH") {
			$getFile = file_get_contents(app_path('Model/BfuiSGvKthvPYsVa/' . $encrypt . '.php'));
			$data = explode(" || ", $getFile);
			$connParams = array(
				'user' => decrypText($data[0]),
				'password' => decrypText($data[1]),
				'ip' => decrypText($data[2]),
				'port' => decrypText($data[3]),
			);
			$getInfo = connectJsonRpc($connParams, "getwalletinfo", array());
			$info = $getInfo['result'];
			$balance = $info['balance'];

			if ($balance > $amount) {
				$getDetails = connectJsonRpc($connParams, "validateaddress", array($address));
				$checkAddr = $getDetails['result'];
				if ($checkAddr['isvalid'] == 1) {
					if ($currency == 'BTC') {
						$setarray = array('Suren@123', 6000);
						$transfer = connectJsonRpc($connParams, 'walletpassphrase', $setarray);
						if (isset($transfer['error']) && !empty($transfer['error'])) {
							return array("msg" => "fail", "result" => "Invalid password");
						}
					}
					$isvalid = connectJsonRpc($connParams, "sendtoaddress", array($address, (float) $amount));
					$withResult = array('msg' => 'success', 'result' => $isvalid['result']);
				} else {
					$withResult = array("msg" => "fail", "result" => "Invalid " . $currency . " Address");
				}
			} else {
				$withResult = array('msg' => 'bal', 'result' => "Insufficient Balance!");
			}
		} elseif ($currency == "ETH") {
			$adminAddr = decrypText(Config::get('cookie.ETH.address'));
			$getBalance = ConnectEth::ethFunctions('checkBalance', array('address' => $adminAddr));

			$ethBalance = $getBalance['result'];
			if ($ethBalance > $amount) {
				$key = decrypText(Config::get('cookie.ETH.key'));
				$key = trim($key);
				$ethDetails = Currency::where('currency_symbol', $currency)->select('gasprice', 'gaslimit')->first();
				$gas = self::gasPrice();
				$gas_limit = $ethDetails->gaslimit;
				$decimals = str_pad(1, 10, '0', STR_PAD_RIGHT);
				$gas = bcmul($gas, $decimals);
				$ethData = array('key' => $key, 'gasPrice' => $gas, 'gasLimit' => $gas_limit, 'amount' => $amount, 'from' => $adminAddr, 'to' => $address);
				$transferEth = ConnectEth::ethFunctions('sendEthereum', $ethData);
				if ($transferEth['type'] == "success") {
					$withResult = array("msg" => "success", "result" => $transferEth['result']);
				} else {
					$withResult = array('msg' => 'fail', 'result' => $transferEth['result']);
				}
			} else {
				$withResult = array('msg' => 'bal', 'result' => "Insufficient Balance!");
			}
		} elseif ($currency == "USDT") {
			$usdtDetails = Currency::where('currency_symbol', $currency)->select('contract_address', 'gasprice', 'gaslimit')->first();
			$contract = $usdtDetails->contract_address;
			$tokenbalance = bcmul($amount, 1000000);
			$encrypt = encrypText('ETH');
			$coin = SiteWallet::where('type', $encrypt)->select('username')->first();
			$adminAddr = strtolower(decrypText($coin->username));
			$balance_token = ConnectEth::ethFunctions('tokenBalance', array('adminaddress' => $adminAddr, 'contract' => $contract));
			$balance = 0;
			if ($balance_token['type'] == 'success') {
				$balance = $balance_token['result'];
			}
			if ($balance > $tokenbalance) {
				$gas = self::gasPrice();
				$gas_limit = $usdtDetails->gaslimit;
				$decimals = str_pad(1, 10, '0', STR_PAD_RIGHT);
				$gas = bcmul($gas, $decimals);
				$transAmount = $tokenbalance;
				$amount = '';
				do {
					$last = bcmod($transAmount, 16);
					$amount = dechex($last) . $amount;
					$transAmount = bcdiv(bcsub($transAmount, $last), 16);
				} while ($transAmount > 0);
				if ($amount) {
					$key = decrypText(Config::get('cookie.ETH.key'));
					$pass_token = trim($key);
					$arr = array('token' => 'USDT', 'account' => $adminAddr, 'toaddress' => $address, 'amount' => $amount, 'key' => $pass_token, 'gasPrice' => $gas, 'gasLimit' => $gas_limit, 'contract' => $contract);
					$transferEth = ConnectEth::ethFunctions('sendToken', $arr);
					if ($transferEth['type'] == "success") {
						$withResult = array("msg" => "success", "result" => $transferEth['result']);
					} else {
						$withResult = array('msg' => 'fail', 'result' => $transferEth['result']);
					}
				} else {
					$withResult = array('msg' => 'fail', 'result' => "Insufficient Balance");
				}
			} else {
				$withResult = array('msg' => 'bal', 'result' => "Insufficient Balance!");
			}
		} elseif ($currency == "XRP") {
			$adminaddress = decrypText(Config::get('cookie.XRP.address'));
			$first = decrypText(Config::get('cookie.XRP.key'));
			$getFile = file_get_contents(app_path('Model/BfuiSGvKthvPYsVa/' . $encrypt . '.php'));
			$details = explode(" || ", $getFile);
			$second = decrypText($details[0]);
			$pass = $first . $second;
			$balance = self::getBalance('XRP');
			if ($balance > $amount) {
				$amount = number_format($amount, 4, '.', '');
				$output = array();
				$return_var = -1;
				$transaction = exec('cd /var/www/html/public/ripple;  node ripple_sendcoins.js ' . $address . ' ' . $amount . ' ' . $adminaddress . ' ' . $pass . ' ' . $tag, $output, $return_var);
				if (isset($output[1])) {
					$result = explode('NaN', $output[1]);
					$rem = json_decode($result[1]);
					if ($rem->resultCode == "tesSUCCESS") {
						$trans = explode('NaN', $output[0]);
						$res = json_decode($trans[1]);
						$txId = $res->txid;
						$withResult = array("msg" => "success", "result" => $txId);
					} else {
						$withResult = array('msg' => 'fail', 'result' => 'Failed to transfer XRP!');
					}
				} else {
					$withResult = array('msg' => 'fail', 'result' => "Failed to transfer XRP");
				}
			} else {
				$withResult = array("msg" => "bal", "result" => "Insufficient Balance!");
			}
		} else {
			$withResult = array('msg' => 'fail', 'result' => "Invalid currency!");
		}
		return $withResult;
	}

	//To check transaction id already exists
	public static function checktxnid($btctxid, $userid) {
		$balance = Deposit::where('reference_no', $btctxid)->where('user_id', $userid)->count();
		return ($balance == 0) ? 'true' : 'false';
	}

	//To check transaction id already exists
	public static function checkpendingtxnid($btctxid, $userid) {
		$balance = PendingDeposit::where('reference_no', $btctxid)->where('user_id', $userid)->count();
		return ($balance == 0) ? 'true' : 'false';
	}

	//To check transaction id already exists
	public static function checktrxid($btctxid, $userid) {
		$balance = TronModel::where('reference_no', $btctxid)->where('user_id', $userid)->count();
		return ($balance == 0) ? 'true' : 'false';
	}

	//To check wallet transaction id already exists
	public static function adminWalTx($txnid) {
		$checktxn = WltDeposit::where('txnid', $txnid)->count();
		return ($checktxn == 0) ? 'true' : 'false';
	}

	public function checkAdminaddress($currency, $address) {
		$address = SiteWallet::where('type', encrypText($currency))->where('address', $address)->select('address')->count();
		return ($address == 1) ? 'true' : 'false';
	}

	//To get user id from the address
	public function getUserByAddr($currency, $address) {
		$address = CoinAddress::where(['currency' => $currency, 'address' => $address])->select('user_id')->first();
		return ($address) ? $address->user_id : "";
	}

	//To get user id from the secret
	public function getUserByTag($currency, $address) {
		$address = CoinAddress::where(['currency' => $currency, 'secret' => $address])->select('user_id')->first();
		return ($address) ? $address->user_id : "";
	}

	//To get user balance for the selected currency
	public function fetchbalance($userid, $currency) {
		$userBalance = Wallet::where('user_id', $userid)->select($currency)->first();
		return $userBalance->$currency;
	}

	//To update balance for BTC related coins
	public function updateBtcBalance($currency) {
		if ($currency == "BTC" || $currency == "LTC" || $currency == "BCH" || $currency == "DASH") {
			$upRec = 0;
			$encrypt = encrypText($currency);
			$ip = Controller::getIpAddress();
			$currencyDetails = Currency::where('currency_symbol', $currency)->select('confirmations', 'wallet_limit')->first();
			$confirmations = $currencyDetails->confirmations;
			$walletLimit = $currencyDetails->wallet_limit;
			$coin = SiteWallet::where('type', $encrypt)->select('external_address')->first();
			$getFile = file_get_contents(app_path('Model/BfuiSGvKthvPYsVa/' . $encrypt . '.php'));
			$data = explode(" || ", $getFile);
			$connParams = array(
				'user' => decrypText($data[0]),
				'password' => decrypText($data[1]),
				'ip' => decrypText($data[2]),
				'port' => decrypText($data[3]),
			);
			$transactions = connectJsonRpc($connParams, 'listtransactions', array());
			if ($transactions) {
				$transactions = $transactions['result'];
				 
				for ($i = 0; $i < count($transactions); $i++) {
					$category = $transactions[$i]['category'];
					$btctxid = $transactions[$i]['txid'];
					$btcaddress = $transactions[$i]['address'];
					$bitcoin_balance = $transactions[$i]['amount'];
					$btcconfirmations = $transactions[$i]['confirmations'];
					$datetime = date('Y-m-d H:i', $transactions[$i]['timereceived']);
					if ($category == "receive") {
						$userId = self::getUserByAddr($currency, trim($btcaddress));
						if ($userId != "") {
							if ($btcconfirmations >= $confirmations) {
								$txnExists = self::checktxnid($btctxid, $userId);
								if ($txnExists == 'true') {
									$upRec = 1;
									$balance = self::fetchbalance($userId, $currency);
									$updateBal = $balance + $bitcoin_balance;

									$lastPrice = get_tradePrice($currency);
									$equiv_inr = $bitcoin_balance * $lastPrice;
									$equiv_inr = number_format($equiv_inr, 2, '.', '');

									$userInfo = User::where('id', $userId)->select('InrDeposit')->first();
									$InrDeposit = $userInfo->InrDeposit;
									$inrDep = $InrDeposit + $equiv_inr;

									$depositData = array('amount' => $bitcoin_balance, 'equiv_inr' => $equiv_inr, 'address_info' => $btcaddress, 'currency' => $currency, 'payment_method' => $currency . " Payment", 'reference_no' => $btctxid, 'status' => 'completed', 'user_id' => $userId, 'currency_type' => 'crypto', 'ip_addr' => $ip, 'block_confirm' => $btcconfirmations);
									$transData = array('user_id' => $userId, 'payment_method' => $currency . " Payment", 'transaction_id' => $btctxid, 'currency_name' => $currency, 'type' => "Deposit", 'method' => $currency . " Payment", 'total' => $bitcoin_balance, 'amount' => $bitcoin_balance, 't_status' => "completed");
									$msg1 = 'You have deposited ' . $bitcoin_balance . ' ' . $currency;
									$insdata = array('user_id' => $userId, 'type' => 'Deposit', 'message' => $msg1, 'status' => 'unread');
									$remarks = 'Deposit completed for ' . $bitcoin_balance . ' ' . $currency . ' Old balance: ' . $balance;
									DB::transaction(function () use ($depositData, $userId, $updateBal, $currency, $transData, $insdata, $inrDep, $remarks) {
										Deposit::create($depositData);
										UserNotification::create($insdata);
										Wallet::where('user_id', $userId)->update([$currency => $updateBal, 'remarks' => $remarks]);
										User::where('id', $userId)->update(['InrDeposit' => $inrDep]);
										Transaction::create($transData);
										echo "Updated";
									});

									$pendingCount = PendingDeposit::where('user_id', $userId)->where('reference_no', $btctxid)->where('status', 'pending')->count();
									if ($pendingCount) {
										PendingDeposit::where('user_id', $userId)->where('reference_no', $btctxid)->where('status', 'pending')->update(['block_confirm' => $btcconfirmations, 'status' => 'completed']);
									}

									$getUser = User::where('id', $userId)->select('consumer_name', 'user_mail_id', 'unusual_user_key')->first();
									$usermail = decrypText($getUser->user_mail_id) . '@' . decrypText($getUser->unusual_user_key);
									$reason = 'verified';

									$message = 'A deposit of ' . $bitcoin_balance . ' ' . $currency . ' to your ' . SITENAME . ' account has been completed! Start Happy trading!';
									$bitcoin_balance = number_format($bitcoin_balance, 8, '.', '');
									$getEmail = EmailTemplate::where('id', 7)->first();
									$getSiteDetails = Controller::getEmailTemplateDetails();
									$info = array('###USER###' => $getUser->consumer_name, '###REF###' => $btctxid, '###AMT###' => $bitcoin_balance . ' ' . $currency, '###TOTAL###' => $bitcoin_balance . ' ' . $currency, '###ACTUAL###' => $bitcoin_balance . ' ' . $currency, '###REASON###' => $reason, '###MESSAGE###' => $message);
									$replace = array_merge($getSiteDetails, $info);
									$emaildata = array('content' => strtr($getEmail->template, $replace));
									$toDetails['useremail'] = $usermail;
									$toDetails['subject'] = $getEmail->subject;
									$toDetails['from'] = $getSiteDetails['contact_mail_id'];
									$toDetails['name'] = $getSiteDetails['site_name'];
									$sendEmail = Controller::sendEmail($emaildata, $toDetails);

									$dep_limit = DepositSettings::where('currency', $currency)->where('currency_type', 'Crypto')->select('dep_limit')->first()->dep_limit;
									if ($bitcoin_balance >= $dep_limit) {
										$info1 = array('###USER###' => 'Admin', '###REF###' => $btctxid, '###AMT###' => $bitcoin_balance . ' ' . $currency, '###TOTAL###' => $bitcoin_balance . ' ' . $currency, '###ACTUAL###' => $bitcoin_balance . ' ' . $currency, '###REASON###' => $reason, '###MESSAGE###' => $message);
										$replace1 = array_merge($getSiteDetails, $info1);
										$emaildata1 = array('content' => strtr($getEmail->template, $replace1));
										$toDetails1['useremail'] = $getSiteDetails['contact_mail_id'];
										$toDetails1['subject'] = $getEmail->subject;
										$toDetails1['from'] = $getSiteDetails['contact_mail_id'];
										$toDetails1['name'] = $getSiteDetails['site_name'];
										$sendEmail = Controller::sendEmail($emaildata1, $toDetails1);
									}
								}
							} else {
								$txnExists = self::checkpendingtxnid($btctxid, $userId);
								if ($txnExists == 'true') {
									$depositData = array('amount' => $bitcoin_balance, 'address_info' => $btcaddress, 'currency' => $currency, 'payment_method' => $currency . " Payment", 'reference_no' => $btctxid, 'status' => 'pending', 'user_id' => $userId, 'currency_type' => 'crypto', 'ip_addr' => $ip, 'block_confirm' => $btcconfirmations);
									DB::transaction(function () use ($depositData) {
										PendingDeposit::create($depositData);
										echo "Pending Updated";
									});
								} else {
									$pendingCount = PendingDeposit::where('user_id', $userId)->where('reference_no', $btctxid)->where('status', 'pending')->count();
									if ($pendingCount) {
										PendingDeposit::where('user_id', $userId)->where('reference_no', $btctxid)->where('status', 'pending')->update(['block_confirm' => $btcconfirmations]);
										echo "Block Updated";
									}
								}
							}
						} else {
							$adminaddress = self::checkAdminaddress($currency, $btcaddress);
							if ($adminaddress == 'true') {
								$txnExists1 = self::adminWalTx($txid);
								if ($txnExists1 == 'true') {
									$wltData = ['amount' => $bitcoin_balance, 'type' => 'Deposit', 'currency' => $currency, 'address' => $btcaddress, 'txnid' => $btctxid, 'status' => 'completed'];
									WltDeposit::create($wltData);
								}
							}
						}
					}
				}
			}

			/*if ($currency != 'BTC' && $upRec == 1) {
				self::moveExternal($currency);
			}*/
		}
	}

	public function updateEthBalance($currency = 'ETH') {
		$currency = 'ETH';
		$ip = Controller::getIpAddress();
		$encrypt = encrypText($currency);
		$coin = SiteWallet::where('type', $encrypt)->select('block')->first();
		 
		$maxBlock = $coin->block;
		echo "maxblock:".$maxBlock."<br>";
		// $adminAddr = decrypText(Config::get('cookie.ETH.address'));
		$adminAddr = "";
		$getBlocks = ConnectEth::ethFunctions("getBlockTransactions", array('block' => $maxBlock));
		$lastBlock = $getBlocks['block'];
		echo "lastBlock==>" . $lastBlock;
		if ($lastBlock > 0) {
			SiteWallet::where('type', $encrypt)->update(['block' => $lastBlock]);
		}
		if ($getBlocks['type'] == "success") {
			echo "string<br>";
			$transactions = $getBlocks['result'];
			$admins = $blocks = array();
			$toAddr = "";
			foreach ($transactions as $transaction) {
				if ($transaction) {
					foreach ($transaction as $trans) {
						$value = $trans['value'];
						$to = $trans['to'];
						if ($to != "") {
							if ($to == $adminAddr) {
								$admins[] = $trans;
							} else {
								$blocks[strtolower($to)][] = $trans;
								$search = $to;
								$toAddr .= "(address LIKE '%$search%') OR ";
							}
						}
					}

				}
			}
			$condition = rtrim($toAddr, ' OR ');
			$query = "SELECT user_id, address FROM " . PREFIX . COINADDRESS . " WHERE currency = 'ETH' AND ($condition)";
			$getAddress = DB::select($query);
			if (!empty($getAddress)) {
				foreach ($getAddress as $users) {
					$userId = $users->user_id;
					$account = strtolower(trim($users->address));
					$transactions = $blocks[$account];
					echo "<pre>";
					print_r($transactions);exit;
					foreach ($transactions as $transaction) {
						$txid = $transaction['hash'];
						$from = strtolower($transaction['from']);
						if ($from != $adminAddr) {
							$blockNumber = hexdec($transaction['blockNumber']);
							$address = $transaction['to'];
							$getTrans = Controller::getContents("https://api.etherscan.io/api?module=proxy&action=eth_getTransactionReceipt&txhash=" . $txid . "&apikey=VJK8NUCX9TM4UABZDXWXY2TP89JAU6P7PT");
							$receipt = json_decode($getTrans, true);
							if (isset($receipt['result']) && !empty($receipt['result'])) {
								$receiptResult = $receipt['result'];
								$status = hexdec($receiptResult['status']);
								if ($status == 1) {
									$txnExists = self::checktxnid($txid, $userId);
									if ($txnExists == 'true') {
										$currency = $currency_name = 'ETH';
										$value = hexdec($transaction['value']);
										$ethBalance = $value / 1000000000000000000;
										echo "ethBalance=>" . $ethBalance . "<br>";

										$balance = self::fetchbalance($userId, $currency);
										$updateBal = $balance + $ethBalance;

										$lastPrice = get_tradePrice($currency);
										$equiv_inr = $ethBalance * $lastPrice;
										$equiv_inr = number_format($equiv_inr, 2, '.', '');

										$userInfo = User::where('id', $userId)->select('InrDeposit')->first();
										$InrDeposit = $userInfo->InrDeposit;
										$inrDep = $InrDeposit + $equiv_inr;

										$depositData = array('amount' => $ethBalance, 'equiv_inr' => $equiv_inr, 'address_info' => $address, 'currency' => $currency, 'payment_method' => $currency . " Payment", 'reference_no' => $txid, 'status' => 'completed', 'user_id' => $userId, 'currency_type' => 'crypto', 'block_confirm' => $blockNumber, 'ip_addr' => $ip); 
										$transData = array('user_id' => $userId, 'payment_method' => $currency . " Payment", 'transaction_id' => $txid, 'currency_name' => $currency, 'type' => "Deposit", 'method' => $currency . " Payment", 'total' => $ethBalance, 'amount' => $ethBalance, 't_status' => "completed");

										$adminData = array('user_id' => $userId, 'currency' => $currency, 'status' => 0);
										$msg1 = 'You have deposited ' . $ethBalance . ' ' . $currency;
										$insdata = array('user_id' => $userId, 'type' => 'Deposit', 'message' => $msg1, 'status' => 'unread');
										$remarks = 'Deposit completed for ' . $ethBalance . ' ' . $currency . ' Old balance: ' . $balance;
										DB::transaction(function () use ($depositData, $userId, $updateBal, $currency, $transData, $adminData, $insdata, $inrDep, $remarks) {
											Deposit::create($depositData);
											UserNotification::create($insdata);
											Wallet::where('user_id', $userId)->update([$currency => $updateBal, 'remarks' => $remarks]);
											User::where('id', $userId)->update(['InrDeposit' => $inrDep]);
											Transaction::create($transData);
											AdminTransfer::create($adminData);
											echo "Updated";
										});
										$ethBalance = number_format($ethBalance, 8, '.', '');
										$getUser = User::where('id', $userId)->select('consumer_name', 'user_mail_id', 'unusual_user_key')->first();
										$usermail = decrypText($getUser->user_mail_id) . '@' . decrypText($getUser->unusual_user_key);
										$reason = 'verified';
										$getEmail = EmailTemplate::where('id', 7)->first();
										$getSiteDetails = Controller::getEmailTemplateDetails();

										$message = 'A deposit of ' . $ethBalance . ' ' . $currency . ' to your ' . SITENAME . ' account has been completed! Start Happy trading!';

										$info = array('###USER###' => $getUser->consumer_name, '###REF###' => $txid, '###AMT###' => $ethBalance . ' ' . $currency, '###TOTAL###' => $ethBalance . ' ' . $currency, '###ACTUAL###' => $ethBalance . ' ' . $currency, '###REASON###' => $reason, '###MESSAGE###' => $message);
										$replace = array_merge($getSiteDetails, $info);

										$emaildata = array('content' => strtr($getEmail->template, $replace));
										$toDetails['useremail'] = $usermail;
										$toDetails['subject'] = $getEmail->subject;
										$toDetails['from'] = $getSiteDetails['contact_mail_id'];
										$toDetails['name'] = $getSiteDetails['site_name'];
										$sendEmail = Controller::sendEmail($emaildata, $toDetails);

										$dep_limit = DepositSettings::where('currency', $currency)->where('currency_type', 'Crypto')->select('dep_limit')->first()->dep_limit;
										if ($ethBalance >= $dep_limit) {
											$info1 = array('###USER###' => 'Admin', '###REF###' => $txid, '###AMT###' => $ethBalance . ' ' . $currency, '###TOTAL###' => $ethBalance . ' ' . $currency, '###ACTUAL###' => $ethBalance . ' ' . $currency, '###REASON###' => $reason, '###MESSAGE###' => $message);
											$replace1 = array_merge($getSiteDetails, $info1);
											$emaildata1 = array('content' => strtr($getEmail->template, $replace1));
											$toDetails1['useremail'] = $getSiteDetails['contact_mail_id'];
											$toDetails1['subject'] = $getEmail->subject;
											$toDetails1['from'] = $getSiteDetails['contact_mail_id'];
											$toDetails1['name'] = $getSiteDetails['site_name'];
											$sendEmail = Controller::sendEmail($emaildata1, $toDetails1);
										}
									}
								}
							}
						}
					}
				}
			} else {
				echo "No user deposit<br>";
			}
			if (!empty($admins)) {
				foreach ($admins as $trans) {
					$value = hexdec($trans['value']);
					$ethBal = $value / 1000000000000000000;
					$txid = $trans['hash'];
					$txnWal = self::adminWalTx($txid);
					if ($txnWal == 'true') {
						$wltData = ['amount' => (float) $ethBal, 'type' => 'Deposit', 'currency' => $currency, 'address' => $adminAddr, 'txnid' => $txid, 'status' => 'completed'];
						WltDeposit::create($wltData);
						echo "Admin Deposit Updated";
					}
				}
			} else {
				echo "No admin deposit<br>";
			}
		} else {
			echo "no string<br>";
		}
	}

	public function manualETH($address) {
		$ip = Controller::getIpAddress();
		$address = strtolower($address);
		$currency = $currency_name = 'ETH';
		$coinAddress = CoinAddress::where('address', $address)->where('currency', $currency)->select('user_id')->first();
		if (!$coinAddress) {
			return false;
		}
		$userId = $coinAddress->user_id;
		if ($userId) {
			$getTrans = getUrlContents("http://api.etherscan.io/api?module=account&action=txlistinternal&address=" . $address . "&sort=desc&apikey=VJK8NUCX9TM4UABZDXWXY2TP89JAU6P7PT");
			$receipt = json_decode($getTrans, true);
			if (isset($receipt['result']) && !empty($receipt['result'])) {
				$results = $receipt['result'];
				foreach ($results as $key => $value) {
					$txid = $value['hash'];
					if ($value['isError'] == 0) {
						$txnExists = self::checktxnid($txid, $userId);
						if ($txnExists == 'true') {
							$blockNumber = $value['blockNumber'];
							$ethBal = $value['value'];
							$ethBalance = $ethBal / 1000000000000000000;
							echo "ethBalance=>" . $ethBalance . "<br>";

							$balance = self::fetchbalance($userId, $currency);
							$updateBal = $balance + $ethBalance;

							$lastPrice = get_tradePrice($currency);
							$equiv_inr = $ethBalance * $lastPrice;
							$equiv_inr = number_format($equiv_inr, 2, '.', '');

							$userInfo = User::where('id', $userId)->select('InrDeposit')->first();
							$InrDeposit = $userInfo->InrDeposit;
							$inrDep = $InrDeposit + $equiv_inr;

							$depositData = array('amount' => $ethBalance, 'equiv_inr' => $equiv_inr, 'address_info' => $address, 'currency' => $currency, 'payment_method' => $currency . " Payment", 'reference_no' => $txid, 'status' => 'completed', 'user_id' => $userId, 'currency_type' => 'crypto', 'block_confirm' => $blockNumber, 'ip_addr' => $ip); 
							$transData = array('user_id' => $userId, 'payment_method' => $currency . " Payment", 'transaction_id' => $txid, 'currency_name' => $currency, 'type' => "Deposit", 'method' => $currency . " Payment", 'total' => $ethBalance, 'amount' => $ethBalance, 't_status' => "completed");

							$adminData = array('user_id' => $userId, 'currency' => $currency, 'status' => 0);
							$msg1 = 'You have deposited ' . $ethBalance . ' ' . $currency;
							$insdata = array('user_id' => $userId, 'type' => 'Deposit', 'message' => $msg1, 'status' => 'unread');
							$remarks = 'Deposit completed for ' . $ethBalance . ' ' . $currency . ' Old balance: ' . $balance;

							DB::transaction(function () use ($depositData, $userId, $updateBal, $currency, $transData, $adminData, $insdata, $inrDep, $remarks) {
								Deposit::create($depositData);
								UserNotification::create($insdata);
								Wallet::where('user_id', $userId)->update([$currency => $updateBal, 'remarks' => $remarks]);
								User::where('id', $userId)->update(['InrDeposit' => $inrDep]);
								Transaction::create($transData);
								AdminTransfer::create($adminData);
								echo "Updated";
							});
							$ethBalance = number_format($ethBalance, 8, '.', '');
							$getUser = User::where('id', $userId)->select('consumer_name', 'user_mail_id', 'unusual_user_key')->first();
							$usermail = decrypText($getUser->user_mail_id) . '@' . decrypText($getUser->unusual_user_key);
							$reason = 'verified';
							$getEmail = EmailTemplate::where('id', 7)->first();
							$getSiteDetails = Controller::getEmailTemplateDetails();

							$message = 'A deposit of ' . $ethBalance . ' ' . $currency . ' to your ' . SITENAME . ' account has been completed! Start Happy trading!';

							$info = array('###USER###' => $getUser->consumer_name, '###REF###' => $txid, '###AMT###' => $ethBalance . ' ' . $currency, '###TOTAL###' => $ethBalance . ' ' . $currency, '###ACTUAL###' => $ethBalance . ' ' . $currency, '###REASON###' => $reason, '###MESSAGE###' => $message);
							$replace = array_merge($getSiteDetails, $info);

							$emaildata = array('content' => strtr($getEmail->template, $replace));
							$toDetails['useremail'] = $usermail;
							$toDetails['subject'] = $getEmail->subject;
							$toDetails['from'] = $getSiteDetails['contact_mail_id'];
							$toDetails['name'] = $getSiteDetails['site_name'];
							$sendEmail = Controller::sendEmail($emaildata, $toDetails);

							$dep_limit = DepositSettings::where('currency', $currency)->where('currency_type', 'Crypto')->select('dep_limit')->first()->dep_limit;
							if ($ethBalance >= $dep_limit) {
								$info1 = array('###USER###' => 'Admin', '###REF###' => $txid, '###AMT###' => $ethBalance . ' ' . $currency, '###TOTAL###' => $ethBalance . ' ' . $currency, '###ACTUAL###' => $ethBalance . ' ' . $currency, '###REASON###' => $reason, '###MESSAGE###' => $message);
								$replace1 = array_merge($getSiteDetails, $info1);
								$emaildata1 = array('content' => strtr($getEmail->template, $replace1));
								$toDetails1['useremail'] = $getSiteDetails['contact_mail_id'];
								$toDetails1['subject'] = $getEmail->subject;
								$toDetails1['from'] = $getSiteDetails['contact_mail_id'];
								$toDetails1['name'] = $getSiteDetails['site_name'];
								$sendEmail = Controller::sendEmail($emaildata1, $toDetails1);
							}
						}
					}
				}
			}
		}
	}

	public function tokenDeposit($currency) {
		$ip = Controller::getIpAddress();
		$tokens = ['USDT'];
		if (in_array($currency, $tokens)) {
			$encrypt = encrypText($currency);
			$coin = SiteWallet::where('type', $encrypt)->select('block', 'username', 'password', 'decimal_point')->first();
			if ($coin) {
				$adminAddr = strtolower(decrypText($coin->username));
				$contractAddr = decrypText($coin->password);
				$decimalPoint = $coin->decimal_point;
				$getDecimals = $decimalPoint + 1;
				$decimals = str_pad(1, $getDecimals, '0', STR_PAD_RIGHT);
				$maxBlock = $coin->block;
				$output = getUrlContents('https://api.etherscan.io/api?module=account&action=tokentx&sort=asc&contractaddress=' . $contractAddr . '&startblock=' . $maxBlock . '&endblock=latest&apikey=VJK8NUCX9TM4UABZDXWXY2TP89JAU6P7PT');
				$result = json_decode($output, true);
				if ($result['message'] == 'OK' && $result['status'] == 1) {
					$transactions = $result['result'];
					echo "<pre>";
					print_r($transactions);exit;
					foreach ($transactions as $transaction) {
						$blockNum = $transaction['blockNumber'];
						$confirmations = $transaction['confirmations'];
						if ($confirmations >= 5) {
							$from = trim($transaction['from']);
							$from = strtolower($from);
							if ($from != $adminAddr) {
								$addr = trim($transaction['to']);
								$addr = strtolower($addr);
								$value = $transaction['value'];
								$txid = $transaction['hash'];
								$tokenBal = $value / $decimals;
								$tokenBal = number_format($tokenBal, 8, '.', '');
								if ($addr == $adminAddr) {
									$txnWal = self::adminWalTx($txid);
									if ($txnWal == 'true') {
										$wltData = ['amount' => (float) $tokenBal, 'type' => 'Deposit', 'currency' => $currency, 'address' => $addr, 'txnid' => $txid, 'status' => 'completed'];
										WltDeposit::create($wltData);
									}
								} else {
									$userId = self::getUserByAddr('ETH', $addr);
									if ($userId != "") {
										$txnExists = self::checktxnid($txid, $userId);
										if ($txnExists == 'true') {
											$balance = self::fetchbalance($userId, $currency);
											$updateBal = (float) $balance + (float) $tokenBal;

											$lastPrice = get_tradePrice($currency);
											$equiv_inr = $tokenBal * $lastPrice;
											$equiv_inr = number_format($equiv_inr, 2, '.', '');

											$userInfo = User::where('id', $userId)->select('InrDeposit')->first();
											$InrDeposit = $userInfo->InrDeposit;
											$inrDep = $InrDeposit + $equiv_inr;

											$depositData = array('amount' => $tokenBal, 'equiv_inr' => $equiv_inr, 'address_info' => $addr, 'currency' => $currency, 'payment_method' => $currency . " Payment", 'reference_no' => $txid, 'status' => 'completed', 'user_id' => $userId, 'currency_type' => 'crypto', 'block_confirm' => $blockNum, 'ip_addr' => $ip); 
											$transData = array('user_id' => $userId, 'payment_method' => $currency . " Payment", 'transaction_id' => $txid, 'currency_name' => $currency, 'type' => "Deposit", 'method' => $currency . " Payment", 'total' => $tokenBal, 'amount' => $tokenBal, 't_status' => "completed");
											$adminData = array('user_id' => $userId, 'currency' => $currency, 'status' => 0);
											$msg1 = 'You have deposited ' . $tokenBal . ' ' . $currency;
											$insdata = array('user_id' => $userId, 'type' => 'Deposit', 'message' => $msg1, 'status' => 'unread');
											$remarks = 'Deposit completed for ' . $tokenBal . ' ' . $currency . ' Old balance: ' . $balance;
											DB::transaction(function () use ($depositData, $userId, $updateBal, $currency, $transData, $adminData, $insdata, $inrDep, $remarks) {
												Deposit::create($depositData);
												UserNotification::create($insdata);
												Wallet::where('user_id', $userId)->update([$currency => $updateBal, 'remarks' => $remarks]);
												User::where('id', $userId)->update(['InrDeposit' => $inrDep]);
												Transaction::create($transData);
												AdminTransfer::create($adminData);
												echo "Updated";
											});
											$ethBalance = number_format($tokenBal, 8, '.', '');
											$getUser = User::where('id', $userId)->select('consumer_name', 'user_mail_id', 'unusual_user_key')->first();
											$usermail = decrypText($getUser->user_mail_id) . '@' . decrypText($getUser->unusual_user_key);
											$reason = 'verified';
											$getEmail = EmailTemplate::where('id', 7)->first();
											$getSiteDetails = Controller::getEmailTemplateDetails();
											$message = 'A deposit of ' . $ethBalance . ' ' . $currency . ' to your ' . SITENAME . ' account has been completed! Start Happy trading!';
											$info = array('###USER###' => $getUser->consumer_name, '###REF###' => $txid, '###AMT###' => $ethBalance . ' ' . $currency, '###TOTAL###' => $ethBalance . ' ' . $currency, '###ACTUAL###' => $ethBalance . ' ' . $currency, '###REASON###' => $reason, '###MESSAGE###' => $message);
											$replace = array_merge($getSiteDetails, $info);
											$emaildata = array('content' => strtr($getEmail->template, $replace));
											$toDetails['useremail'] = $usermail;
											$toDetails['subject'] = $getEmail->subject;
											$toDetails['from'] = $getSiteDetails['contact_mail_id'];
											$toDetails['name'] = $getSiteDetails['site_name'];
											$sendEmail = Controller::sendEmail($emaildata, $toDetails);

											$dep_limit = DepositSettings::where('currency', $currency)->where('currency_type', 'Crypto')->select('dep_limit')->first()->dep_limit;
											if ($ethBalance >= $dep_limit) {
												$info1 = array('###USER###' => 'Admin', '###REF###' => $txid, '###AMT###' => $ethBalance . ' ' . $currency, '###TOTAL###' => $ethBalance . ' ' . $currency, '###ACTUAL###' => $ethBalance . ' ' . $currency, '###REASON###' => $reason, '###MESSAGE###' => $message);
												$replace1 = array_merge($getSiteDetails, $info1);
												$emaildata1 = array('content' => strtr($getEmail->template, $replace1));
												$toDetails1['useremail'] = $getSiteDetails['contact_mail_id'];
												$toDetails1['subject'] = $getEmail->subject;
												$toDetails1['from'] = $getSiteDetails['contact_mail_id'];
												$toDetails1['name'] = $getSiteDetails['site_name'];
												$sendEmail = Controller::sendEmail($emaildata1, $toDetails1);
											}
										}
									}
								}
							}
						} else {
							break;
						}
					}
					SiteWallet::where('type', $encrypt)->update(['block' => (int) $blockNum]);
				}
			}
		} else {
			echo "Invalid request";exit();
		}
	}

	//To transfer user's ETH balance to Admin
	public function ethAdminTransfer() {
		$currency = "ETH";
		$adminAddr = decrypText(Config::get('cookie.ETH.address'));
		$key = decrypText(Config::get('cookie.ETH_USR.key'));

		$ethDetails = Currency::where('currency_symbol', 'ETH')->select('gasprice', 'gaslimit')->first();
		$gas = self::gasPrice();
		$gas_limit = $ethDetails->gaslimit;
		$decimals = str_pad(1, 10, '0', STR_PAD_RIGHT);
		$gas = bcmul($gas, $decimals);

		$users = AdminTransfer::where(['currency' => 'ETH', 'status' => 0])->orWhere('status', 2)->select('user_id')->groupBy('user_id')->get();

		if (!$users->isEmpty()) {
			$address = CoinAddress::whereIn('user_id', $users)->where('currency', 'ETH')->select('user_id', 'address')->get();
			foreach ($address as $addr) {
				$account = trim($addr->address);
				$userId = $addr->user_id;
				$ethData = array('key' => trim($key), 'gasPrice' => $gas, 'gasLimit' => $gas_limit, 'adminaddress' => trim($adminAddr), 'useraddress' => trim($account));
				$output = ConnectEth::ethFunctions('moveFundsToAdmin', $ethData);
				if ($output['type'] == "success") {
					AdminTransfer::where(['user_id' => $userId, 'currency' => 'ETH'])->update(['status' => 1]);
				} 
			}
		}
	}

	public function tokenTransfer($token = '') {
		$tokens = array();
		if (in_array($token, $tokens)) {
			$number = 1;
			$gas = self::gasPrice();
			$coin = Currency::where('currency_symbol', $token)->first();
			$contractAddr = $coin->contract_address;
			$getDecimals = $coin->decimal_point;
			$getLimit = $coin->gaslimit;
			$gasPrice = $gas;
			$decimals = str_pad($number, $getDecimals, '0', STR_PAD_RIGHT);
			$adminAddr = decrypText(Config::get('cookie.ETH.address'));
			$key = decrypText(Config::get('cookie.ETH_USR.key'));
			$pass_token = trim($key);

			$ethDetails = Currency::where('currency_symbol', 'ETH')->select('gasprice', 'gaslimit')->first();
			$eth_gas = $gas;
			$eth_gas_limit = $ethDetails->gaslimit;
			$decimals1 = str_pad(1, 10, '0', STR_PAD_RIGHT);
			$eth_gas = bcmul($eth_gas, $decimals1);

			$users = AdminTransfer::where('currency', $token)->where('status', '!=', '1')->select('user_id', 'fee_tx', 'id')->groupBy('user_id')->get();

			if (!$users->isEmpty()) {
				foreach ($users as $value) {
					$userId = $value->user_id;
					$transfer_id = $value->id;
					$address = CoinAddress::where('user_id', $userId)->where('currency', 'ETH')->select('address')->first();
					$account = trim($address->address);
					$getBalance = getUrlContents('https://api.etherscan.io/api?module=account&action=tokenbalance&contractaddress=' . $contractAddr . '&address=' . $account . '&tag=latest&apikey=VJK8NUCX9TM4UABZDXWXY2TP89JAU6P7PT');
					$decodebalance = json_decode($getBalance);
					$result = $tokenbalance = $decodebalance->result;
					$balance = $result / $decimals;
					if ((float) $balance > 0) {
						$getEthBalance = getUrlContents('https://api.etherscan.io/api?module=account&action=balance&address=' . $account . '&tag=latest&apikey=VJK8NUCX9TM4UABZDXWXY2TP89JAU6P7PT');
						$decodeBalance = json_decode($getEthBalance);
						$resulteth = $decodeBalance->result;
						$ethbalance = $resulteth / 1000000000000000000;
						echo "<br>ethbalance=>" . $ethbalance;
						if ($value->fee_tx == '' && (0 == $ethbalance || $ethbalance < 0.005)) {
							echo $ethbalance . ' low';
							$amount = 0.005;
							$key = decrypText(Config::get('cookie.ETH.key'));
							$ethData = array('key' => $key, 'gasPrice' => $eth_gas, 'gasLimit' => $eth_gas_limit, 'amount' => $amount, 'from' => $adminAddr, 'to' => $account);
							$transferEth = ConnectEth::ethFunctions('sendEthereum', $ethData); 
							if ($transferEth['type'] == "success") {
								AdminTransfer::where('currency', $token)->where(['id' => $transfer_id])->update(['status' => 2, 'fee_tx' => $transferEth['result']]);
							}
						} else {
							echo "string<br>";
							$toaddress = $adminAddr;
							$gas = $gasPrice;
							$gas_limit = $getLimit;
							$decimals = str_pad($number, 10, '0', STR_PAD_RIGHT);
							$gas = bcmul($gas, $decimals);
							$transAmount = $tokenbalance;
							$amount = '';
							do {
								$last = bcmod($transAmount, 16);
								$amount = dechex($last) . $amount;
								$transAmount = bcdiv(bcsub($transAmount, $last), 16);
							} while ($transAmount > 0);

							if ($amount) {
								$arr = array('token' => $token, 'account' => $account, 'toaddress' => $toaddress, 'amount' => $amount, 'key' => $pass_token, 'gasPrice' => $gas, 'gasLimit' => $gas_limit, 'contract' => $contractAddr);
								$transferEth = ConnectEth::ethFunctions('sendToken', $arr); 
								if ($transferEth['type'] == "success") {
									AdminTransfer::where('currency', $token)->where('id', $transfer_id)->update(['status' => 1]);
								}
							}
						}
					} else {
						AdminTransfer::where('currency', $token)->where('user_id', $userId)->update(['status' => 1]);
					}
				}
			}
		}
	}

	//To update XRP balance
	public function checkDepositsXRP() {
		$currency = 'XRP';
		$upRec = 0;
		$xrpAddr = decrypText(Config::get('cookie.XRP.address'));
		$url = "https://data.ripple.com/v2/accounts/" . $xrpAddr . "/payments?currency=XRP&type=received&limit=1000";

		$result = Controller::getContents($url);
		$res = json_decode($result, true);
		if ($res['result'] == 'success' && $res['count'] > 0) {
			$transactions = $res['payments'];
			if ($transactions) {
				foreach ($transactions as $transaction) {
					$amount = $transaction['delivered_amount'];
					$address = $transaction['destination'];
					if (isset($transaction['destination_tag']) && $transaction['destination_tag'] != "") {
						$desTag = $transaction['destination_tag'];
						if ($xrpAddr == $address) {
							$getDetail = CoinAddress::where(['secret' => $desTag, 'currency' => $currency])->select('user_id')->first();
							if ($getDetail) {
								$userId = $getDetail->user_id;
								$txid = $transaction['tx_hash'];
								$exeTime = $transaction['executed_time'];
								$txnExists = self::checktxnid($txid, $userId);
								if ($txnExists == 'true') {
									$upRec = 1;
									$balance = Wallet::where('user_id', $userId)->select($currency)->first()->$currency;
									$updateBal = $balance + $amount;

									$lastPrice = get_tradePrice($currency);
									$equiv_inr = $amount * $lastPrice;
									$equiv_inr = number_format($equiv_inr, 2, '.', '');

									$userInfo = User::where('id', $userId)->select('InrDeposit')->first();
									$InrDeposit = $userInfo->InrDeposit;
									$inrDep = $InrDeposit + $equiv_inr;

									$remarks = 'Deposit ' . $currency . ' ' . $amount;
									$depositData = array('amount' => $amount, 'equiv_inr' => $equiv_inr, 'address_info' => $address, 'currency' => $currency, 'payment_method' => $currency . " Payment", 'reference_no' => $txid, 'status' => 'completed', 'user_id' => $userId, 'currency_type' => 'crypto', 'block_confirm' => $exeTime);

									$message = 'You have deposited ' . $amount . ' ' . $currency;
									$notify = array('user_id' => $userId, 'type' => 'Deposit', 'message' => $message, 'status' => 'unread');
									$remarks = 'Deposit completed for ' . $amount . ' ' . $currency . ' Old balance: ' . $balance;
									$result = DB::transaction(function () use ($depositData, $userId, $updateBal, $currency, $notify, $inrDep, $remarks) {
										UserNotification::create($notify);
										Deposit::create($depositData);
										Wallet::where('user_id', $userId)->update([$currency => $updateBal, 'remarks' => $remarks]);
										User::where('id', $userId)->update(['InrDeposit' => $inrDep]);
									});
									if ($result) {
										$amount = number_format($amount, 8, '.', '');
										$getUser = User::where('id', $userId)->select('consumer_name', 'user_mail_id', 'unusual_user_key')->first();
										$usermail = decrypText($getUser->user_mail_id) . '@' . decrypText($getUser->unusual_user_key);
										$reason = 'verified';
										$getEmail = EmailTemplate::where('id', 7)->first();
										$getSiteDetails = Controller::getEmailTemplateDetails();

										$message = 'A deposit of ' . $amount . ' ' . $currency . ' to your ' . SITENAME . ' account has been completed! Start Happy trading!';

										$info = array('###USER###' => $getUser->consumer_name, '###REF###' => $txid, '###AMT###' => $amount . ' ' . $currency, '###TOTAL###' => $amount . ' ' . $currency, '###ACTUAL###' => $amount . ' ' . $currency, '###REASON###' => $reason, '###MESSAGE###' => $message);

										$replace = array_merge($getSiteDetails, $info);

										$emaildata = array('content' => strtr($getEmail->template, $replace));
										$toDetails['useremail'] = $usermail;
										$toDetails['subject'] = $getEmail->subject;
										$toDetails['from'] = $getSiteDetails['contact_mail_id'];
										$toDetails['name'] = $getSiteDetails['site_name'];

										$sendEmail = Controller::sendEmail($emaildata, $toDetails);

										$dep_limit = DepositSettings::where('currency', $currency)->where('currency_type', 'Crypto')->select('dep_limit')->first()->dep_limit;
										if ($amount >= $dep_limit) {
											$info1 = array('###USER###' => 'Admin', '###REF###' => $txid, '###AMT###' => $amount . ' ' . $currency, '###TOTAL###' => $amount . ' ' . $currency, '###ACTUAL###' => $amount . ' ' . $currency, '###REASON###' => $reason, '###MESSAGE###' => $message);
											$replace1 = array_merge($getSiteDetails, $info1);
											$emaildata1 = array('content' => strtr($getEmail->template, $replace1));
											$toDetails1['useremail'] = $getSiteDetails['contact_mail_id'];
											$toDetails1['subject'] = $getEmail->subject;
											$toDetails1['from'] = $getSiteDetails['contact_mail_id'];
											$toDetails1['name'] = $getSiteDetails['site_name'];
											$sendEmail = Controller::sendEmail($emaildata1, $toDetails1);
										}
										echo "Updated";
									}
								}
							}
						}
					}
				}
			}
		}

		/*if ($upRec == 1) {
			self::moveExternal($currency);
		}*/
	}
 

	public static function moveExternal($currency) {
		$ip = Controller::getIpAddress();
		$encrypt = encrypText($currency);
		$getBalance = self::getBalance($currency);
		if ($getBalance > 0) {
			$coin = SiteWallet::where('type', $encrypt)->select('external_address', 'tag')->first();
			$currencyDetails = Currency::where('currency_symbol', $currency)->select('wallet_limit', 'move_limit')->first();
			$walletLimit = $currencyDetails->wallet_limit;
			$moveLimit = $currencyDetails->move_limit;
			if ($getBalance > $walletLimit) {
				$remainBal = $getBalance - $walletLimit;
				$amount = number_format($remainBal, 8, '.', '');
				if ($remainBal > $moveLimit) {
					$externalAddress = $coin->external_address;
					$tag = ($coin->tag != '') ? $coin->tag : '';
					if ($externalAddress != '') {
						$insdata1 = array('amount' => $remainBal, 'token_id' => 'nseuxbrbiaix', 'currency' => $currency, 'payment_method' => $currency . ' payment', 'ip_address' => $ip, 'to_address' => $externalAddress, 'tag' => $tag);
						$sendAmt = self::sendCryptoAmount($currency, $externalAddress, $amount, $tag, ''); 
						if ($sendAmt) {
							$status = $sendAmt['msg'];
							if ($status == 'success') {
								$referenceNumber = $sendAmt['result'];
								$keyCode = User::randomString(8);
								$encryptKey = encrypText($keyCode);
								$insdata = array('amount' => $amount, 'token_id' => $encryptKey, 'currency' => $currency, 'payment_method' => $currency . ' payment', 'status' => 'completed', 'ip_address' => $ip, 'to_address' => $externalAddress, 'type' => 'withdraw', 'reference_no' => $referenceNumber);
								$createWithdraw = ContactUs::create($insdata); 
							}
						}
					}
				} else {
					echo $currency . " Limit not reached";
				}
			} else {
				echo $currency . " Low Balance";
			}
		}
	}

	public static function randomstring($currency) {
		$length = 8;
		$characters = '123456789';
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, strlen($characters) - 1)];
		}
		$res = CoinAddress::where(['secret' => $randomString, 'currency' => $currency])->count();
		$res1 = SiteWallet::where('type', encrypText($currency))->where('block', $randomString)->count();
		if ($res || $res1) {
			return randomstring($currency);
		}

		return $randomString;
	}

	public function checkFee($tx) {
		$tx = trim($tx);
		$users = AdminTransfer::where(['currency' => '', 'fee_tx' => $tx])->first();
		if ($users) {
			return false;
		} else {
			return true;
		}
	}

	public static function gasPrice() {
		$output = Controller::getContents('https://api.etherscan.io/api?module=gastracker&action=gasoracle&apikey=VJK8NUCX9TM4UABZDXWXY2TP89JAU6P7PT');
		$result = json_decode($output);
		$gasprice = $result->result->ProposeGasPrice;
		return $gasprice;
	}
}