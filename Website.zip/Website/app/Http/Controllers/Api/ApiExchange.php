<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;

use App\Model\CoinProfit;
use App\Model\Currency;
use App\Model\News;
use App\Model\EmailTemplate;
use App\Model\ExchangeModel;
use App\Model\ExchangePairs;
use App\Model\TradePairs;
use App\Model\User;
use App\Model\Wallet;
use App\Model\SiteSettings;

use Config;
use DB;
use Redirect;
use Session;
use URL;
use Validator;
use DateTime;


class ApiExchange extends Controller {
	public function __construct() {
	}


	public function exchange() {
		$data = Input::all();
		$userId = $data['user_id'];
		if($userId != '') {
			$exchangepair = ExchangePairs::where('status','1')->select('from_symbol', 'to_symbol', 'trade_fee', 'last_price', 'min_amt', 'max_amt', 'status')->orderBy('eid','asc')->get()->toArray();
			$results = self::arraygroupBy($exchangepair,'to_symbol');
			if($userId) {
				$currency = Currency::where('status', '1')->select('currency_symbol')->orderBy('cid', 'asc')->get();
				$fields = ['id', 'user_id', 'created_at', 'updated_at'];
				$wallet = Wallet::where('user_id',$userId)->first();
				$wallet = collect($wallet)->except($fields)->toArray();
				foreach ($currency as $curr) {
					$sym = $curr->currency_symbol;
					$res['currency'] = $sym;
					$res['balance'] = $wallet[$sym];
					$result[] = $res;
				}
			} else {
				$user = $result =  '';
			}
			$exchangetime = Sitesettings::where('id', 1)->select('exchangetime')->first()->exchangetime;
			$min = self::minutes($exchangetime);
			$minutes = number_format($min);
			$response['status'] = 1;
			$response['wallet'] = $result;
			$response['exchangeminutes'] = $minutes;
			$response['exchangepair'] = $exchangepair;
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);exit;
	}


	function minutes($time){
		$time = explode(':', $time);
		return ($time[0]*60) + ($time[1]) + ($time[2]/60);
	}

	public function arraygroupBy($array, $key) {
		$return = array();
		foreach($array as $val) {
			$return[$val[$key]][$val['from_symbol']] = $val;
		}
		return $return;
	}


	public function makeexchange() {
		$data = Input::all();
		$id = $data['user_id'];
		if($id) {
			$extype = $data['extype'];
			$validate = Validator::make($data, [
				'from_currency' => "required",
				'to_currency' => "required",
				'amount' => "required|numeric",
			], [
				'from_currency.required' => 'Choose From Currency',
				'to_currency.required' => 'Choose To Currency',
				'amount.required' => 'Enter amount',
				'amount.numeric' => 'Enter valid amount',
			]);

			if ($validate->fails()) {
				foreach ($validate->messages()->getMessages() as $val => $msg) {
					$response = array('status' => '0', 'msg' =>  $msg[0]);
					echo json_encode($response);exit;
				}
			}


			$prevoiusOrder = ExchangeModel::where('user_id', $id)->select('created_at')->orderBy('id', 'desc')->first();
			if($prevoiusOrder) {
				$datetime1 = new DateTime();
				$datetime2 = new DateTime($prevoiusOrder->created_at);
				$interval = $datetime1->diff($datetime2);
				$mins = $interval->format('%i');
				if($mins < 1) {
					$response = array('status' => '0', 'msg' => 'Please try again after sometime');
					echo json_encode($response);exit;
				}
			} 

			if($extype == 'buy') {
				$bal_symbol = $from_symbol = $data['from_currency'];
				$to_symbol = $data['to_currency'];
			} else {
				$bal_symbol = $from_symbol = $data['from_currency'];
				$to_symbol = $data['to_currency'];
			}
			$amount = $data['amount'];

			if($amount < 0) {
				$response = array('status' => '0', 'msg' => 'Enter valid amount');
				echo json_encode($response);exit;
			}

			$digit = ($from_symbol == 'INR') ? 2 : 8;
			$digit1 = ($to_symbol == 'INR') ? 2 : 8;
			$site = SiteSettings::where('id',1)->select('exchangetime')->first();
			if($extype == 'buy') {
				$exchangepair = ExchangePairs::where('from_symbol',$from_symbol)->where('to_symbol',$to_symbol)->select('last_price', 'trade_fee', 'min_amt', 'max_amt')->first();
			} else {
				$exchangepair = ExchangePairs::where('from_symbol',$to_symbol)->where('to_symbol',$from_symbol)->select('last_price', 'trade_fee', 'min_amt', 'max_amt')->first();
			}
			if($extype == 'buy') {
				$last_price = $exchangepair->last_price;
				$last_price = number_format($last_price, $digit1, '.', '');
			} else {
				$price = $exchangepair->last_price;
				if($price > 0) {
					$last_price = 1 / $price;
				} else {
					$last_price = 0;
				}
				$last_price =  number_format($last_price, $digit1, '.', '');
			}

			if($last_price == 0) {
				$response = array('status' => '0', 'msg' => 'Please try again later');
				echo json_encode($response);exit;
			}

			$trade_fee = $exchangepair->trade_fee;
			$from_symbol_id = $exchangepair->from_symbol_id;
			$min_amt = $exchangepair->min_amt;
			$max_amt = $exchangepair->max_amt;
			$total = $amount * $last_price;


			$fees = $total * $trade_fee / 100;

			$final = $total - $fees;
			$balance = Wallet::where('user_id',$id)->select($bal_symbol)->first()->$bal_symbol;


			if($amount > $balance) {
				$response = array('status' => '0', 'msg' => 'You have insufficient balance');
				echo json_encode($response);exit;
			}

			if($amount < $min_amt) {
				$response = array('status' => '0', 'msg' => 'Enter amount more than minimum value');
				echo json_encode($response);exit;
			}

			if($amount > $max_amt) {
				$response = array('status' => '0', 'msg' => 'Enter amount less than maximum value');
				echo json_encode($response);exit;
			}

			$updateBal = $balance - $amount;
			$remarks = 'Exchange request placed for ' . $amount . ' ' . $bal_symbol . ' Old balance: ' . $balance;
			$update = Wallet::where('user_id',$id)->update([$bal_symbol => $updateBal, 'remarks' => $remarks]);
			if($update) {
				$newdate = date('Y-m-d H:i:s'); 
				$etimestamp = strtotime($newdate. ' + '.date('H',strtotime($site->exchangetime)).' hour '.date('i',strtotime($site->exchangetime)).' minute '.date('s',strtotime($site->exchangetime)).' second'); 
				$etime = date('Y-m-d H:i:s', $etimestamp);
				$create = array(
					'user_id' => $id,
					'from_symbol' => $from_symbol,
					'to_symbol' => $to_symbol,
					'type' => $extype,
					'amount' => $amount,
					'fees' => $fees,
					'fee_per' => $trade_fee,
					'total' => $final,
					'status' => 'pending',
					'ip_address' => $_SERVER['REMOTE_ADDR'],
					'created_at' => date('Y-m-d H:i:s'),
					'expired_at' => $etime,
					'app_site' => 'app',
				);
				$result = ExchangeModel::create($create);
				$lastid = encrypText($result->id);
				$link1 = url('/BVZrcniXhwivGdIA/exchange_confim/'.$lastid);
				$link2 = url('/BVZrcniXhwivGdIA/exchange_cancel/'.$lastid);
				$email = get_user_email($id);

				$amount =number_format($amount, $digit, '.', ',');
				$fees =number_format($fees, $digit1, '.', ',');
				$final =number_format($final, $digit1, '.', ',');

				$info = array('###AMOUNT###' => $amount." ". $from_symbol, '###FEES###' => $fees." ". $to_symbol, '###TOTAL###' => $final." ". $to_symbol, '###LINK1###' => $link1, '###LINK2###' => $link2, '###NAME###' => getUserName($id), '###USER###' => $email);
				$getEmail = EmailTemplate::where('id', 35)->first();
				$getSiteDetails = Controller::getEmailTemplateDetails();
				$replace = array_merge($getSiteDetails, $info);
				$emaildata = array('content' => strtr($getEmail->template, $replace));
				$toDetails['useremail'] = $getSiteDetails['contact_mail_id'];
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails['contact_mail_id'];
				$toDetails['name'] = $getSiteDetails['site_name'];
				$sendEmail = Controller::sendEmail($emaildata, $toDetails, '', '');
				if($sendEmail) {
					$response = array('status' => '1', 'msg' => 'Your order has been submited');
				} else {
					$response = array('status' => '0', 'msg' => 'Please try again later');
				}
				echo json_encode($response);exit;
			} else {
				$response = array('status' => '0', 'msg' => 'Please try again later');
				echo json_encode($response);exit;
			}
		} else {
			$response = array('status' => '0', 'msg' => 'Please login to continue');
			echo json_encode($response);exit;
		}
	}

	public function exchange_history() {
		$datas = Input::all();
		$id = $datas['user_id'];
		if($id) {
			$data = $orders = array();
			$exchange = ExchangeModel::where('user_id', $id);			
			$exchange_count = $exchange->count();			
			$data = array();
			$no = 1;
			if ($exchange_count) {
				$orders = $exchange->select('from_symbol', 'to_symbol', 'amount', 'fees', 'total', 'status', 'created_at','id','type', 'expired_at', 'user_id')->orderBy('id','desc')->get()->toArray();
				foreach ($orders as $r) {
					if($r['status'] == 'confirmed') {
						$status = URL::to('public/frontend/img/tick.png');
					} else if($r['status'] == 'pending') {
						$status = URL::to('public/frontend/img/pending.png');
					} else {
						$status = URL::to('public/frontend/img/cancel.png');
					}

					$digits = ($r['from_symbol'] == 'INR') ? 2 : 8;
					$digits1 = ($r['to_symbol'] == 'INR') ? 2 : 8;

					$amount = number_format($r['amount'], $digits, '.', '');
					$fees = number_format($r['fees'], $digits1, '.', '');
					$total = number_format($r['total'], $digits1, '.', '');

					array_push($data, array(
						'S.no' => $no,
						'DateTime' => $r['created_at'],
						'Type' => ucfirst($r['type']),
						'From_Symbol' => $r['from_symbol'],
						'To_Symbol' => $r['to_symbol'],
						'Amount' => $amount." ".$r['from_symbol'],
						'Fees' => $fees." ".$r['to_symbol'],
						'Total' => $total." ".$r['to_symbol'],
						'Status' => $r['status'],
						'Image' => $status,
					));
					$no++;
				}
				echo json_encode(array('status' => '1','recordsTotal' => $exchange_count, 'recordsFiltered' => $exchange_count, 'data' => $data));
			} 
			else 
			{
				echo json_encode(array('status' => '0','recordsTotal' => $exchange_count, 'recordsFiltered' => $exchange_count, 'data' => array()));
			}
		}
	}

}