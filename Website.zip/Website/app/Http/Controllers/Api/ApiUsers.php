<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\CryptoAddress;
use App\Http\Controllers\Front\Trades;
use App\Model\AdminBank;
use App\Model\AdminNotification;
use App\Model\Cms;
use App\Model\CoinAddress;
use App\Model\CommissionManagement;
use App\Model\ConsumerVerification;
use App\Model\Country;
use App\Model\Currency;
use App\Model\Deposit;
use App\Model\DepositSettings;
use App\Model\EmailTemplate;
use App\Model\Googleauthenticator;
use App\Model\Helpcategory;
use App\Model\HelpCentre;
use App\Model\PendingDeposit;
use App\Model\ReferralCommision;
use App\Model\SavedAddress;
use App\Model\SiteSettings;
use App\Model\SiteWallet;
use App\Model\Tokendetail;
use App\Model\TradeModel;
use App\Model\TradePairs;
use App\Model\Transfer;
use App\Model\User;
use App\Model\UserActivity;
use App\Model\UserBank;
use App\Model\UserNotification;
use App\Model\Wallet;
use App\Model\Withdraw;
use App\Model\WithdrawSettings;
use DateTime;
use DB;
use Hash;
use Illuminate\Support\Facades\Input;
use Mail;
use URL;
use Validator;

class ApiUsers extends Controller {
	public function __construct() {
	}

	public function dashboard() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId) {
			$all_cur = $curr = $all_cur1 = $curr1 = $transaction = $transactions = $convert = $conv = array();
			$getUserDetails = User::where('id', $userId)->select('consumer_name', 'phone', 'status', 'verified_status', 'first_name', 'last_name', 'country', 'tfa_status', 'otp_status', 'otp_phone', 'profile_picture', 'cashfree_status', 'cashfree_accnum', 'cashfree_ifsc', 'user_mail_id', 'unusual_user_key', 'tfa_status', 'with_status', 'with_pass')->first();
			$first = decrypText($getUserDetails['user_mail_id']);
			$second = decrypText($getUserDetails['unusual_user_key']);
			$useremailid = $first . "@" . $second;
			$verification = ConsumerVerification::where('user_id', $userId)->select('profile_update')->first();
			$userbank = UserBank::where('user_id', $userId)->where('status', '1')->orderBy('id', 'asc')->select('id', 'acc_name', 'acc_number', 'bank_name', 'bank_branch', 'bank_swift', 'country', 'currency', 'status', 'beneId_status')->get();
			$wallet = Wallet::where('user_id', $userId)->select('INR', 'USDT')->first();
			$allcurr = Currency::where('status', '1')->whereIn('currency_symbol', ['INR', 'USDT'])->get();
			foreach ($allcurr as $key => $value) {
				$symbol = $value->currency_symbol;
				$balance_val = $wallet->$symbol;
				$curr['balance'] = number_format($balance_val, 8, '.', '');
				$curr['name'] = $value->currency_name;
				$curr['symbol'] = $value->currency_symbol;
				$curr['image'] = URL::to('public/frontend/img/' . $value->currency_symbol . '.png');
				$curr['type'] = $value->currency_type;
				$curr['btc_value'] = $balance_val * $value->btc_value;
				array_push($all_cur, $curr);
			}

			$inr_value = get_inr_price('USDT');
			$response['status'] = 1;
			$response['userDetails'] = $getUserDetails;
			$response['userVerfication'] = $verification;
			$response['userBank'] = $userbank;
			$response['userEmail'] = $useremailid;
			$response['transfersettings'] = DepositSettings::where("currency", 'INR')->where('currency_type', 'Transfer')->select('min', 'max', 'currency', 'fees', 'status', 'fee_type')->first();
			$response['usd_price'] = number_format($inr_value, 2, '.', '');
			$response['depsettings'] = DepositSettings::whereIn("currency", ['INR', 'USDT'])->where('currency_type', 'Fiat')->select('currency', 'min', 'max', 'fees', 'fee_type', 'status', 'instant', 'standard')->get();
			$response['withsettings'] = WithdrawSettings::whereIn("currency", ['INR', 'USDT'])->where('currency_type', 'Fiat')->select('min', 'max', 'currency', 'fee', 'status', 'instant', 'standard', 'fee_type', 'neft', 'neft_min', 'neft_max', 'withdraw_limit_day', 'instant_min', 'instant_max')->get();
			$response['allcurr'] = $all_cur; 
			$getContent = Cms::whereIn('id', ['35', '36', '37', '38', '39'])->select('content', 'title', 'image')->get();
			foreach ($getContent as $value) {
				$res['title'] = $value->title;
				$res['content'] = strip_tags($value->content);
				$res['image'] = $value->image;
				$content[] = $res;
			}
			$response['getContent'] = $content;
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);
	}

	//To sort array
	public function array_sort_by_column(&$array, $column, $direction = SORT_DESC) {
		$reference_array = array();
		foreach ($array as $key => $row) {
			$reference_array[$key] = $row[$column];
		}
		array_multisort($reference_array, $direction, $array);
	}

	public function viewChart() {
		$data = Input::all();
		$userId = encrypText($data['user_id']);
		if ($userId != '') {
			return view('frontend.users.userbalChart')->with('wcwr', $userId);
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
			echo json_encode($response);exit;
		}
	}

	public function userBalChart($type, $user_id) {
		$userId = decrypText($user_id);
		if ($userId != '') {
			if ($type == 'spot') {
				$balance_val = Wallet::where('user_id', $userId)->first();
				$currency = Currency::where('status', '1')->select('currency_symbol')->get();
				foreach ($currency as $cur) {
					$inorders = userInorder($cur->currency_symbol, $userId);
					$result[$cur->currency_symbol] = $inorders;
				}
				$others = ($balance_val->LTC + $result['LTC']) + ($balance_val->USDT + $result['USDT']) + ($balance_val->BCH + $result['BCH']) + ($balance_val->DASH + $result['DASH']) + ($balance_val->XRP + $result['XRP']);

				$chart = array(array('users' => 'BTC', 'value' => ($balance_val->BTC + $result['BTC'])), array('users' => 'ETH', 'value' => ($balance_val->ETH + $result['ETH'])), array('users' => 'INR', 'value' => ($balance_val->INR + $result['INR'])), array('users' => 'Alt coins', 'value' => $others));
			}  
			echo json_encode($chart);exit;
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
			echo json_encode($response);exit;
		}
	}

	public function transfer() {
		$data = Input::all();
		$userId = $data['user_id'];
		$validate = Validator::make($data, [
			'username' => "required",
			'with_pass' => "required",
			'amount' => "required|numeric",
		], [
			'username.required' => 'Enter username',
			'with_pass.required' => 'Enter withdraw password',
			'amount.required' => 'Enter amount',
			'amount.numeric' => 'Enter valid amount',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}
		$currency = 'INR';
		$details = DepositSettings::where('currency', $currency)->where('currency_type', 'Transfer')->select('fees', 'fee_type', 'min', 'max', 'status')->first();
		if ($details->status == 1) {

			$prevoiusOrder = Transfer::where('user_id', $userId)->select('created_at')->orderBy('id', 'desc')->first();
			if ($prevoiusOrder) {
				$datetime1 = new DateTime();
				$datetime2 = new DateTime($prevoiusOrder->created_at);
				$interval = $datetime1->diff($datetime2);
				$mins = $interval->format('%i');
				if ($mins < 1) {
					$response = array('status' => '0', 'msg' => 'Please try again after sometime');
					echo json_encode($response);exit;
				}
			}

			
			$amount = $data['amount'];
			$withPass = $userId . strip_tags($data['with_pass']);

			$fees = $fee_amt = $details->fees;
			$fee_type = $details->fee_type;
			$min = $details->min;
			$max = $details->max;
			if ($fee_type == 'amount') {
				if ($amount <= $fees) {
					$response = array('status' => '0', 'msg' => 'Enter amount more than fees value');
					echo json_encode($response);exit;
				}
			}

			if ($userId != '') {
				$userdetails = User::where('id', $userId)->select('user_mail_id', 'unusual_user_key', 'consumer_name', 'device_token', 'auto_with', 'with_status', 'with_pass')->first();
				$now = date('Y-m-d H:i:s');
				$username = $data['username'];
				if ($userdetails->auto_with == 1) {
					if ($userdetails->with_status == 1) {

						if (!Hash::check($withPass, $userdetails->with_pass)) {
							$response = array('status' => '0', 'msg' => 'Invalid withdraw password');
							echo json_encode($response);exit;
						}

						$details = User::where('consumer_name', $username)->select('id')->first();
						if ($details) {
							$user_id = $details->id;
							if ($user_id != $userId) {
								$senduserBal = Wallet::where('user_id', $userId)->select('INR')->first()->INR;
								if ($senduserBal >= $amount) {
									if ($amount >= $min && $amount <= $max) {
										if ($fee_type == 'amount') {
											$total = $amount - $fees;
										} else {
											$fee_amt = ($amount * $fees) / 100;
											$total = $amount - $fee_amt;
										}
										if ($total >= '0.01') {
											$sendupBal = $senduserBal - $amount;
											$rand = randomString(34);
											$expire = date('Y-m-d H:i:s', strtotime("+10 days"));
											$create = array(
												'user_id' => $userId,
												'rec_user_id' => $user_id,
												'rec_user_name' => $username,
												'currency' => 'INR',
												'amount' => $amount,
												'fee_per' => $fees,
												'fees' => $fee_amt,
												'fee_type' => $fee_type,
												'total' => $total,
												'code' => $rand,
												'status' => 'pending',
												'created_at' => $now,
												'expire_at' => $expire,
												'app_site' => 'app',
											);

											$remarks = 'Tranfer initiated for ' . $amount . ' INR'. ' Old balance: '. $senduserBal;
											$update = DB::transaction(function () use ($userId, $currency, $sendupBal, $create, $remarks) {
												Transfer::create($create);
												Wallet::where('user_id', $userId)->update([$currency => $sendupBal, 'remarks' => $remarks]);
												return true;
											});

											$info = array('###USER###' => $userdetails->consumer_name, '###OTP###' => $rand);
											$getEmail = EmailTemplate::where('id', 38)->first();
											$getSiteDetails = Controller::getEmailTemplateDetails();
											$replace = array_merge($getSiteDetails, $info);
											$emaildata = array('content' => strtr($getEmail->template, $replace));
											$toDetails['useremail'] = decrypText($userdetails->user_mail_id) . '@' . decrypText($userdetails->unusual_user_key);
											$toDetails['subject'] = $getEmail->subject;
											$toDetails['from'] = $getSiteDetails['contact_mail_id'];
											$toDetails['name'] = $getSiteDetails['site_name'];

											$sendEmail = Controller::sendEmail($emaildata, $toDetails);
											if ($sendEmail) {
												$devicetoken = $userdetails->device_token;
												$title = 'Transfer';
												$msg = 'Transferred Successfully';
												self::sendnotification($title, $msg, $devicetoken);
												$response = array('status' => '1', 'msg' => 'Transferred Successfully');
											} else {
												$response = array('status' => '0', 'msg' => 'Please try again later');
											}
										} else {
											$response = array('status' => '0', 'msg' => 'Your Transfer Amount should be Minimum 0.01');
										}
									} else {
										$response = array('status' => '0', 'msg' => 'Enter the amount Minimum Amount ' . $min . ' ' . $currency . " - Maximum Amount " . $max . ' ' . $currency);
									}
								} else {
									$response = array('status' => '0', 'msg' => 'Insufficient Balance');
								}
							} else {
								$response = array('status' => '0', 'msg' => 'You should not enter your username');
							}
						} else {
							$response = array('status' => '0', 'msg' => 'Username not exists');
						}
					} else {
						$response = array('status' => '0', 'msg' => 'Please enable withdraw password');
					}
				} else {
					$response = array('status' => '0', 'msg' => 'Please try again later');
				}
			} else {
				$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
			}
		} else {
			$response = array('status' => '0', 'msg' => 'Transfer Under Maintenance');
		}
		echo json_encode($response);exit;
	}

	public function transfer_redeem() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'code' => "required",
			'with_pass' => "required",
		], [
			'code.required' => 'Enter code',
			'with_pass.required' => 'Enter withdraw password',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}

		$currency = 'INR';
		$details = DepositSettings::where('currency', $currency)->where('currency_type', 'Transfer')->select('fees', 'fee_type', 'min', 'max', 'status')->first();
		if ($details->status == 1) {
			$userId = $data['user_id'];
			$withPass = $userId . strip_tags($data['with_pass']);
			$userdetails = User::where('id', $userId)->select('with_status', 'with_pass')->first();

			$prevoiusOrder = Transfer::where('rec_user_id', $userId)->where('redemption_at', '!=', NULL)->select('redemption_at')->orderBy('id', 'desc')->first();
			if ($prevoiusOrder) {
				$datetime1 = new DateTime();
				$datetime2 = new DateTime($prevoiusOrder->redemption_at);
				$interval = $datetime1->diff($datetime2);
				$mins = $interval->format('%i');
				if ($mins < 1) {
					$response = array('status' => '0', 'msg' => 'Please try again after sometime');
					echo json_encode($response);exit;
				}
			}

			if ($userId != '') {
				$code = $data['code'];
				$now = date('Y-m-d H:i:s');
				if ($userdetails->with_status == 1) {

					if (!Hash::check($withPass, $userdetails->with_pass)) {
						$response = array('status' => '0', 'msg' => 'Invalid withdraw password');
						echo json_encode($response);exit;
					}

					if ($code) {
						$transfer = Transfer::where('code', $code)->where('status', 'pending')->first();
						if ($transfer) {
							$transId = $transfer->id;
							$user_id = $transfer->user_id;
							$rec_user_id = $transfer->rec_user_id;
							$expire = $transfer->expire_at;
							$original = $transfer->amount;
							if ($expire >= $now) {
								if ($user_id != $userId) {
									if ($userId == $rec_user_id) {
										$fees = $fee_amt = $transfer->fee_per;
										$fee_type = $transfer->fee_type;
										$amount = $transfer->total;
										if ($fee_type == 'amount') {
											$total = $amount - $fees;
										} else {
											$fee_amt = ($amount * $fees) / 100;
											$total = $amount - $fee_amt;
										}
										if ($total >= '0.01') {
											$recuserBal = Wallet::where('user_id', $rec_user_id)->select('INR')->first()->INR;
											$recupBal = $recuserBal + $total;
											$remarks = 'Redeem completed for ' . $total . ' INR'. ' Old balance: '. $recuserBal;

											$theftdata = array('user_id' => $user_id, 'theftAmount' => $fee_amt, 'theftCurrency' => $currency, 'type' => 'Transfer fees');
											$theftdata1 = array('user_id' => $rec_user_id, 'theftAmount' => $fee_amt, 'theftCurrency' => $currency, 'type' => 'Transfer fees');

											$update = DB::transaction(function () use ($rec_user_id, $recupBal, $transId, $now, $remarks, $theftdata, $theftdata1) {
												Wallet::where('user_id', $rec_user_id)->update(['INR' => $recupBal, 'remarks' => $remarks]);
												Transfer::where('id', $transId)->update(['status' => 'completed', 'redemption_at' => $now, 'code' => '']);
												CoinProfit::create($theftdata);
												CoinProfit::create($theftdata1);
												return true;
											});
											$userdetails = User::where('id', $userId)->select('device_token')->first();
											$devicetoken = $userdetails->device_token;
											$title = 'Redeemed';
											$msg = 'Redeemed Successfully';
											self::sendnotification($title, $msg, $devicetoken);
											$response = array('status' => '1', 'msg' => 'Redeemed Successfully');
										} else {
											$response = array('status' => '0', 'msg' => 'Your Received Amount should be  Minimum 0.01');
										}
									} else {
										$response = array('status' => '0', 'msg' => 'Invalid Code');
									}
								} else {
									$response = array('status' => '0', 'msg' => 'You should not use this code for yourself');
								}
							} else {
								$senduserBal = Wallet::where('user_id', $user_id)->select('INR')->first()->INR;
								$sendupBal = $senduserBal + $original;
								$remarks = 'Transfer reverted for ' . $original . ' INR'. ' Old balance: '. $senduserBal;
								$update = DB::transaction(function () use ($user_id, $sendupBal, $code, $now, $remarks) {
									Wallet::where('user_id', $user_id)->update(['INR' => $sendupBal, 'remarks' => $remarks]);
									Transfer::where('id', $transId)->update(['status' => 'cancelled', 'code' => '', 'redemption_at' => $now]);
									return true;
								});
								$response = array('status' => '0', 'msg' => 'Code Expired');
							}
						} else {
							$response = array('status' => '0', 'msg' => 'Transfer already processed');
						}
					} else {
						$response = array('status' => '0', 'msg' => 'Please try again later');
					}
				} else {
					$response = array('status' => '0', 'msg' => 'Please enable withdraw password');
				}
			} else {
				$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
			}
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);
	}

	public function wallet() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$currencies = $currency = Currency::where('status', '1')->select('currency_name', 'currency_symbol', 'btc_value', 'image', 'cid', 'currency_type')->orderBy('cid', 'asc')->get();

			$fields = ['id', 'user_id', 'created_at', 'updated_at'];
			$wallet = $userwallet = Wallet::where('user_id', $userId)->first();
			$wallet = collect($wallet)->except($fields)->toArray();

			$btcEqu['BTC'] = $wallet['BTC'];
			$usdEqu_site = $btcEqu_site = $currPairs = array();
			$pairs = TradePairs::where('site_status', '1')->select('from_symbol', 'to_symbol', 'last_price', 'trading_pair')->get()->map(function ($curr) {return ['key' => $curr->trading_pair, 'value' => $curr];})->pluck('value', 'key')->toArray();

			$btcVal = $usdVal = 0;
			$user = User::where('id', $userId)->select('fav_curs', 'verified_status')->first();
			$get_fav = $user->fav_curs;
			$fav = explode(',', $get_fav);

			$btcVal = $btcEqu_site['BTC'] = $wallet['BTC'];
			foreach ($currency as $curr) {
				$price = $curr->btc_value;
				$sym = $curr->currency_symbol;
				$bal = $wallet[$sym] ? $wallet[$sym] : 0;
				$val = $wallet[$sym] * $price;
				$btcEqu_site[$sym] = number_format($val, 8, '.', '');

				if ($sym == 'INR') {
					$last_price = 1;
				} else {
					$last_price = isset($pairs[$sym . '_INR']) ? $pairs[$sym . '_INR']['last_price'] : 1;
				}

				$balance = $wallet[$sym];
				$estimated = $balance * $last_price;

				$inOrders = portfolioInorder($sym, $userId, 1);
				$res['currency'] = $sym;
				$res['balance'] = $balance;
				$res['inorders'] = $inOrders['inorders'];
				$res['btc_equ'] = $inOrders['btc_equ'];
				$res['estimated'] = number_format($estimated, 2, '.', '');
				$results[] = $res;
			}

			$response['status'] = 1;
			$response['currencies'] = $currencies;
			$response['fav'] = $fav;
			$response['user'] = $user;
			$response['wallet'] = $results;
			$response['value'] = $wallet['value'];
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);
	}

	public function walletPairs() {
		$data = Input::all();
		$userId = $data['user_id'];
		$filter = $data['currency'];
		if ($userId != '') {
			$currPairs = array();
			$pairs1 = TradePairs::where('site_status', '1')->where('from_symbol', $filter)->select('from_symbol', 'to_symbol', 'last_price', 'trading_pair')->get()->map(function ($curr) {return ['key' => $curr->trading_pair, 'value' => $curr];})->pluck('value', 'key')->toArray();
			$pairs2 = TradePairs::where('site_status', '1')->where('to_symbol', $filter)->select('from_symbol', 'to_symbol', 'last_price', 'trading_pair')->get()->map(function ($curr) {return ['key' => $curr->trading_pair, 'value' => $curr];})->pluck('value', 'key')->toArray();
			$pairs = array_merge($pairs1, $pairs2);
			foreach ($pairs as $pair) {
				$from = $pair['from_symbol'];
				$to = $pair['to_symbol'];
				$price = $pair['last_price'];
				if (!empty($price) && $price != '0.00000000') {
					$pairname = $from . '/' . $to;
					$tradeData = Trades::getTradeData($pairname, $from, $to);
					$currPairs['pair'][] = array(
						'pair' => $from . '/' . $to,
						'volume' => $tradeData['volume'],
						'change' => $tradeData['change'],
						'open' => $tradeData['open'],
					);
				}
			}
			$response['status'] = 1;
			$response['currPairs'] = $currPairs;
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);
	}

	public function getPortfolio() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'value' => "required",
		], [
			'value.required' => 'Enter value',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}
		$userId = $data['user_id'];
		if ($userId != '') {
			$value = $data['value'];
			$update = Wallet::where('user_id', $userId)->update(['value' => $value]);
			if ($update) {
				$response = array('status' => '1', 'msg' => 'Updated Successfully');
				echo json_encode($response);exit;
			}
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
			echo json_encode($response);exit;
		}
	}

	public function addfavcoin() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId) {
			$pair = strip_tags($data['curr']);
			$fav_array = array();
			$curr = trim(strip_tags($data['curr']));
			$get_fav = User::where('id', $userId)->select('fav_curs')->first();
			$fav_curs = $get_fav->fav_curs;
			if ($fav_curs) {
				$fav_array = explode(',', $fav_curs);
			}

			if (in_array($curr, $fav_array)) {
				if (($key = array_search($curr, $fav_array)) !== false) {
					unset($fav_array[$key]);
				}
				$fav_curs = implode(',', $fav_array);
			} else {
				if ($fav_curs) {
					$fav_curs .= ',' . $curr;
				} else {
					$fav_curs = $curr;
				}
			}
			$update = User::where('id', $userId)->update(array('fav_curs' => $fav_curs));
			if ($update) {
				$response = array('status' => '1', 'msg' => 'Updated Successfully');
			}
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);
	}

	public function deposit() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$adminbank = AdminBank::where('status', 'active')->select('acc_name', 'bank_code', 'acc_number', 'bank_name', 'bank_branch', 'bank_country')->orderBy('id', 'asc')->get();
			$currency = Currency::where('status', '1')->orderBy('cid', 'asc')->get();
			$response = array('status' => '1', 'adminbank' => $adminbank, 'currency' => $currency);
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);
	}

	public function getDepositCrypto() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'currency' => "required",
			'dtype' => "required",
		], [
			'currency.required' => 'Enter currency',
			'dtype.required' => 'Enter deposit type',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}
		$userId = $data['user_id'];
		if ($userId != '') {
			$token_adrr = '';
			$currency = $selectCurr = $data['currency'];
			$dtype = $data['dtype'];
			$getLimit = DepositSettings::where('currency', $currency)->where('currency_type', $dtype)->select('min', 'max', 'status')->first();
			$confirmation = Currency::where('currency_symbol', $currency)->select('confirmations')->first()->confirmations;
			$pro_user = User::where('id', $userId)->select('pro_user')->first()->pro_user;
			$pro_user = 0;
			if ($pro_user) {
				$response['success'] = 2;
			} else {
				if ($getLimit->status == 0) {
					$response['success'] = 2;
				} else {
					$token_info_new = Tokendetail::where('token_symbol', $currency)->where('base_coin', 'ETH')->first();
					if (!empty($token_info_new)) {
						$currency = 'ETH';
					} else if ($currency == 'USDT') {
						$currency = 'ETH';
					}
					if ($currency == 'XRP') {
						$coin = SiteWallet::where('type', encrypText($currency))->select('username')->first();
						$token_adrr = decrypText($coin->username);
					} 
					$getAddress = CoinAddress::where('user_id', $userId)->where('currency', $currency)->select('address', 'secret')->orderBy('id', 'desc')->first();
					if ($getAddress) {
						$address = $getAddress->address;
						if ($currency == 'XRP') {
							$desination = $getAddress->secret;
						} else {
							$desination = '';
						}
					} else {

						$token_info_new = Tokendetail::where('token_symbol', $currency)->where('base_coin', 'ETH')->first();
						if (!empty($token_info_new)) {
							$currency = 'ETH';
						}
						$getAddr = CryptoAddress::createAddress($currency, $userId);
						$addrStatus = $getAddr['status'];
						if ($addrStatus == 1 || $addrStatus == 2) {
							$address = $getAddr['address'];
							$desination = $getAddr['tag'];
							$hex = $getAddr['hex'];
							if ($addrStatus == 1) {
								CoinAddress::create(['user_id' => $userId, 'currency' => $currency, 'address' => $address, 'secret' => $desination, 'hex' => $hex]);
							}
							if ($currency == 'XRP') {
								$desination = $desination;
							} else {
								$desination = '';
							}
						} else {
							$result = array('success' => 0, 'msg' => 'Failed to create address!');
							echo json_encode($result);exit();
						}
					}

					if ($currency == 'BCH') {
						$bchaddress = explode(':', $address);
						$address = $bchaddress[1];
					}

					$addr = ($currency == 'XRP') ? $token_adrr : $address;
					$response['success'] = 1;
					$response['address'] = $addr;
					$response['tag'] = $desination;
					$response['url'] = "https://chart.googleapis.com/chart?cht=qr&chs=256x258&chl=$addr&choe=UTF-8&chld=L";
				}
			}
			$balance = Wallet::where('user_id', $userId)->select($selectCurr)->first();
			$response['balance'] = $balance->$selectCurr;
			$response['currency'] = $selectCurr;
			$response['confirmation'] = $confirmation;
			$response['min'] = $getLimit->min;
			$response['max'] = $getLimit->max;
		} else {
			$response = array('success' => 0, 'msg' => 'Please login to continue');
		}
		echo json_encode($response);
	}

	public function getDepositFiat() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'currency' => "required",
			'dtype' => "required",
		], [
			'currency.required' => 'Enter currency',
			'dtype.required' => 'Enter deposit type',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}
		$userId = $data['user_id'];
		if ($userId != '') {
			$currency = strip_tags($data['currency']);
			$dtype = strip_tags($data['dtype']);
			$settings = DepositSettings::where("currency", $currency)->where('currency_type', $dtype)->select('min', 'max', 'currency', 'fees', 'status', 'fee_type', 'standard', 'instant')->first();

			$pro_user = User::where('id', $userId)->select('pro_user')->first()->pro_user;
			$pro_user = 0;
			if ($pro_user) {
				$response['success'] = 2;
			} else {
				if ($dtype == 'Fiat' && $currency == 'USDT') {
					$inr_value = get_inr_price('USDT');
					$inr_price = 1 / $inr_value;
					$settings['inr_price'] = number_format($inr_price, 2, '.', '');
					$settings['usd_price'] = number_format($inr_value, 2, '.', '');
				}
				$balance = Wallet::where('user_id', $userId)->select($currency)->first();
				$response['adminbank'] = AdminBank::where('currency', 'INR')->where('status', 'active')->count();
				$response['min'] = $settings->min;
				$response['max'] = $settings->max;
				$response['fees'] = $settings->fees;
				$response['fee_type'] = $settings->fee_type;
				$response['status'] = $settings->status;
				$settings['standard'] = $settings->standard;
				$settings['instant'] = $settings->instant;
				$response['balance'] = $balance->$currency;
			}
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);
	}

	public function adminBankDetails() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$acc_number = $data['acc_number'];
			$result_val = AdminBank::where('currency', 'INR')->where('acc_number', $acc_number)->where('status', 'active')->select('id', 'acc_name', 'acc_number', 'bank_name', 'bank_branch', 'bank_code', 'purpose', 'bank_country')->first();
			if ($result_val) {
				$response['purpose'] = $result_val->purpose;
				$response['id'] = $result_val->id;
				$response['receipt_name'] = SITENAME."Merchant";
				$response['acc_name'] = $result_val->acc_name;
				$response['acc_number'] = $result_val->acc_number;
				$response['bank_name'] = $result_val->bank_name;
				$response['bank_branch'] = $result_val->bank_branch;
				$response['bank_code'] = $result_val->bank_code;
				$response['bank_country'] = $result_val->bank_country;
			} else {
				$response = $result_val;
			}
		} else {
			$response = array('status' => '0', 'msg' => "Please login again to continue!");
		}
		echo json_encode($response);
	}

	public function checkDepositLimit() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'currency' => "required",
			'amount' => "required|numeric",
			'dtype' => "required",
		], [
			'currency.required' => 'Enter currency',
			'amount.required' => 'Enter amount',
			'amount.numeric' => 'Enter valid amount',
			'dtype.required' => 'Enter deposit type',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}
		$userId = $data['user_id'];
		if ($userId != '') {
			$currency = $data['currency'];
			$amount = $data['amount'];
			$dtype = $data['dtype'];
			$getLimit = DepositSettings::where('currency', $currency)->where('currency_type', $dtype)->select('min', 'max')->first();
			$minLimit = $getLimit->min;
			$maxLimit = $getLimit->max;
			$min_amo = trans('app_lang.enter_amount_with_minimum');
			$max_amo = trans('app_lang.max_amount');
			if ($amount >= $minLimit) {
				$response = array('status' => '1', 'msg' => 'true');
			} else {
				$response = array('status' => '0', 'msg' => $min_amo . number_format($minLimit, 2) . " " . $currency);
			}
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);
	}

	public function checkrefExists() {
		$data = Input::all();
		$reference_no = strip_tags($data['transaction_ref']);
		$currency = strip_tags($data['currency']);

		$getCount = Deposit::where('reference_no', $reference_no)->where('status', '!=', 'cancelled')->count();
		$msg = ($getCount > 0) ? "false" : "true";
		$status = ($getCount > 0) ? 0 : 1;
		$response = array('status' => $status, 'msg' => $msg);
		echo json_encode($response);exit;
	}

	public function updateDepositFiatCurrency() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$currency = $data['fiat_currency'];
			$getLimit = DepositSettings::where('currency', $currency)->where('currency_type', 'Fiat')->select('min', 'max', 'fees', 'fee_type', 'standard', 'status')->first();
			$getDetail = User::select('verified_status', 'consumer_name', 'tfa_status', 'secret', 'user_mail_id', 'unusual_user_key', 'pro_user')->where('id', $userId)->first();
			$pro_user = $getDetail->pro_user;
			$pro_user = 0;
			if ($getLimit->status == 1 && $getLimit->standard == 1 && $pro_user == 0) {
				$getDetail = User::select('verified_status', 'consumer_name', 'tfa_status', 'secret', 'user_mail_id', 'unusual_user_key')->where('id', $userId)->first();
				$ip = Controller::getIpAddress();
				if ($getDetail->verified_status == 3) {
					$validate = Validator::make($data, [
						'transaction_ref' => "required",
						'deposit_amount' => "required|numeric",
						'fiat_currency' => "required",
						'bankwire' => "required",
						'account' => "required",
						'proof' => "required",
					], [
						'transaction_ref.required' => 'Please Enter transaction number',
						'deposit_amount.required' => 'Please Enter amount',
						'deposit_amount.numeric' => 'Please Enter valid amount',
						'fiat_currency.required' => 'Please chooose currency',
						'bankwire.required' => 'Please chooose deposit type',
						'account.required' => 'Please chooose account',
						'proof.required' => 'Please upload proof',
					]);

					if ($validate->fails()) {
						foreach ($validate->messages()->getMessages() as $val => $msg) {
							$response = array('status' => '0', 'msg' => $msg[0]);
							echo json_encode($response);exit;
						}
					}

					$getUserDetails = User::where('id', $userId)->select('id', 'tfa_status', 'verified_status')->first();

					if (empty($data['transaction_ref'])) {
						$response = array('status' => '0', 'msg' => trans('app_lang.enter_valid_transaction_number'));
						echo json_encode($response);exit;
					}

					$count = Deposit::where('reference_no', strip_tags($data['transaction_ref']))->where('status', '!=', 'cancelled')->count();
					if ($count > 0) {
						$response = array('status' => '0', 'msg' => 'Reference number already exists');
						echo json_encode($response);exit;
					}

					$ip = Controller::getIpAddress();
					$amount = $data['deposit_amount'];
					$proof = $data['proof'];
					$minLimit = $getLimit->min;
					$maxLimit = $getLimit->max;
					$fee_amt = $fees = $getLimit->fees;
					$fee_type = $getLimit->fee_type;
					if ($fee_type == 'amount') {
						if ($amount <= $fee_amt) {
							$response = array('status' => '0', 'msg' => 'Enter amount more than fees value');
							echo json_encode($response);exit;
						}
					}

					if ($amount >= $minLimit && $amount <= $maxLimit) {

						if ($fee_type == 'amount') {
							$total = $amount - $fees;
						} else {
							$fee_amt = ($amount * $fees) / 100;
							$total = $amount - $fee_amt;
						}
						$fee_amt = number_format($fee_amt, 2, '.', '');
						$fees = number_format($fees, 2, '.', '');
						$total = number_format($total, 2, '.', '');
						if ($total >= '0.01') {
							$transaction_number = User::randomString(8);
							$adminBank = AdminBank::where('acc_number', strip_tags($data['account']))->select('acc_name', 'acc_number', 'bank_code', 'bank_name', 'bank_branch', 'bank_country')->first();
							$encodeBankDetails = json_encode($adminBank);
							$depositData = array('currency_type' => 'fiat', 'amount' => strip_tags($amount), 'reference_no' => strip_tags($data['transaction_ref']), 'payment_method' => 'bank', 'status' => 'pending', 'user_id' => $userId, 'ip_addr' => $ip, 'currency' => $currency, 'proof' => strip_tags($data['proof']), 'transaction_number' => $transaction_number, 'payment_type' => strip_tags($data['bankwire']), 'fees' => $fee_amt, 'fee_per' => $fees, 'total' => $total, 'dep_bank_info' => $encodeBankDetails, 'app_site' => 'app');
							$createDeposit = Deposit::create($depositData);
							$txId = $createDeposit->id;

							if ($createDeposit) {
								$depositId = encrypText($txId);
								$uId = encrypText($userId);
								$securl1 = URL::to('BVZrcniXhwivGdIA/confirmDeposit/' . $depositId . '/' . $uId);
								$securl2 = URL::to('BVZrcniXhwivGdIA/rejectDeposit/' . $depositId . '/' . $uId);

								$getProfile = User::getProfile($userId);
								$getEmail = EmailTemplate::where('id', 5)->first();
								$getSiteDetails = Controller::getEmailTemplateDetails();
								$info = array('###USER###' => $getProfile['user']->consumer_name, '###LINK1###' => $securl1, '###LINK2###' => $securl2, '###AMT###' => $amount . ' ' . $currency, '###REF###' => $data['transaction_ref'], '###MESSAGE###' => '', '###ADDRESS###' => '', '###MESSAGE1###' => '');
								$replace = array_merge($getSiteDetails, $info);

								$emaildata = array('content' => strtr($getEmail->template, $replace));
								$toDetails['useremail'] = $getSiteDetails['contact_mail_id'];
								$toDetails['subject'] = $getEmail->subject;
								$toDetails['from'] = $getSiteDetails['contact_mail_id'];
								$toDetails['name'] = $getSiteDetails['site_name'];

								$sendEmail = Controller::sendEmail($emaildata, $toDetails);

								if (count(Mail::failures()) > 0) {
									$response = array('status' => '0', 'msg' => trans('app_lang.Email sending failed.'));
								} else {
									$msg1 = $getProfile['user']->consumer_name . " have requested deposit for the amount of " . $amount . " " . $currency;
									$insdata = array('admin_id' => 1, 'type' => 'Deposit', 'message' => $msg1, 'status' => 'unread');
									AdminNotification::create($insdata);
									$devicetoken = $getProfile['user']->device_token;
									$title = 'Fiat Deposit';
									$msg = $amount . " " . $currency . ' Deposit request sent to admin';
									self::sendnotification($title, $msg, $devicetoken);
									$response = array('status' => '1', 'msg' => $amount . " " . $currency . ' Deposit request sent to admin');
								}
							} else {
								$response = array('status' => '0', 'msg' => trans('app_lang.Failed to update.'));
							}
						} else {
							$response = array('status' => '0', 'msg' => 'Your Received Amount Minimum 0.01 ' . $currency);
						}
					} else {
						$response = array('status' => '0', 'msg' => "Please enter the amount Minimum Amount " . $minLimit . " " . $currency . " - Maximum Amount" . $maxLimit . " " . $currency);
					}
				} else {
					$response = array('status' => '0', 'msg' => trans('app_lang.Your KYC documents not verified yet.'));
				}
			} else {
				$response = array('status' => '0', 'msg' => 'Deposit Under Maintenance');
			}
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);
	}

	public function withdraw() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$response['status'] = 1;
			$response['user'] = User::where('id', $userId)->select('tfa_status', 'phone', 'otp_status', 'verified_status')->first();
			$response['userbank'] = UserBank::where('user_id', $userId)->where('status', '1')->orderBy('id', 'asc')->select('id', 'acc_name', 'acc_number', 'bank_name', 'bank_branch', 'bank_swift', 'country', 'currency', 'status')->get()->map(function ($bank) {return ['key' => $bank->acc_number, 'value' => $bank];})->pluck('value', 'key')->toArray();
			$response['currency'] = Currency::where('status', '1')->orderBy('cid', 'asc')->get();
			$response['saved'] = SavedAddress::where('user_id', $userId)->where('status', 'active')->get()->toArray();
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);exit;
	}

	public function getWithdrawSettings() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			if ((isset($data['currency']) && $data['currency'] != "") && (isset($data['wtype']) && $data['wtype'] != "")) {
				$currency = strip_tags($data['currency']);
				$wtype = strip_tags($data['wtype']);
				$mtype = $data['mtype'];
				$settings = DB::table('withdraw_settings as ws')->leftjoin('currency as c', 'c.currency_symbol', '=', 'ws.currency')->where("ws.currency", $currency)->where('ws.currency_type', $wtype)->select('ws.min', 'ws.max', 'ws.currency', 'ws.fee', 'ws.status', 'ws.standard', 'ws.instant', 'ws.neft', 'ws.fee_type', 'ws.neft_min', 'ws.neft_max', 'ws.instant_min', 'ws.instant_max', 'c.status as with_status')->first();
				if ($settings->with_status) {
					if ($wtype == 'Crypto') {
						$saved = SavedAddress::where("currency", $currency)->where('user_id', $userId)->where('status', 'active')->select('currency', 'address', 'lable', 'tag')->get();
						$response['saved'] = $saved;
					}

					if ($wtype == 'Fiat' && $currency == 'USDT') {
						$inr_value = get_inr_price('USDT');
						$inr_price = 1 / $inr_value;
						$response['inr_price'] = number_format($inr_price, 2, '.', '');
						$response['usd_price'] = number_format($inr_value, 2, '.', '');
					}

					$balance = Wallet::where('user_id', $userId)->select($currency)->first();
					$digits = ($wtype == 'Fiat') ? 2 : 8;
					$response['fee'] = number_format($settings->fee, $digits, '.', '');
					$response['balance'] = number_format($balance->$currency, $digits, '.', '');
					$inorder = portfolioInorder($currency, $userId);
					$response['inorder'] = $inorder;
					$total = $balance->$currency + $inorder;
					$response['total'] = number_format($total, $digits, '.', '');
					$response['fee_type'] = $settings->fee_type;
					$response['standard'] = $settings->standard;
					$response['instant'] = $settings->instant;
					$response['neft'] = $settings->neft;
					if ($currency == 'INR') {
						if ($mtype == 1) {
							$sta = $settings->status;
							$min = $settings->min;
							$max = $settings->max;
						} else if ($mtype == 2) {
							$sta = $settings->instant;
							$min = $settings->instant_min;
							$max = $settings->instant_max;
						} else if ($mtype == 3) {
							$sta = $settings->neft;
							$min = $settings->neft_min;
							$max = $settings->neft_max;
						} else {
							$sta = $settings->status;
							$min = $settings->min;
							$max = $settings->max;
						}
					} else {
						$sta = $settings->status;
						$min = $settings->min;
						$max = $settings->max;
					}
					if($sta) {
						$response['min'] = number_format($min, $digits, '.', '');
						$response['max'] = number_format($max, $digits, '.', '');
						$response['success'] = 1;
					} else {
						$response['success'] = 2;
					}
				} else {
					$response['success'] = 2;
				}
			} else {
				$response['success'] = 0;
			}
		} else {
			$response['success'] = 0;
		}
		echo json_encode($response);
	}

	public function checkWithdrawLimit() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'amount' => "required|numeric",
			'currency' => "required",
			'wtype' => "required",
		], [
			'amount.required' => 'Enter amount',
			'amount.numeric' => 'Enter valid amount',
			'currency.required' => 'Enter currency',
			'wtype.required' => 'Enter withdraw type',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}
		$userId = $data['user_id'];
		if ($userId != '') {
			$currency = $data['currency'];
			$wtype = $data['wtype'];
			$mtype = isset($data['mtype']) ? $data['mtype'] : 0;
			$getMin = WithdrawSettings::where('currency', $currency)->where('currency_type', $wtype)->select('min', 'max', 'neft_min', 'neft_max', 'instant_min', 'instant_max')->first();
			if ($currency == 'INR') {
				if ($mtype == 0) {
					$minAmount = $getMin->min;
					$maxAmount = $getMin->max;
				} else if ($mtype == 1) {
					$minAmount = $getMin->instant_min;
					$maxAmount = $getMin->instant_max;
				} else if ($mtype == 2) {
					$minAmount = $getMin->neft_min;
					$maxAmount = $getMin->neft_max;
				}
			} else {
				$minAmount = $getMin->min;
				$maxAmount = $getMin->max;
			}

			$getBalance = TradeModel::fetchuserbalancebyId($userId, $data['currency']);
			if ($data['amount'] >= $minAmount && $data['amount'] <= $maxAmount) {
				if ($data['amount'] <= $getBalance) {
					$response = array('status' => '1', 'msg' => 'true');
				} else {
					$response = array('status' => '0', 'msg' => trans('app_lang.insufficint_balance'));
				}
			} else {
				$response = array('status' => '0', 'msg' => trans('app_lang.enter_amount_with_minimum') . $minAmount . " " . $currency . trans('app_lang.max_amount') . $maxAmount . " " . $currency);
			}
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.please_login'));
		}
		echo json_encode($response);
	}

	public function userBankDetails() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'acc_number' => "required",
		], [
			'acc_number.required' => 'Enter account number',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}
		$userId = $data['user_id'];
		if ($userId != '') {
			$acc_number = $data['acc_number'];
			$result = UserBank::where('user_id', $userId)->where('currency', 'INR')->where('acc_number', $acc_number)->where('status', '1')->select('acc_name', 'acc_number', 'bank_name', 'bank_branch', 'bank_iban', 'bank_swift', 'country', 'beneId_status', 'beneId')->first();
			if ($result) {
				$response = array('status' => 1, 'result' => $result);
			} else {
				$response = array('status' => 0, 'msg' => 'Please try again later');
			}
		} else {
			$response = array('status' => 0, 'msg' => 'Please login again to continue!');
		}
		echo json_encode($response);
	}

	public static function checkUserAddress($currency, $address, $tag) {
		if ($currency == 'USDT') {
			$currency = 'ETH';
		} else {
			$currency = strtoupper($currency);
		}
		if ($currency == 'XRP') {
			$search_arr = ['currency' => $currency, 'secret' => $tag];
		} else {
			$search_arr = ['currency' => $currency, 'address' => $address];
		}
		$user_id = CoinAddress::where($search_arr)->select('user_id')->first();
		if ($user_id) {
			return 'false';
		} else {
			return 'true';
		}
	}

	public function withdrawPaymentSubmit() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$withPass = $userId . strip_tags($data['with_pass']);
			$getDetail = User::select('verified_status', 'consumer_name', 'tfa_status', 'secret', 'user_mail_id', 'unusual_user_key', 'mobile_otp', 'otp_status', 'device_token', 'pro_user', 'InrDeposit', 'InrWithdraw', 'with_status', 'with_pass')->where('id', $userId)->first();
			$pro_user = $getDetail->pro_user;
			$InrWithdraw = $getDetail->InrWithdraw;
			$InrDeposit = $getDetail->InrDeposit;
			$pro_user = 0;
			if ($pro_user == 0) {
				$ip = Controller::getIpAddress();
				if ($getDetail->verified_status == 3) {
					$data = Input::all();
					$Validation = Validator::make($data, User::$withdrawCryptoRule);
					if ($Validation->fails()) {
						foreach ($Validation->messages()->getMessages() as $field_name => $message) {
							$response = array('status' => '0', 'msg' => $message[0]);
							echo json_encode($response);exit;
						}
					}

					$currency = strip_tags($data['crypto_currency']);
					if ($getDetail->tfa_status == 'enable') {
						require_once app_path('Model/Googleauthenticator.php');
						$googleAuth = new Googleauthenticator();
						$verify = $googleAuth->verifyCode($getDetail->secret, $data['crypto_auth_key'], $discrepancy = 2);
						if ($verify == 1) {
							goto next;
						} else {
							$response = array('status' => '0', 'msg' => trans('app_lang.Invalid authentication key.'));
							echo json_encode($response);exit;
						}
					} else {
						$userotp = decrypText($getDetail->mobile_otp);
						if ($getDetail->otp_status == 1) {
							$otp = $data['crypto_otp'];
							if ($userotp == $otp) {
								goto next;
							} else {
								$response = array('status' => '0', 'msg' => 'Invalid OTP');
								echo json_encode($response);exit;
							}
						} else {
							$response = array('status' => '0', 'msg' => 'Enter OTP');
							echo json_encode($response);exit;
						}
					}
					next:

					if ($getDetail->with_status == 0) {
						$response = array('status' => '0', 'msg' => 'Please enable Withdraw Password');
						echo json_encode($response);exit;
					}

					if (!Hash::check($withPass, $getDetail->with_pass)) {
						$response = array('status' => '0', 'msg' => 'Invalid withdraw password');
						echo json_encode($response);exit;
					}

					$amount = strip_tags($data['crypto_amount']);
					$coin_address = strip_tags($data['coin_address']);
					$withPass = $userId . strip_tags($data['with_pass']);
					$strlen = strlen($coin_address);
					if ($strlen > 150) {
						$response = array('status' => '0', 'msg' => 'Enter valid address');
						echo json_encode($response);exit;
					}

					$currencycategorys = User::CurrencyCategory("Crypto");
					if (in_array($currency, $currencycategorys)) {
						$currencyResult = User::CurrencyCategoryResult($currency);
						$data['payment_method'] = $currencyResult[0];
					} else {
						$data['payment_method'] = "Bank";
					}

					$settings = WithdrawSettings::where('currency', strip_tags($data['crypto_currency']))->first();
					$userbalance = Wallet::where('user_id', $userId)->first();
					$balance = $userbalance->$currency;
					if ($balance >= $amount) {
						if ($amount >= $settings->min && $amount <= $settings->max) {
							$limitDay = $settings->withdraw_limit_day;
							$getWithdrawCount = Withdraw::where('user_id', $userId)->whereDate('created_at', date('Y-m-d'))->where('currency', $currency)->sum('amount');
							if ($getWithdrawCount < $limitDay) {
								$fee_per = $settings->fee;
								if ($settings->fee_type == 'percent') {
									$fee_amt = ($amount * $fee_per) / 100;
								} else {
									$fee_amt = $fee_per;
								}
								$total = $amount - $fee_amt;
								$destiTag = strip_tags($data['coin_tag']);
								$transaction_number = User::randomString(8);

								$insdata = array('amount' => $amount, 'currency' => $currency, 'payment_method' => $data['payment_method'], 'fee_per' => $fee_per, 'status' => 'in progress', 'user_id' => $userId, 'ip_addr' => $ip, 'destination_tag' => $destiTag);
								$coin_array = Currency::where('status', 1)->select('currency_symbol')->get()->toArray();
								if ($coin_address != '' && in_array($currency, $coin_array)) {
									$txnExists = self::checkUserAddress($currency, $coin_address, $destiTag);
									$insdata['trans_type'] = ($txnExists == 'true') ? 'External' : 'Internal';
								}
								$insdata['address_info'] = strip_tags($data['coin_address']);
								$insdata['fees_amt'] = number_format($fee_amt, 8, '.', '');
								$insdata['total'] = number_format($total, 8, '.', '');
								$insdata['transaction_number'] = $transaction_number;
								$rand = time() . '12' . mt_rand(0, 999999);
								$insdata['rcode'] = $rand;
								$insdata['expire_at'] = date('Y-m-d H:i:s', strtotime("+10 minutes"));
								$insdata['app_site'] = 'app';

								if ($currency == 'INR') {
									$equiv_inr = $amount;
								} else {
									$lastPrice = get_tradePrice($currency);
									$equiv_inr = $amount * $lastPrice;
								}
								$equiv_inr = number_format($equiv_inr, 2, '.', '');
								$inrWith = $InrWithdraw + $equiv_inr;
								if ($InrDeposit >= $inrWith) {
									$dis_with = 1;
								} else if ($InrDeposit < $inrWith) {
									$dis_with = 0;
								}

								$insdata['equiv_inr'] = $equiv_inr;

								$createWithdraw = Withdraw::create($insdata);
								$txId = $createWithdraw->id;

								$updatebalance = $balance - $amount;
								if ($currency == "INR") {
									$updatebalance = number_format($updatebalance, 2, '.', '');
								} else {
									$updatebalance = number_format($updatebalance, 8, '.', '');
								}
								$remarks = 'Withdraw request placed for ' . $amount . ' ' . $currency . ' Old balance: ' . $balance;
								$update = Wallet::where('user_id', $userId)->update([$currency => $updatebalance, 'remarks' => $remarks]);
								User::where('id', $userId)->update(['mobile_otp' => '', 'InrWithdraw' => $inrWith]);

								if ($createWithdraw) {
									$withdrawId = encrypText($txId);
									$uId = encrypText($userId);
									$rand = encrypText($rand);
									$securl1 = URL::to('confirmWithdraw/' . $withdrawId . '/' . $uId . '/' . $rand);
									$securl2 = URL::to('rejectWithdraw/' . $withdrawId . '/' . $uId . '/' . $rand);
									if ($currency == 'INR') {
										$amount = number_format($amount, 2, '.', '');
										$fees_amt = number_format($fee_amt, 2, '.', '');
									} else {
										$amount = number_format($amount, 8, '.', '');
										$fees_amt = number_format($fee_amt, 8, '.', '');
									}
									$getEmail = EmailTemplate::where('id', 9)->first();

									$message = 'You have requested withdrawal of ' . $amount . " " . $currency;
									$message1 = 'Double check the address before confirming the withdrawal';

									$addr = 'Address ' . strip_tags($data['coin_address']);
									$getSiteDetails = Controller::getEmailTemplateDetails();

									if ($dis_with == 0) {
										$getEmail3 = EmailTemplate::where('id', 52)->first();
										$info3 = array('###USER###' => $getDetail->consumer_name);
										$replace3 = array_merge($getSiteDetails, $info3);
										$emaildata3 = array('content' => strtr($getEmail3->template, $replace3));
										$toDetails3['useremail'] = $getSiteDetails['contact_mail_id'];
										$toDetails3['subject'] = $getEmail3->subject;
										$toDetails3['from'] = $getSiteDetails['contact_mail_id'];
										$toDetails3['name'] = $getSiteDetails['site_name'];
										$sendEmail3 = Controller::sendEmail($emaildata3, $toDetails3);
									}

									$info = array('###USER###' => $getDetail->consumer_name, '###LINK1###' => $securl1, '###LINK2###' => $securl2, '###AMT###' => $amount . " " . $currency, '###FEE###' => $fees_amt . " " . $currency, '###MESSAGE###' => $message, '###MESSAGE1###' => $message1, '###ADDRESS###' => $addr);
									$replace = array_merge($getSiteDetails, $info);

									$emaildata = array('content' => strtr($getEmail->template, $replace));
									$toDetails['useremail'] = decrypText($getDetail->user_mail_id) . '@' . decrypText($getDetail->unusual_user_key);
									$toDetails['subject'] = $getEmail->subject;
									$toDetails['from'] = $getSiteDetails['contact_mail_id'];
									$toDetails['name'] = $getSiteDetails['site_name'];

									$sendEmail = Controller::sendEmail($emaildata, $toDetails);

									if (count(Mail::failures()) > 0) {
										$response = array('status' => '0', 'msg' => trans('app_lang.Email sending failed.'));
									} else {
										$devicetoken = $getDetail->device_token;
										$title = 'Crypto Withdraw';
										$msg = $amount . " " . $currency . ' Withdraw request confirmation sent to your registered email.';
										self::sendnotification($title, $msg, $devicetoken);
										$response = array('status' => '1', 'msg' => $amount . " " . $currency . ' Withdraw request confirmation sent to your registered email.');
									}
								} else {
									$response = array('status' => '0', 'msg' => trans('app_lang.Failed to update withdraw.'));
								}
							} else {
								$response = array('status' => '0', 'msg' => 'You reached maximum Withdraw Limit of the day');
							}
						} else {
							$response = array('status' => '0', 'msg' => 'Enter the amount Minimum Amount ' . $settings->min . ' ' . $currency . " - Maximum Amount " . $settings->max . ' ' . $currency);
						}
					} else {
						$response = array('status' => '0', 'msg' => trans('app_lang.You have not enough balance.'));
					}
				} else {
					$response = array('status' => '0', 'msg' => trans('app_lang.Your KYC documents not verified yet.'));
				}
			} else {
				$response = array('status' => '0', 'msg' => 'Withdraw Under Maintenance');
			}
		} else {
			$response = array('status' => '0', 'msg' => 'Please login to continue');
		}
		echo json_encode($response);
	}

	public function updateWithdrawFiatCurrency() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$currency = strip_tags($data['fiat_currency']);
			$instant = strip_tags($data['instant']);
			$withPass = $userId . strip_tags($data['fiat_with_pass']);

			if ($instant == 1) {
				$with_set = WithdrawSettings::where('currency_type', 'Fiat')->where('instant', '1')->where('currency', strip_tags($currency))->first();
			} else if ($instant == 2) {
				$with_set = WithdrawSettings::where('currency_type', 'Fiat')->where('neft', '1')->where('currency', strip_tags($currency))->first();
			} else {
				$with_set = WithdrawSettings::where('currency_type', 'Fiat')->where('standard', '1')->where('currency', strip_tags($currency))->first();
			}
			if (count($with_set) > 0) {
				$settings = $with_set;
				$Validation = Validator::make($data, User::$withdrawFiatRule);
				if ($Validation->fails()) {
					foreach ($Validation->messages()->getMessages() as $field_name => $message) {
						$response = array('status' => '0', 'msg' => $message[0]);
						echo json_encode($response);exit;
					}
				}
				$user_acc = strip_tags($data['user_bank']);
				$getDetail = User::select('id', 'consumer_name', 'tfa_status', 'secret', 'user_mail_id', 'unusual_user_key', 'verified_status', 'mobile_otp', 'otp_status', 'device_token', 'pro_user', 'InrDeposit', 'InrWithdraw', 'with_status', 'with_pass')->where('id', $userId)->with('wallet')->first();
				$pro_user = $getDetail->pro_user;
				$InrWithdraw = $getDetail->InrWithdraw;
				$InrDeposit = $getDetail->InrDeposit;
				$pro_user = 0;

				if ($getDetail->verified_status != 3) {
					$response = array('status' => '0', 'msg' => trans('app_lang.Please verify your KYC documents.'));
					echo json_encode($response);exit;
				}

				if ($pro_user == 1) {
					$response = array('status' => '0', 'msg' => 'Withdraw Under Maintenance');
					echo json_encode($response);exit;
				}

				if ($getDetail->tfa_status == 'enable') {
					require_once app_path('Model/Googleauthenticator.php');
					$googleAuth = new Googleauthenticator();
					$verify = $googleAuth->verifyCode($getDetail->secret, $data['fiat_auth_key'], $discrepancy = 2);
					if ($verify == 1) {
						goto next;
					} else {
						$response = array('status' => '0', 'msg' => trans('app_lang.Invalid authentication key.'));
						echo json_encode($response);exit;
					}
				} else {
					$userotp = decrypText($getDetail->mobile_otp);
					if ($getDetail->otp_status == 1) {
						$otp = $data['fiat_otp'];
						if ($userotp == $otp) {
							goto next;
						} else {
							$response = array('status' => '0', 'msg' => 'Invalid OTP');
							echo json_encode($response);exit;
						}
					} else {
						$response = array('status' => '0', 'msg' => 'Enter OTP');
						echo json_encode($response);exit;
					}
				}
				next:

				if ($getDetail->with_status == 0) {
					$response = array('status' => '0', 'msg' => 'Please enable Withdraw Password');
					echo json_encode($response);exit;
				}

				if (!Hash::check($withPass, $getDetail->with_pass)) {
					$response = array('status' => '0', 'msg' => 'Invalid withdraw password');
					echo json_encode($response);exit;
				}

				$amount = strip_tags($data['withdraw_amount']);

				$data['payment_method'] = "bank";

				$Validation = Validator::make($data, User::$withdrawBankRule);
				if ($Validation->fails()) {
					$response = array('status' => '0', 'msg' => $Validation->messages());
					echo json_encode($response);exit;
				}
				$getBankDetails = UserBank::where('user_id', $userId)->where('currency', 'INR')->where('acc_number', $user_acc)->select('acc_number', 'acc_name', 'bank_iban', 'bank_branch', 'bank_name', 'bank_swift', 'country', 'postal', 'beneId_status', 'beneId')->first();
				if (empty($getBankDetails)) {
					$response = array('status' => '0', 'msg' => trans('app_lang.Please add bank for selected currency'));
					echo json_encode($response);exit;
				}
				$encodeBankDetails = json_encode($getBankDetails);

				$userbalance = $getDetail->wallet;
				$balance = $userbalance->$currency;
				if ($currency == 'INR') {
					if ($instant == 1) {
						$min = $settings->instant_min;
						$max = $settings->instant_max;
					} else if ($instant == 2) {
						$min = $settings->neft_min;
						$max = $settings->neft_max;
					} else {
						$min = $settings->min;
						$max = $settings->max;
					}
				} else {
					$min = $settings->min;
					$max = $settings->max;
				}
				if ($balance >= $amount) {
					if ($amount >= $min && $amount <= $max) {
						$limitDay = $settings->withdraw_limit_day;
						$getWithdrawCount = Withdraw::where('user_id', $userId)->whereDate('created_at', date('Y-m-d'))->where('currency', $currency)->sum('amount');
						if ($getWithdrawCount < $limitDay) {
							$fee_type = $settings->fee_type;
							$fee_per = $fee_amt = $settings->fee;
							if ($fee_type == 'amount') {
								$total = $amount - $fee_amt;
							} else {
								$fee_amt = ($amount * $fee_amt) / 100;
								$total = $amount - $fee_amt;
							}
							if ($total >= '0.01') {
								$ip = Controller::getIpAddress();
								if ($currency == 'USDT') {
									$conv_price = get_inr_price('USDT');
								} else {
									$conv_price = 0;
								}
								$insdata = array('amount' => $amount, 'currency' => $currency, 'payment_method' => $data['payment_method'], 'fee_per' => $fee_per, 'status' => 'in progress', 'user_id' => $userId, 'ip_addr' => $ip, 'conv_price' => $conv_price, 'instant' => strip_tags($data['instant']));
								$transaction_number = User::randomString(8);
								$insdata['transaction_number'] = $transaction_number;

								$insdata['withdraw_bank_info'] = $encodeBankDetails;
								$insdata['fees_amt'] = number_format($fee_amt, 2, '.', '');
								$insdata['total'] = number_format($total, 2, '.', '');
								$rand = time() . '12' . mt_rand(0, 999999);
								$insdata['rcode'] = $rand;
								$insdata['expire_at'] = date('Y-m-d H:i:s', strtotime("+10 minutes"));
								$insdata['app_site'] = 'app';

								if ($currency == 'INR') {
									$equiv_inr = $amount;
								} else {
									$lastPrice = get_tradePrice($currency);
									$equiv_inr = $amount * $lastPrice;
								}
								$equiv_inr = number_format($equiv_inr, 2, '.', '');
								$inrWith = $InrWithdraw + $equiv_inr;
								if ($InrDeposit >= $inrWith) {
									$dis_with = 1;
								} else if ($InrDeposit < $inrWith) {
									$dis_with = 0;
								}

								$insdata['equiv_inr'] = $equiv_inr;
								$createWithdraw = Withdraw::create($insdata);
								$txId = $createWithdraw->id;

								$updatebalance = $balance - $amount;
								$updatebalance = number_format($updatebalance, 2, '.', '');
								$remarks = 'Withdraw request placed for ' . $amount . ' ' . $currency . ' Old balance: ' . $balance;
								Wallet::where('user_id', $userId)->update([$currency => $updatebalance, 'remarks' => $remarks]);
								User::where('id', $userId)->update(['mobile_otp' => '', 'InrWithdraw' => $inrWith]);

								if ($createWithdraw) {
									$withdrawId = encrypText($txId);
									$uId = encrypText($userId);
									$rand = encrypText($rand);

									$securl1 = URL::to('confirmWithdraw/' . $withdrawId . '/' . $uId . '/' . $rand);
									$securl2 = URL::to('rejectWithdraw/' . $withdrawId . '/' . $uId . '/' . $rand);
									if ($currency == 'INR') {
										$amount = number_format($amount, 2, '.', '');
										$fees_amt = number_format($fee_amt, 2, '.', '');
									} else {
										$amount = number_format($amount, 8, '.', '');
										$fees_amt = number_format($fee_amt, 8, '.', '');
									}
									$getEmail = EmailTemplate::where('id', 9)->first();
									$getSiteDetails = Controller::getEmailTemplateDetails();

									if ($dis_with == 0) {
										$getEmail3 = EmailTemplate::where('id', 52)->first();
										$info3 = array('###USER###' => $getDetail->consumer_name);
										$replace3 = array_merge($getSiteDetails, $info3);
										$emaildata3 = array('content' => strtr($getEmail3->template, $replace3));
										$toDetails3['useremail'] = $getSiteDetails['contact_mail_id'];
										$toDetails3['subject'] = $getEmail3->subject;
										$toDetails3['from'] = $getSiteDetails['contact_mail_id'];
										$toDetails3['name'] = $getSiteDetails['site_name'];
										$sendEmail3 = Controller::sendEmail($emaildata3, $toDetails3);
									}

									$info = array('###USER###' => $getDetail->consumer_name, '###LINK1###' => $securl1, '###LINK2###' => $securl2, '###AMT###' => $amount . " " . $currency, '###FEE###' => $fees_amt . " " . $currency, '###MESSAGE###' => '', '###ADDRESS###' => '', '###MESSAGE1###' => '');
									$replace = array_merge($getSiteDetails, $info);

									$emaildata = array('content' => strtr($getEmail->template, $replace));
									$toDetails['useremail'] = decrypText($getDetail->user_mail_id) . '@' . decrypText($getDetail->unusual_user_key);
									$toDetails['subject'] = $getEmail->subject;
									$toDetails['from'] = $getSiteDetails['contact_mail_id'];
									$toDetails['name'] = $getSiteDetails['site_name'];

									$sendEmail = Controller::sendEmail($emaildata, $toDetails);
									if (count(Mail::failures()) > 0) {
										$response = array('status' => '0', 'msg' => trans('app_lang.Email sending failed'));
									} else {
										$devicetoken = $getDetail->device_token;
										$title = 'Fiat Withdraw';
										$msg = $amount . " " . $currency . ' Withdraw confirmation sent to your registered email.';
										self::sendnotification($title, $msg, $devicetoken);
										$response = array('status' => '1', 'msg' => $amount . " " . $currency . ' Withdraw confirmation sent to your registered email.');
									}
								} else {
									$response = array('status' => '0', 'msg' => trans('app_lang.Failed to update withdraw'));
								}
							} else {
								$response = array('status' => '0', 'msg' => 'Your Received Amount Minium 0.01 ' . $currency);
							}
						} else {
							$response = array('status' => '0', 'msg' => 'You reached maximum Withdraw Limit of the day');
						}
					} else {
						$response = array('status' => '0', 'msg' => "Please enter the amount Minimum Amount" . $settings->min . " " . $currency . " - Maximum Amount" . $settings->max . " " . $currency);
					}
				} else {
					$response = array('status' => '0', 'msg' => 'You have not enough balance');
				}
			} else {
				$response = array('status' => '0', 'msg' => 'Withdraw Under Maintenance');
			}
		} else {
			$response = array('status' => '0', 'msg' => 'Please login to continue');
		}
		echo json_encode($response);
	}

	public function checkLabelExists() {
		$data = Input::all();
		$label = strip_tags($data['label']);
		$getCount = SavedAddress::where('lable', $label)->count();
		$msg = ($getCount > 0) ? "false" : "true";
		$status = ($getCount > 0) ? 0 : 1;
		$response = array('status' => $status, 'msg' => $msg);
		echo json_encode($response);exit;
	}

	public function addAddress() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$Validation = Validator::make($data, [
				'add_curr' => 'required',
				'add_address' => 'required',
				'label' => 'required',
			], [
				'add_curr.required' => 'Currency required',
				'add_address.required' => 'Address required',
				'label.required' => 'Label required',
			]);
			if ($Validation->fails()) {
				foreach ($Validation->messages()->getMessages() as $field => $message) {
					$response = array('success' => 0, 'message' => $message[0]);
					echo json_encode($response);exit;
				}
			}

			$now = date('Y-m-d H:i:s');
			$currency = strip_tags($data['add_curr']);
			$address = strip_tags($data['add_address']);
			$getCount = SavedAddress::where('address', $address)->where('currency', $currency)->where('user_id', $userId)->count();
			if ($getCount) {
				$response = array('success' => 0, 'message' => 'Address already exists');
				echo json_encode($response);exit;
			}
			if (isset($data['tag'])) {
				$tag = strip_tags($data['tag']);
			} else {
				$tag = '';
			}
			$lable = strip_tags($data['label']);
			$create = array(
				'user_id' => $userId,
				'currency' => $currency,
				'status' => 'active',
				'address' => $address,
				'lable' => $lable,
				'tag' => $tag,
				'created_at' => $now,
			);
			$result = SavedAddress::create($create);
			if ($result) {
				$response = array('success' => 1, 'message' => "Address saved successfully");
			} else {
				$response = array('success' => 0, 'message' => "Please try again");
			}
		} else {
			$response = array('success' => 0, 'message' => "Login and continue");
		}
		echo json_encode($response);exit;
	}

	public function deleteAddress() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$Validation = Validator::make($data, [
				'delete_curr' => 'required',
				'delete_address' => 'required',
			], [
				'delete_curr.required' => 'Currency required',
				'delete_address.required' => 'Address required',
			]);
			if ($Validation->fails()) {
				foreach ($Validation->messages()->getMessages() as $field => $message) {
					$response = array('success' => 0, 'message' => $message[0]);
					echo json_encode($response);exit;
				}
			}
			$currency = strip_tags($data['delete_curr']);
			$address = strip_tags($data['delete_address']);
			$getAddress = SavedAddress::where('address', $address)->where('currency', $currency)->where('user_id', $userId);
			$getCount = $getAddress->count();
			if ($getCount) {
				$result = $getAddress->delete();
				$response = array('success' => 1, 'message' => "Address deleted successfully");
			} else {
				$response = array('success' => 0, 'message' => "Invalid Address");
			}
		} else {
			$response = array('success' => 0, 'message' => "Login and continue");
		}
		echo json_encode($response);exit;
	}

	public function viewBank() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$userbank = UserBank::where('user_id', $userId)->orderBy('id', 'desc')->select('id', 'acc_name', 'acc_number', 'bank_name', 'bank_branch', 'bank_swift', 'country', 'currency', 'status', 'acc_type', 'bank_proof')->get();
			$response = array('status' => '1', 'result' => $userbank);
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);
	}

	public function checkAccnoExists() {
		$data = Input::all();
		$userId = $data['user_id'];
		$acc_number = strip_tags($data['account_number']);
		$update_type = strip_tags($data['type']);
		if ($update_type == 2) {
			$getCount = UserBank::where('acc_number', $acc_number)->where('user_id', '!=', $userId)->count();
		} else {
			$getCount = UserBank::where('acc_number', $acc_number)->count();
		}
		$status = ($getCount > 0) ? "0" : "1";
		$msg = ($getCount > 0) ? "false" : "true";
		$response = array('status' => $status, 'msg' => $msg);
		echo json_encode($response);
	}

	public function updateBank() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$Validation = Validator::make($data, [
				'ifsc_number' => 'required',
				'bank_name' => 'required',
				'account_number' => 'required',
				'account_name' => 'required',
				'account_type' => 'required',
				'bank_branch' => 'required',
				'proof' => 'required',
			], [
				'ifsc_number.required' => 'IFSC required',
				'bank_name.required' => 'Bank Name required',
				'account_number.required' => 'Account Number required',
				'account_name.required' => 'Account Name required',
				'account_type.required' => 'Account Type required',
				'bank_branch.required' => 'Bank Branch required',
				'proof.required' => 'Bank proof required',
			]);
			if ($Validation->fails()) {
				foreach ($Validation->messages()->getMessages() as $field => $message) {
					$response = array('status' => '0', 'msg' => $message[0]);
					echo json_encode($response);exit;
				}
			}

			$getProfile = User::getProfile($userId);
			$currency = 'INR';
			$type = strip_tags($data['update_type']);
			$bank_proof = strip_tags($data['proof']);
			$bank_swift = strip_tags($data['ifsc_number']);
			$insdata = array('bank_name' => strip_tags($data['bank_name']), 'bank_swift' => strtoupper($bank_swift), 'acc_name' => strip_tags($data['account_name']), 'acc_number' => strip_tags($data['account_number']), 'bank_branch' => strip_tags($data['bank_branch']), 'status' => '2', 'currency' => $currency, 'acc_type' => strip_tags($data['account_type']));
			if ($type == 2) {
				$bankId = strip_tags($data['bankId']);
				$bank_detail = UserBank::where('id', $bankId)->select('status', 'bank_proof')->first();
				$bank_status = $bank_detail->status;
				if ($bank_status != '1') {
					if ($bank_proof == "") {
						$insdata['bank_proof'] = $bank_detail->bank_proof;
					} else {
						$insdata['bank_proof'] = $bank_proof;
					}
					$createBank = UserBank::where('id', $bankId)->update($insdata);
					$msg1 = $getProfile['user']->consumer_name . " has updated bank details.";
					$sessionMessage = trans('app_lang.Bank details Updated Successfully');
				} else {
					$response = array('status' => '0', 'msg' => 'Your bank account already verified by admin');
					echo json_encode($response);exit;
				}
			} else {
				$checkBank = UserBank::where('user_id', $userId)->where('currency', $currency)->count();
				if ($checkBank >= 5) {
					$response = array('status' => '0', 'msg' => 'Bank limit reached');
					echo json_encode($response);exit;
				}
				$insdata['user_id'] = $userId;
				$insdata['bank_proof'] = $bank_proof;
				$createBank = UserBank::create($insdata);
				$msg1 = $getProfile['user']->consumer_name . " has added bank details.";
				$sessionMessage = trans('app_lang.Bank details Added Successfully');
			}
			if ($createBank) {
				$notifydata = array('admin_id' => 1, 'type' => 'KYC', 'message' => $msg1, 'status' => 'unread');
				AdminNotification::create($notifydata);
				$response = array('status' => '1', 'msg' => $sessionMessage);
			} else {
				$response = array('status' => '0', 'msg' => trans('app_lang.Failed to update.'));
			}
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);
	}

	public function deleteUserBank() {
		$data = Input::all();
		$bankId = $data['bankId'];
		if ($bankId != "") {
			$quote = UserBank::where(['id' => strip_tags($bankId)])->delete();
			if ($quote) {
				$response = array('status' => 1, 'message' => trans('app_lang.bank_deleted_success'));
			} else {
				$response = array('status' => 0, 'message' => trans('app_lang.bank_deleted_fail'));
			}
		} else {
			$response = array('status' => 0, 'message' => "Invalid request");
		}
		echo json_encode($response);
	}

	public function country() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$country = Country::all();if ($country->isEmpty()) {$country = array();}
			$response['status'] = 1;
			$response['country'] = $country;
		} else {
			$response = array('status' => '0', 'msg' => 'Please login to continue');
		}
		echo json_encode($response);exit;
	}

	public function settings() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$base_url = URL::to('/');

			require_once app_path('Model/Googleauthenticator.php');
			$googleAuth = new Googleauthenticator();

			$getProfile = User::where('id', $userId)->select('consumer_name', 'phone', 'first_name', 'last_name', 'address', 'country', 'user_mail_id', 'unusual_user_key', 'verified_status', 'notify_tfa', 'notify_new_device', 'notify_password', 'profile_picture', 'dob', 'city', 'state', 'secret', 'tfa_url', 'tfa_status')->first();
			$first = decrypText($getProfile['user_mail_id']);
			$second = decrypText($getProfile['unusual_user_key']);
			$useremailid = $first . "@" . $second;
			if ($getProfile->secret == "" && $getProfile->tfa_url == "") {
				$secret = $googleAuth->createSecret();
				$tfaUrl = $googleAuth->getQRCodeGoogleUrl(SITENAME."(" . $useremailid . ")", $secret);
				User::where('id', $userId)->update(['secret' => $secret, 'tfa_url' => $tfaUrl]);
				$getProfile['secret'] = $secret;
				$getProfile['tfa_url'] = $tfaUrl;
			}
			$verification = ConsumerVerification::where('user_id', $userId)->select('id_proof', 'id_status', 'id_proof1', 'id_status1', 'addr_proof', 'addr_status', 'id_num')->first();
			$verification['verified_status'] = $getProfile->verified_status;
			$userbank = UserBank::where('user_id', $userId)->select('id', 'acc_name', 'acc_number', 'bank_name', 'bank_branch', 'bank_swift', 'country', 'currency', 'status', 'beneId_status')->orderBy('id', 'asc')->get();
			if ($userbank->isEmpty()) {$userbank = array();}
			$notify = UserNotification::where('user_id', $userId)->select('type', 'message', 'created_at')->orderBy('id', 'desc')->get();
			$response['status'] = 1;
			$response['profile'] = $getProfile;
			$response['email'] = $useremailid;
			$response['verification'] = $verification;
			$response['notify'] = $notify;
			$response['userbank'] = $userbank;
		} else {
			$response = array('status' => '0', 'msg' => 'Please login to continue');
		}
		echo json_encode($response);exit;
	}

	public function sendOtp() {
		$data = Input::all();

		$validate = Validator::make($data, [
			'phone' => "required",
			'type' => "required",
		], [
			'phone.required' => 'Enter phone',
			'type.required' => 'Enter type',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}

		$userId = strip_tags($data['user_id']);
		$phone = strip_tags($data['phone']);
		$type = strip_tags($data['type']);
		if ($phone != "") {
			$user = User::where('id', $userId)->select('otp_phone', 'otp_status', 'user_mail_id', 'unusual_user_key', 'consumer_name')->first();
			if ($user) {
				if ($type == 1) {
					if ($user->otp_status == 1 && $user->otp_phone == $phone) {
						$response = array('status' => '0', 'msg' => 'Mobile number already verified');
						echo json_encode($response);exit;						
					}
					$exist = User::where('phone', $phone)->where('id', '!=', $userId)->count();
					if ($exist > 0) {
						$response = array('status' => '0', 'msg' => "Mobile number already exists");
						echo json_encode($response);exit;	
					}
				}
				$first = decrypText($user->user_mail_id);
				$second = decrypText($user->unusual_user_key);
				$email = $first . "@" . $second;

				$key = TWOFACTORKEY;
				$otp = randomInteger(6);

				$url = "http://2factor.in/API/V1/" . $key . "/ADDON_SERVICES/SEND/TSMS";
				$data = ['From' => TWOFACTORSENDER, 'To' => $phone, 'TemplateName' => 'sms_otp', 'VAR1' => $otp];

				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
				$response = curl_exec($ch);
				curl_close($ch);

				$getEmail = EmailTemplate::where('id', 39)->first();
				$getSiteDetails = Controller::getEmailTemplateDetails();
				$info = array('###USER###' => $user->consumer_name, '###OTP###' => $otp);
				$replace = array_merge($getSiteDetails, $info);
				$emaildata = array('content' => strtr($getEmail->template, $replace));

				$toDetails['useremail'] = $email;
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails['contact_mail_id'];
				$toDetails['name'] = $getSiteDetails['site_name'];
				$sendEmail = Controller::sendOtpEmail($emaildata, $toDetails);

				$res = json_decode($response, true);
				if ((isset($res['Status']) && $res['Status'] == "Success") || $sendEmail) {
					User::where('id', $userId)->update(['otp_phone' => $phone, 'mobile_otp' => encrypText($otp)]);
					$response = array('status' => '1', 'msg' => "OTP sent successfully", 'otp' => $otp);
				} else {
					$response = array('status' => '0', 'msg' => "Failed to send OTP");
				}
			} else {
				$response = array('status' => '0', 'msg' => "Invalid User");
			}
		} else {
			$response = array('status' => '0', 'msg' => "Enter Phone number");
		}
		echo json_encode($response);exit;
	}

	public function updateProfile() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$Validation = Validator::make($data, User::$profileRule);
			if ($Validation->fails()) {
				foreach ($Validation->messages()->getMessages() as $field_name => $message) {
					$response = array('status' => '0', 'msg' => $message[0]);
					echo json_encode($response);exit;
				}
			} else {
				$getUser = User::where('id', $userId)->select('profile_picture', 'otp_phone', 'mobile_otp', 'otp_status', 'country')->first();
				if ($getUser->country == 'India') {
					if ($getUser->otp_status == 1) {
						if (isset($data['otp']) && $data['otp'] != "") {
							$otp = strip_tags($data['otp']);
							if (encrypText($otp) != $getUser->mobile_otp) {
								$response = array('status' => '0', 'msg' => "Invalid OTP");
								echo json_encode($response);exit;
							}
						} else {
							$response = array('status' => '0', 'msg' => "Enter OTP");
							echo json_encode($response);exit;
						}
					}

					if (strlen($data['phone']) != 10) {
						$response = array('status' => '0', 'msg' => "Enter 10 digits only");
						echo json_encode($response);exit;
					}
				}
				if (strip_tags($data['country']) == 'India') {
					$otp_status = 1;
				} else {
					$otp_status = 0;
				}
				$userName = strip_tags($data['firstname']) . " " . strip_tags($data['lastname']);
				$result = User::where('id', $userId)->update(['first_name' => strip_tags($data['firstname']), 'last_name' => strip_tags($data['lastname']), 'address' => strip_tags($data['address']), 'city' => strip_tags($data['city']), 'state' => strip_tags($data['state']), 'country' => strip_tags($data['country']), 'dob' => strip_tags($data['dob']), 'profile_picture' => strip_tags($data['profile']), 'phone' => strip_tags($data['phone']), 'mobile_otp' => '', 'otp_status' => 1]);
				if ($result) {
					ConsumerVerification::where('user_id', $userId)->update(['profile_update' => 1]);
					$response = array('status' => '1', 'msg' => trans('app_lang.Profile updated successfully'));
				} else {
					$response = array('status' => '0', 'msg' => trans('app_lang.Failed to update profile!'));
				}
			}
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);exit;
	}

	public function checkUserPassword() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$pwd = encrypText($data['current_pwd']);
			$getCount = User::where('id', $userId)->where('user_protect_key', $pwd)->count();
			echo ($getCount == 1) ? "true" : "false";
		} else {
			echo "false";
		}
	}

	public function updateUserProfilePassword() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$profile_update = ConsumerVerification::where('user_id', $userId)->select('profile_update')->first()->profile_update;
			if ($profile_update != 1) {
				$response = array('status' => '0', 'msg' => trans('app_lang.Please complete your profile details'));
				echo json_encode($response);exit;
			}
			$data = Input::all();
			$Validation = Validator::make($data, User::$changePasswordRule);
			if ($Validation->fails()) {
				foreach ($Validation->messages()->getMessages() as $field_name => $message) {
					$response = array('status' => '0', 'msg' => $message[0]);
					echo json_encode($response);exit;
				}
			} else {
				if ($data == array_filter($data)) {
					$new_pwd = strip_tags($data['new_pwd']);
					$confirm_pwd = strip_tags($data['confirm_pwd']);
					$pwd = encrypText(strip_tags($data['current_pwd']));
					$getUser = User::where('id', $userId)->where('user_protect_key', $pwd)->select('tickets')->first();
					$getCount = count($getUser);
					if ($getCount == 1) {
						if ($new_pwd == $confirm_pwd) {
							$updateData = encrypText($confirm_pwd);
							$passtickets = $getUser->tickets;

							$tickets = unserialize($passtickets);
							if (in_array($updateData, $tickets)) {
								$response = array('status' => '0', 'msg' => 'You are not supposed to use last 5 passwords');
								echo json_encode($response);exit;
							}

							if (is_array($tickets)) {
								array_unshift($tickets, $updateData);
								$old_passwords = array_slice($tickets, 0, 5);
							} else {
								$old_passwords = array($updateData);
							}

							$old_passwords = serialize($old_passwords);
							$randnum = randomString(10);

							$result = User::where('id', $userId)->update(['user_protect_key' => $updateData, 'changepassword_time' => time(), 'tickets' => $old_passwords, 'session_id' => $randnum]);

							if ($result) {
								$getCount_notify = User::where('id', $userId)->select('consumer_name', 'id', 'user_mail_id', 'unusual_user_key', 'notify_password')->first();
								if ($getCount_notify['notify_password'] == 1) {

									$first = decrypText($getCount_notify['user_mail_id']);
									$second = decrypText($getCount_notify['unusual_user_key']);
									$useremailid = $first . "@" . $second;
									$notf_msg2 = trans('app_lang.hi');
									$notf_msg3 = trans('app_lang.new_password_change_success');
									$msg1 = $notf_msg2 . " " . $getCount_notify['consumer_name'] . ", " . $notf_msg3;
									$insdata = array('user_id' => $getCount_notify['id'], 'type' => 'Change-Password', 'message' => $msg1, 'status' => 'unread');
									UserNotification::create($insdata);

									$getEmail = EmailTemplate::where('id', 24)->first();
									$getSiteDetails = Controller::getEmailTemplateDetails();
									$info = array('###USER###' => $getCount_notify['consumer_name']);

									$replace = array_merge($getSiteDetails, $info);

									$emaildata = array('content' => strtr($getEmail->template, $replace));
									$toDetails['useremail'] = $useremailid;
									$toDetails['subject'] = $getEmail->subject;
									$toDetails['from'] = $getSiteDetails['contact_mail_id'];
									$toDetails['name'] = $getSiteDetails['site_name'];

									$sendEmail = Controller::sendEmail($emaildata, $toDetails);
									if (count(Mail::failures()) > 0) {
										$response = array('status' => '0', 'msg' => trans('app_lang.change_pwd_email_sending_failed'));
									} else {
										$response = array('status' => '1', 'msg' => trans('app_lang.change_pwd_email_sending_success'));
									}
								}
								$response = array('status' => '1', 'msg' => trans('app_lang.password_updated_success'));
							} else {
								$response = array('status' => '0', 'msg' => trans('app_lang.Failed to update password!'));
							}
						} else {
							$response = array('status' => '0', 'msg' => trans('app_lang.Password doesnt match!'));
						}
					} else {
						$response = array('status' => '0', 'msg' => trans('app_lang.Incorrect old password'));
					}
				} else {
					$response = array('status' => '0', 'msg' => trans('app_lang.Enter all fields'));
				}
			}
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);exit;
	}

	public function enableDisableTFa() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$profile_update = ConsumerVerification::where('user_id', $userId)->select('profile_update')->first()->profile_update;
			if ($profile_update != 1) {
				$response = array('status' => '0', 'msg' => trans('app_lang.Please complete your profile details'));
				echo json_encode($response);exit;
			}
			$getUserDetails = User::where('id', $userId)->first();
			$first = decrypText($getUserDetails['user_mail_id']);
			$second = decrypText($getUserDetails['unusual_user_key']);
			$useremailid = $first . "@" . $second;

			require_once app_path('Model/Googleauthenticator.php');
			$googleAuth = new Googleauthenticator();
			if ($googleAuth->verifyCode($data['secret_code'], $data['auth_key'], 1)) {
				if ($data['tfa_status'] == "disable") {
					$updateData = array('secret' => $data['secret_code'], 'tfa_url' => $data['tfa_url'], 'tfa_status' => 'enable');
					$msg = trans('app_lang.TFA enabled successfully');
					$type = 'TFA enabled';
					$notf_msg3 = 'You have enabled 2FA';
					$user_id = encrypText($userId);
				} else {
					$secret = $googleAuth->createSecret();
					$tfaUrl = $googleAuth->getQRCodeGoogleUrl(SITENAME."(" . $useremailid . ")", $secret);
					$updateData = array('secret' => $secret, 'tfa_url' => $tfaUrl, 'tfa_status' => 'disable');
					$type = 'TFA disabled';
					$msg = trans('app_lang.TFA disabled successfully');
					$notf_msg3 = 'You have disabled 2FA';
					$user_id = '';
				}
				$result = User::where('id', $userId)->update($updateData);
				if ($result) {
					$notf_msg1 = trans('app_lang.hi');

					$ip = $_SERVER['REMOTE_ADDR'];
					$msg1 = $notf_msg1 . " ," . $notf_msg3 . "!";
					$insdata = array('user_id' => $userId, 'type' => 'New-user', 'message' => $msg1, 'status' => 'unread', 'ip' => $ip);
					UserNotification::create($insdata);

					if ($getUserDetails['notify_tfa'] == 1) {

						$getEmail = EmailTemplate::where('id', 25)->first();
						$getSiteDetails = Controller::getEmailTemplateDetails();
						$info = array('###USER###' => $getUserDetails['consumer_name'], '###TYPE###' => $type);

						$replace = array_merge($getSiteDetails, $info);

						$emaildata = array('content' => strtr($getEmail->template, $replace));
						$toDetails['useremail'] = $useremailid;
						$toDetails['subject'] = $getEmail->subject;
						$toDetails['from'] = $getSiteDetails['contact_mail_id'];
						$toDetails['name'] = $getSiteDetails['site_name'];

						$sendEmail = Controller::sendEmail($emaildata, $toDetails);

					}
					$response = array('status' => '1', 'msg' => $msg, 'id' => $user_id);
				} else {
					$response = array('status' => '0', 'msg' => trans('app_lang.Failed to update TFA verification.'));
				}
			} else {
				$response = array('status' => '0', 'msg' => trans('app_lang.Invalid 6-digit Authentication Code'));
			}
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);exit;
	}

	public function alertnotification() {
		$data = Input::all();
		$userId = $data['user_id'];
		$profile_update = ConsumerVerification::where('user_id', $userId)->select('profile_update')->first()->profile_update;
		if ($profile_update != 1) {
			$result_show = "2";
			echo $result_show;
		} else {
			$type = strip_tags($data['type']);
			$result_get = User::where('id', $userId)->first();
			$val = $result_get->$type;
			if ($val == '1') {
				$notf_msg = trans('app_lang.deactive_fail');
				$message = $type . " " . $notf_msg;
				$val_res = "";
				$result_show = "0";
				$response = array('status' => '1', 'msg' => 'Deactivated Successfully');
			} else {
				$notf_msg = trans('app_lang.active_success');
				$message = $type . " " . $notf_msg;
				$val_res = "1";
				$result_show = "1";
				$response = array('status' => '1', 'msg' => 'Activated Successfully');
			}
			if (!empty($type)) {
				$result = User::where('id', $userId)->update([$type => $val_res]);
				echo json_encode($response);exit;
			}
		}
	}

	public function checkPanExists() {
		$data = Input::all();
		$userId = $data['user_id'];
		$pancard = strip_tags($data['pancard']);
		$getCount = ConsumerVerification::where('pancard_num', $pancard)->count();
		$msg = ($getCount > 0) ? "false" : "true";
		$status = ($getCount > 0) ? 0 : 1;
		$response = array('status' => $status, 'msg' => $msg);
		echo json_encode($response);exit;
	}

	public function checkIdExists() {
		$data = Input::all();
		$userId = $data['user_id'];
		$id = strip_tags($data['idcard']);
		$getCount = ConsumerVerification::where('id_num', $id)->count();
		$msg = ($getCount > 0) ? "false" : "true";
		$status = ($getCount > 0) ? 0 : 1;
		$response = array('status' => $status, 'msg' => $msg);
		echo json_encode($response);exit;
	}

	public function updateKYC() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$validate = Validator::make($data, [
				'proof1' => "required",
				'proof2' => "required",
				'proof3' => "required",
				'idnum' => "required",
			], [
				'proof1.required' => 'ID proof front side is required',
				'proof2.required' => 'ID proof back side is required',
				'proof3.required' => 'Selfie proof is required',
				'idnum.required' => 'ID number is required',
			]);

			if ($validate->fails()) {
				foreach ($validate->messages()->getMessages() as $val => $msg) {
					$response = array('status' => '0', 'msg' => $msg[0]);
					echo json_encode($response);exit;
				}
			}

			$getPictures = ConsumerVerification::where('user_id', $userId)->first();
			if ($getPictures->profile_update == 1) {
				$idStatus = ($getPictures->id_status == "") ? 0 : $getPictures->id_status;
				$idStatus1 = ($getPictures->id_status1 == "") ? 0 : $getPictures->id_status1;
				$addr_status = ($getPictures->addr_status == "") ? 0 : $getPictures->addr_status;

				$idProof = $getPictures->id_proof;
				$idProof1 = $getPictures->id_proof1;
				$add_proof = $getPictures->addr_proof;

				$idnum = isset($data['idnum']) ? strip_tags($data['idnum']) : $getPictures->id_num;

				if ($idStatus != 3 && $idStatus != 1) {
					$idProof = $data['proof1'];
					$idStatus = 1;
				} else {
					$idProof = $getPictures->id_proof;
				}

				if ($idStatus1 != 3 && $idStatus1 != 1) {
					$idProof1 = $data['proof2'];
					$idStatus1 = 1;
				} else {
					$idProof1 = $getPictures->id_proof1;
				}

				if ($addr_status != 3 && $addr_status != 1) {
					$addr_proof_front = $data['proof3'];
					$addr_status = 1;
				} else {
					$addr_proof_front = $getPictures->addr_proof;
				}

				if ($idStatus == 3 && $idStatus1 == 3 && $addr_status == 3) {
					$verifyStatus = 3;
				} else if ($idStatus == 2 || $idStatus1 == 2 || $addr_status == 2) {
					$verifyStatus = 2;
				} else {
					$verifyStatus = 1;
				}
				$result = ConsumerVerification::where('user_id', $userId)->update(['id_proof' => $idProof, 'addr_proof' => $addr_proof_front, 'id_status' => $idStatus, 'id_proof1' => $idProof1, 'id_status1' => $idStatus1, 'addr_status' => $addr_status, 'id_num' => $idnum]);

				if ($result) {
					User::where('id', $userId)->update(['verified_status' => $verifyStatus]);
					$getProfile = User::getProfile($userId);
					$msg1 = $getProfile['user']->consumer_name . " has submitted KYC document.";
					$insdata = array('admin_id' => 1, 'type' => 'KYC', 'message' => $msg1, 'status' => 'unread');
					AdminNotification::create($insdata);
					$response = array('status' => '1', 'msg' => trans('app_lang.KYC Updated Successfully'));
				} else {
					$response = array('status' => '0', 'msg' => trans('app_lang.Failed to update.'));
				}
			} else {
				$response = array('status' => '0', 'msg' => trans('app_lang.Please complete your profile details'));
			}
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);exit;
	}

	public function enable_key() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$getUserDetails = User::where('id', $userId)->select('user_mail_id', 'unusual_user_key', 'consumer_name')->first();
			$first = decrypText($getUserDetails['user_mail_id']);
			$second = decrypText($getUserDetails['unusual_user_key']);
			$useremailid = $first . "@" . $second;

			$update = User::where('id', $userId)->update(['api_status' => '2']);

			$getEmail = EmailTemplate::where('id', 41)->first();
			$getSiteDetails = Controller::getEmailTemplateDetails();
			$info = array('###USER###' => $getUserDetails['consumer_name'], '###MAIL###' => $useremailid);

			$replace = array_merge($getSiteDetails, $info);

			$emaildata = array('content' => strtr($getEmail->template, $replace));
			$toDetails['useremail'] = $getSiteDetails['contact_mail_id'];
			$toDetails['subject'] = $getEmail->subject;
			$toDetails['from'] = $getSiteDetails['contact_mail_id'];
			$toDetails['name'] = $getSiteDetails['site_name'];
			$sendEmail = Controller::sendEmail($emaildata, $toDetails, '', '');
			if ($sendEmail) {
				$response = array('status' => '1', 'msg' => 'API request send to admin Successfully');
			} else {
				$response = array('status' => '0', 'msg' => 'Please try again!');
			}
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);exit;
	}

	public function support() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$getUserDetails = User::where('id', $userId)->select('user_mail_id', 'unusual_user_key', 'consumer_name')->first();
			$getTickets = HelpCentre::where('user_id', $userId)->orderBy('created_at', 'desc')->groupBy('reference_no')->select('user_id', 'ticket_status', 'subject', 'reference_no', 'created_at', 'id', 'image')->get();
			if (count($getTickets) > 0) {
				foreach ($getTickets as $value) {
					$ticket_status = HelpCentre::where('reference_no', $value->id)->orderBy('created_at', 'desc')->select('ticket_status')->first();

					if ($ticket_status->ticket_status == 'close') {
						$status = trans('app_lang.Close');
					}
					if ($ticket_status->ticket_status == 'active') {
						$status = trans('app_lang.Active');
					}

					$tickets[] = array(
						'user_id' => $value->user_id,
						'ticket_status' => $status,
						'subject' => $value->subject,
						'created_at' => date($value->created_at),
						'id' => encrypText($value->id),
						'reference_no' => encrypText($value->reference_no),
						'ticket_id' => 'NXTKID' . $value->id,
						'image' => $value->image,
					);
				}
			} else {
				$tickets = array();
			}

			$results['helpcategory'] = Helpcategory::all();
			$results['getTickets'] = $tickets;
			$first = decrypText($getUserDetails['user_mail_id']);
			$second = decrypText($getUserDetails['unusual_user_key']);
			$getUserDetail['useremailid'] = $first . "@" . $second;
			$getUserDetail['consumer_name'] = $getUserDetails->consumer_name;
			$results['getUserDetails'] = $getUserDetail;
			$results['getContent'] = Cms::whereIn('id', [17])->select('content', 'title')->get();
			$response = array('status' => '1', 'msg' => $results);
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);exit;
	}

	public function supportSubmit() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$Validation = Validator::make($data, User::$helpRule);
			if ($Validation->fails()) {
				foreach ($Validation->messages()->getMessages() as $field => $message) {
					$response = array('status' => '0', 'msg' => $message[0]);
					echo json_encode($response);exit;
				}
			}
			$help['user_id'] = $userId;
			$help['emailid'] = strip_tags($data['emailid']);
			$help['subject'] = strip_tags($data['subject']);
			$help['description'] = strip_tags($data['description']);
			$help['image'] = strip_tags($data['image']);
			$help['status'] = "unread";
			$help['ticket_status'] = "active";
			$createHelp = HelpCentre::create($help);
			if ($createHelp) {
				$helpId = $createHelp->id;
				$update = HelpCentre::where('id', $helpId)->update(['reference_no' => $helpId]);
				$getUser = User::where('id', $userId)->select('consumer_name')->first();
				$username = $getUser->consumer_name;

				$msg1 = $username . " have raised new ticket regarding " . $data['subject'];
				$insdata = array('admin_id' => 1, 'type' => 'Support', 'message' => $msg1, 'status' => 'unread');
				AdminNotification::create($insdata);

				if ($update) {
					$getEmail = EmailTemplate::where('id', 42)->first();
					$getSiteDetails = Controller::getEmailTemplateDetails();
					$info = array('###USER###' => $username, '###MESSAGE###' => $data['description'], '###SUBJECT###' => $data['subject']);
					$replace = array_merge($getSiteDetails, $info);
					$emaildata = array('content' => strtr($getEmail->template, $replace));
					$toDetails['useremail'] = $getSiteDetails['contact_mail_id'];
					$toDetails['subject'] = $getEmail->subject;
					$toDetails['from'] = $getSiteDetails['contact_mail_id'];
					$toDetails['name'] = $getSiteDetails['site_name'];
					$sendEmail = Controller::sendEmail($emaildata, $toDetails);
					$response = array('status' => '1', 'msg' => trans('app_lang.Your query submitted to the Admin'), 'ticket_id' => encrypText($helpId));
				} else {
					$response = array('status' => '0', 'msg' => trans('app_lang.Failed to submit query.'));
				}
			} else {
				$response = array('status' => '0', 'msg' => trans('app_lang.Please try again!'));
			}
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);exit;
	}

	public function querySubmit() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$Validation = Validator::make($data, User::$queryRule);
			if ($Validation->fails()) {
				foreach ($Validation->messages()->getMessages() as $field => $message) {
					$response = array('status' => '0', 'msg' => $message[0]);
					echo json_encode($response);exit;
				}
			}

			$help['reference_no'] = $refno = decrypText(strip_tags($data['reference_no']));
			$status = HelpCentre::where('reference_no', $refno)->orderBy('created_at', 'desc')->select('ticket_status')->first()->ticket_status;
			if ($status == 'close') {
				$response = array('status' => '0', 'msg' => 'Ticket has beed closed by admin');
				echo json_encode($response);exit;
			}

			$help['user_id'] = $userId;
			$subject = $help['subject'] = strip_tags($data['subject']);
			$message = $help['description'] = strip_tags($data['description']);
			$help['image'] = strip_tags($data['image']);
			if (empty($data['customCheck1'])) {
				$help['status'] = "unread";
				$help['ticket_status'] = "active";
			} else {
				$help['status'] = "unread";
				$help['ticket_status'] = "close";
			}

			$createHelp = HelpCentre::create($help);

			$getUser = User::where('id', $userId)->select('consumer_name')->first();
			$username = $getUser->consumer_name;
			$msg1 = $username . " have raised new ticket regarding " . $data['subject'];
			$insdata = array('admin_id' => 1, 'type' => 'Support', 'message' => $msg1, 'status' => 'unread');
			AdminNotification::create($insdata);
			if ($createHelp) {
				$getEmail = EmailTemplate::where('id', 42)->first();
				$getSiteDetails = Controller::getEmailTemplateDetails();
				$info = array('###USER###' => $username, '###MESSAGE###' => $message, '###SUBJECT###' => $subject);
				$replace = array_merge($getSiteDetails, $info);
				$emaildata = array('content' => strtr($getEmail->template, $replace));
				$toDetails['useremail'] = $getSiteDetails['contact_mail_id'];
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails['contact_mail_id'];
				$toDetails['name'] = $getSiteDetails['site_name'];
				$sendEmail = Controller::sendEmail($emaildata, $toDetails);
				$response = array('status' => '1', 'msg' => trans('app_lang.Your query submitted to the Admin'));
			} else {
				$response = array('status' => '0', 'msg' => trans('app_lang.Failed to submit query.'));
			}
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);exit;
	}

	public function viewSupport() {
		$data = Input::all();
		$id = $data['ticket_id'];
		$userId = $data['user_id'];
		if ($userId != '') {
			$getTickets = HelpCentre::where('user_id', $userId)->orderBy('created_at', 'desc')->groupBy('reference_no')->select('user_id', 'ticket_status', 'subject', 'reference_no', 'created_at', 'id', 'image', 'description')->get();
			$refId = decrypText($id);
			$getQuery = HelpCentre::where('reference_no', $refId)->orderBy('id', 'asc')->get();
			$getUserDetails = User::where('id', $userId)->select('tfa_status', 'verified_status', 'tfa_url', 'secret', 'user_mail_id', 'unusual_user_key', 'consumer_name')->first();
			if ($getQuery->isEmpty()) {
				$ticks = array();
			} else {
				foreach ($getQuery as $value) {
					$consumer_name = ($value->user_id == 0) ? 'Admin' : $getUserDetails->consumer_name;
					$ticks[] = array(
						'user_id' => $value->user_id,
						'consumer_name' => $consumer_name,
						'ticket_status' => $value->ticket_status,
						'subject' => $value->subject,
						'description' => $value->description,
						'reference_no' => $value->reference_no,
						'created_at' => date($value->created_at),
						'id' => $value->id,
						'image' => $value->image,
					);
				}
			}

			$getQuery_closed = HelpCentre::where('reference_no', $refId)->where('ticket_status', 'close')->orderBy('id', 'asc')->count();
			$first = decrypText($getUserDetails['user_mail_id']);
			$second = decrypText($getUserDetails['unusual_user_key']);
			$useremailid = $first . "@" . $second;

			$getContent = Cms::whereIn('id', [17])->select('content', 'title')->get();

			$helpcategory = Helpcategory::all();
			if ($getTickets->isEmpty()) {
				$getTickets = array();
			}

			$response['status'] = 1;
			$response['queries'] = $ticks;
			$response['listtickets'] = $getTickets;
			$response['category'] = $helpcategory;
			$response['closed_status'] = $getQuery_closed;
			$response['profile'] = $getUserDetails;
			$response['email'] = $useremailid;
			$response['content'] = $getContent;
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);exit;
	}

	public function withdrawResendMail() {
		$data = Input::all();
		$userId = $data['user_id'];
		$tid = $data['with_id'];
		if ($userId != '') {
			$txId = decrypText($tid);
			$withdrawId = $tid;
			$uId = encrypText($userId);
			$query = Withdraw::where('id', $txId)->where('status', 'in progress')->first();
			if (count($query) > 0) {
				$amount = $query['amount'];
				$currency = $query['currency'];
				$fee = $query['fees_amt'];
				$address_info = $query['address_info'];
				$rand = time() . '12' . mt_rand(0, 999999);
				$expire_at = date('Y-m-d H:i:s', strtotime("+5 minutes"));
				$uIds = encrypText($rand);
				$update = Withdraw::where('id', $txId)->update(['rcode' => $rand, 'expire_at' => $expire_at]);
				$securl1 = URL::to('confirmWithdraw/' . $withdrawId . '/' . $uId . '/' . $uIds);
				$securl2 = URL::to('rejectWithdraw/' . $withdrawId . '/' . $uId . '/' . $uIds);
				if ($currency == 'INR') {
					$amount = number_format($amount, 2, '.', '');
					$fee = number_format($fee, 2, '.', '');
				} else {
					$amount = number_format($amount, 8, '.', '');
					$fee = number_format($fee, 8, '.', '');
				}

				$getDetail = User::select('verified_status', 'consumer_name', 'tfa_status', 'secret', 'user_mail_id', 'unusual_user_key')->where('id', $userId)->first();
				$getEmail = EmailTemplate::where('id', 9)->first();
				$getSiteDetails = Controller::getEmailTemplateDetails();
				$info = array('###USER###' => $getDetail->consumer_name, '###LINK1###' => $securl1, '###LINK2###' => $securl2, '###AMT###' => $amount . " " . $currency, '###FEE###' => $fee . " " . $currency, '###ADDRESS###' => $address_info);
				$replace = array_merge($getSiteDetails, $info);

				$emaildata = array('content' => strtr($getEmail->template, $replace));
				$toDetails['useremail'] = decrypText($getDetail->user_mail_id) . '@' . decrypText($getDetail->unusual_user_key);
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails['contact_mail_id'];
				$toDetails['name'] = $getSiteDetails['site_name'];

				$sendEmail = Controller::sendEmail($emaildata, $toDetails);
				$ip = Controller::getIpAddress();
				if (count(Mail::failures()) > 0) {
					$response = array('status' => '0', 'msg' => trans('app_lang.Email sending failed.'));
				} else {
					$response = array('status' => '1', 'msg' => $amount . " " . $currency . ' Withdraw request confirmation Sent to your registered email.');
				}
			} else {
				$query = Withdraw::where('id', $tid)->get();
				$stringstatus = strtoupper($query['status']);
				$response = array('status' => '0', 'msg' => 'Already Transaction ' . $stringstatus . ' !');
			}
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);exit;
	}

	public function checkpasscode() {
		$data = Input::all();
		if ($data) {
			$passcode = $data['passcode'];
			$id = $data['user_id'];
			$check = User::select('passcode')->where('id', $id)->first();
			$pass = $check->passcode;
			if ($pass == $passcode) {
				$response = array('status' => '1', 'msg' => 'true');
			} else {
				$response = array('status' => '0', 'msg' => 'Invalid Passcode');
			}
		}
		echo json_encode($response);exit;
	}

	public function passcode() {
		$data = Input::all();
		$id = $data['user_id'];
		$token = $data['token'];
		$key = $data['key'];
		$user_passcode = $data['old_passcode'];
		$validate = Validator::make($data, [
			'passcode' => "required|min:4",
			'key' => "required",
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$data = array('status' => '0', 'message' => $msg[0]);
				echo json_encode($data);
				exit;
			}
		}
		$passcode = strip_tags($data['passcode']);
		if ($key == 1) {
			$update = User::where('id', $id)->where('token', $token)->update(['passcode' => $passcode]);
			if ($update) {
				$message = 'You have updated your Passcode';
				$insdata = array('user_id' => $id, 'type' => 'Change-Passcode', 'message' => $message, 'status' => 'unread');
				UserNotification::create($insdata);
				$data = array('status' => '1', 'message' => 'Passcode created successfully');
			} else {
				$data = array('status' => '0', 'message' => 'Please try again');
			}
		} else if ($key == 2) {
			$old_passcode = User::select('passcode')->where('id', $id)->where('token', $token)->first()->passcode;
			if ($old_passcode == $user_passcode) {
				$update = User::where('id', $id)->where('token', $token)->update(['passcode' => $passcode]);
				if ($update) {
					$message = 'You have updated your Passcode';
					$insdata = array('user_id' => $id, 'type' => 'Change-Passcode', 'message' => $message, 'status' => 'unread');
					UserNotification::create($insdata);
					$data = array('status' => '1', 'message' => 'Passcode updated successfully');
				} else {
					$data = array('status' => '0', 'message' => 'Please try again');
				}
			} else {
				$data = array('status' => '0', 'message' => 'Wrong old passcode');
			}
		} else {
			$login = User::where('id', $id)->where('passcode', $passcode)->select('token', 'status')->first();
			if ($login) {
				if ($login->status == 'active') {
					$data = array('status' => '1', 'message' => 'Authentication successfully', 'token' => $login->token, 'token' => $passcode);
					echo json_encode($data);
					exit;
				} else if ($login->status == 'deactive') {
					$data = array('status' => '0', 'message' => 'Your account deactivated! please contact support team');
					echo json_encode($data);
					exit;
				} else {
					$data = array('status' => '0', 'message' => 'Invalid passcode');
					echo json_encode($data);
					exit;
				}
			} else {
				$data = array('status' => '0', 'message' => 'Invalid passcode');
				echo json_encode($data);
				exit;
			}
		}
		echo json_encode($data);
		exit;
	}

	public function forgot_passcode() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'email' => "required|email|indisposable",
		], [
			'email.required' => 'Enter email address',
			'email.email' => 'Enter valid email address',
		]);
		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$data = array('status' => '0', 'message' => $msg[0]);
				echo json_encode($data);
				exit;
			}
		}
		$userid = strip_tags($data['user_id']);
		$email = explode('@', strip_tags(strtolower($data['email'])));
		$first = encrypText($email[0]);
		$second = encrypText($email[1]);
		$user = User::where('user_mail_id', $first)->where('unusual_user_key', $second)->select('id', 'passcode', 'status', 'user_mail_id', 'unusual_user_key', 'consumer_name')->first();
		if ($user->id != $userid) {
			$response = array('status' => '0', 'message' => 'Invalid credentials');
			echo json_encode($response);exit;
		}
		if ($user) {
			if ($user->status == 'active') {
				$passcode = $user->passcode;
				$first = decrypText($user->user_mail_id);
				$second = decrypText($user->unusual_user_key);
				$useremail = $first . "@" . $second;

				$getEmail = EmailTemplate::where('id', 45)->first();
				$getSiteDetails = Controller::getEmailTemplateDetails();
				$info = array('###USER###' => $user->consumer_name, '###PSD###' => $passcode);
				$replace = array_merge($getSiteDetails, $info);
				$emaildata = array('content' => strtr($getEmail->template, $replace));
				$toDetails['useremail'] = $useremail;
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails['contact_mail_id'];
				$toDetails['name'] = $getSiteDetails['site_name'];
				$sendEmail = Controller::sendEmail($emaildata, $toDetails);
				if ($sendEmail) {
					$response = array('status' => '1', 'message' => 'Passcode sent to your email id');
				} else {
					$response = array('status' => '0', 'message' => 'Email sending failed!');
				}
			} else if ($user->status == 'inactive') {
				$response = array('status' => '0', 'message' => 'Please activate your account!');
			} else {
				$response = array('status' => '0', 'message' => 'Please contact support team, Your account deactivated!');
			}
		} else {
			$data = array('status' => '0', 'message' => 'User not exists');
		}
		echo json_encode($response);exit;
	}

	public function referral() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$getId = User::where('id', $userId)->select('refer_id')->first();
			$referId = $getId->refer_id;
			$referral['refer_id'] = $referId;
			$getTotal = User::where('referrer_id', $referId)->select(DB::raw("COUNT(*) as totalCount"), DB::raw('SUM(refer_amount) as totalAmount'))->first();
			$referral['total_count'] = $getTotal->totalCount;
			$totalAmount = $getTotal->totalAmount;
			if ($totalAmount == "") {
				$totalAmount = 0.00;
			}
			$referral['active_count'] = User::where('referrer_id', $referId)->where('status', 'active')->count();
			$referral['inactive_count'] = User::where('referrer_id', $referId)->whereIn('status', ['inactive', 'deactive'])->count();
			$listUsers = User::where('referrer_id', $referId)->select('user_mail_id', 'unusual_user_key', 'created_at', 'status', 'consumer_name', 'refer_amount')->orderBy('id', 'desc')->get();
			$res = array();
			if (count($listUsers) > 0) {
				foreach ($listUsers as $value) {
					$userStatus = $value->status;
					if ($userStatus == "inactive") {
						$result_status = "Registered";
					} else if ($userStatus == "active") {
						$result_status = "Activated";
					} else {
						$result_status = "Deactivated";
					}
					$result['email'] = decrypText($value->user_mail_id) . '@' . decrypText($value->unusual_user_key);
					$result['consumer_name'] = $value->consumer_name;
					$result['status'] = $result_status;
					$result['created_at'] = date($value->created_at);
					array_push($res, $result);
				}
			}

			$refer = ReferralCommision::where('refer_by_id', $userId)->select('user_id', 'refer_currency', 'created_at', 'amount')->orderBy('refer_com_id', 'desc');
			$total_refamt = ReferralCommision::sum('amount');
			$referrralCommission = $refer->get();
			$referral['total_amount'] = $inr_value = $refer->sum('amount');
			if ($total_refamt > 0) {
				$rate = $inr_value / $total_refamt * 100;
			} else {
				$rate = 0;
			}
			$referral['rate'] = number_format($rate, 2, '.', '');
			if ($referrralCommission->isEmpty()) {
				$commissionHis = array();
			} else {
				$no = 1;
				foreach ($referrralCommission as $value) {
					$commissionHis[] = array(
						'S.no' => $no,
						'User' => get_user_email($value->user_id),
						'Commission_Fee' => $value->amount,
						'Currency' => $value->refer_currency,
						'Created_at' => date($value->created_at),
					);
					$no++;
				}
			}
			$userWallet = Wallet::where('user_id', $userId)->select('Ref_INR', 'clear_bal')->first();
			$referral['unclear'] = $userWallet->Ref_INR;
			$referral['clear'] = $userWallet->clear_bal;
			$referral['users'] = $res;

			$response['status'] = 1;
			$response['referral'] = $referral;
			$response['referrralCommission'] = $commissionHis;
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);exit;
	}

	public function referral_copy() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$getId = User::where('id', $userId)->select('refer_id')->first();
			$referId = $getId->refer_id;
			$referral['refer_id'] = $referId;
			$getTotal = User::where('referrer_id', $referId)->select(DB::raw("COUNT(*) as totalCount"), DB::raw('SUM(refer_amount) as totalAmount'))->first();
			$referral['total_count'] = $getTotal->totalCount;
			$referral['active_count'] = User::where('referrer_id', $referId)->where('status', 'active')->count();
			$referral['inactive_count'] = User::where('referrer_id', $referId)->whereIn('status', ['inactive', 'deactive'])->count();

			$refer = ReferralCommision::where('refer_by_id', $userId)->select('user_id', 'refer_currency', 'created_at')->orderBy('refer_com_id', 'desc');
			$total_refamt = ReferralCommision::sum('amount');
			$referrralCommission = $refer->get();
			$referral['total_amount'] = $inr_value = $refer->sum('amount');
			if ($total_refamt > 0) {
				$rate = $inr_value / $total_refamt * 100;
			} else {
				$rate = 0;
			}
			$referral['rate'] = number_format($rate, 2, '.', '');
			$userWallet = Wallet::where('user_id', $userId)->select('Ref_INR', 'clear_bal')->first();
			$referral['unclear'] = $userWallet->Ref_INR;
			$referral['clear'] = $userWallet->clear_bal;

			$top = User::where('rank', '!=', 0)->select('consumer_name', 'rank', 'total_volume')->orderBy('rank', 'asc')->limit(10);

			$response['status'] = 1;
			$response['referral'] = $referral;
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);exit;
	}

	public function referral_history() {
		$datas = Input::all();
		$id = $datas['user_id'];
		if ($id != '') {
			$data = $orders = array();
			$referral = ReferralCommision::where('refer_by_id', $id);
			$referral_count = $referral->count();
			$no = 1;
			if ($referral_count) {
				foreach ($orders as $r) {
					$orders = $referral->select('user_id', 'amount', 'refer_currency', 'created_at')->orderBy('id', 'desc')->get()->toArray();
					$emailid = get_user_email($r['user_id']);
					array_push($data, array(
						"S.no" => $no,
						"DateTime" => $r['created_at'],
						"Email" => $emailid,
						"Currency" => $r['refer_currency'],
						"Commission" => $r['amount'],
					));
					$no++;
				}
				echo json_encode(array('status' => '1', 'recordsTotal' => $referral_count, 'recordsFiltered' => $referral_count, 'data' => $data));
			} else {
				echo json_encode(array('status' => '0', 'recordsTotal' => $referral_count, 'recordsFiltered' => $referral_count, 'data' => array()));
			}
		}
	}

	public function deposit_history() {
		$datas = Input::all();
		$id = $datas['user_id'];
		if ($id != '') {
			$deposit_type = $datas['deposit_type'];
			$curr = $datas['currency'];
			$from_date = $datas['from_date'];
			$to_date = $datas['to_date'];
			$data = $orders = array();
			$redirect = '';

			if ($curr == '') {
				if ($deposit_type == "Bank") {
					$deposit = Deposit::where('user_id', $id)->where('payment_method', "Bank");
				} else {
					$deposit = Deposit::where('user_id', $id)->where('payment_method', '!=', "Bank");
				}
			} else {
				if ($deposit_type == "Bank") {
					$deposit = Deposit::where('user_id', $id)->where('currency', $curr)->where('payment_method', "Bank");
				} else {
					if ($curr == 'INR') {
						$deposit = Deposit::where('user_id', $id)->where('currency', $curr)->where('payment_method', "Bank");
					} else {
						$deposit = Deposit::where('user_id', $id)->where('currency', $curr)->where('payment_method', '!=', "Bank");
					}
				}
			}

			if ($from_date) {
				$deposit = $deposit->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
			}

			if ($to_date) {
				$deposit = $deposit->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
			}

			$deposit_count = $deposit->count();
			$no = 1;

			if ($deposit_count) {
				$orders = $deposit->select('updated_at', 'address_info', 'transaction_number', 'currency', 'amount', 'fees', 'total', 'status', 'payment_method', 'reference_no', 'payment_type', 'trans_type')->orderBy('id', 'desc')->get()->toArray();
				foreach ($orders as $r) {
					$address = $r['address_info'];
					$tx = $r['reference_no'];
					$dcur = $r['currency'];
					if (($r['currency'] == 'INR' || $r['currency'] == 'USDT') && $r['payment_method'] == 'bank') {
						$amount = number_format($r['amount'], 2, '.', ',');
						$fees = number_format($r['fees'], 2, '.', ',');
						$total = number_format($r['total'], 2, '.', ',');
					} else {
						$amount = number_format($r['amount'], 8, '.', ',');
						$fees = $total = '-';
					}

					if ($r['payment_method'] == 'bank') {
						$trans_id = $tx;
						$pay_type = ($r['payment_type'] != '' && $r['payment_type'] == 'cashfree') ? 'Instant' : $r['payment_type'];
						$payment = ($r['payment_type'] != '') ? "Bank" . '-' . $pay_type : 'Bank';
						$confirm = '-';
					} else {
						if ($r['trans_type'] == 'External') {
							$txUrl = array(
								'BTC' => 'https://live.blockcypher.com/btc/tx/',
								'ETH' => 'https://etherscan.io/tx/',
								'USDT' => 'https://etherscan.io/tx/', 
								'LTC' => 'https://live.blockcypher.com/ltc/tx/',
								'BCH' => 'https://explorer.bitcoin.com/bch/tx/',
								'DASH' => 'https://live.blockcypher.com/dash/tx/', 
								'XRP' => 'https://bithomp.com/explorer/', 
							);
							$redirect = $txUrl[$dcur] . $tx;
							$trans_id = $tx;
						} else {
							$trans_id = $tx;
						}
						$payment = "Wallet";
						$confirmations = Currency::where('currency_symbol', $dcur)->select('confirmations')->first()->confirmations;
						$confirm = "Confirmed";
					}

					if ($r['status'] == 'completed') {
						$status = URL::to('public/frontend/img/tick.png');
					} else if ($r['status'] == 'pending') {
						$status = URL::to('public/frontend/img/pending.png');
					} else if ($r['status'] == 'cancelled') {
						$status = URL::to('public/frontend/img/cancel.png');
					} else {
						$status = '<span style="color:red">' . $r['status'] . '</span>';
					}
					array_push($data, array(
						"S.no" => $no,
						"DateTime" => $r['updated_at'],
						"Currency" => $r['currency'],
						"Payment" => $payment,
						"Amount" => $amount,
						"Fees" => $fees,
						"Total" => $total,
						"Transaction_id" => $trans_id,
						"Link" => $redirect,
						"Status" => $r['status'],
						"Image" => $status,
						"Confirm" => $confirm,
					));
					$no++;
				}
				echo json_encode(array('status' => '1', 'recordsTotal' => $deposit_count, 'recordsFiltered' => $deposit_count, 'data' => $data));
			} else {
				echo json_encode(array('status' => '0', 'recordsTotal' => $deposit_count, 'recordsFiltered' => $deposit_count, 'data' => array()));
			}
		}
	}

	public function pending_deposit_history() {
		$datas = Input::all();
		$id = $datas['user_id'];
		if ($id != '') {
			$deposit_type = $datas['deposit_type'];
			$curr = $datas['currency'];
			$from_date = $datas['from_date'];
			$to_date = $datas['to_date'];
			$data = $orders = array();
			$redirect = '';

			if ($curr == '') {
				$deposit = PendingDeposit::where('user_id', $id)->where('status', 'pending')->where('payment_method', '!=', "Bank");
			} else {
				$deposit = PendingDeposit::where('user_id', $id)->where('currency', $curr)->where('status', 'pending')->where('payment_method', '!=', "Bank");
			}

			if ($from_date) {
				$deposit = $deposit->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
			}

			if ($to_date) {
				$deposit = $deposit->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
			}

			$deposit_count = $deposit->count();
			$no = 1;

			if ($deposit_count) {
				$orders = $deposit->select('updated_at', 'address_info', 'transaction_number', 'currency', 'amount', 'fees', 'total', 'status', 'payment_method', 'reference_no', 'payment_type', 'trans_type', 'block_confirm')->orderBy('id', 'desc')->get()->toArray();
				foreach ($orders as $r) {
					$address = $r['address_info'];
					$tx = $r['reference_no'];
					$amount = number_format($r['amount'], 8, '.', ',');
					$fees = $total = '-';
					$dcur = $r['currency'];
					$confirmations = Currency::where('currency_symbol', $dcur)->select('confirmations')->first()->confirmations;
					if ($r['trans_type'] == 'External') {
						$txUrl = array(
							'BTC' => 'https://live.blockcypher.com/btc/tx/',
							'ETH' => 'https://etherscan.io/tx/',
							'USDT' => 'https://etherscan.io/tx/', 
							'LTC' => 'https://live.blockcypher.com/ltc/tx/',
							'BCH' => 'https://explorer.bitcoin.com/bch/tx/',
							'DASH' => 'https://live.blockcypher.com/dash/tx/', 
							'XRP' => 'https://bithomp.com/explorer/', 
						);
						$redirect = $txUrl[$dcur] . $tx;
						$trans_id = $tx;
					} else {
						$trans_id = $tx;
					}

					if ($r['status'] == 'completed') {
						$completed = URL::to('public/frontend/img/tick.png');
						$status = '<img src="' . $completed . '" alt="Completed" title="Completed">';
					} else if ($r['status'] == 'pending') {
						$pending = URL::to('public/frontend/img/pending.png');
						$status = '<img src="' . $pending . '" alt="Pending" title="Pending">';
					} else if ($r['status'] == 'cancelled') {
						$cancel = URL::to('public/frontend/img/cancel.png');
						$status = '<img src="' . $cancel . '" alt="Cancelled" title="Cancelled">';
					} else {
						$status = '<span style="color:red">' . $r['status'] . '</span>';
					}

					array_push($data, array(
						"S.no" => $no,
						"DateTime" => $r['updated_at'],
						"Currency" => $r['currency'],
						"Payment" => "Wallet",
						"Amount" => $amount,
						"Fees" => $fees,
						"Total" => $total,
						"Transaction_id" => $trans_id,
						"Link" => $redirect,
						"Status" => $r['status'],
						"Image" => $status,
						"Confirm" => $r['block_confirm'] . '/' . $confirmations,
					));
					$no++;
				}
				echo json_encode(array('status' => '1', 'recordsTotal' => $deposit_count, 'recordsFiltered' => $deposit_count, 'data' => $data));
			} else {
				echo json_encode(array('status' => '0', 'recordsTotal' => $deposit_count, 'recordsFiltered' => $deposit_count, 'data' => array()));
			}
		}
	}

	public function withdraw_history() {
		$datas = Input::all();
		$id = $datas['user_id'];
		if ($id != '') {
			$withdraw_type = $datas['withdraw_type'];
			$curr = $datas['currency'];
			$type = $datas['type'];
			$from_date = $datas['from_date'];
			$to_date = $datas['to_date'];

			$data = $orders = array();
			$redirect = '';

			if ($curr == '') {
				if ($type == 2) {
					if ($withdraw_type == "Bank") {
						$withdraw = Withdraw::where('user_id', $id)->where('payment_method', "Bank");
					} else {
						$withdraw = Withdraw::where('user_id', $id)->where('payment_method', "!=", "Bank");
					}
				} else {
					$withdraw = Withdraw::where('user_id', $id);
				}
			} else {
				if ($type == 2) {
					if ($withdraw_type == "Bank") {
						$withdraw = Withdraw::where('user_id', $id)->where('currency', $curr)->where('payment_method', "Bank");
					} else {
						$withdraw = Withdraw::where('user_id', $id)->where('currency', $curr)->where('payment_method', "!=", "Bank");
					}
				} else {
					$withdraw = Withdraw::where('user_id', $id)->where('currency', $curr);
				}
			}

			if ($from_date) {
				$withdraw = $withdraw->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
			}

			if ($to_date) {
				$withdraw = $withdraw->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
			}

			$withdraw_count = $withdraw->count();
			$no = 1;

			if ($withdraw_count) {
				$orders = $withdraw->select('updated_at', 'address_info', 'transaction_number', 'currency', 'amount', 'status', 'fees_amt', 'id', 'reference_no', 'total', 'payment_method', 'user_id', 'trans_type', 'wallet_type')->orderBy('id', 'desc')->get()->toArray();
				foreach ($orders as $r) {
					$id = $r['id'];
					$user_id = $r['user_id'];
					$tx = $r['reference_no'];
					$wcur = $r['currency'];
					if ($r['currency'] == 'INR') {
						$amount = number_format($r['amount'], 2, '.', ',');
						$fees = number_format($r['fees_amt'], 2, '.', ',');
						$total = number_format($r['total'], 2, '.', ',');
						$address = '-';
					} else {
						$amount = number_format($r['amount'], 8, '.', ',');
						$fees = number_format($r['fees_amt'], 8, '.', ',');
						$total = number_format($r['total'], 8, '.', ',');
						$address = $r['address_info'];
					}
					if ($tx != '') {
						if ($r['payment_method'] == 'bank') {
							$payment = "Bank";
							$trans_id = $tx;
						} else {
							if ($r['trans_type'] == 'External' && $r['wallet_type'] == 0) {
								$txUrl = array(
									'BTC' => 'https://live.blockcypher.com/btc/tx/',
									'ETH' => 'https://etherscan.io/tx/',
									'USDT' => 'https://etherscan.io/tx/', 
									'LTC' => 'https://live.blockcypher.com/ltc/tx/',
									'BCH' => 'https://explorer.bitcoin.com/bch/tx/',
									'DASH' => 'https://live.blockcypher.com/dash/tx/', 
									'XRP' => 'https://bithomp.com/explorer/', 
								);
								$redirect = $txUrl[$wcur] . $tx;
								$trans_id = $tx;
							} else {
								$trans_id = $tx;
							}
							$payment = "Wallet";
						}
					} else {
						$trans_id = $tx;
						$payment = "-";
					}
					if ($r['status'] == 'completed') {
						$status = URL::to('public/frontend/img/tick.png');
					} else if ($r['status'] == 'in progress') {
						$status = URL::to('public/frontend/img/inprogress.png');
					} else if ($r['status'] == 'pending') {
						$status = URL::to('public/frontend/img/pending.png');
					} else if ($r['status'] == 'cancelled') {
						$status = URL::to('public/frontend/img/cancel.png');
					} else {
						$status = '<span style="color:red">' . $r['status'] . '</span>';
					}

					$with_id = ($r['status'] == 'in progress') ? encrypText($r['id']) : '-';

					array_push($data, array(
						"S.no" => $no,
						"DateTime" => $r['updated_at'],
						"Currency" => $r['currency'],
						"Payment" => $payment,
						"Amount" => $amount,
						"Fees" => $fees,
						"Total" => $total,
						"Transaction_id" => $trans_id,
						"Link" => $redirect,
						"Status" => $r['status'],
						"Image" => $status,
						"With_id" => $with_id,
					));
					$no++;
				}

				echo json_encode(array('status' => '1', 'recordsTotal' => $withdraw_count, 'recordsFiltered' => $withdraw_count, 'data' => $data));
			} else {
				echo json_encode(array('status' => '0', 'recordsTotal' => $withdraw_count, 'recordsFiltered' => $withdraw_count, 'data' => array()));
			}
		}
	}

	public function transfer_history() {
		$datas = Input::all();
		$id = $datas['user_id'];
		if ($id != '') {
			$stype = $datas['stype'];
			$data = $orders = array();

			if ($stype == 'transfer') {
				$transfer = Transfer::where('user_id', $id);
			} else if ($stype == 'redeem') {
				$transfer = Transfer::where('rec_user_id', $id);
			} else {
				$transfer = Transfer::where('user_id', $id)->orWhere('rec_user_id', $id);
			}
			$transfer_count = $transfer->count();
			$no = 1;
			if ($transfer_count) {
				$orders = $transfer->select('user_id', 'rec_user_id', 'amount', 'fees', 'total', 'currency', 'rec_user_name', 'created_at', 'status', 'fee_per', 'fee_type', 'redemption_at')->orderBy('id', 'desc')->get()->toArray();
				foreach ($orders as $r) {
					if ($r['status'] == 'completed') {
						$status = URL::to('public/frontend/img/tick.png');
					} else if ($r['status'] == 'pending') {
						$status = URL::to('public/frontend/img/pending.png');
					} else if ($r['status'] == 'cancelled') {
						$status = URL::to('public/frontend/img/cancel.png');
					} else {
						$status = $r['status'];
					}

					if ($id == $r['user_id']) {
						$fees = ($r['fees'] == 0) ? '-' : $r['fees'] . " " . $r['currency'];
						$total = ($r['total'] == 0) ? '-' : $r['total'] . " " . $r['currency'];
						array_push($data, array(
							"S.no" => $no,
							"DateTime" => $r['created_at'],
							"SendUser" => getUserName($r['user_id']),
							"ReceiveUser" => $r['rec_user_name'],
							"Amount" => $r['amount'] . " " . $r['currency'],
							"Fees" => $fees,
							"Total" => $total,
							"Status" => $r['status'],
							"Image" => $status,
						));
						$no++;
					} else if ($id == $r['rec_user_id']) {
						$fees = $fee_amt = $r['fee_per'];
						$fee_type = $r['fee_type'];
						$amount = $r['total'];
						if ($fees == 0) {
							$total = $amount = $r['amount'];
						} else {
							if ($fee_type == 'amount') {
								$total = $amount - $fees;
							} else {
								$fee_amt = ($amount * $fees) / 100;
								$total = $amount - $fee_amt;
							}
						}

						$total = number_format($total, 2, '.', '');
						$fee_amt = number_format($fee_amt, 2, '.', '');

						array_push($data, array(
							"S.no" => $no,
							"DateTime" => $r['created_at'],
							"SendUser" => getUserName($r['user_id']),
							"ReceiveUser" => $r['rec_user_name'],
							"Amount" => $amount . " " . $r['currency'],
							"Fees" => $fee_amt . " " . $r['currency'],
							"Total" => $total . " " . $r['currency'],
							"Status" => $r['status'],
							"Image" => $status,
						));
						$no++;
					}
				}
				echo json_encode(array('status' => '1', 'recordsTotal' => $transfer_count, 'recordsFiltered' => $transfer_count, 'data' => $data));
			} else {
				echo json_encode(array('status' => '0', 'recordsTotal' => $transfer_count, 'recordsFiltered' => $transfer_count, 'data' => array()));
			}
		}
	}

	public function payoutHistory() {
		$datas = Input::all();
		$id = $datas['user_id'];
		if ($id != '') {
			$data = $orders = array();
			$payout = DB::table('clear_payout as p')->leftjoin('user_info AS U', 'U.id', '=', 'p.user_id')->where('p.user_id', $id);

			$payout_count = $payout->count();
			$data = array();
			$no = 1;

			if ($payout_count) {
				$payout = $payout->select('p.amount', 'p.currency', 'p.created_at', 'p.user_id', 'U.consumer_name')->orderBy('p.id', 'desc')->get()->toArray();
				foreach ($payout as $r) {
					array_push($data, array(
						"S.no" => $no,
						"Amount" => $r->amount . " " . $r->currency,
						"DateTime" => $r->created_at,
					));
					$no++;
				}
				echo json_encode(array('status' => '1', 'recordsTotal' => $payout_count, 'recordsFiltered' => $payout_count, 'data' => $data));
			} else {
				echo json_encode(array('status' => '0', 'recordsTotal' => $payout_count, 'recordsFiltered' => $payout_count, 'data' => array()));
			}
		}
	}

	public function login_history() {
		$datas = Input::all();
		$id = $datas['user_id'];
		if ($id != '') {
			$data = $orders = array();
			$login = UserActivity::where('user_id', $id);
			$login_count = $login->count();
			$no = 1;

			if ($login_count) {
				$orders = $login->select('browser_name', 'created_at', 'os', 'ip_address')->orderBy('id', 'desc')->get()->toArray();
				foreach ($orders as $r) {
					if ($r['browser_name'] == 'Firefox') {
						$img = URL::to('public/frontend/img/firefox.png');
					} else {
						$img = URL::to('public/frontend/img/chrome.png');
					}
					array_push($data, array(
						"Browser" => $img,
						"DateTime" => $r['created_at'],
						"OS" => ucfirst($r['os']),
						"IP" => $r['ip_address'],
					));
					$no++;
				}
				echo json_encode(array('status' => '1', 'recordsTotal' => $login_count, 'recordsFiltered' => $login_count, 'data' => $data));
			} else {
				echo json_encode(array('status' => '0', 'recordsTotal' => $login_count, 'recordsFiltered' => $login_count, 'data' => array()));
			}
		}
	}

	public function checkToken() {
		$data = Input::all();
		$user_id = isset($data['user_id']) ? $data['user_id'] : '';
		$token = isset($data['token']) ? $data['token'] : '';
		if ($user_id && $token) {
			$result = User::select('status')->where(['id' => $user_id, 'token' => $token])->first();
			if ($result) {
				if ($result->status == "deactive") {
					echo json_encode(array('status' => '3', 'message' => 'Your account deactivated by Admin'), JSON_FORCE_OBJECT);
					exit;
				} else {
					echo json_encode(array('status' => '1', 'message' => 'Success'), JSON_FORCE_OBJECT);
					exit;
				}
			} else {
				echo json_encode(array('status' => '0', 'message' => 'Invalid credentials'), JSON_FORCE_OBJECT);
				exit;
			}
		}
		echo json_encode(array('status' => '0', 'message' => 'Enter user id and token'), JSON_FORCE_OBJECT);
		exit;
	}

	public static function sendnotification($title, $msg, $devicekey) {
		 
		return true;
	}

	public function cdn_data() {
		$getFile = file_get_contents(app_path('Model/cJfcgPqrCW.php'));
		$data = explode(" || ", $getFile);
		$cld = decrypText($data[0]);
		$key = decrypText($data[1]);
		$secret = decrypText($data[2]);
		$dt = array(
			"cloud_name" => $cld,
			"api_key" => $key,
			"api_secret" => $secret,
		);
		return array('status' => '1', 'data' => $dt);
	}

	public function platform() {
		$data = Input::all();
		$Validation = Validator::make($data, [
			'platform' => 'required',
			'version' => 'required',
		], [
			'platform.required' => 'Platform required',
			'version.required' => 'Version required',
		]);
		if ($Validation->fails()) {
			foreach ($Validation->messages()->getMessages() as $field => $message) {
				$response = array('status' => '0', 'msg' => $message[0]);
				echo json_encode($response);exit;
			}
		}
		$result = SiteSettings::where('id', '1')->select('platform', 'version')->first();
		if ($result->platform == $data['platform'] && $result->version == $data['version']) {
			echo json_encode(array('status' => '1', 'type' => '1', 'message' => 'Success'), JSON_FORCE_OBJECT);exit;
		} else {
			echo json_encode(array('status' => '0', 'type' => '2', 'message' => 'Update'), JSON_FORCE_OBJECT);exit;
		}
	}

	public function with_password() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$validate = Validator::make($data, [
				'with_pass' => "required|min:6",
				'with_pass_confirm' => "required|min:6",
			], [
				'with_pass.required' => 'Please Enter withdraw password',
				'with_pass.min' => 'Please Enter minimum 6 characters',
				'with_pass_confirm.required' => 'Please Enter confirm withdraw password',
				'with_pass_confirm.min' => 'Please Enter minimum 6 characters',
			]);

			if ($validate->fails()) {
				foreach ($validate->messages()->getMessages() as $val => $msg) {
					$response = array('status' => '0', 'message' => $msg[0]);
					echo json_encode($response);
					exit;
				}
			}
			$with_pass = strip_tags($data['with_pass']);
			$with_pass_confirm = strip_tags($data['with_pass_confirm']);
			if ($with_pass == $with_pass_confirm) {
				$userdetails = User::where('id', $userId)->select('with_status')->first();
				if ($userdetails) {
					if ($userdetails->with_status == 0) {
						$pass = $userId . strip_tags($data['with_pass']);
						$encPass = Hash::make($pass);
						$update = User::where('id', $userId)->update(['with_pass' => $encPass, 'with_status' => 1]);
						if ($update) {
							$response = array('status' => '1', 'message' => 'Withdraw password enabled successfully');
						} else {
							$response = array('status' => '0', 'message' => 'Please try again later');
						}
					} else {
						$response = array('status' => '0', 'message' => 'Already enabled');
					}
				} else {
					$response = array('status' => '0', 'message' => 'Invalid user');
				}
			} else {
				$response = array('status' => '0', 'message' => 'Withdraw password and Confirm withdraw password should be same');
			}
		} else {
			$response = array('status' => '0', 'result' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);
	}

	public function reset_with_password() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$getDetail = User::where('id', $userId)->select('id', 'consumer_name', 'user_mail_id', 'unusual_user_key', 'tfa_status', 'otp_status', 'country', 'secret', 'mobile_otp', 'with_status')->first();
			if ($getDetail) {
				if ($getDetail->with_status == 1) {
					if ($getDetail->tfa_status == 'enable') {
						require_once app_path('Model/Googleauthenticator.php');
						$googleAuth = new Googleauthenticator();
						$verify = $googleAuth->verifyCode($getDetail->secret, $data['auth_key'], $discrepancy = 2);
						if ($verify == 1) {
							goto next;
						} else {
							$response = array('status' => '0', 'message' => trans('app_lang.Invalid authentication key.'));
							echo json_encode($response);exit;
						}
					} else {
						if ($getDetail->country == 'India') {
							$userotp = decrypText($getDetail->mobile_otp);
							if ($getDetail->otp_status == 1) {
								$otp = $data['auth_otp'];
								if ($userotp == $otp) {
									goto next;
								} else {
									$response = array('status' => '0', 'message' => 'Invalid OTP');
									echo json_encode($response);exit;
								}
							} else {
								$response = array('status' => '0', 'message' => 'Enter OTP');
								echo json_encode($response);exit;
							}
						} else {
							$response = array('status' => '0', 'message' => trans('app_lang.enable_tfa'));
							echo json_encode($response);exit;
						}
					}
					next:

					$first = decrypText($getDetail->user_mail_id);
					$second = decrypText($getDetail->unusual_user_key);
					$useremail = $first . "@" . $second;

					$id = encrypText($getDetail->id);
					$generateCode = User::randomString(8);
					$randomCode = encrypText($generateCode);
					$randnum = randomString(10);
					$token = $getDetail->id . time() . rand(10, 100);

					$update = User::where('id', $getDetail->id)->update(['reset_code' => $randomCode, 'reset_status' => 'active']);
					$securl = URL::to('resetWithPassword/' . $id . '/' . $randomCode);

					$getEmail = EmailTemplate::where('id', 53)->first();
					$getSiteDetails = Controller::getEmailTemplateDetails();
					$info = array('###USER###' => $getDetail->consumer_name, '###LINK###' => $securl);
					$replace = array_merge($getSiteDetails, $info);
					$emaildata = array('content' => strtr($getEmail->template, $replace));
					$toDetails['useremail'] = $useremail;
					$toDetails['subject'] = $getEmail->subject;
					$toDetails['from'] = $getSiteDetails['contact_mail_id'];
					$toDetails['name'] = $getSiteDetails['site_name'];
					$sendEmail = Controller::sendEmail($emaildata, $toDetails);
					if (count(Mail::failures()) > 0) {
						$response = array('status' => '0', 'message' => 'Please Try Again');
					} else {
						$response = array('status' => '1', 'message' => 'Reset withdraw password Link has sent to your registered email');
					}
				} else {
					$response = array('status' => '0', 'message' => 'Reset option not available');
				}
			} else {
				$response = array('status' => '0', 'message' => 'Invalid user');
			}
		} else {
			$response = array('status' => '0', 'result' => trans('app_lang.Please login to continue'));
		}
		echo json_encode($response);
	}
}