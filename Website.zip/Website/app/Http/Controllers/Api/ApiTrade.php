<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Front\Trades;
use App\Http\Controllers\Api\ApiUsers;
use App\Model\CoinOrder;
use App\Model\CoinProfit;
use App\Model\Currency;
use App\Model\EmailTemplate;
use App\Model\ImagePath;
use App\Model\OrderTemp;
use App\Model\Trade;
use App\Model\TradeModel;
use App\Model\TradePairs;
use App\Model\ExchangePairs; 
use App\Model\ReferralCommision;
use App\Model\User;
use App\Model\Wallet;
use App\Model\SiteSettings;
use App\Model\BinanceModel;
use App\Model\BinanceOrders;

use DateTime;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Redirect;
use Session;
use URL;
use Validator;


class ApiTrade extends Controller {
	
	public function __construct() {
	}

	public function tickers() {

		$data = Input::all();
		$validate = Validator::make($data, [
			'pair' => "required",
		], [
			'pair.required' => 'Please Enter pair',
		]);
		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '1', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}
		$pair = $data['pair'];
		$res  = explode('_', $pair);
		$from_symbol = $res[0];
		$to_symbol   = $res[1];
		$yesterday = date('Y-m-d H:i:s', strtotime("-1 days"));
		$getPairs  = TradePairs::where('site_status', '1')->where(['from_symbol' => $from_symbol,'to_symbol' => $to_symbol])->select('fee_per', 'tfee_per', 'min_price','minamt', 'last_price', 'trading_pair', 'pair_name', 'from_symbol', 'to_symbol', 'select_start', 'select_end', 'digit_amount', 'digit_price')->get();
		foreach ($getPairs as $pair) {
			$from_symbol = $pair->from_symbol;
			$to_symbol = $pair->to_symbol;
			$pairname = $pair->pair_name;
			$tradeData = Trades::getTradeData($pairname, $from_symbol, $to_symbol);
			$result['pair'] =  $pairname;
			$result['base_full_name'] =  getcurrencyname($from_symbol);
			$result['current_price'] =  $pair->last_price;
			$result['low'] =  $tradeData['low'];
			$result['high'] =  $tradeData['high'];
			$result['percent'] =  $tradeData['change'];
			$result['start_price'] =  $tradeData['open'];
			$result['volume'] = $tradeData['volume'];
			$result['count'] = CoinOrder::where('pair', $pairname)->where('status', 'filled')->where('datetime', '>=', $yesterday)->count();
			$result['select_start'] = $pair->select_start;
			$result['select_end'] = $pair->select_end;
			$result['digit_amount'] = $pair->digit_amount;
			$result['digit_price'] = $pair->digit_price;
			$results[] = $result;
		}
		$response["status"] = 1;
		$response["pairlist"] = $results;
		echo json_encode($response);		
	}
	
	public function pairDetails() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'pair' => "required",
		], [
			'pair.required' => 'Please Enter pair',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '1', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}
		$pair = $data['pair'];
		$uid = $data['user_id'];

		$res = explode('_', $pair);
		$from_symbol = $res[0];
		$to_symbol = $res[1];
		$getTrade = TradePairs::where('from_symbol', $from_symbol)->where('to_symbol', $to_symbol)->select('fee_per', 'tfee_per', 'min_price','minamt', 'last_price')->first();
		$getBal = Wallet::where('user_id', $uid)->select($from_symbol, $to_symbol)->first();
		if($getTrade) {
			$maker = $getTrade->fee_per;
			$taker = $getTrade->tfee_per;
			$response['status'] = 1;
			$response['message'] = 'suceess';
			$response['pair'] = $pair;
			$response['minAmount'] =  $getTrade->minamt;
			$response['minPrice'] =  $getTrade->min_price;
			$response['lastPrice'] =  $getTrade->last_price;
			$response['maker'] = number_format($maker, 2, '.', '');
			$response['taker'] = number_format($taker, 2, '.', '');
			if (!empty($getBal)) {
				$response['firstBal'] = $getBal->$from_symbol;
				$response['secondBal'] = $getBal->$to_symbol;
			} else {
				$response['firstBal'] = 0;
				$response['secondBal'] = 0;
			}
		} else {
			$response['status'] = 0;
			$response['message'] = 'Invalid Pair';
		}
		echo json_encode($response);	
	}

	public function getOrders() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'pair' => "required",
		], [
			'pair.required' => 'Please Enter pair',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '1', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}
		$pair = $data['pair'];
		$res = explode('_', $pair);
		$from_symbol = $res[0];
		$to_symbol = $res[1];
		$buyOrders = Trades::getOrders('Buy', $from_symbol, $to_symbol, 'API_WISE_ORDERS');
		$sellOrders = Trades::getOrders('Sell', $from_symbol, $to_symbol, 'API_WISE_ORDERS');
		$response['status'] = 1;
		$response['message'] = 'suceess';
		$response['bids'] = $buyOrders;
		$response['asks'] = $sellOrders;
		echo json_encode($response);
	}

	public function getHistory() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'pair' => "required",
		], [
			'pair.required' => 'Please Enter pair',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '1', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}
		$pair = $data['pair'];
		$res = explode('_', $pair);
		$from_symbol = $res[0];
		$to_symbol = $res[1];
		$orders = Trades::allHistory($from_symbol, $to_symbol, 'API_WISE_ORDER');
		if($orders) {
			$response['status'] = 1;
			$response['message'] = 'suceess';
			$response['orders'] = $orders;
		} else {
			$response['status'] = 0;
			$response['message'] = 'suceess';
			$response['orders'] = trans('app_lang.No_Tradehistory');
		}
		echo json_encode($response);	
	}

	public function getActiveOrders() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'pair' => "required",
		], [
			'pair.required' => 'Please Enter pair',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '1', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}
		$pair = $data['pair'];
		$userId = $data['user_id'];
		if($userId != '') {
			$res = explode('_', $pair);
			$from_symbol = $res[0];
			$to_symbol = $res[1];
			$orders = Trades::getActiveOrders($from_symbol, $to_symbol, $userId, 'API_WISE_ORDERS');
			if($orders) {
				$response['status'] = 1;
				$response['message'] = 'suceess';
				$response['orders'] = $orders;
			} else {
				$response['status'] = 0;
				$response['message'] = 'suceess';
				$response['orders'] = trans('app_lang.no_activeorder');
			}
		} else {
			$response['status'] = 0;
			$response['message'] = 'Invalid Keys';
		}
		echo json_encode($response);	
	}

	public function getStopOrders() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'pair' => "required",
		], [
			'pair.required' => 'Please Enter pair',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '1', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}
		$pair = $data['pair'];
		$userId = $data['user_id'];
		if($userId != '') {
			$res = explode('_', $pair);
			$from_symbol = $res[0];
			$to_symbol = $res[1];
			$orders = Trades::getStopOrders($from_symbol, $to_symbol, $userId, 'API_WISE_ORDERS');
			if($orders) {
				$response['status'] = 1;
				$response['message'] = 'suceess';
				$response['orders'] = $orders;
			} else {
				$response['status'] = 0;
				$response['message'] = 'suceess';
				$response['orders'] = trans('app_lang.no_stoporder');
			}
		} else {
			$response['status'] = 0;
			$response['message'] = 'Invalid Keys';
		}
		echo json_encode($response);	
	}

	public function getMyhistory() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'pair' => "required",
		], [
			'pair.required' => 'Please Enter pair',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '1', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}
		$pair = $data['pair'];
		$userId = $data['user_id'];
		if($userId != '') {
			$res = explode('_', $pair);
			$from_symbol = $res[0];
			$to_symbol = $res[1];
			$orders = Trades::myHistory($from_symbol, $to_symbol, $userId, 'API_WISE_ORDERS');
			if($orders) {
				$response['status'] = 1;
				$response['message'] = 'suceess';
				$response['orders'] = $orders;
			} else {
				$response['status'] = 0;
				$response['message'] = 'suceess';
				$response['orders'] = trans('app_lang.No_Tradehistory');
			}
		} else {
			$response['status'] = 0;
			$response['message'] = 'Invalid Keys';
		}
		echo json_encode($response);	
	}

	public function createOrder() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'pair' => "required",
			'order' => "required",
			'type' => "required",
			'amount' => "required|numeric",
			'price' => "required|numeric",
		], [
			'pair.required' => 'Please Enter pair',
			'order.required' => 'Please Enter ordertype',
			'type.required' => 'Please Enter type',
			'amount.required' => 'Please Enter amount',
			'amount.numeric' => 'Please Enter valid amount',
			'price.required' => 'Please Enter price',
			'price.numeric' => 'Please Enter valid price',			
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '1', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		} else {
			$userId = $data['user_id'];
			if($userId != '') {
				$type = strip_tags($data['type']);
				if($type == 'Buy') {
					$response = self::createBuyorder();
				} else {
					$response = self::createSellorder();
				}
			} else {
				$response['status'] = 0;
				$response['message'] = 'Invalid Keys';
			}
			echo json_encode($response);	
		}
	}

	public function createBuyorder() {
		$data = Input::all();
		$userId = $data['user_id'];
		if($userId != '') {
			$order_type = strip_tags($data['order']);
			$amount = strip_tags($data['amount']);
			$price = strip_tags($data['price']);
			$pair = strip_tags($data['pair']);
			$pair1 = explode('/', $pair);
			$from_symbol = $pair1[0];
			$to_symbol = $pair1[1];
			$tradeFromSym = $from_symbol;
			$tradeToSym = $to_symbol;

			$userDetails = User::where('id', $userId)->select('pro_user', 'auto_trade')->first();
			$pro_user = $userDetails->pro_user;
			$auto_trade = $userDetails->auto_trade;	
			$sta = 1;

			if($sta && $auto_trade) {
				$prevoiusOrder = CoinOrder::where('user_id', $userId)->select('created_at')->orderBy('id', 'desc')->first();
				if($prevoiusOrder) {
					$datetime1 = new DateTime();
					$datetime2 = new DateTime($prevoiusOrder->created_at);
					$interval = $datetime1->diff($datetime2);
					$secs = $interval->format('%s');
					if($secs < 10) {
						$ret = array('status' => '0', 'msg' => 'Please try again after sometime');
						echo json_encode($ret);exit;
					}
				} 

				if($to_symbol == 'INR') {
					$inr_price = get_inr_price('USDT');
				} else {
					$inr_price = 0;
				}

				$getTrade = TradePairs::where('from_symbol', $from_symbol)->where('to_symbol', $to_symbol)->select('fee_per', 'tfee_per','min_price', 'last_price','pair','digit_amount', 'digit_price', 't_status')->first();
				$digit_amount = $getTrade->digit_amount;
				$digit_price = $getTrade->digit_price;
				$table_price = $getTrade->last_price;
				$t_status = $getTrade->t_status;
				$tot = $amount * $price;
				if ($_SERVER['HTTP_HOST'] != "localhost") {
					$orderDetails = CoinOrder::where('firstCurrency', $from_symbol)->where('secondCurrency', $to_symbol)->where('user_id', $userId)->where('Type', 'sell')->whereIn('status', ['active','partially'])->where('ordertype', '!=', 'instant')->select('Price')->orderBy('Price', 'asc')->first();
					if(count($orderDetails)) {
						$row = $orderDetails->Price;
						if($row <= $price) {
							$response = array('status' => '0', 'msg' => 'Enter Price less than '. $row . ' ' . $to_symbol);
							return $response;
						}
					}
				}
				if ($order_type != "1") {
					$sell_rate = $table_price;
				}
				$limit = "0";
				if ($order_type == "market") {
					$getorder = Trades::checkActiveOrder($from_symbol, $to_symbol, 'Sell', $userId);
					if ($getorder == 0) {
						$ret = array('status' => '0', 'msg' => trans('app_lang.no_sell_order_available'));
						return $ret;
					}
					$price = $sell_rate;
					$order_typeval = "instant";
					$api_type = 'exchange limit';
					$order_status = "market";
				} else if ($order_type == "limit") {
					$order_typeval = "limit";
					$order_status = "active";
					$api_type = 'exchange limit';
				} else if ($order_type == "stoporder") {
					$order_typeval = "stoporder";
					$order_status = "stoporder";
					$api_type = 'exchange stop';
					if ($price <= $sell_rate) {
						$response = array('status' => '0', 'msg' => trans('app_lang.enter_above_market_price_buy_order'));
						return $response;
					}
				} 
				if ($amount != "" && $price != "") {
					if (is_numeric($amount) && is_numeric($price)) {
						if ($amount > 0 && $price > 0) {
							$feePer = $getTrade->fee_per;
							$tfeePer = $getTrade->tfee_per;
							$pairname = $getTrade->pair;
							$checkPrice = ($order_type == "3") ? $limit : $price;
							$subTotal = $amount * $checkPrice;
							$fee_amt = 0;
							if($to_symbol == 'INR') {
								$total = number_format($subTotal, 2, '.', '');
							} else {
								$total = number_format($subTotal, 8, '.', '');
							}
							$minAmt = $getTrade->min_price;
							$lastPrice = $getTrade->last_price;
							$minPrice = $lastPrice / 5;
							$maxPrice = $lastPrice * 5;
							if ($checkPrice < $minPrice) {
								$response = array('status' => '0', 'msg' => "Minimum Price is " . number_format($minPrice, $digit_price, '.', '') . ' ' . $to_symbol);
								return $response;
							}
							if ($checkPrice > $maxPrice) {
								$response = array('status' => '0', 'msg' => "Maximum Price is " . number_format($maxPrice, $digit_price, '.', '') . ' ' . $to_symbol);
								return $response;
							}
							if ($amount < $minAmt) {
								$response = array('status' => '0', 'msg' => trans('app_lang.min_trade_amount') . ' ' . $minAmt . ' ' . $pair1[0]);
								return $response;
							}
							$balance = TradeModel::fetchuserbalancebyId($userId, $tradeToSym);
							if ($total <= $balance) {
								if ($order_type != "market") {
									$updatesecondBalance = $balance - $total;
									$updatesecondBalance = number_format(trim($updatesecondBalance), 8, '.', '');
									$remarks = 'BuyOrder placed for '. $total . ' ' . $tradeToSym . ' Old balance: '. $balance;
									$updatedata = array($tradeToSym => $updatesecondBalance, 'remarks' => $remarks);
								} else {
									$updatedata = array();
								}
								$current_date = date('Y-m-d');
								$current_time = date('H:i:s');
								$datetime = date("Y-m-d H:i:s");
								$trdPrice = number_format($price, $digit_price, '.', '');
								$rand = Trades::randomstring();
								$data = array(
									'user_id' => $userId,
									'Amount' => number_format($amount, $digit_amount, '.', ''),
									'originalAmount' => number_format($amount, $digit_amount, '.', ''),
									'Price' => $trdPrice,
									'Total' => number_format($total, 8, '.', ''),
									'Fee' => number_format($fee_amt, 8, '.', ''),
									'firstCurrency' => $from_symbol,
									'secondCurrency' => $to_symbol,
									'Type' => "Buy",
									'orderDate' => $current_date,
									'orderTime' => $current_time,
									'datetime' => $datetime,
									'pair' => $pair,
									'status' => $order_status,
									'fee_per' => $feePer,
									'taker_fee_par' => $tfeePer,
									'trade_type_status' => 0,
									'ordertype' => $order_typeval,
									'inr_price' => $inr_price,
									'stoporderprice' => number_format($price, $digit_price, '.', ''),
									'trigger_price' => number_format($limit, $digit_price, '.', ''),
									'liquidity_order' => 0,
									'app_site' => 'app',
									'pro_user' => $pro_user,
									'ledger_id' => $rand,
								);
								$create = DB::transaction(function () use ($userId, $updatedata, $data, $order_type) {
									if ($order_type != "market") {
										$updatequery = Wallet::where('user_id', $userId)->update($updatedata);
									}
									$create = CoinOrder::create($data);
									return $create;
								});
								if ($create) {
									$map = array();
									if ($order_typeval == "limit") {
										$map = TradeModel::mapping($create->id, $lastPrice);							
									} else if ($order_typeval == "instant") {
										$map = TradeModel::marketMapping($create->id, $lastPrice);
									}
									$userdetails = User::where('id', $userId)->select('device_token')->first();
									$devicetoken = $userdetails->device_token;
									$title = 'Trade';
									$msg = trans('app_lang.buy_order_place_successfully');
									ApiUsers::sendnotification($title,$msg,$devicetoken);
									$response = array('status' => '1', 'msg' => trans('app_lang.buy_order_place_successfully'));
								} else {
									$response = array('status' => '0', 'msg' => trans('failed_create_order'));
								}
							} else {
								$response = array('status' => '0', 'msg' => trans('app_lang.insufficint_balance'));
							}
						} else {
							$response = array('status' => '0', 'msg' => trans('app_lang.enter_valid_amount_price'));
						}
					} else {
						$response = array('status' => '0', 'msg' => trans('app_lang.enter_amount_price'));
					}
				} else {
					$response = array('status' => '0', 'msg' => trans('app_lang.enter_amount_price'));
				}
			} else {
				$response = array('status' => '0', 'msg' => 'Trade is under maintenance');
			}
		} else {
			$response['status'] = 0;
			$response['message'] = 'Invalid Keys';
		}
		return $response;
	}

	public function createSellorder() {
		$data = Input::all();
		$userId = $data['user_id'];
		if($userId != '') {
			$limit = 0;
			$order_type = strip_tags($data['order']);
			$pair = strip_tags($data['pair']);
			$amount = strip_tags($data['amount']);
			$price = strip_tags($data['price']);
			$pair1 = explode('/', $pair);
			$from_symbol = $pair1[0];
			$to_symbol = $pair1[1];
			$tradeFromSym = $from_symbol;
			$tradeToSym = $to_symbol;

			$userDetails = User::where('id', $userId)->select('pro_user', 'auto_trade', 'country')->first();
			$pro_user = $userDetails->pro_user;
			$auto_trade = $userDetails->auto_trade;	
			$sta = 1;

			if($sta && $auto_trade) {				
				$prevoiusOrder = CoinOrder::where('user_id', $userId)->select('created_at')->orderBy('id', 'desc')->first();
				if($prevoiusOrder) {
					$datetime1 = new DateTime();
					$datetime2 = new DateTime($prevoiusOrder->created_at);
					$interval = $datetime1->diff($datetime2);
					$secs = $interval->format('%s');
					if($secs < 10) {
						$ret = array('status' => '0', 'msg' => 'Please try again after sometime');
						echo json_encode($ret);exit;
					}
				} 

				if($to_symbol == 'INR') {
					$inr_price = get_inr_price('USDT');
				} else {
					$inr_price = 0;
				}

				$getTrade = TradePairs::where('from_symbol', $from_symbol)->where('to_symbol', $to_symbol)->select('fee_per', 'tfee_per','min_price', 'last_price','pair','digit_amount', 'digit_price', 't_status')->first();
				$digit_amount = $getTrade->digit_amount;
				$digit_price = $getTrade->digit_price;
				$table_price = $getTrade->last_price;
				$t_status = $getTrade->t_status;

				if ($_SERVER['HTTP_HOST'] != "localhost") {
					$orderDetails = CoinOrder::where('firstCurrency', $from_symbol)->where('secondCurrency', $to_symbol)->where('user_id', $userId)->where('Type', 'buy')->whereIn('status', ['active','partially'])->where('ordertype', '!=', 'instant')->select('Price')->orderBy('Price', 'desc')->first();
					if(count($orderDetails)) {
						$row = $orderDetails->Price;
						if($row >= $price) {
							$response = array('status' => '0', 'msg' => 'Enter Price more than '. $row . ' ' . $to_symbol);
							return $response;
						}
					}
				}

				if ($order_type != "1") {
					$buy_rate = $table_price;
				}
				if ($order_type == "market") {
					$getorder = Trades::checkActiveOrder($from_symbol, $to_symbol, 'buy', $userId);
					if ($getorder == 0) {
						$response = array('status' => '0', 'msg' => trans('app_lang.no_buy_order'));
						return $response;
					}
					$price = $buy_rate;
					$order_typeval = "instant";
					$order_status = "market";
					$api_type = 'exchange market';
				} else if ($order_type == "limit") {
					$order_typeval = "limit";
					$order_status = "active";
					$api_type = 'exchange limit';
				} else if ($order_type == "stoporder") {
					$order_typeval = "stoporder";
					$order_status = "stoporder";
					$api_type = 'exchange stop';
					if ($price >= $buy_rate) {
						$response = array('status' => '0', 'msg' => trans('app_lang.enter_below_market_price_sell_order'));
						return $response;
					}
				}
				if ($amount != "" && $price != "") {
					if (is_numeric($amount) && is_numeric($price)) {
						if ($amount > 0 && $price > 0) {
							$getTrade = TradePairs::where('from_symbol', $from_symbol)->where('to_symbol', $to_symbol)->select('fee_per', 'tfee_per', 'min_price', 'last_price', 'pair')->first();
							$feePer = $getTrade->fee_per;
							$tfeePer = $getTrade->tfee_per;
							$pairname = $getTrade->pair;
							$checkPrice = ($order_type == "3") ? $limit : $price;
							$subTotal = $amount * $checkPrice;
							$fee_amt = 0;
							$total = $subTotal;
							$minAmt = $getTrade->min_price;
							$lastPrice = $getTrade->last_price;
							$minPrice = $lastPrice / 5;
							$maxPrice = $lastPrice * 5;
							if ($checkPrice < $minPrice) {
								$response = array('status' => '0', 'msg' => "Minimum Price is " . number_format($minPrice, $digit_price, '.', '') . ' ' . $to_symbol);
								return $response;
							}
							if ($checkPrice > $maxPrice) {
								$response = array('status' => '0', 'msg' => "Maximum Price is " . number_format($maxPrice, $digit_price, '.', '') . ' ' . $to_symbol);
								return $response;
							}
							if ($amount < $minAmt) {
								$response = array('status' => '0', 'msg' => trans('app_lang.min_trade_amount') . ' ' . $minAmt . ' ' . $pair1[0]);
								return $response;
							}
							$balance = TradeModel::fetchuserbalancebyId($userId, $tradeFromSym);
							if ($amount <= $balance) {
								if ($order_type != "market") {
									$updatefirstBalance = $balance - ($amount);
									$updatefirstBalance = number_format(trim($updatefirstBalance), 8, '.', '');
									$remarks = 'SellOrder placed for '. $amount . ' ' . $tradeFromSym . ' Old balance: '. $balance;
									$updatedata = array($tradeFromSym => $updatefirstBalance, 'remarks' => $remarks);
								} else {
									$updatedata = array();
								}
								$current_date = date('Y-m-d');
								$current_time = date('H:i:s');
								$datetime = date("Y-m-d H:i:s");
								$trdPrice = number_format($price, $digit_price, '.', '');
								$rand = Trades::randomstring();
								$data = array(
									'user_id' => $userId,
									'Amount' => number_format($amount, $digit_amount, '.', ''),
									'originalAmount' => number_format($amount, $digit_amount, '.', ''),
									'Price' => $trdPrice,
									'Total' => number_format($total, 8, '.', ''),
									'Fee' => number_format($fee_amt, 8, '.', ''),
									'firstCurrency' => $from_symbol,
									'secondCurrency' => $to_symbol,
									'Type' => "Sell",
									'orderDate' => $current_date,
									'orderTime' => $current_time,
									'datetime' => $datetime,
									'pair' => $pair,
									'status' => $order_status,
									'fee_per' => $feePer,
									'taker_fee_par' => $tfeePer,
									'trade_type_status' => 0,
									'ordertype' => $order_typeval,
									'inr_price' => $inr_price,
									'stoporderprice' => number_format($price, $digit_price, '.', ''),
									'trigger_price' => number_format($limit, $digit_price, '.', ''),
									'liquidity_order' => 0,
									'app_site' => 'app',
									'ledger_id' => $rand,
								);
								$create = DB::transaction(function () use ($userId, $updatedata, $data, $order_type) {
									if ($order_type != "market") {
										$updatequery = Wallet::where('user_id', $userId)->update($updatedata);
									}
									$create = CoinOrder::create($data);
									return $create;
								});
								if ($create) {
									$map = array();
									if ($order_typeval == "limit") {
										$map = TradeModel::mapping($create->id, $lastPrice);			
									} else if ($order_typeval == "instant") {
										$map = TradeModel::marketMapping($create->id, $lastPrice);
									}

									$userdetails = User::where('id', $userId)->select('device_token')->first();
									$devicetoken = $userdetails->device_token;
									$title = 'Trade';
									$msg = trans('app_lang.sell_order_placed_success');
									ApiUsers::sendnotification($title,$msg,$devicetoken);
									$response = array('status' => '1', 'msg' => trans('app_lang.sell_order_placed_success'));
								} else {
									$response = array('status' => '0', 'msg' => "Failed to create an order");
								}
							} else {
								$response = array('status' => '0', 'msg' => trans('app_lang.insufficint_balance'), 'amt' => $amount, 'fee' => $fee_amt);
							}
						} else {
							$response = array('status' => '0', 'msg' => trans('app_lang.enter_valid_amount_price'));
						}
					} else {
						$response = array('status' => '0', 'msg' => trans('app_lang.enter_valid_amount_price'));
					}
				} else {
					$response = array('status' => '0', 'msg' => trans('app_lang.enter_amount_price'));
				}
			} else {
				$response = array('status' => '0', 'msg' => 'Trade is under maintenance');
			}
		} else {
			$response['status'] = 0;
			$response['message'] = 'Invalid Keys';
		}
		return $response;
	}

	public function cancelOrder() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'orderid' => "required",
		], [
			'orderid.required' => 'Please Enter orderid',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '1', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}
		$userId = $data['user_id'];
		if($userId != '') {
			$dec = decrypText($data['orderid']);
			$res = explode('-', $dec);
			$id = $res[0];
			$rand = $res[1];
			$date = self::datecheck($rand);
			if($date) {
				$result_data = array('status' => '0', 'msg' => 'Invalid Request');
			} else {
				$res = CoinOrder::where('id', $id)->where('ledger_id', $rand)->select('status', 'Type', 'Price', 'firstCurrency', 'secondCurrency')->first();
				if(!empty($res)) {
					$status = $res->status;
					$firstCurrency = $res->firstCurrency;
					$secondCurrency = $res->secondCurrency;
					if ($status == "cancelled" || $status == "filled") {
						$msg = trans('app_lang.already_cancelled');
						$response = array('status' => '0', 'msg' => $msg);
					} else {
						$result = DB::transaction(function () use ($id) {
							CoinOrder::where('id', $id)->whereIn('status', ['active', 'partially', 'stoporder'])->update(['status' => "cancelled", 'tradetime' => date('Y-m-d H:i:s')]);
							$res_order = TradeModel::remove_active_model($id);
							return $res_order;
						});						
						$msg = "Order cancelled successfully";
						$userdetails = User::where('id', $userId)->select('device_token')->first();
						$devicetoken = $userdetails->device_token;
						$title = 'Trade';
						ApiUsers::sendnotification($title,$msg,$devicetoken);
						$response = array('status' => '1', 'msg' => $msg);
					}
				} else {
					$result_data = array('status' => '0', 'msg' => 'Invalid Request');
				}
			}
		} else {
			$response['status'] = 0;
			$response['message'] = 'Invalid Keys';
		}
		echo json_encode($response);	
	}

	public static function datecheck($date) {
		if (preg_match("/\d{4}-[01]\d-[0-3]\d [0-2]\d:[0-5]\d:[0-5]\d/",$date)) {
			return true;
		} else {
			return false;
		}
	}

	public function cancelAllActiveOrder() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$pair = $data['pair'];
			$res = explode('/', $pair);
			$from_symbol = $res[0];
			$to_symbol = $res[1];
			$result = CoinOrder::where('user_id', $userId)->where('firstCurrency', $from_symbol)->where('secondCurrency', $to_symbol)->whereIn('status', ['active', 'partially'])->select('id','status', 'Type', 'Price','api_id', 'firstCurrency', 'secondCurrency')->get();
			if(count($result) > 0) {
				foreach ($result as $res) {				
					$status = $res->status;
					$id = $res->id;
					$api_id = $res->api_id;
					$firstCurrency = $res->firstCurrency;
					$secondCurrency = $res->secondCurrency;
					if ($status == "cancelled" || $status == "filled") {
						$msg = trans('app_lang.already_cancelled');
						$response = array('status' => '0', 'msg' => $msg);
					} else {
						sleep(1);
						$result = DB::transaction(function () use ($id) {
							CoinOrder::where('id', $id)->whereIn('status', ['active', 'partially'])->update(['status' => "cancelled", 'tradetime' => date('Y-m-d H:i:s')]);
							$res_order = TradeModel::remove_active_model($id);
							return $res_order;
						});	
						$msg = "Order cancelled successfully";
						$userdetails = User::where('id', $userId)->select('device_token')->first();
						$devicetoken = $userdetails->device_token;
						$title = 'Trade';
						ApiUsers::sendnotification($title,$msg,$devicetoken);
						$response = array('status' => '1', 'msg' => $msg, 'ordertype' => strtolower($res->Type), 'order' => str_replace('.', '_', $res->Price), 'trade' => array());
					}
				}
			} else {
				$msg = 'No active Orders';
				$response = array('status' => '0', 'msg' => $msg);
			}
		} else {
			$msg = trans('app_lang.login_failure');
			$response = array('status' => '2', 'msg' => $msg);
		}
		echo json_encode($response);
	}

	public function cancelAllStopOrder() {
		$data = Input::all();
		$userId = $data['user_id'];
		if ($userId != '') {
			$pair = $data['pair'];
			$res = explode('/', $pair);
			$from_symbol = $res[0];
			$to_symbol = $res[1];
			$result = CoinOrder::where('user_id', $userId)->where('firstCurrency', $from_symbol)->where('secondCurrency', $to_symbol)->whereIn('status', ['stoporder'])->select('id','status', 'Type', 'Price','api_id', 'firstCurrency', 'secondCurrency')->get();
			if(count($result) > 0) {
				foreach ($result as $res) {				
					$status = $res->status;
					$id = $res->id;
					$api_id = $res->api_id;
					$firstCurrency = $res->firstCurrency;
					$secondCurrency = $res->secondCurrency;
					if ($status == "cancelled" || $status == "filled") {
						$msg = trans('app_lang.already_cancelled');
						$response = array('status' => '0', 'msg' => $msg);
					} else {
						sleep(1);
						$result = DB::transaction(function () use ($id) {
							CoinOrder::where('id', $id)->whereIn('status', ['stoporder'])->update(['status' => "cancelled", 'tradetime' => date('Y-m-d H:i:s')]);
							$res_order = TradeModel::remove_active_model($id);
							return $res_order;
						});
						$msg = "Order cancelled successfully";
						$userdetails = User::where('id', $userId)->select('device_token')->first();
						$devicetoken = $userdetails->device_token;
						$title = 'Trade';
						ApiUsers::sendnotification($title,$msg,$devicetoken);
						$response = array('status' => '1', 'msg' => $msg, 'ordertype' => strtolower($res->Type), 'order' => str_replace('.', '_', $res->Price), 'trade' => array());
					}
				}
			} else {
				$msg = 'No active Orders';
				$response = array('status' => '2', 'msg' => $msg);
			}
		} else {
			$msg = trans('app_lang.login_failure');
			$response = array('status' => '2', 'msg' => $msg);
		}
		echo json_encode($response);
	}

	public function viewTradechart($pair) {
		return view('frontend.trade.tradeChart')->with('pair', $pair);
	}

	public function markets() {
		$data = Input::all();
		$userId = $data['user_id'];
		$type   = $data['type'];
		$currency   = $data['currency'];
		$response = $coinImg = array();
		$upArrow = URL::to('public/frontend/img/tri1.png');
		$downArrow = URL::to('public/frontend/img/trig.png');
		$yesterday = date('Y-m-d H:i:s', strtotime("-1 day"));
		$pairDetails = DB::select("select c.image, c.currency_name,b.id, b.from_symbol, b.to_symbol, (sum(askPrice * filledAmount)) as volume, a.askPrice as yesterday_price, MAX(a.askPrice) as high, MIN(a.askPrice) as low,b.last_price FROM ".PREFIX.ORDERTEMP." a right join ".PREFIX.TRADEPAIRS." b on a.firstCurrency = b.from_symbol and a.secondCurrency = b.to_symbol and a.created_at >= '" . $yesterday . "' and a.cancel_id = 0 left join ".PREFIX.CURRENCY." c on c.currency_symbol=b.from_symbol where b.site_status = 1 and b.to_symbol = '" . $currency . "' GROUP BY b.id ORDER BY b.id ASC");
		foreach ($pairDetails as $pairs) {
			$fromSymbol = $pairs->from_symbol;
			$toSymbol = $pairs->to_symbol;
			$forName = $fromSymbol . '/' . $toSymbol;
			$forUrl	 = $fromSymbol . '_' . $toSymbol;
			$coin = $curname = $pairs->currency_name;
			$curimg = $pairs->image;
			$high = ($pairs->high == "") ? "0.00" : $pairs->high;
			$low = ($pairs->low == "") ? "0.00" : $pairs->low;
			$inr_spread = 0;
			$lastPrice = $pairs->last_price;
			$upArrow = '<i class="fa fa-arrow-up"></i>';
			$downArrow = '<i class="fa fa-arrow-down"></i>';
			
			if($toSymbol == 'INR') {
				$lastPriceINR =  $lastPrice + $inr_spread;
			}
			$yesterPrice = $pairs->yesterday_price;
			if ($yesterPrice <= 0) {
				$changePer = "0.00";
				$arrow = $upArrow;
				$sym = "+";
				$cls = "text_green_1";
			} else {
				$changePrice = ($lastPrice - $yesterPrice) / $yesterPrice;
				$changePer = $changePrice * 100;
				$arrow = ($lastPrice >= $yesterPrice) ? $upArrow : $downArrow;
				$sym = ($lastPrice >= $yesterPrice) ? "+" : "";
				$cls = ($lastPrice >= $yesterPrice) ? "text_green_1" : "text_red_1";
			}
			$changePer = number_format($changePer, 2, '.', '') . '%';

			$lastPrice = rtrim(rtrim(sprintf('%.8F', $lastPrice), '0'), ".");
			$volume = ($pairs->volume == "") ? "0.00" : number_format($pairs->volume, 4, '.', '');
			$coinImg[] = strtolower($toSymbol) . ".png";
			if (!in_array($fromSymbol, $coinImg)) {
				$coinImg[] = strtolower($fromSymbol) . ".png";
			}
			$favorites = dashboard_fav($userId);
			$fav = 0;
			if (in_array($forUrl, $favorites)) {
				$fav = 1;
			}
			$ifav = ($fav == 1) ? 1 : 0;
			$getBal = Wallet::where('user_id', $userId)->select($fromSymbol, $toSymbol)->first();
			if (!empty($getBal)) {
				$firstBal = $getBal->$fromSymbol;
				$secondBal = $getBal->$toSymbol;
			} else {
				$firstBal = 0;
				$secondBal = 0;
			}
			switch ($toSymbol) {
				case 'BTC':
				if (in_array($forUrl, $favorites)) {
					if($type == 1) {
						$fav = array(
							'Fav' => '1',
							'Market' => $forName,
							'Name' => $forName,
							'Lastprice' => number_format($lastPrice, 8, '.', ''),
							'Change' => $changePer,
							'Arrow' => $arrow,
							'High' => number_format($high, 8, '.', ''),
							'Low' => number_format($low, 8, '.', ''),
							'High' => number_format($high, 8, '.', ''),
							'Volume' => number_format($volume, 8, '.', ''),
							'FirstBal' => $firstBal,
							'SecondBal' => $secondBal,
							'Image' => $curimg,
						);
						$response['FAV'][] = $fav;
					} else {
						$fav = array(
							'Fav' => '1',
							'Market' => $forName,
							'Lastprice' => number_format($lastPrice, 8, '.', ''),
							'Change' => $changePer,
							'Arrow' => $arrow,
							'FirstBal' => $firstBal,
							'SecondBal' => $secondBal,
							'Image' => $curimg,
						);
						$response['FAV'][] = $fav;
					}
					$fav = 1;
				}
				if($type == 1) {
					$btc = array(
						'Fav' => $ifav,
						'Market' => $forName,
						'Name' => $forName,
						'Lastprice' => number_format($lastPrice, 8, '.', ''),
						'Change' => $changePer,
						'Arrow' => $arrow,
						'High' => number_format($high, 8, '.', ''),
						'Low' => number_format($low, 8, '.', ''),
						'High' => number_format($high, 8, '.', ''),
						'Volume' => number_format($volume, 8, '.', ''),
						'FirstBal' => $firstBal,
						'SecondBal' => $secondBal,
						'Image' => $curimg,						
					);
					$response['BTC'][] = $btc;
				} else {
					$btc = array(
						'Fav' => $ifav,
						'Market' => $forName,
						'Lastprice' => number_format($lastPrice, 8, '.', ''),
						'Change' => $changePer,
						'Arrow' => $arrow,
						'FirstBal' => $firstBal,
						'SecondBal' => $secondBal,
						'Image' => $curimg,
					);
					$response['BTC'][] = $btc;
				}
				break;
				case 'INR':
				if (in_array($forUrl, $favorites)) {
					if($type == 1) { 
						$fav = array(
							'Fav' => '1',
							'Market' => $forName,
							'Name' => $forName,
							'Lastprice' => number_format($lastPrice, 4, '.', ''),
							'Change' => $changePer,
							'Arrow' => $arrow,
							'High' => number_format($high, 4, '.', ''),
							'Low' => number_format($low, 4, '.', ''),
							'High' => number_format($high, 4, '.', ''),
							'Volume' => number_format($volume, 4, '.', ''),
							'FirstBal' => $firstBal,
							'SecondBal' => $secondBal,
							'Image' => $curimg,
						);
						$response['FAV'][] = $fav;
					} else {
						$fav = array(
							'Fav' => '1',
							'Market' => $forName,
							'Lastprice' => number_format($lastPrice, 4, '.', ''),
							'Arrow' => $arrow,
							'Change' => $changePer,
							'FirstBal' => $firstBal,
							'SecondBal' => $secondBal,
							'Image' => $curimg,
						);
						$response['FAV'][] = $fav;
					}
					$fav = 1;
				}
				if($type == 1) {
					$inr = array(
						'Fav' => $ifav,
						'Market' => $forName,
						'Name' => $forName,
						'Lastprice' => number_format($lastPrice, 4, '.', ''),
						'Change' => $changePer,
						'High' => number_format($high, 4, '.', ''),
						'Arrow' => $arrow,
						'Low' => number_format($low, 4, '.', ''),
						'High' => number_format($high, 4, '.', ''),
						'Volume' => number_format($volume, 4, '.', ''),
						'FirstBal' => $firstBal,
						'SecondBal' => $secondBal,
						'Image' => $curimg,
					);
					$response['INR'][] = $inr;
				} else {
					$inr = array(
						'Fav' => $ifav,
						'Market' => $forName,
						'Lastprice' => number_format($lastPrice, 4, '.', ''),
						'Arrow' => $arrow,
						'Change' => $changePer,
						'FirstBal' => $firstBal,
						'SecondBal' => $secondBal,
						'Image' => $curimg,
					);
					$response['INR'][] = $inr;
				}
				break;
				case 'USDT':
				if (in_array($forUrl, $favorites)) {
					if($type == 1) { 
						$fav = array(
							'Fav' => '1',
							'Market' => $forName,
							'Name' => $forName,
							'Lastprice' => number_format($lastPrice, 8, '.', ''),
							'Change' => $changePer,
							'Arrow' => $arrow,
							'High' => number_format($high, 8, '.', ''),
							'Low' => number_format($low, 8, '.', ''),
							'High' => number_format($high, 8, '.', ''),
							'Volume' => number_format($volume, 8, '.', ''),
							'FirstBal' => $firstBal,
							'SecondBal' => $secondBal,
							'Image' => $curimg,
						);
						$response['FAV'][] = $fav;
					} else {
						$fav = array(
							'Fav' => '1',
							'Market' => $forName,
							'Lastprice' => number_format($lastPrice, 8, '.', ''),
							'Change' => $changePer,
							'Arrow' => $arrow,
							'FirstBal' => $firstBal,
							'SecondBal' => $secondBal,
							'Image' => $curimg,
						);
						$response['FAV'][] = $fav;
					}
					$fav = 1;
				}
				if($type == 1) {
					$usdt = array(
						'Fav' => $ifav,
						'Market' => $forName,
						'Name' => $forName,
						'Lastprice' => number_format($lastPrice, 8, '.', ''),
						'Change' => $changePer,
						'Arrow' => $arrow,
						'High' => number_format($high, 8, '.', ''),
						'Low' => number_format($low, 8, '.', ''),
						'High' => number_format($high, 8, '.', ''),
						'Volume' => number_format($volume, 8, '.', ''),
						'FirstBal' => $firstBal,
						'SecondBal' => $secondBal,
						'Image' => $curimg,
					);
					$response['USDT'][] = $usdt;
				} else {
					$usdt = array(
						'Fav' => $ifav,
						'Market' => $forName,
						'Lastprice' => number_format($lastPrice, 8, '.', ''),
						'Change' => $changePer,
						'Arrow' => $arrow,
						'FirstBal' => $firstBal,
						'SecondBal' => $secondBal,
						'Image' => $curimg,
					);
					$response['USDT'][] = $usdt;
				}
				break;
				default:
				break;
			}
			$response['FAV'] = empty($response['FAV']) ? array() : $response['FAV'];
		}
		echo json_encode($response);
	}

	public function favorites() {

		$data = Input::all();
		$userId = $data['user_id'];
		$type   = $data['type'];
		$response = $coinImg = array();
		$upArrow = URL::to('public/frontend/img/tri1.png');
		$downArrow = URL::to('public/frontend/img/trig.png');
		$yesterday = date('Y-m-d H:i:s', strtotime("-1 day"));
		$pairDetails = DB::select("select c.image, c.currency_name,b.id, b.from_symbol, b.to_symbol, (sum(askPrice * filledAmount)) as volume, a.askPrice as yesterday_price, MAX(a.askPrice) as high, MIN(a.askPrice) as low,b.last_price FROM ".PREFIX.ORDERTEMP." a right join ".PREFIX.TRADEPAIRS." b on a.firstCurrency = b.from_symbol and a.secondCurrency = b.to_symbol and a.created_at >= '" . $yesterday . "' and a.cancel_id = 0 left join ".PREFIX.CURRENCY." c on c.currency_symbol=b.from_symbol where b.site_status = 1 GROUP BY b.id ORDER BY b.id ASC");
		foreach ($pairDetails as $pairs) {
			$fromSymbol = $pairs->from_symbol;
			$toSymbol = $pairs->to_symbol;
			$inr_spread = 0;
			$forName = $fromSymbol . '/' . $toSymbol;
			$forUrl	 = $fromSymbol . '_' . $toSymbol;
			$coin = $curname = $pairs->currency_name;
			$curimg = $pairs->image;
			$high = ($pairs->high == "") ? "0.00" : $pairs->high;
			$low = ($pairs->low == "") ? "0.00" : $pairs->low;
			$lastPrice = ($pairs->last_price == 0) ? $pairs->sell_rate : $pairs->last_price;
			$tradeData = Trades::getTradeData($forName, $fromSymbol, $toSymbol);
			$lastPrice = $tradeData['lastprice'];
			$cls = $tradeData['class'];
			if($cls == "text_red_1") {
				$changePer = $tradeData['change'].'%';
				$arrow = '<i class="fa fa-arrow-down"></i>';
			} else {
				$changePer = $tradeData['change'].'%';
				$arrow = '<i class="fa fa-arrow-up"></i>';
			}
			$high = $tradeData['high'];
			$low = $tradeData['low'];
			$volume = $tradeData['volume'];
			
			if($toSymbol == 'INR') {
				$lastPriceINR =  $lastPrice + $inr_spread;
			}
			$coinImg[] = strtolower($toSymbol) . ".png";
			if (!in_array($fromSymbol, $coinImg)) {
				$coinImg[] = strtolower($fromSymbol) . ".png";
			}
			$favorites = dashboard_fav($userId);
			$fav = 0;
			if (in_array($forUrl, $favorites)) {
				$fav = 1;
			}
			$ifav = ($fav == 1) ? 1 : 0;
			$getBal = Wallet::where('user_id', $userId)->select($fromSymbol, $toSymbol)->first();
			if (!empty($getBal)) {
				$firstBal = $getBal->$fromSymbol;
				$secondBal = $getBal->$toSymbol;
			} else {
				$firstBal = 0;
				$secondBal = 0;
			}
			switch ($toSymbol) {
				case 'BTC':
				if (in_array($forUrl, $favorites)) {
					if($type == 1) {
						$fav = array(
							'Fav' => '1',
							'Market' => $forName,
							'Name' => $forName,
							'Lastprice' => number_format($lastPrice, 8, '.', ''),
							'Change' => $changePer,
							'Arrow' => $arrow,
							'High' => number_format($high, 8, '.', ''),
							'Low' => number_format($low, 8, '.', ''),
							'High' => number_format($high, 8, '.', ''),
							'Volume' => number_format($volume, 8, '.', ''),
							'FirstBal' => $firstBal,
							'SecondBal' => $secondBal,
							'Image' => $curimg,
						);
						$response['FAV'][] = $fav;
					} else {
						$fav = array(
							'Fav' => '1',
							'Market' => $forName,
							'Lastprice' => number_format($lastPrice, 8, '.', ''),
							'Change' => $changePer,
							'Arrow' => $arrow,
							'FirstBal' => $firstBal,
							'SecondBal' => $secondBal,
							'Image' => $curimg,
						);
						$response['FAV'][] = $fav;
					}
					$fav = 1;
				}
				break;
				case 'INR':
				if (in_array($forUrl, $favorites)) {
					if($type == 1) { 
						$fav = array(
							'Fav' => '1',
							'Market' => $forName,
							'Name' => $forName,
							'Lastprice' => number_format($lastPrice, 4, '.', ''),
							'Change' => $changePer,
							'Arrow' => $arrow,
							'High' => number_format($high, 4, '.', ''),
							'Low' => number_format($low, 4, '.', ''),
							'High' => number_format($high, 4, '.', ''),
							'Volume' => number_format($volume, 4, '.', ''),
							'FirstBal' => $firstBal,
							'SecondBal' => $secondBal,
							'Image' => $curimg,
						);
						$response['FAV'][] = $fav;
					} else {
						$fav = array(
							'Fav' => '1',
							'Market' => $forName,
							'Lastprice' => number_format($lastPrice, 4, '.', ''),
							'Arrow' => $arrow,
							'Change' => $changePer,
							'FirstBal' => $firstBal,
							'SecondBal' => $secondBal,
							'Image' => $curimg,
						);
						$response['FAV'][] = $fav;
					}
					$fav = 1;
				}
				break;
				case 'USDT':
				if (in_array($forUrl, $favorites)) {
					if($type == 1) { 
						$fav = array(
							'Fav' => '1',
							'Market' => $forName,
							'Name' => $forName,
							'Lastprice' => number_format($lastPrice, 8, '.', ''),
							'Change' => $changePer,
							'Arrow' => $arrow,
							'High' => number_format($high, 8, '.', ''),
							'Low' => number_format($low, 8, '.', ''),
							'High' => number_format($high, 8, '.', ''),
							'Volume' => number_format($volume, 8, '.', ''),
							'FirstBal' => $firstBal,
							'SecondBal' => $secondBal,
							'Image' => $curimg,
						);
						$response['FAV'][] = $fav;
					} else {
						$fav = array(
							'Fav' => '1',
							'Market' => $forName,
							'Lastprice' => number_format($lastPrice, 8, '.', ''),
							'Change' => $changePer,
							'Arrow' => $arrow,
							'FirstBal' => $firstBal,
							'SecondBal' => $secondBal,
							'Image' => $curimg,
						);
						$response['FAV'][] = $fav;
					}
					$fav = 1;
				}
				break;
				default:
				break;
			}
			$response['FAV'] = empty($response['FAV']) ? array() : $response['FAV'];
		}
		echo json_encode($response);
	}

	public function addfav() {
		$data = Input::all();
		$pair = strip_tags($data['pair']);
		$userId = strip_tags($data['user_id']);
		if($userId != '') {
			$row = DB::table('pair_favorite')->where('user_id', $userId)->where('pair', $pair)->select('status')->first();
			$count = count($row);
			if ($count == 0) {
				$data = array(
					'user_id' => $userId,
					'pair' => $pair,
					'status' => '1',
				);
				$createOrder = DB::table('pair_favorite')->insert($data);
				$response = array('status' => '1', 'msg' => 'Added');
			} else {
				$status = $row->status;
				$sta = ($status == 0) ? 1 : 0;
				$msg = ($status == 0) ? 'Added' : 'Removed';
				DB::table('pair_favorite')->where('user_id', $userId)->where('pair', $pair)->update(['status' => $sta]);
				$response = array('status' => '1', 'msg' => $msg);
			}
		}
		echo json_encode($response);
	}
}