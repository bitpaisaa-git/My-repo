<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\CryptoAddress;
use App\Http\Controllers\Front\Trades;
use App\Model\AdminNotification;
use App\Model\BlockIP;
use App\Model\Career;
use App\Model\CareerCategory;
use App\Model\CareerDetails;
use App\Model\Cms;
use App\Model\CoinOrder;
use App\Model\ConsumerVerification;
use App\Model\Currency;
use App\Model\DepositSettings;
use App\Model\EmailTemplate;
use App\Model\ExchangePairs;
use App\Model\Faq;
use App\Model\GeetestLib;
use App\Model\Googleauthenticator;
use App\Model\LoginAttempt;
use App\Model\News;
use App\Model\SiteSettings;
use App\Model\Subscribe;
use App\Model\Support;
use App\Model\TradePairs; 
use App\Model\User;
use App\Model\UserActivity;
use App\Model\UserNotification;
use App\Model\Wallet;
use App\Model\WithdrawSettings;

use App\Model\Wallet\ConnectEth; 


use DB;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Mail;
use Redirect;
use URL;
use Validator;

class ApiHome extends Controller {
	public function __construct() {
	}

	public function home() {
		$yesterday = date('Y-m-d H:i:s', strtotime("-1 days"));
		$getPairs = TradePairs::where('site_status', '1')->where('to_symbol', 'INR')->select('fee_per', 'tfee_per', 'min_price','minamt', 'last_price', 'trading_pair', 'pair_name', 'from_symbol', 'to_symbol')->get();
		foreach ($getPairs as $pair) {
			$from_symbol = $pair->from_symbol;
			$getCurr = Currency::where('currency_symbol', $from_symbol)->select('currency_name', 'image')->first();
			$to_symbol = $pair->to_symbol;
			$pairname = $pair->pair_name;
			$tradeData = Trades::getTradeData($pairname, $from_symbol, $to_symbol);
			$res['pair'] =  $pairname;
			$res['base_full_name'] = $getCurr->currency_name;
			$res['currency_image'] = $getCurr->image;
			$res['current_price'] =  $pair->last_price;
			$res['low'] =  $tradeData['low'];
			$res['high'] =  $tradeData['high'];
			$res['percent'] =  $tradeData['change'];
			$res['start_price'] =  $tradeData['open'];
			$res['volume'] = $tradeData['volume'];
			$res['count'] = CoinOrder::where('pair', $pairname)->where('status', 'filled')->where('datetime', '>=', $yesterday)->count();
			$result[] = $res;
		}
		$getContent = Cms::where('id', '33')->select('content', 'title', 'image')->first();
		$response = array('status' => 1, 'tickers' => $result, 'content' => strip_tags($getContent->content));
		echo json_encode($response);exit;
	}

	public function calculator() {
		$exchange =  ExchangePairs::where('status','1')->orderBy('eid','asc')->get()->toArray();
		$response = array('status' => 1, 'exchangepair' => $exchange);
		echo json_encode($response);exit;
	}

	public function announcement() {
		$getContent = Cms::whereIn('id', ['35','36','37','38','39'])->select('content', 'title', 'image')->get();
		foreach ($getContent as $value) {
			$res['title'] = $value->title;
			$res['content'] = strip_tags($value->content);
			$res['image'] = $value->image;
			$content[] = $res;
		}
		$response = array('status' => 1, 'getContent' => $content);
		echo json_encode($response);exit;
	}

	public function checkusernameExists() {
		$data = Input::all();
		$first = strip_tags($data['user_name']);
		$getCount = User::where('consumer_name', $first)->count();
		$msg = ($getCount > 0) ? "false" : "true";
		$status = ($getCount > 0) ? 0 : 1;
		$response = array('status' => $status, 'msg' => $msg);
		echo json_encode($response);exit;
	}

	public function checkMobileExists() {
		$data = Input::all();
		$phone = strip_tags($data['phone']);
		$getCount = User::where('phone', $phone)->count();
		$msg = ($getCount > 0) ? "false" : "true";
		$status = ($getCount > 0) ? 0 : 1;
		$response = array('status' => $status, 'msg' => $msg);
		echo json_encode($response);exit;
	}

	public function checkEmailExists() {
		$data = Input::all();
		$email = explode('@', strip_tags(strtolower($data['email'])));
		$first = encrypText($email[0]);
		$second = encrypText($email[1]);
		$getCount = User::where('user_mail_id', $first)->where('unusual_user_key', $second)->count();
		$msg = ($getCount > 0) ? "false" : "true";
		$status = ($getCount > 0) ? 0 : 1;
		$response = array('status' => $status, 'msg' => $msg);
		echo json_encode($response);exit;
	}

	public function signup() {
		$data = Input::all();
		$Validation = Validator::make($data, User::$userSignupRule, User::$userSignupMsg);
		if ($Validation->fails()) {
			foreach ($Validation->messages()->getMessages() as $field_name => $message) {
				$response = array('status' => '0', 'msg' => $message[0]);
				echo json_encode($response);exit;
			}
		}
		if ($data == array_filter($data)) {
			$email = explode('@', strip_tags(strtolower($data['email'])));
			$first = encrypText($email[0]);
			$second = encrypText($email[1]);
			$checkEmail = User::where('user_mail_id', $first)->where('unusual_user_key', $second)->count();
			if ($checkEmail > 0) {
				$response = array('status' => '0', 'msg' => trans('app_lang.Email already exists'));
				echo json_encode($response);exit;
			}
			if (strip_tags($data['confirm_pwd']) != strip_tags($data['pwd'])) {
				$response = array('status' => '0', 'msg' => trans('app_lang.Password doesnt match!'));
				echo json_encode($response);exit;
			}
			$userName = strip_tags($data['first_name']);
			$checkName = User::where('consumer_name', $userName)->count();
			if ($checkName > 0) {
				$response = array('status' => '0', 'msg' => trans('app_lang.username_exists'));
				echo json_encode($response);exit;
			}
			$mobileNumber = strip_tags($data['phone']);
			$checkPhone = User::where('phone', $mobileNumber)->count();
			if ($checkPhone > 0) {
				$response = array('status' => '0', 'msg' => trans('app_lang.mobile_exists'));
				echo json_encode($response);exit;
			}
			if(isset($data['refer_id'])) {
				if ($data['refer_id'] != 0) {
					$refer_id = strip_tags($data['refer_id']);
				} else {
					$refer_id = '';
				}
			}
			$password = encrypText(strip_tags($data['confirm_pwd']));
			$expire = date('Y-m-d H:i:s', strtotime("+10 days"));
			$userinfo['consumer_name'] = $userName;
			$userinfo['user_mail_id'] = $first;
			$userinfo['unusual_user_key'] = $second;
			$userinfo['user_protect_key'] = $password;
			$userinfo['ip_address'] = Controller::getIpAddress();
			$userinfo['status'] = 'inactive';
			$userinfo['tfa_status'] = 'disable';
			$userinfo['phone'] = $mobileNumber;
			$userinfo['verified_status'] = 0;
			$userinfo['refer_id'] = User::randomReferNumber(6);
			$rand = time() . '12' . mt_rand(0, 999999);
			$userinfo['mailcode'] = $rand;
			$userinfo['referrer_id'] = $refer_id;
			$userinfo['expire_at'] = $expire;
			$userinfo['tickets'] = serialize(array($password));
			$userinfo['device_token'] = strip_tags($data['device_token']);

			if(isset($data['refer_id'])) {
				if ($data['refer_id'] != 0) {
					$referId = strip_tags($data['refer_id']);
					if (strlen($referId) > 6) {
						$response = array('status' => '0', 'msg' => trans('app_lang.Please use valid referral code'));
						echo json_encode($response);exit;
					}
					$userinfo['referrer_id'] = $referId;
				}
			}
			$result = User::create($userinfo);
			if ($result) {
				$userId = $result->id;
				ConsumerVerification::create(['user_id' => $userId]);
				$id = encrypText($result->id);
				$rid = encrypText($rand);
				$securl = URL::to('activateEmail/' . $id . '/' . $rid);

				$getEmail = EmailTemplate::where('id', 1)->first();
				$getSiteDetails = Controller::getEmailTemplateDetails();
				$info = array('###USER###' => '', '###LINK###' => $securl, '###registerverify_link###' => $securl);
				$replace = array_merge($getSiteDetails, $info);

				$emaildata = array('content' => strtr($getEmail->template, $replace));
				$toDetails['useremail'] = $data['email'];
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails['contact_mail_id'];
				$toDetails['name'] = $getSiteDetails['site_name'];

				$sendEmail = Controller::sendEmail($emaildata, $toDetails);

				if (count(Mail::failures()) > 0) {
					$response = array('status' => '0', 'msg' => trans('app_lang.Email sending failed.'));
					echo json_encode($response);exit;
				} else {
					$msg1 = "New User signed up with ".SITENAME." with username " . $userinfo['consumer_name'] . " and email " . $data['email'];
					$insdata = array('admin_id' => 1, 'type' => 'New-user', 'message' => $msg1, 'status' => 'unread');
					AdminNotification::create($insdata);

					$response = array('status' => '1', 'msg' => trans('app_lang.Registration Successful and Activation link has been sent to registered email address.'));
					echo json_encode($response);exit;
				}
			} else {
				$response = array('status' => '0', 'msg' => trans('app_lang.Failed to create User'));
				echo json_encode($response);exit;
			}
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.Please fill all fields'));
			echo json_encode($response);exit;
		}
	}

	public function checkInactiveEmail() {
		$data = Input::all();
		$email = explode('@', strip_tags(strtolower($data['email'])));
		$first = encrypText($email[0]);
		$second = encrypText($email[1]);
		$getCount = User::where('user_mail_id', $first)->where('unusual_user_key', $second)->where('status', 'inactive')->count();
		$msg = ($getCount > 0) ? "true" : "false";
		$status = ($getCount > 0) ? 1 : 0;
		$response = array('status' => $status, 'msg' => $msg);
		echo json_encode($response);exit;
	}

	public function resendEmail() {
		$data = Input::all();

		$validate = Validator::make($data, [
			'email' => "required",
		], [
			'email.required' => 'Enter email',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}

		if ($data) {
			$email = explode('@', strip_tags(strtolower($data['email'])));
			$first = encrypText($email[0]);
			$second = encrypText($email[1]);
			$user = User::where('user_mail_id', $first)->where('unusual_user_key', $second)->where('status', 'inactive')->select('id', 'user_mail_id', 'unusual_user_key', 'consumer_name')->first();
			if (count($user)) {
				$email_id = decrypText($user->user_mail_id) . "@" . decrypText($user->unusual_user_key);
				$username = $user->consumer_name;
				$rand = time() . '12' . mt_rand(0, 999999);
				$rid = encrypText($rand);
				$id = $user->id;
				$ids = encrypText($id);
				$expire = date('Y-m-d H:i:s', strtotime("+10 days"));
				User::where('id', $id)->update(['mailcode' => $rand, 'expire_at' => $expire]);
				$securl = URL::to('activateEmail/' . $ids . '/' . $rid);
				$getEmail = EmailTemplate::where('id', 1)->first();
				$getSiteDetails = Controller::getEmailTemplateDetails();
				$info = array('###USER###' => '', '###LINK###' => $securl, '###registerverify_link###' => $securl);
				$replace = array_merge($getSiteDetails, $info);
				$emaildata = array('content' => strtr($getEmail->template, $replace));
				$toDetails['useremail'] = $email_id;
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails['contact_mail_id'];
				$toDetails['name'] = $getSiteDetails['site_name'];
				$sendEmail = Controller::sendEmail($emaildata, $toDetails);
				if (count(Mail::failures()) > 0) {
					$response = array('status' => '0', 'msg' => 'Mail Resend Failed!');
					echo json_encode($response);exit;
				} else {
					$msg1 = "New User signed up with ".SITENAME." with username " . $username . " and email " . $email_id;
					$insdata = array('admin_id' => 1, 'type' => 'New-user-ResendMail', 'message' => $msg1, 'status' => 'unread');
					AdminNotification::create($insdata);
					$response = array('status' => '1', 'msg' => 'Mail Resend Successfully!');
					echo json_encode($response);exit;
				}
			} else {
				$response = array('status' => '0', 'msg' => 'Not a proper activation mail');
				echo json_encode($response);exit;
			}
		}
	}

	public function userLogin() {
		$data = Input::all();
		
		$Validation = Validator::make($data, User::$userLoginRule);
		if ($Validation->fails()) {
			$response = array('status' => '0', 'msg' => $Validation->messages());
			echo json_encode($response);exit;
		}
		if ($data == array_filter($data)) {
			$password = encrypText(strip_tags($data['password']));
			if (strpos($data['email'], '@') !== FALSE) {
				$userEmail = strip_tags(strtolower($data['email']));
				$device_token = strip_tags($data['device_token']);
				$email = explode('@', $userEmail);
				$first = encrypText($email[0]);
				$second = encrypText($email[1]);
				$login_result = User::where('user_mail_id', $first)->where('unusual_user_key', $second)->where('user_protect_key', $password)->first();
				if ($login_result) {
					$useremail_show = $userEmail;
					$login = $login_result;
				} else {
					$useremail_show = "";
					$login = User::where('consumer_name', $data['email'])->where('user_protect_key', $password)->first();
				}
			} else {
				$login = User::where('consumer_name', $data['email'])->where('user_protect_key', $password)->first();
				$useremail_show = "";
			}
			if ($login) {
				if ($login['status'] == "active") {
					if ($login['tfa_status'] == "enable") {
						$loginId = encrypText($login['id']);
						$response = array('status' => '3', 'msg' => 'tfaVerification', 'id' => $loginId);
						echo json_encode($response);exit;
					}
					if ($login['otp_status'] == 1) {
						$loginId = encrypText($login['id']);
						$response = array('status' => '2', 'msg' => 'otpVerification', 'id' => $loginId);
						echo json_encode($response);exit;
					}
					$ip = Controller::getIpAddress();
					$lastLogin = UserActivity::where('user_id', $login['id'])->where('activity', 'Login')->where('ip_address', $_SERVER['REMOTE_ADDR'])->first();

					if (!$lastLogin) {

						$notf_msg = trans('app_lang.noty_new_device_login');
						$notf_msg2 = trans('app_lang.hi');

						$msg1 = $notf_msg2 . " " . $login['consumer_name'] . ", " . $notf_msg;
						$insdata = array('user_id' => $login['id'], 'type' => 'New-Device-Login', 'message' => $msg1, 'status' => 'unread');
						UserNotification::create($insdata);
						if ($login['notify_new_device']) {
							$getEmail = EmailTemplate::where('id', 23)->first();
							$getSiteDetails = Controller::getEmailTemplateDetails();
							$info = array('###USER###' => $login['consumer_name']);
							$info['###IP###'] = Controller::getIpAddress();

							$replace = array_merge($getSiteDetails, $info);
							$emaildata = array('content' => strtr($getEmail->template, $replace));

							$toDetails['useremail'] = $useremail_show;
							$toDetails['subject'] = $getEmail->subject;
							$toDetails['from'] = $getSiteDetails['contact_mail_id'];
							$toDetails['name'] = $getSiteDetails['site_name'];
							$sendEmail = Controller::sendEmail($emaildata, $toDetails);

						}
					}

					$geolocation_show = Controller::getLocation();
					$result_show = explode('##', $geolocation_show);
					$cntry = ($result_show[0]) ? $result_show[0] : "";
					$activity['country'] = $cntry;
					$activity['city'] = ($result_show[1]) ? $result_show[1] : $cntry;
					$activity['os'] = Controller::getPlatform();
					$activity['ip_address'] = $ip;
					$activity['browser_name'] = Controller::getBrowser();
					$activity['activity'] = "Login";
					$activity['user_id'] = $login['id'];
					UserActivity::create($activity);
					$randnum = randomString(10);
					$token = $login['id'] . time() . rand(10, 100);
					User::where('id', $login['id'])->update(['token' => $token, 'device_token' => $device_token, 'session_id' => $randnum, 'login_status' => 1]);
					LoginAttempt::where('ip_address', $ip)->where('status', 'new')->update(['status' => 'old']);
					$response = array('status' => '1', 'msg' => trans('app_lang.You are successfully logged in.') , 'user_id' => $login['id'], 'token' => $token, 'passcode' => $login['passcode'], 'email' => $data['email']);
					echo json_encode($response);exit;
				} elseif ($login['status'] == "inactive") {
					$response = array('status' => '0', 'msg' => trans('app_lang.Please activate your account from registered email.'));
					echo json_encode($response);exit;
				} else {
					$response = array('status' => '0', 'msg' => trans('app_lang.Your account deactivated by admin.'));
					echo json_encode($response);exit;
				}
			} else {
				$username = encrypText($data['email']);
				$password = encrypText($password);
				$ip = Controller::getIpAddress();
				$os = Controller::getPlatform();
				$browser = Controller::getBrowser();
				$getCount = LoginAttempt::where('ip_address', $ip)->where('status', 'new')->count();
				if ($getCount >= 5) {
					$getBlockCount = BlockIP::where('ip_addr', $ip)->where('status', 'active')->count();
					if ($getBlockCount == 0) {
						$updata = array('ip_addr' => $ip, 'status' => 'active');
						BlockIP::create($updata);
					} else {
						BlockIP::where('ip_addr', $ip)->update(['status' => 'active']);
					}
				}
				$createAttempt = array('ip_address' => $ip, 'os' => $os, 'browser' => $browser, 'status' => 'new', 'username' => $username, 'password' => $password);
				LoginAttempt::create($createAttempt);

				$response = array('status' => '0', 'msg' => trans('app_lang.Invalid login credentials!'));
				echo json_encode($response);exit;
			}
		} else {
			$response = array('status' => '0', 'msg' => 'Please fill all the fields');
			echo json_encode($response);exit;
		}
	}	

	public function sendLoginOtp() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'token' => "required",
		], [
			'token.required' => 'Enter token',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}
		if (isset($data['token'])) {
			$userId = decrypText(strip_tags($data['token']));
			$user = User::where('id', $userId)->select('user_mail_id', 'unusual_user_key', 'consumer_name', 'phone')->first();
			if ($user) {
				$phone = $user->phone;
				$first = decrypText($user->user_mail_id);
				$second = decrypText($user->unusual_user_key);
				$email = $first . "@" . $second;

				$key = TWOFACTORKEY;
				$otp = randomInteger(6);
				$url = "http://2factor.in/API/V1/" . $key . "/ADDON_SERVICES/SEND/TSMS";
				$data = ['From' => TWOFACTORSENDER, 'To' => $phone, 'TemplateName' => 'sms_otp', 'VAR1' => $otp];

				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
				$response = curl_exec($ch);
				curl_close($ch);

				$getEmail = EmailTemplate::where('id', 39)->first();
				$getSiteDetails = Controller::getEmailTemplateDetails();
				$info = array('###USER###' => $user->consumer_name, '###OTP###' => $otp);
				$replace = array_merge($getSiteDetails, $info);
				$emaildata = array('content' => strtr($getEmail->template, $replace));

				$toDetails['useremail'] = $email;
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails['contact_mail_id'];
				$toDetails['name'] = $getSiteDetails['site_name'];
				$sendEmail = Controller::sendOtpEmail($emaildata, $toDetails);

				$res = json_decode($response, true);
				if ((isset($res['Status']) && $res['Status'] == "Success") || $sendEmail) {
					User::where('id', $userId)->update(['otp_phone' => $phone, 'mobile_otp' => encrypText($otp)]);
					$response = array('status' => '1', 'msg' => 'OTP sent successfully', 'otp' => $otp);
				} else {
					$response = array('status' => '0', 'msg' => 'Failed to send OTP');
				}
			} else {
				$response = array('status' => '0', 'msg' => 'Invalid User');
			}
		} else {
			$response = array('status' => '0', 'msg' => 'Invalid Request');
		}
		echo json_encode($response);exit;
	}

	public function otpLogin() {
		$data = Input::all();
		if ($data == array_filter($data)) {
			$userId = decrypText(strip_tags($data['uid']));
			$getUser = User::where('id', $userId)->select('id', 'mobile_otp', 'consumer_name', 'user_mail_id', 'unusual_user_key', 'notify_new_device', 'passcode')->first();
			$otp = strip_tags($data['otp']);
			$device_token = strip_tags($data['device_token']);
			$first = decrypText($getUser->user_mail_id);
			$second = decrypText($getUser->unusual_user_key);
			$passcode = $getUser->passcode;
			$useremail_show = $first . "@" . $second;

			if (encrypText($otp) == $getUser->mobile_otp) {
				$ip = Controller::getIpAddress();
				$geoLoc = Controller::getLocation();
				$resGeo = explode('##', $geoLoc);
				$cntry = ($resGeo[0]) ? $resGeo[0] : "";
				$city = ($resGeo[1]) ? $resGeo[1] : $cntry;
				$activity = ['country' => $cntry, 'city' => $city, 'os' => Controller::getPlatform(), 'ip_address' => $ip, 'browser_name' => Controller::getBrowser(), 'activity' => 'Login', 'user_id' => $userId];
				UserActivity::create($activity);
				$token = $userId . time() . rand(10, 100);
				$randnum = randomString(10);
				User::where('id', $userId)->update(['mobile_otp' => '', 'token' => $token, 'device_token' => $device_token, 'session_id' => $randnum, 'login_status' => 1]);
				LoginAttempt::where('ip_address', $ip)->where('status', 'new')->update(['status' => 'old']);
				$lastLogin = UserActivity::where('user_id', $userId)->where('activity', 'Login')->where('ip_address', $ip)->first();
				if (!$lastLogin) {
					$notf_msg = trans('app_lang.noty_new_device_login');
					$notf_msg2 = trans('app_lang.hi');
					$msg1 = $notf_msg2 . " " . $getUser->consumer_name . ", " . $notf_msg;
					if ($getUser->notify_new_device) {
						$getEmail = EmailTemplate::where('id', 23)->first();
						$getSiteDetails = Controller::getEmailTemplateDetails();
						$info = array('###USER###' => $getUser['consumer_name']);
						$info['###IP###'] = Controller::getIpAddress();

						$replace = array_merge($getSiteDetails, $info);
						$emaildata = array('content' => strtr($getEmail->template, $replace));

						$toDetails['useremail'] = $useremail_show;
						$toDetails['subject'] = $getEmail->subject;
						$toDetails['from'] = $getSiteDetails['contact_mail_id'];
						$toDetails['name'] = $getSiteDetails['site_name'];
						$sendEmail = Controller::sendEmail($emaildata, $toDetails);
					}
					$insdata = array('user_id' => $userId, 'type' => 'New-Device-Login', 'message' => $msg1, 'status' => 'unread');
					UserNotification::create($insdata);
				}

				$response = array('status' => '1', 'msg' => trans('app_lang.You are successfully logged in.'), 'user_id' => $userId, 'token' =>$token, 'passcode' => $passcode, 'email' => $useremail_show);
			} else {
				$response = array('status' => '0', 'msg' => 'Invalid authentication key.');
			}
		} else {
			$response = array('status' => '0', 'msg' => 'Please try again.');
		}
		echo json_encode($response);exit; 
	}

	public function tfaLogin() {
		$data = Input::all();
		if ($data == array_filter($data)) {
			$userId = decrypText(strip_tags($data['uid']));
			$tfaDetails = User::where('id', $userId)->select('id', 'secret', 'consumer_name', 'user_mail_id', 'unusual_user_key', 'notify_new_device', 'passcode')->first();
			$secret = $tfaDetails->secret;
			$code = $data['auth_key'];
			$device_token = $data['device_token'];
			$first = decrypText($tfaDetails->user_mail_id);
			$second = decrypText($tfaDetails->unusual_user_key);
			$passcode = $tfaDetails->passcode;
			$useremail_show = $first . "@" . $second;
			require_once app_path('Model/Googleauthenticator.php');
			$googleAuth = new Googleauthenticator();
			$verify = $googleAuth->verifyCode($secret, $code, $discrepancy = 2);
			if ($verify == 1) {
				$ip = Controller::getIpAddress();
				$geolocation_show = Controller::getLocation();
				$result_show = explode('##', $geolocation_show);
				if ($result_show[0]) {
					$activity['country'] = $result_show[0];
				}

				if ($result_show[1]) {
					$activity['city'] = $result_show[1];
				} else {
					$activity['city'] = $result_show[0];
				}

				$activity['ip_address'] = $ip;
				$activity['os'] = Controller::getPlatform();
				$activity['browser_name'] = Controller::getBrowser();
				$activity['activity'] = "Login";
				$activity['user_id'] = $tfaDetails->id;
				$randnum = randomString(10);
				$token = $userId . time() . rand(10, 100);
				User::where('id', $userId)->update(['token' => $token, 'device_token' => $device_token, 'session_id' => $randnum, 'login_status' => 1]);
				$lastLogin = UserActivity::where('user_id', $tfaDetails->id)->where('activity', 'Login')->where('ip_address', $_SERVER['REMOTE_ADDR'])->first();
				UserActivity::create($activity);

				if (!$lastLogin) {
					$getCount_notify = User::where('id', $userId)->select('consumer_name', 'id', 'user_mail_id', 'unusual_user_key', 'notify_tfa')->first();
					$notf_msg = trans('app_lang.noty_new_device_login');
					$notf_msg2 = trans('app_lang.hi');

					$msg1 = $notf_msg2 . " " . $getCount_notify['consumer_name'] . ", " . $notf_msg;
					if ($tfaDetails->notify_new_device) {
						$getEmail = EmailTemplate::where('id', 23)->first();
						$getSiteDetails = Controller::getEmailTemplateDetails();
						$info = array('###USER###' => $tfaDetails['consumer_name']);
						$info['###IP###'] = Controller::getIpAddress();

						$replace = array_merge($getSiteDetails, $info);
						$emaildata = array('content' => strtr($getEmail->template, $replace));

						$toDetails['useremail'] = $useremail_show;
						$toDetails['subject'] = $getEmail->subject;
						$toDetails['from'] = $getSiteDetails['contact_mail_id'];
						$toDetails['name'] = $getSiteDetails['site_name'];
						$sendEmail = Controller::sendEmail($emaildata, $toDetails);

					}
					$insdata = array('user_id' => $userId, 'type' => 'New-Device-Login', 'message' => $msg1, 'status' => 'unread');
					UserNotification::create($insdata);
				}
				$response = array('status' => '1', 'msg' => trans('app_lang.You are successfully logged in.'), 'user_id' => $userId, 'token' => $token, 'passcode' => $passcode, 'email' => $useremail_show);
			} else {
				$response = array('status' => '0', 'msg' => 'Invalid authentication key.');
			}
		} else {
			$response = array('status' => '0', 'msg' => 'Please try again.');
		}
		echo json_encode($response);exit; 
	}

	public function sendForgotEmail() {
		$data = Input::all();
		$Validation = Validator::make($data, User::$forgotRule);
		if ($Validation->fails()) {
			$response = array('status' => '0', 'msg' => 'Email required');
			echo json_encode($response);exit;
		}
		if ($data == array_filter($data)) {
			if (strpos($data['email'], '@') !== FALSE) {
				$email = explode('@', strip_tags(strtolower($data['email'])));
				$first = encrypText($email[0]);
				$second = encrypText($email[1]);
				$login_result = User::where('user_mail_id', $first)->where('unusual_user_key', $second)->first();
				if ($login_result) {
					$useremail = $email[0] . "@" . $email[1]; 
					$getDetail = $login_result;
				} else {
					$getDetail = User::where('consumer_name', $data['email'])->first();
					$useremail = "";
				}
			} else {
				$getDetail = User::where('consumer_name', $data['email'])->first();
				if ($getDetail) {
					$first = decrypText($getDetail->user_mail_id);
					$second = decrypText($getDetail->unusual_user_key);
					$useremail = $first . "@" . $second;
				} else {
					$getDetail = "";
				}
			}

			if ($getDetail) {
				if ($getDetail->status == 'active') {
					$id = encrypText($getDetail->id);
					$generateCode = User::randomString(8);
					$randomCode = encrypText($generateCode);

					$randnum = randomString(10);
					$update = User::where('id', $getDetail->id)->update(['forgot_code' => $randomCode, 'forgot_status' => 'active', 'session_id' => $randnum]);
					$securl = URL::to('resetPassword/' . $id . '/' . $randomCode);

					$getEmail = EmailTemplate::where('id', 2)->first();
					$getSiteDetails = Controller::getEmailTemplateDetails();
					$info = array('###USER###' => $getDetail->consumer_name, '###LINK###' => $securl);
					$replace = array_merge($getSiteDetails, $info);
					$emaildata = array('content' => strtr($getEmail->template, $replace));
					$toDetails['useremail'] = $useremail;
					$toDetails['subject'] = $getEmail->subject;
					$toDetails['from'] = $getSiteDetails['contact_mail_id'];
					$toDetails['name'] = $getSiteDetails['site_name'];

					$sendEmail = Controller::sendEmail($emaildata, $toDetails);
					if (count(Mail::failures()) > 0) {
						$response = array('status' => '0', 'msg' => 'Please Try Again');
					} else {
						$response = array('status' => '1', 'msg' => 'Reset password Link has sent to your registered email');
					}

				} else {
					$response = array('status' => '0', 'msg' => "Before Activate Your account .You Not able reset Password");
				}

			} else {
				$response = array('status' => '0', 'msg' => 'Invalid Email ID or Username');
			}
		} else {
			$response = array('status' => '0', 'msg' => 'Please Field the All the Field!');
		}
		echo json_encode($response);
	}

	public function contactDetails() {
		$contact = SiteSettings::where('id', '1')->select('contact_email', 'contact_number', 'contact_address', 'city', 'country', 'postal')->first();
		if($contact) {
			$response = array('status' => '1', 'msg' => $contact);
		} else {
			$response = array('status' => '0', 'msg' => 'Please try again later');
		}
		echo json_encode($response);
	}

	public function contactSubmit() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'useremail' => "required|email",
			'subject' => 'required|min:3',
			'message' => 'required',
			'username' => 'required',
		], [
			'useremail.required' => 'Enter email address',
			'useremail.email' => 'Enter valid email address',
			'username.required' => 'Enter Your Username',
			'message.required' => 'Enter Message',
			'subject.required' => 'Enter Subject',
			'subject.min' => 'Enter atleast 3 characters',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}
		$name = trim(strip_tags($data['username']));
		$email = trim(strip_tags($data['useremail']));
		$subject = trim(strip_tags($data['subject']));
		$message = trim(strip_tags($data['message']));

		$prevoiusOrder = Support::where('email', $email)->select('created_at')->orderBy('id', 'desc')->first();
		if($prevoiusOrder) {
			$datetime1 = new DateTime();
			$datetime2 = new DateTime($prevoiusOrder->created_at);
			$interval = $datetime1->diff($datetime2);
			$mins = $interval->format('%i');
			if($mins < 1) {		
				$response = array('status' => '0', 'msg' => 'Please try again later');
				echo json_encode($response);exit;
			}
		} 

		$subject = self::cleanStr($subject);
		$message = self::cleanStr($message);

		$userdata = array('user_name' => $name,
			'email' => $email,
			'subject' => $subject,
			'message' => $message,
			'status' => 'unread',
			'read_status' => 'unread',
		);

		$insertData = Support::create($userdata);

		if ($insertData) {
			$getEmail = EmailTemplate::where('id', 22)->first();
			$getSiteDetails = Controller::getEmailTemplateDetails();
			$info = array('###USER###' => $name, '###MESSAGE###' => $message, '###EMAIL###' => $email, '###SUBJECT###' => $subject);
			$replace = array_merge($getSiteDetails, $info);
			$emaildata = array('content' => strtr($getEmail->template, $replace));
			$toDetails['useremail'] = $email;
			$toDetails['subject'] = $getEmail->subject;
			$toDetails['from'] = $getSiteDetails['contact_mail_id'];
			$toDetails['name'] = $getSiteDetails['site_name'];
			$sendEmail = Controller::sendEmail($emaildata, $toDetails);
			$response = array('status' => '1', 'msg' => 'Contact request submitted successfully');
		} else {
			$response = array('status' => '0', 'msg' => 'Please try again later');
		}
		echo json_encode($response);exit;
	}

	function cleanStr($string) {
		$string = preg_replace('/[^a-zA-Z0-9_ -]/s', '', $string);
		return $string;
	}

	public function subscribeusers() {
		$data = Input::all();

		$validate = Validator::make($data, [
			'email' => "required|email|indisposable",
		], [
			'email.required' => 'Please Enter email address',
			'email.email' => 'Please Enter valid email address',
			'email.indisposable' => 'Disposable email addresses are not allowed',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($response);exit;				
			}
		}

		if ($data == array_filter($data)) {
			$subscribe['email'] = strip_tags($data['email']);
			$checkEmail = Subscribe::where('email', $subscribe['email'])->where('status', '0')->count();
			if ($checkEmail > 0) {
				$response = array('status' => '0', 'msg' =>  trans('app_lang.Email already subscribed newsletter.'));
			} else {
				Subscribe::create($subscribe);
				$response = array('status' => '1', 'msg' =>  trans('app_lang.subscribed_success'));
			}
		} else {
			$response = array('status' => '0', 'msg' =>  trans('app_lang.Failed to subscribe!'));
		}
		echo json_encode($response);exit;				
	}

	public function cms() {
		$data = Input::all();

		$validate = Validator::make($data, [
			'id' => "required",
		], [
			'id.required' => 'Please Enter id',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($response);exit;				
			}
		}
		$id = $data['id'];
		$getContent = Cms::where('id', $id)->select('title', 'content')->first();
		$result['title'] = $getContent->title;
		$result['content'] = strip_tags($getContent->content);
		if ($getContent) {
			$response = array('status' => '1', 'msg' => $result);
		} else {
			$response = array('status' => '0', 'msg' =>  'Please try again later');
		}
		echo json_encode($response);exit;				
	}

	public function faq() {
		$getFaq = Faq::where('status', 'active')->orderBy('id', 'ASC')->get();
		if ($getFaq) {
			$response = array('status' => '1', 'msg' => $getFaq);
		} else {
			$response = array('status' => '0', 'msg' =>  'Please try again later');
		}
		echo json_encode($response);exit;				
	}

	public function fees() {
		$result['deposit_withdraw'] = DB::table('deposit_settings as d')->leftjoin('currency as c', 'c.currency_symbol', '=', 'd.currency')->leftjoin('withdraw_settings as w', 'd.currency', '=', 'w.currency')->where('c.status', '1')->where('d.status', '1')->select('c.currency_symbol', 'c.currency_name', 'd.min as deposit_min', 'w.min as withdraw_min', 'w.max as withdraw_max', 'w.fee as withdraw_fee', 'w.fee_type as withdraw_fee_type', 'c.confirmations', 'c.status as currency_status', 'd.status as deposit_status', 'w.status as withdraw_status')->get();

		$result['tradepair'] = TradePairs::where('site_status','1')->select('pair_name', 'from_symbol','minamt','fee_per','tfee_per','site_status')->get()->toArray();

		$result['buyexchangepairs'] = ExchangePairs::select('from_symbol', 'to_symbol','min_amt','max_amt' ,'trade_fee','status')->get()->toArray();
  
		if ($result) {
			$response = array('status' => '1', 'msg' => $result);
		} else {
			$response = array('status' => '0', 'msg' =>  'Please try again later');
		}
		echo json_encode($response);exit;				
	}

	public function career() {
		$result['category'] = CareerCategory::where('status','1')->get()->map(function ($cat) {return ['key' => $cat->id, 'value' => $cat];})->pluck('value', 'key')->toArray();
		$result['careerDetails'] = CareerDetails::where('status','1')->select('id', 'job_category', 'job_title', 'job_location')->get()->toArray();
		if ($result) {
			$response = array('status' => '1', 'msg' => $result);
		} else {
			$response = array('status' => '0', 'msg' =>  'Please try again later');
		}
		echo json_encode($response);exit;
	}

	public function arraygroupBy($array, $key) {
		$return = array();
		foreach($array as $val) {
			$return[$val[$key]][] = $val;
		}
		return $return;
	}

	public function careerDetails() {
		$data = Input::all();

		$validate = Validator::make($data, [
			'id' => "required",
		], [
			'id.required' => 'Please Enter id',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($response);exit;				
			}
		}
		$id = $data['id'];
		$result['careerDetails'] = DB::table('career_details as cd')->leftjoin('career_category as c','c.id', '=', 'cd.job_category')->where('cd.status','1')->where('cd.id', $id)->select('cd.*', 'c.category_name')->first();
		if ($result) {
			$response = array('status' => '1', 'msg' => $result);
		} else {
			$response = array('status' => '0', 'msg' =>  'Please try again later');
		}
		echo json_encode($response);exit;
	}

	public function careerForm() {
		$data = Input::all();

		$validate = Validator::make($data, [
			'id' => "required",
		], [
			'id.required' => 'Please Enter id',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($response);exit;				
			}
		}
		$id = $data['id'];
		$result['careerDetails'] = DB::table('career_details as cd')->leftjoin('career_category as c','c.id', '=', 'cd.job_category')->where('cd.status','1')->where('cd.id', $id)->select('cd.*', 'c.category_name')->first();
		if ($result) {
			$response = array('status' => '1', 'msg' => $result);
		} else {
			$response = array('status' => '0', 'msg' =>  'Please try again later');
		}
		echo json_encode($response);exit;
	}

	public function careerMobileExists() {
		$data = Input::all();
		$phone = strip_tags($data['phone']);
		$getCount = Career::where('phone', $phone)->count();
		$msg = ($getCount > 0) ? "false" : "true";
		$status = ($getCount > 0) ? 0 : 1;
		$response = array('status' => $status, 'msg' => $msg);
		echo json_encode($response);exit;
	}

	public function careerEmailExists() {
		$data = Input::all();
		$email = strip_tags(strtolower($data['email']));
		$getCount = Career::where('email', encrypText($email))->count();
		$msg = ($getCount > 0) ? "false" : "true";
		$status = ($getCount > 0) ? 0 : 1;
		$response = array('status' => $status, 'msg' => $msg);
		echo json_encode($response);exit;
	}

	public function careerSubmit() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'email' => "required|email|indisposable",
			'fullname' => "required",
			'phone' => "required",
			'photo' => "required",
			'resume' => "required",
		], [
			'email.required' => 'Please Enter email address',
			'email.email' => 'Please Enter valid email address',
			'email.indisposable' => 'Disposable email addresses are not allowed',
			'fullname.required' => 'Please Enter name',
			'phone.required' => 'Please Enter phone',
			'photo.required' => 'Please Enter photo',
			'resume.required' => 'Please Enter resume',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$response = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($response);exit;
			}
		}
		$create['name'] = strip_tags($data['fullname']);
		$create['email'] = strip_tags(encrypText($data['email']));
		$create['phone'] = strip_tags($data['phone']);
		$create['cover'] = strip_tags($data['cover']);
		$create['exp'] = strip_tags($data['radio']);
		$create['title'] = strip_tags($data['title']);
		$create['ctc'] = isset($data['ctc']) ? strip_tags($data['ctc']) : '0';
		$create['created_at'] = date('Y-m-d H:i:s');
		$create['photo'] = strip_tags($data['photo']);
		$create['resume'] = strip_tags($data['resume']);
		$result = Career::create($create);
		if($result) {
			$response = array('status' => '1', 'msg' => "Applied Successfully");
		} else {
			$response = array('status' => '0', 'msg' =>  'Please try again later');
		}
		echo json_encode($response);exit;
	}
}

