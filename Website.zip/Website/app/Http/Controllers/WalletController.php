<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Controllers\CryptoAddress;
use App\Model\AdminActivity;
use App\Model\BlockIP;
use App\Model\CoinProfit;
use App\Model\ContactUs;
use App\Model\Currency;
use App\Model\EmailTemplate;
use App\Model\LoginAttempt;
use App\Model\PaymentGateway;
use App\Model\SiteSettings;
use App\Model\SiteWallet;
use App\Model\SubAdmin;
use App\Model\User;
use App\Model\Wallet;
use App\Model\WltDeposit;
use App\Model\Googleauthenticator;
use Config;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Mail;
use Redirect;
use Session;
use URL;
use Validator;

class WalletController extends Controller {
	public function __construct() {
		$this->Url = WALLETURL;
		if ($_SERVER['HTTP_HOST'] != "localhost") {
			if (!isset($_SERVER['PHP_AUTH_USER']) || (isset($_SERVER['PHP_AUTH_USER']) && ($_SERVER['PHP_AUTH_USER'] != 'DskSDtrasvTxdfs' || $_SERVER['PHP_AUTH_PW'] != 'PRasfhnftudETG'))) {
				header('WWW-Authenticate: Basic realm=" Auth"');
				header('HTTP/1.0 401 Unauthorized');
				echo 'Authentication Failed';exit;
			}
		}
	}

	public function index() {

		if (session('walletId') != '') {
			if ($_SERVER['REMOTE_ADDR'] != '127.0.0.1' || $_SERVER['REMOTE_ADDR'] != '::1') {
				$data['admin_BTC'] = CryptoAddress::getBalance('BTC');
				$data['admin_LTC'] = CryptoAddress::getBalance('LTC');
				$data['admin_BCH'] = CryptoAddress::getBalance('BCH');
				$data['admin_DASH'] = CryptoAddress::getBalance('DASH'); 
				$data['admin_ETH'] = CryptoAddress::getBalance('ETH');
				$data['admin_USDT'] = CryptoAddress::getBalance('USDT');
				$data['admin_XRP'] = CryptoAddress::getBalance('XRP'); 
			} else {
				$data['admin_BTC'] = $data['admin_LTC'] = $data['admin_BCH'] = $data['admin_DASH'] = $data['admin_ETH'] = $data['admin_XRP'] = $data['admin_USDT'] = 0;
			}
			return view('wallet.dashboard')->with('data', $data)->with('redirectUrl', $this->Url);
		}
		return view('wallet.login')->with('redirectUrl', $this->Url);
	}

	//send otp to login
	public function sendOtpToLogin(Request $request) {
		$keyCode = User::randomString(10);
		$encryptKey = encrypText($keyCode);
		$update = PaymentGateway::where('id', 1)->update(['user_key' => $encryptKey]);
		if ($update) {
			$arrres = PaymentGateway::where('id', 1)->select('address', 'application','otp_mail')->first();
			// $useremail = decrypText($arrres->address) . '@' . decrypText($arrres->application);
			$useremail = decrypText($arrres->otp_mail);

			$getEmail = EmailTemplate::where('id', 19)->first();
			$getSiteDetails = Controller::getEmailTemplateDetails();
			$info = array('###OTP###' => $keyCode);
			$replace = array_merge($getSiteDetails, $info);

			$emaildata = array('content' => strtr($getEmail->template, $replace));
			$toDetails['useremail'] = $useremail;
			$toDetails['subject'] = $getEmail->subject;
			$toDetails['from'] = $getSiteDetails['contact_mail_id'];
			$toDetails['name'] = $getSiteDetails['site_name'];

			$sendEmail = Controller::sendEmail($emaildata, $toDetails);
			$sendEmail = 1;
			$result = array('status' => '1', 'code' => '');
		} else {
			$result = array('status' => '0');
		}
		echo json_encode($result);
	}

	public function adminLogin() {
		$data = Input::all();

		$Validation = Validator::make($data, Wallet::$adminLoginRule);
		if ($Validation->fails()) {
			Session::flash('error', $Validation->messages());
			return Redirect::to($this->Url);
		}
		if ($data == array_filter($data)) {
			$email = explode('@', strip_tags($data['username']));
			$first = encrypText($email[0]);
			$second = encrypText($email[1]);
			$password = encrypText(strip_tags($data['user_pwd']));
			$pattern = encrypText(strip_tags($data['pattern_code']));
			$keyCode = encrypText(strip_tags($data['key_code']));

			$ip = Controller::getIpAddress();
			$browser = Controller::getBrowser();
			$platform = Controller::getPlatform();
			$login = PaymentGateway::where('address', $first)->where('application', $second)->where('name', $password)->where('access', $pattern)->first();

			if ($login) {
				LoginAttempt::where('ip_address', $ip)->where('status', 'new')->update(['status' => 'olds']);

				PaymentGateway::where('id', 1)->update(['user_key' => ""]);

				$activity['ip_address'] = $ip;
				$activity['browser_name'] = $browser;
				$activity['os'] = $platform;
				$activity['activity'] = "login";
				$activity['admin_id'] = $login['id'];
				AdminActivity::create($activity);

				// session(['walletId' => $login['id']]);
				$arrSiteSettings = SiteSettings::where('id', 1)->first();  
				if($arrSiteSettings->go_status==1){ 
						session(['is_login_wal' => 1,'login_id_wal' => $login->id]);
						return redirect($this->Url . '/twofactorwallet'); 
				}else{
					session(['walletId' => $login['id']]);
				} 
				Session::flash('success', 'Login Success');
				return Redirect::to($this->Url);
			} else {
				$getCount = LoginAttempt::where('ip_address', $ip)->where('status', 'news')->count();
				if ($getCount >= 2) {
					$getBlockCount = BlockIP::where('ip_addr', $ip)->count();
					if ($getBlockCount == 0) {
						$updata = array('ip_addr' => $ip, 'status' => 'active');
						BlockIP::create($updata);
					} else {
						BlockIP::where('ip_addr', $ip)->update(['status' => 'active']);
					}

					$arrres = PaymentGateway::where('id', 1)->select('address', 'application')->first();
					$useremail = decrypText($arrres->address) . '@' . decrypText($arrres->application);
					$getEmail = EmailTemplate::where('id', 18)->first();
					$getSiteDetails = Controller::getEmailTemplateDetails();
					$getSiteDetails['###IP###'] = $_SERVER['REMOTE_ADDR'];

					$emaildata = array('content' => strtr($getEmail->template, $getSiteDetails));
					$toDetails['useremail'] = $useremail;
					$toDetails['subject'] = $getEmail->subject;
					$toDetails['from'] = $getSiteDetails['contact_mail_id'];
					$toDetails['name'] = $getSiteDetails['site_name'];

					$sendEmail = Controller::sendEmail($emaildata, $toDetails);
				}
				$createAttempt = array('ip_address' => $ip, 'os' => $platform, 'browser' => $browser, 'status' => 'news', 'username' => strip_tags($data['username']), 'password' => $data['user_pwd']);
				LoginAttempt::create($createAttempt);

				Session::flash('error', 'Invalid login credentials!');
				return Redirect::to($this->Url);
			}
		} else {
			Session::flash('error', 'Please fill all fields!');
			return Redirect::to($this->Url);
		}
	}

	public function logout() {
		if (session('walletId') != '') {
			$ip = Controller::getIpAddress();
			$activity['ip_address'] = $ip;
			$activity['browser_name'] = Controller::getBrowser();
			$activity['os'] = Controller::getPlatform();
			$activity['activity'] = "logout";
			$activity['admin_id'] = session('walletId');
			AdminActivity::create($activity);

			Session::flush();
			Session::flash('error', 'Logged out!');
			return Redirect::to($this->Url);
		} else {
			Session::flash('error', 'Session Expired!');
			return Redirect::to($this->Url);
		}
	}

	public function checkResetEmail(Request $request) {
		$email = explode('@', strip_tags($request['email_addr']));
		$first = encrypText($email[0]);
		$second = encrypText($email[1]);
		$getCount = PaymentGateway::where('address', $first)->where('application', $second)->count();
		echo ($getCount == 1) ? "true" : "false";
	}

	//Forgot password actions
	public function forgotPassword(Request $request) {
		$data = $request->all();
		$validate = Validator::make($data, [
			'useremail' => "required|indisposable",
		], [
			'useremail.required' => 'Please Enter email',
		]);
		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$result_data = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($result_data); exit;
			}
		}
		if ($data == array_filter($data)) {
			$useremail = strip_tags($data['useremail']);
			$email = explode('@', $useremail);
			$first = encrypText($email[0]);
			$second = encrypText($email[1]);

			$getDetail = PaymentGateway::select('id', 'name')->where('address', $first)->where('application', $second)->first();
			if ($getDetail->count()) {
				$id = encrypText($getDetail->id);
				$generateCode = User::randomString(8);
				$randomCode = encrypText($generateCode);
				$update = PaymentGateway::where('id', $getDetail->id)->update(['code' => $randomCode, 'status' => 'active']);
				$securl = URL::to($this->Url.'/resetPassword/' . $id . '/' . $randomCode);

				$getEmail = EmailTemplate::where('id', 2)->first();
				$getSiteDetails = SiteSettings::select('site_logo', 'site_name', 'contact_mail_id', 'contact_number', 'contact_address', 'city', 'country')->where('id', 1)->first();
				$replace = array('###USER###' => 'Admin', '###LINK###' => $securl, '###SITENAME###' => $getSiteDetails->site_name, '###img###' => $getSiteDetails->site_logo, '###address###' => $getSiteDetails->contact_address, '###city###' => $getSiteDetails->city, '###phone###' => $getSiteDetails->contact_number);
				$emaildata = array('content' => strtr($getEmail->template, $replace));
				$toDetails['useremail'] = $useremail;
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails->contact_mail_id;
				$toDetails['name'] = $getSiteDetails->site_name;

				$sendEmail = Controller::sendEmail($emaildata, $toDetails);
				if (count(Mail::failures()) > 0) {
					$result_data = array('status' => '0', 'msg' => 'Please Try Again');
				} else {
					$result_data = array('status' => '1', 'msg' => 'Reset password Link has sent to Your Mail Id');
				}
			} else {
				$result_data = array('status' => '0', 'msg' => 'Invalid Email ID');
			}
		}
		echo json_encode($result_data);
	}

	public function resetPassword($arg1, $arg2) {
		$id = decrypText($arg1);
		$getDetail = PaymentGateway::select('id', 'status')
		->where('id', $id)->first();
		if ($getDetail->status == "active") {
			$data['fcode'] = $arg2;
			$data['ucode'] = $arg1;
			return view('wallet.reset')->with('data', $data)->with('redirectUrl', $this->Url);
		} else {
			Session::flash('error', 'URL expired');
			return Redirect::to($this->Url);
		}
	}

	public function updatePassword() {
		$data = Input::all();

		$Validation = Validator::make($data, User::$passwordRule);
		if ($Validation->fails()) {
			Session::flash('error', $Validation->messages());
			return Redirect::to($this->Url);
		}

		if ($data == array_filter($data)) {
			$new_pwd = strip_tags($data['new_pwd']);
			$cnfirm_pwd = strip_tags($data['cnfirm_pwd']);
			$fcode = strip_tags($data['fcode']);
			$userid = decrypText(strip_tags($data['ucode']));
			if ($new_pwd == $cnfirm_pwd) {
				$getDetail = PaymentGateway::select('id', 'status')->where('id', $userid)->first();
				if ($getDetail->status == "active") {
					$password = encrypText($cnfirm_pwd);
					$update = PaymentGateway::where('id', $userid)->update(['name' => $password, 'code' => "", 'status' => 'deactive']);
					if ($update) {
						Session::flash('success', 'Password Reset Success');
						return Redirect::to($this->Url);
					} else {
						Session::flash('error', 'Please Try Again');
					}
				} else {
					Session::flash('error', 'Reset Url Expired');
				}
			} else {
				Session::flash('error', 'Password Must match');
			}
		} else {
			Session::flash('error', 'Fill All the Field');
		}
		return Redirect::to($this->Url);
	}

	//Forgot password actions
	public function forgotPattern(Request $request) {
		$data = $request->all();
		$validate = Validator::make($data, [
			'useremail' => "required|indisposable",
		], [
			'useremail.required' => 'Please Enter email',
		]);
		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$result_data = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($result_data); exit;
			}
		}
		if ($data == array_filter($data)) {
			$useremail = strip_tags($data['useremail']);
			$email = explode('@', $useremail);
			$first = encrypText($email[0]);
			$second = encrypText($email[1]);

			$getDetail = PaymentGateway::select('id', 'name')->where('address', $first)->where('application', $second)->first();
			if ($getDetail->count()) {
				$id = encrypText($getDetail->id);
				$generateCode = User::randomString(8);
				$randomCode = encrypText($generateCode);
				$update = PaymentGateway::where('id', $getDetail->id)->update(['forgot_code' => $randomCode, 'forgot_status' => 'active']);
				$securl = URL::to($this->Url.'/resetPattern/' . $id . '/' . $randomCode);
				$getEmail = EmailTemplate::where('id', 53)->first();
				$getSiteDetails = SiteSettings::select('site_logo', 'site_name', 'contact_mail_id', 'contact_number', 'contact_address', 'city', 'country')->where('id', 1)->first();
				$replace = array('###USER###' => 'Admin', '###LINK###' => $securl, '###SITENAME###' => $getSiteDetails->site_name, '###img###' => $getSiteDetails->site_logo, '###address###' => $getSiteDetails->contact_address, '###city###' => $getSiteDetails->city, '###phone###' => $getSiteDetails->contact_number);
				$emaildata = array('content' => strtr($getEmail->template, $replace));
				$toDetails['useremail'] = $useremail;
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails->contact_mail_id;
				$toDetails['name'] = $getSiteDetails->site_name;

				$sendEmail = Controller::sendEmail($emaildata, $toDetails);
				if (count(Mail::failures()) > 0) {
					$result_data = array('status' => '0', 'msg' => 'Please Try Again');
				} else {
					$result_data = array('status' => '1', 'msg' => 'Reset password Link has sent to Your Mail Id');
				}
			} else {
				$result_data = array('status' => '0', 'msg' => 'Invalid Email ID');
			}
		}
		echo json_encode($result_data);
	}

	public function resetPattern($arg1, $arg2) {
		$id = decrypText($arg1);
		$getDetail = PaymentGateway::select('id', 'forgot_status')->where('id', $id)->first();
		if ($getDetail->forgot_status == "active") {
			$data['fcode'] = $arg2;
			$data['ucode'] = $arg1;
			return view('wallet.resetpattern')->with('data', $data)->with('redirectUrl', $this->Url);
		} else {
			Session::flash('error', 'URL expired');
			return Redirect::to($this->Url);
		}
	}

	public function updatePattern() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'pattern_code' => 'required|min:3',
			'pattern_code_confirmation' => 'required|min:3',
		], [
			'pattern_code.required' => 'Enter pattern',
			'pattern_code.min' => 'Enter atleast 3 characters',
			'pattern_code_confirmation.required' => 'Enter confirm pattern',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				Session::flash('error', $msg[0]);
				return Redirect::to($this->Url);
			}
		}
		if ($data == array_filter($data)) {
			$new_pwd = strip_tags($data['pattern_code']);
			$cnfirm_pwd = strip_tags($data['pattern_code_confirmation']);
			$fcode = strip_tags($data['fcode']);
			$userid = decrypText(strip_tags($data['ucode']));
			if ($new_pwd == $cnfirm_pwd) {
				$getDetail = PaymentGateway::select('id', 'forgot_status')->where('id', $userid)->first();
				if ($getDetail->forgot_status == "active") {
					$pattern = encrypText($cnfirm_pwd);
					$update = PaymentGateway::where('id', $userid)->update(['access' => $pattern, 'forgot_code' => "", 'forgot_status' => 'deactive']);
					if ($update) {
						Session::flash('success', 'Pattern Reset Success');
					} else {
						Session::flash('error', 'Please Try Again');
					}
				} else {
					Session::flash('error', 'Reset Url Expired');
				}
			} else {
				Session::flash('error', 'Pattern Must match');
			}
		} else {
			Session::flash('error', 'Fill All the Field');
		}
		return Redirect::to($this->Url);
	}

	//return view for change password
	public function changePassword() {
		if (session('walletId') != '') {
			$arrres = SiteSettings::where('id', 1)->first();
			if ($arrres->go_secret == "" && $arrres->go_url == "") { 
				$googleAuth = new Googleauthenticator(); 
				$secret = $googleAuth->createSecret();
				$tfaUrl = $googleAuth->getQRCodeGoogleUrl("Wall(wallet)", $secret,'ru');
				SiteSettings::where('id', 1)->update(['go_secret' => $secret, 'go_url' => $tfaUrl]); 
			}

			return view('wallet.changePassword')->with('result',$arrres)->with('redirectUrl', $this->Url);
		}
		Session::flash('error', 'Session expired!');
		return Redirect::to($this->Url);
	}

	//change password
	public function checkPassword() {
		if (session('walletId') != '') {
			$pwd = encrypText($_GET['current_pwd']);
			$getCount = PaymentGateway::where('id', session('walletId'))
			->where('name', $pwd)->count();
			echo ($getCount == 1) ? "true" : "false";
		} else {
			echo "false";
		}
	}

	//update change password
	public function changeUpdatePassword() {
		if (session('walletId') != '') {
			$data = Input::all();
			$adminId = session('walletId');
			$Validation = Validator::make($data, SubAdmin::$pwdRule);
			if ($Validation->fails()) {
				Session::flash('error', $Validation->messages());
				return Redirect::back();
			}
			if ($data == array_filter($data)) {
				$new_pwd = strip_tags($data['new_pwd']);
				$confirm_pwd = strip_tags($data['confirm_pwd']);
				$pwd = encrypText(strip_tags($data['current_pwd']));
				$getCount = PaymentGateway::where('id', $adminId)
				->where('name', $pwd)->count();
				if ($getCount == 1) {
					if ($new_pwd == $confirm_pwd) {
						$updateData = encrypText($confirm_pwd);
						$result = PaymentGateway::where('id', $adminId)->update(['name' => $updateData]);
					}
				}
				if ($result) {
					Session::flash('success', 'password Updated Successfully');
				} else {
					Session::flash('error', 'Failed to update.');
				}
				return Redirect::back();
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//return view for admin profit
	public function walletProfit() {
		if (session('walletId') != '') {
			$data = CoinProfit::orderBy('id', 'desc')->get();

			$query = CoinProfit::select(DB::raw('SUM(theftAmount) as Amount'))
			->first();
			if ($query->Amount != null) {
				$profit['total_amount'] = ($query->count() == 0) ? "0.00" : $query->Amount;
			} else {
				$profit['total_amount'] = "0.00";
			}

			$profit['BTC_profit'] = Controller::adminProfit('BTC');
			$profit['ETH_profit'] = Controller::adminProfit('ETH');
			$profit['HAO_profit'] = Controller::adminProfit('HAO');

			return view('wallet.theft')->with('result', $data)->with('profit', $profit)->with('redirectUrl', $this->Url);
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//return wallet deposit page
	public function walletDeposit() {
		if (session('walletId') != '') {
			$currency = Currency::where('status','1')->where('currency_type','Crypto')->get();
			return view('wallet.walletDeposit')->with('currency',$currency)->with('redirectUrl', $this->Url);
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//get selected crypto currency info
	public function getCryptoCurrencyInfo(Request $request) {
		if (session('walletId') != '') {
			$currency = $request['currency'];
			$adminId = session('walletId');
			if ($currency == 'ETH' || $currency == 'USDT') {
				$address = decrypText(Config::get('cookie.ETH.address'));
			} else {
				$encrypt = encrypText($currency);
				$coin = SiteWallet::where('type', $encrypt)->select('address', 'block', 'tag')->first();
				if ($currency == 'XRP') {
					$address = decrypText(Config::get('cookie.XRP.address'));
				} else {
					if($coin->address) {
						$address = $coin->address;
					} else {
						$getAddr = CryptoAddress::createAddress($currency, $adminId);
						$addrStatus = $getAddr['status'];
						if ($addrStatus == 1 || $addrStatus == 2) {
							$address = $getAddr['address'];
							$secret = $getAddr['tag'];
							if ($addrStatus == 1) {
								SiteWallet::where('type', $encrypt)->update(['address' => $address, 'tag' => $secret]);
							}
						} else {
							$result = array('success' => 0, 'msg' => 'Failed to create address!');
							echo json_encode($result);exit();
						}
					}
				}
			}
			if ($currency == 'XRP') {
				$tag =  $coin->tag;
			} else {
				$tag = '';
			}
			$result['success'] = 1;
			$result['address'] = $address;
			$result['tag'] = $tag;
			$result['url'] = "https://chart.googleapis.com/chart?cht=qr&chs=150x150&chl=$address&choe=UTF-8&chld=L";
		} else {
			$result = array('success' => 0, 'msg' => 'Please login to continue');
		}
		echo json_encode($result);
	}

	//send confirmation to withdraw
	public function sendWithdrawOtp() {
		$keyCode = User::randomString(8);
		$encryptKey = encrypText($keyCode);
		$update = PaymentGateway::where('id', 1)->update(['code' => $encryptKey, 'status' => 'deactivate']);
		if ($update) {
			$arrres = PaymentGateway::where('id', 1)->select('address', 'application','otp_mail')->first();
			// $useremail = decrypText($arrres->address) . '@' . decrypText($arrres->application);
			$useremail = decrypText($arrres->otp_mail);

			$getEmail = EmailTemplate::where('id', 28)->first();
			$getSiteDetails = Controller::getEmailTemplateDetails();
			$info = array('###USER###' => 'admin', '###OTP###' => $keyCode, '###TYPE###' => 'admin wallet withdraw');
			$replace = array_merge($getSiteDetails, $info);

			$emaildata = array('content' => strtr($getEmail->template, $replace));
			$toDetails['useremail'] = $useremail;
			$toDetails['subject'] = $getEmail->subject;
			$toDetails['from'] = $getSiteDetails['contact_mail_id'];
			$toDetails['name'] = $getSiteDetails['site_name'];

			$sendEmail = Controller::sendEmail($emaildata, $toDetails);
			$result = array('status' => '1', 'code' => '');
		} else {
			$result = array('status' => '0');
		}
		echo json_encode($result);
	}

	//clear otp from db
	public function clearConfirmOtp() {
		$keyCode = User::randomString(8);
		$encryptKey = encrypText($keyCode);
		$update = PaymentGateway::where('id', 1)->update(['code' => $encryptKey, 'status' => 'deactive']);
		if ($update) {
			$result = array('status' => '1');
		} else {
			$result = array('status' => '0');
		}
		echo json_encode($result);
	}

	//return withdraw page
	public function walletWithdraw() {
		if (session('walletId') != '') {
			$currency = Currency::where('status','1')->where('currency_type','Crypto')->get();
			return view('wallet.walletWithdraw')->with('currency',$currency)->with('redirectUrl', $this->Url);
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//check bitcoin address
	public function bitCoinAddress(Request $request) {
		if (session('walletId') != '') {
			$data = $request->all();
			$currency = $data['currency'];
			if ($currency == 'BTC') {
				$address = $data['address'];
				$origbase58 = $address;
				$dec = "0";
				for ($i = 0; $i < strlen($address); $i++) {
					$dec = bcadd(bcmul($dec, "58", 0), strpos("123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz", substr($address, $i, 1)), 0);
				}
				$address = "";
				while (bccomp($dec, 0) == 1) {
					$dv = bcdiv($dec, "16", 0);
					$rem = (integer) bcmod($dec, "16");
					$dec = $dv;
					$address = $address . substr("0123456789ABCDEF", $rem, 1);
				}
				$address = strrev($address);
				for ($i = 0; $i < strlen($origbase58) && substr($origbase58, $i, 1) == "1"; $i++) {
					$address = "00" . $address;
				}
				if (strlen($address) % 2 != 0) {
					$address = "0" . $address;
				}
				if (strlen($address) != 50) {
					echo "false";exit();
				}
				$final = substr(strtoupper(hash("sha256", hash("sha256", pack("H*", substr($address, 0, strlen($address) - 8)), true))), 0, 8) == substr($address, strlen($address) - 8);
				echo ($final == 1) ? "true" : "false";
			} else {
				echo "true";
			}
		} else {
			Session::flash('error', 'Session Expired');
			return Redirect::to($this->Url);
		}
	}

	//withdraw admin wallet amount
	public function withdrawCryptoAmountWallet() {
		if (session('walletId') != '') {
			$data = Input::all();
			$Validation = Validator::make($data, Wallet::$withdrawRule);
			if ($Validation->fails()) {
				Session::flash('error', $Validation->messages());
				return Redirect::back();
			}
			$password = strip_tags($data['password']);
			$otp = strip_tags($data['confirm_code']);
			$encryptKey = encrypText($password);
			$encryptOtp = encrypText($otp);

			$checkAdmin = PaymentGateway::where('id', 1)->where('name', $encryptKey)->where('code', $encryptOtp)->where('status', 'deactivate')->select('address', 'application')->first();

			if ($checkAdmin) {
				PaymentGateway::where('id', 1)->update(['code' => '', 'status' => 'deactive']);
				$useremail = decrypText($checkAdmin->address) . '@' . decrypText($checkAdmin->application);

				$currency = strip_tags($data['currency']);
				$address = strip_tags($data['address']);
				$amount = strip_tags($data['amount']);
				$ip = Controller::getIpAddress();
				$keyCode = User::randomString(8);
				$encryptKey = encrypText($keyCode);

				$cryptoCurrency = array('BTC', 'ETH', 'XRP', 'HAO');
				if (!in_array($currency, $cryptoCurrency)) {
					Session::flash('error', 'Invalid currency!');
					return Redirect::back();
				}

				$referenceNumber = "";

				$insdata = array('amount' => $amount, 'token_id' => $encryptKey, 'currency' => $currency, 'payment_method' => $currency . ' payment', 'status' => 'pending', 'ip_address' => $ip, 'to_address' => $address, 'type' => 'withdraw', 'reference_no' => $referenceNumber);
				$createWithdraw = ContactUs::create($insdata);
				$txId = $createWithdraw->id;
				$transid = encrypText($txId);

				$securl1 = URL::to($this->Url.'/confirmWithdraw/' . $transid . '/' . $keyCode);
				$securl2 = URL::to($this->Url.'/rejectWithdraw/' . $transid . '/' . $keyCode);

				
				$getEmail = EmailTemplate::where('id', 10)->first();
				$getSiteDetails = Controller::getEmailTemplateDetails();
				$info = array('###USER###' => 'Admin', '###LINK1###' => $securl1, '###LINK2###' => $securl2, '###AMT###' => $amount . " " . $currency, '###FEE###' => "0 " . $currency);
				$replace = array_merge($getSiteDetails, $info);
				$emaildata = array('content' => strtr($getEmail->template, $replace));
				$toDetails['useremail'] = $useremail;
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails['contact_mail_id'];
				$toDetails['name'] = $getSiteDetails['site_name'];

				$sendEmail = Controller::sendEmail($emaildata, $toDetails);
				if (count(Mail::failures()) > 0) {
					Session::flash('error', 'Email sending failed.');
				} else {
					Session::flash('success', 'Confirmation mail sent to your registered email.');
				}
				return Redirect::back();
			} else {
				Session::flash('error', 'Invalid OTP/ Password.');
				return Redirect::back();
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//confirm withdraw from email
	public function confirmCryptoWithdraw($tid, $token) {
		if (session('walletId') != '') {
			$tid = decrypText(strip_tags($tid));
			$token = encrypText(strip_tags($token));
			$checkStatus = ContactUs::where('id', $tid)->where('token_id', $token)->select('status', 'currency', 'to_address', 'amount')->first();
			if ($checkStatus->status == "pending") {
				$toAddress = $checkStatus->to_address;
				$amount = $checkStatus->amount;
				$currency = $checkStatus->currency;

				$sendAmt = CryptoAddress::sendCryptoAmount($currency, $toAddress, $amount, "");
				if ($sendAmt) {
					$status = $sendAmt['msg'];
					if ($status == 'success') {
						$referenceNumber = $sendAmt['result'];
					} else {
						$value = $sendAmt['result'];
						if ($value == '' || $value == null) {
							Session::flash('error', 'Withdraw is not available now . Please try again later.');
						} else {
							Session::flash('error', $value);
						}
						return Redirect::to($this->Url.'/viewAdminWithdraw');
					}
				} else {
					Session::flash('error', 'Something went to wrong . Please try again later.');
					return Redirect::to($this->Url.'/viewAdminWithdraw');
				}

				$update = ContactUs::where('id', $tid)->update(['reference_no' => $referenceNumber, 'status' => 'completed']);
				Session::flash('success', 'Withdraw has been completed Successfully.');
				return Redirect::to($this->Url.'/viewAdminWithdraw');
			} else {
				Session::flash('success', 'Transaction already been processed.');
				return Redirect::to($this->Url.'/viewAdminWithdraw');
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//reject withdraw from email
	public function rejectCryptoWithdraw($tid, $token) {
		if (session('walletId') != '') {
			$tid = decrypText(strip_tags($tid));
			$token = encrypText(strip_tags($token));
			$checkStatus = ContactUs::where('id', $tid)->where('token_id', $token)->select('status')->first();
			if ($checkStatus->status == "pending") {
				ContactUs::where('id', $tid)->update(['status' => 'cancelled']);
				Session::flash('success', 'Withdraw has been rejected Successfully.');
			} else {
				Session::flash('success', 'Transaction already been processed.');
			}
			return Redirect::to($this->Url.'/viewAdminWithdraw');
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//wallet deposit history
	public function walletDepositHist() {
		if (session('walletId') != '') {
			$data = WltDeposit::orderBy('id', 'desc')->get();
			return view('wallet.depoHistory')->with('deposit', $data)->with('redirectUrl', $this->Url);
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//wallet deposit history
	public function walletWithdrawHist() {
		if (session('walletId') != '') {
			$data = ContactUs::where('type', 'withdraw')->orderBy('id', 'desc')->get();
			return view('wallet.withHistory')->with('withdraw', $data)->with('redirectUrl', $this->Url);
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function twofactorwallet() { 
		if (Session::get('is_login_wal') == 1) {
			if (Session::get('walletId') == "") {
				$admin = SiteSettings::find(1); 
				return view('wallet.tfa_login')->with('admin',$admin)->with('redirectUrl', $this->Url);
			} else {
				return redirect($this->Url);
			}
		}else {
			return redirect($this->Url);
		}
	}
	public function enableDisableTFawallet() { 
		if (Session::get('walletId') == "") {
			return redirect($this->Url);
		} else { 
			$data = Input::all();  
			require_once app_path('Model/Googleauthenticator.php');  
			$googleAuth = new Googleauthenticator();
			if ($googleAuth->verifyCode($data['secret_code'], $data['auth_key'], 1)) {
				if ($data['tfa_status'] == "0") {
					$updateData = array('go_secret' => $data['secret_code'], 'go_url' => $data['tfa_url'], 'go_status' => '1');
					$msg = 'TFA enabled successfully';
					$type = 'TFA enabled';
					$notf_msg3 = 'You have enabled 2FA for admin wallet';
				} else {
					$secret = $googleAuth->createSecret(); 
					$tfaUrl = $googleAuth->getQRCodeGoogleUrl("Wall(wallet)", $secret,'ru');
					$updateData = array('go_secret' => $secret, 'go_url' => $tfaUrl, 'go_status' => '0');
					$type = 'TFA disabled';
					$msg = 'TFA disabled successfully';
					$notf_msg3 = 'You have disabled 2FA for admin wallet'; 
				}

				$result = SiteSettings::where('id', 1)->update($updateData);
				if ($result) { 
					$msg1 = " Hi ," . $notf_msg3 . "!"; 
					$ip = Controller::getIpAddress();
					$browser = Controller::getBrowser();
					$platform = Controller::getPlatform();

					$activity['ip_address'] = $ip;
					$activity['browser_name'] = $browser;
					$activity['os'] = $platform;
					$activity['activity'] = $msg1;
					$activity['admin_id'] = 1;
					AdminActivity::create($activity);

					 
					Session::flash('success', $msg);
				} else {
					Session::flash('error', 'Failed to update TFA verification.');
				}
				return redirect($this->Url . '/changePassword'); 
			} else {
				Session::flash('error', 'Invalid 6-digit Authentication Code');
				return redirect($this->Url . '/changePassword');
			}
		}
		 
	}

	public function tfaLoginadminwallet() {
			if (Session::get('is_login_wal') == 1) {
				
				$lid = Session::get('login_id_wal');
			$data = Input::all();
			if ($data == array_filter($data)) { 
				$tfaDetails1 = SiteSettings::where('id', 1)->first(); 
				$secret = $tfaDetails1->go_secret;
				$code = $data['auth_key'];  
				require_once app_path('Model/Googleauthenticator.php');
				$googleAuth = new Googleauthenticator();
				$verify = $googleAuth->verifyCode($secret, $code, $discrepancy = 2);
				if ($verify == 1) {   
						$ip = Controller::getIpAddress();
						$notf_msg1 = 'Hi'; 
						$notf_msg2 = 'You have login 2FA for wallet '.$ip;
						$msg1 = $notf_msg1 . " ," . $notf_msg2 . "!";  
						$browser = Controller::getBrowser();
						$platform = Controller::getPlatform();

						$activity['ip_address'] = $ip;
						$activity['browser_name'] = $browser;
						$activity['os'] = $platform;
						$activity['activity'] = $msg1;
						$activity['admin_id'] = 1;
						AdminActivity::create($activity);

						session(['walletId' => $lid]);  
					 return redirect($this->Url);
				} else { 

					Session::flash('error', 'Invalid authentication key');
					return redirect($this->Url . '/twofactorwallet');
				}
			} else {
				Session::flash('error', 'Please try again');
				return redirect($this->Url . '/twofactorwallet');
			}
		}else {
			Session::flash('error', 'Please try again');
			return redirect($this->Url);
		}
	}

	public function changePattern() {
		if (session('walletId') != '') {
			$data = Input::all();
			$adminId = session('walletId');
			/*$Validation = Validator::make($data, SubAdmin::$adminPatternRule);
			if ($Validation->fails()) {
				Session::flash('error', $Validation->messages());
				return Redirect::back();
			}*/
			if ($data == array_filter($data)) {
				$pattern = encrypText(strip_tags($data['pattern_code']));
				$old_pattern = encrypText(strip_tags($data['old_pattern_code']));   
				$getCount = PaymentGateway::where('id', $adminId)->where('access', $old_pattern)->count();  
				if ($getCount > 0) { 
					$result = PaymentGateway::where('id', $adminId)->update(['access' => $pattern]);
					if ($result) {
						Session::flash('success', 'Patteren Updated Successfully');
						// return Redirect::to($this->Url . '/logout');
					} else {
						Session::flash('error', 'Failed to update.');
					}
				} else {
					Session::flash('error', ' Invalid old pattern');
				}
				return Redirect::back();
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}
}