<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Model\CoinOrder;
use App\Model\CoinProfit;
use App\Model\Currency;
use App\Model\EmailTemplate;
use App\Model\OrderTemp;
use App\Model\TradeModel;
use App\Model\TradePairs;
use App\Model\ExchangePairs;
use App\Model\ReferralCommision;
use App\Model\User;
use App\Model\Wallet;
use App\Model\SiteSettings;

use DateTime;
use DB;
use Illuminate\Http\Request;
use Redirect;
use Session;
use URL;

class Trades extends Controller {
	
	public function __construct() {
	}

	public function index() {
		$pairs = TradePairs::select('trading_pair')->where('site_status', 1)->first();
		if (!empty($pairs)) {
			$pair = $pairs->trading_pair;
			return redirect('/trade/' . $pair);
		} else {
			return redirect::to('/page404');
		}
	}

	public function trade($pair) {
		$userId = session('userId');
		$sta = 1;
		$res = explode('_', $pair);
		$from_symbol = $res[0];
		$to_symbol = $res[1];
		$pairList = array();
		$tradePair = $from_symbol . '/' . $to_symbol;
		$response = array('from_symbol' => $from_symbol, 'to_symbol' => $to_symbol, 'current_pair' => $pair, 'tradeFromSym' => $from_symbol, 'tradeToSym' => $to_symbol,'tradePair' => $tradePair, 'sta' => $sta);
		$depthbuy = file_get_contents(public_path('depth/depthjson/'.$from_symbol.''.$to_symbol.'/depth_buy.json')); 
		$depthsell = file_get_contents(public_path('depth/depthjson/'.$from_symbol.''.$to_symbol.'/depth_sell.json')); 
		return view('frontend.trade.trade', $response)->with('depthbuy', $depthbuy)->with('depthsell', $depthsell);
		// return view('frontend.trade.trade', $response);
	}

	public function loadDesign() {
		$response = array();
		$pair = strip_tags($_POST['pair']);
		$wcwr_id = strip_tags($_POST['wcwr_id']);
		$userId = session('userId');

		if($wcwr_id != '') {
			$wcwr = decrypText($wcwr_id);
			if($wcwr == $userId){
				$uid = $wcwr;
			} 
		} else {
			$uid = $userId;
		}
		$res = explode('/', $pair);
		$from_symbol = $res[0];
		$to_symbol = $res[1];

		$getTrade = TradePairs::where('from_symbol', $from_symbol)->where('to_symbol', $to_symbol)->where('site_status', 1)->select('fee_per', 'tfee_per', 'min_price','minamt', 'digit_amount', 'digit_price', 'last_price', 'low', 'high', 'base_volume', 'change')->first();
		if (!$getTrade) { echo json_encode(array('success' => 0));exit(); }
		$maker = $getTrade->fee_per;
		$taker = $getTrade->tfee_per;
		$last_price = $getTrade->last_price;
		$getBal = Wallet::where('user_id', $uid)->select($from_symbol, $to_symbol)->first();
		$response['success'] = 1;
		$response['pair'] = $pair;
		$response['from_symbol'] = $from_symbol;
		$response['to_symbol'] = $to_symbol;
		$response['minAmount'] =  $getTrade->minamt;
		$response['minPrice'] =  $getTrade->min_price;
		$response['digit_amount'] =  $digit_amount = $getTrade->digit_amount;
		$response['digit_price'] =  $digit_price = $getTrade->digit_price;
		$response['fees'] = $response['maker'] = number_format($maker, 2, '.', '');
		$response['taker'] = number_format($taker, 2, '.', '');
		if (!empty($getBal)) {
			$response['firstBal'] = $getBal->$from_symbol;
			$response['secondBal'] = $getBal->$to_symbol;
		} else {
			$response['firstBal'] = 0;
			$response['secondBal'] = 0;
		}
		$response['buy_rate'] = rtrim(rtrim(sprintf('%.'.$digit_price.'F', $last_price), '0'), ".");
		$response['sell_rate'] = rtrim(rtrim(sprintf('%.'.$digit_price.'F', $last_price), '0'), ".");
		$response['depth_buy_orders'] = self::getMarketdepth('Buy', $from_symbol, $to_symbol);
		$response['depth_sell_orders'] = self::getMarketdepth('Sell', $from_symbol, $to_symbol);
		$response['all_trade'] = self::allHistory($from_symbol, $to_symbol);
		$response['trade_data'] = self::getTradeData($pair, $from_symbol, $to_symbol);
		$response['active_order'] = self::getActiveOrders($from_symbol, $to_symbol, $uid);
		$response['stop_order'] = self::getStopOrders($from_symbol, $to_symbol, $uid);
		$response['my_history'] = self::myHistory($from_symbol, $to_symbol, $uid);
		$response['liquidity_status'] = 0;
		echo json_encode($response);
	}

	//To get buy and sell orders
	public static function getOrders($type, $from, $to, $apiReq = '') {
		$response = "";
		$query = CoinOrder::where(['firstCurrency' => $from, 'secondCurrency' => $to, 'Type' => $type])->whereIn('status', ['active', 'partially'])->select(DB::raw('SUM(Amount) as amount'), 'id', 'Price', 'status')->groupBy('Price');
		if ($type == "Buy") {
			$orders = $query->orderBy('Price', 'desc')->limit(15)->get();
		} else {
			$orders = $query->orderBy('Price', 'asc')->limit(15)->get();
		}
		if (!$orders->isEmpty()) {
			$k = 1;
			$totalamount = 0;
			foreach ($orders as $order) {
				$orderId = $order->id;
				$price = $trdPrice = $order->Price;
				$amount = $order->amount;
				$status = $order->status;

				$getTrade = trade_digit($from, $to);
				$digit_amount = $getTrade->digit_amount;
				$digit_price = $getTrade->digit_price;

				if ($status == "active") {
					$filledAmount = $amount;
				} else {
					$filledAmount = TradeModel::checkFilledAmount($orderId, $type);
					$filledAmount = ($filledAmount) ? $amount - $filledAmount : $amount;
				}
				$total = $filledAmount * $price;
				
				$amount = number_format($filledAmount, $digit_amount, '.', '');
				$price = number_format($price, $digit_price, '.', '');
				$total = number_format($total, 8, '.', '');

				if ($type == "Buy") {
					$clsName = 'class="plus_value"';
					$idName = 'id="buy_' . str_replace('.', '_', $trdPrice) . '"';
					$keyId = 2;
				} else {
					$clsName = 'class="minus_value"';
					$idName = 'id="sell_' . str_replace('.', '_', $trdPrice) . '"';
					$keyId = 1;
				}
				$totalamount = $amount + $totalamount;
				if($amount > 0 && $totalamount > 0) {
					if ($apiReq == 'API_WISE_ORDERS') {
						$result['pair'] = $from.'_'.$to;
						$result['price'] = $price;
						$result['amount'] = $amount;
						$result['totalamount'] = $totalamount;
						$response[] = $result;
					} else {
						$result['pair'] = $from.'_'.$to;
						$result['amount'] = $amount;
						$result['price'] = $price;
						$result['keyId'] = $keyId;
						$result['clsName'] = $clsName;
						$response[] = $result;
					}
					$k++;
				}
			}
		} else {
			if ($apiReq == 'API_WISE_ORDERS') {
				if ($type == "Buy") {
					$response = trans('app_lang.No_Buyorders');
				} else {
					$response = trans('app_lang.No_Sellorders');
				}
			} else {
				$response = 0;
			}
		}
		return $response;
	}

	public static function getMarketdepth($type, $from, $to, $apiReq = '') {
		$response = "";
		$query = CoinOrder::where(['firstCurrency' => $from, 'secondCurrency' => $to, 'Type' => $type])->whereIn('status', ['active', 'partially'])->select(DB::raw('SUM(Amount) as amount'), 'id', 'Price', 'status')->groupBy('Price');
		if ($type == "Buy") {
			$orders = $query->orderBy('Price', 'desc')->limit(15)->get();
		} else {
			$orders = $query->orderBy('Price', 'asc')->limit(15)->get();
		}
		if (!$orders->isEmpty()) {
			$k = 1;
			$totalamount = 0;
			foreach ($orders as $order) {
				$orderId = $order->id;
				$price = $trdPrice = $order->Price;
				$amount = $order->amount;
				$status = $order->status;

				$getTrade = trade_digit($from, $to);
				$digit_amount = $getTrade->digit_amount;
				$digit_price = $getTrade->digit_price;

				if ($status == "active") {
					$filledAmount = $amount;
				} else {
					$filledAmount = TradeModel::checkFilledAmount($orderId, $type);
					$filledAmount = ($filledAmount) ? $amount - $filledAmount : $amount;
				}
				$total = $filledAmount * $price;
				
				$amount = number_format($filledAmount, $digit_amount, '.', '');
				$price = number_format($price, $digit_price, '.', '');
				$total = number_format($total, 8, '.', '');

				if ($type == "Buy") {
					$clsName = 'class="plus_value"';
					$idName = 'id="buy_' . str_replace('.', '_', $trdPrice) . '"';
					$keyId = 2;
				} else {
					$clsName = 'class="minus_value"';
					$idName = 'id="sell_' . str_replace('.', '_', $trdPrice) . '"';
					$keyId = 1;
				}
				$totalamount = $amount + $totalamount;
				if($amount > 0 && $totalamount > 0) {
					if ($apiReq == 'API_WISE_ORDERS') {
						$result['pair'] = $from.'_'.$to;
						$result['amount'] = $amount;
						$result['price'] = $price;
						$response[] = $result;
					} else {
						$result['pair'] = $from.'_'.$to;
						$result['amount'] = $amount;
						$result['price'] = $price;
						$result['keyId'] = $keyId;
						$result['clsName'] = $clsName;
						$response[] = $result;

					}
					$k++;
				}
			}
		} else {
			if ($apiReq == 'API_WISE_ORDERS') {
				if ($type == "Buy") {
					$response = 'No Marketdepth Buy orders at the moment';
				} else {
					$response = 'No Marketdepth Sell orders at the moment';
				}
			} else {
				$response = 0;
			}
		}
		return $response;
	}

	public static function getBothOrders($type, $from, $to, $apiReq = '') {
		$response = "";
		$query = CoinOrder::where(['firstCurrency' => $from, 'secondCurrency' => $to, 'Type' => $type])->whereIn('status', ['active', 'partially'])->select(DB::raw('SUM(Amount) as amount'), 'id', 'Price', 'status')->groupBy('Price');
		if ($type == "Buy") {
			$orders = $query->orderBy('Price', 'desc')->limit(15)->get();
		} else {
			$orders = $query->orderBy('Price', 'asc')->limit(15)->get();
		}
		if (!$orders->isEmpty()) {
			$k = 1;
			$totalamount = 0;
			foreach ($orders as $order) {
				$orderId = $order->id;
				$price = $trdPrice = $order->Price;
				$amount = $order->amount;
				$status = $order->status;

				$getTrade = trade_digit($from, $to);
				$digit_amount = $getTrade->digit_amount;
				$digit_price = $getTrade->digit_price;

				if ($status == "active") {
					$filledAmount = $amount;
				} else {
					$filledAmount = TradeModel::checkFilledAmount($orderId, $type);
					$filledAmount = ($filledAmount) ? $amount - $filledAmount : $amount;
				}
				$total = $filledAmount * $price;
				
				$amount = number_format($filledAmount, $digit_amount, '.', '');
				$price = number_format($price, $digit_price, '.', '');
				$total = number_format($total, 8, '.', '');

				if ($type == "Buy") {
					$clsName = 'class="plus_value"';
					$idName = 'id="buy_' . str_replace('.', '_', $trdPrice) . '"';
					$keyId = 2;
				} else {
					$clsName = 'class="minus_value"';
					$idName = 'id="sell_' . str_replace('.', '_', $trdPrice) . '"';
					$keyId = 1;
				}
				$totalamount = $amount + $totalamount;
				if($amount > 0 && $totalamount > 0) {
					if ($apiReq == 'API_WISE_ORDERS') {
						$response_result[] = $price . "##" . $amount;
						$response = $response_result;
					} else {
						$result['amount'] = $amount;
						$result['price'] = $price;
						$result['keyId'] = $keyId;
						$result['clsName'] = $clsName;
						$response[] = $result;
					}
					$k++;
				}
			}
		} else {
			if ($apiReq == 'API_WISE_ORDERS') {
				if ($type == "Buy") {
					$response = trans('app_lang.No_Buyorders');
				} else {
					$response = trans('app_lang.No_Sellorders'); 
				}
			} else {
				$response = 0;
			}
		}
		return $response;
	}

	//To get all trade history
	public static function allHistory($from, $to, $apiReq = '') {
		$response = "";
		$orders = OrderTemp::where('firstCurrency', $from)->where('secondCurrency', $to)->where('cancel_id', 0)->select('id', 'askPrice', 'filledAmount', 'updated_at', 'taker_type')->orderBy('id', 'desc')->limit(15)->get();
		if (!$orders->isEmpty()) {
			foreach ($orders as $order) {
				$getTrade = trade_digit($from, $to);
				$digit_amount = $getTrade->digit_amount;
				$digit_price = $getTrade->digit_price;

				$filledAmount = number_format($order->filledAmount, $digit_amount, '.', '');
				$price = number_format($order->askPrice, $digit_price, '.', '');

				$orderTime = date('H:i:s', strtotime($order->updated_at));
				$clsName = ($order->taker_type == "buy") ? 'class="plus_value"' : 'class="minus_value"';
				$id = 'id="trade_' . encrypText($order->id) . '"';
				if ($apiReq == 'API_WISE_ORDERS') {
					$tradetype = ($order->taker_type == "buy") ? '1' : '2';
					$result['pair'] = $from.'_'.$to;
					$result['type'] = ucfirst($order->taker_type);
					$result['id'] = $order->id;
					$result['created_at'] = strtotime($orderTime);
					$result['price'] = $price;
					$result['volume'] = $filledAmount;
					$result['initiative'] = $tradetype;
					$response[] = $result;
				} else {
					if ($apiReq == 'API_WISE_ORDERS') {
						$response = array();
					} else {
						$result['pair'] = $from.'_'.$to;
						$result['type'] = ucfirst($order->taker_type);
						$result['datetime'] = $orderTime;
						$result['amount'] = $filledAmount;
						$result['price'] = $price;
						$result['clsName'] = $clsName;
						$response[] = $result;
					}
				}
			}
		} else {
			if ($apiReq == 'API_WISE_ORDERS') {
				$response = trans('app_lang.No_Tradehistory');
			} else {
				$response = 0;
			}
		}
		return $response;
	}

	//To get Active Orders
	public static function getActiveOrders($from, $to, $uid, $apiReq = '') {
		if (!empty($uid)) {
			$activeOrders = CoinOrder::where('user_id', $uid)->where('firstCurrency', $from)->where('secondCurrency', $to)->where('ordertype', '!=', 'instant')->whereIn('status', ['active', 'partially'])->select('id', 'Price', 'Amount', 'Type', 'ordertype', 'status', 'fee_per', 'pair', 'created_at', 'ledger_id')->orderBy('id', 'desc')->get();
			$response = "";
			if (!$activeOrders->isEmpty()) {
				foreach ($activeOrders as $active) {
					$orderId = $active->id;
					$ledger_id = $active->ledger_id;
					$activePrice = $active->Price;
					$activeAmount = $active->Amount;
					$type = $active->Type;
					$orderType = ucfirst($active->ordertype);
					$orderTime =  date('Y-m-d H:i:s', strtotime($active->created_at));
					$status = $active->status;
					$feePer = $active->fee_per;
					$pair = $active->pair;
					
					$getTrade = trade_digit($from, $to);
					$digit_amount = $getTrade->digit_amount;
					$digit_price = $getTrade->digit_price;

					if ($status == "active") {
						$filledAmount = $activeAmount;
					} else {
						$filledAmount = TradeModel::checkFilledAmount($orderId, $type);
						$filledAmount = ($filledAmount) ? $activeAmount - $filledAmount : $activeAmount;
					}
					$enc = $orderId . '-'. $ledger_id;
					$tradeid = encrypText($enc);

					$filledAmount = number_format($filledAmount, $digit_amount, '.', '');
					$activePrice = number_format($activePrice, $digit_price, '.', '');
					$feeAmount = (($filledAmount * $activePrice) * $feePer) / 100;

					if ($type == "Buy") {
						$total = $filledAmount * $activePrice;
						$clsName = 'class="plus_value"';
					} else {
						$total = $filledAmount * $activePrice;
						$clsName = 'class="minus_value"';
					}
					
					$feeAmount = number_format($feeAmount, 8, '.', '');
					$total = number_format($total, 8, '.', '');
					
					if($filledAmount > 0) {
						if ($apiReq == 'API_WISE_ORDERS') {
							$result['pair'] = $from.'_'.$to;						
							$result['datetime'] = $orderTime;
							$result['type'] = $type;
							$result['amount'] = $filledAmount;
							$result['price'] = $activePrice;
							$result['total'] = $total;
							$result['orderid'] = $tradeid;
							$response[] = $result;
						} else {
							$result['pair'] = $from.'_'.$to;						
							$result['datetime'] = $orderTime;
							$result['type'] = $type;
							$result['amount'] = $filledAmount;
							$result['price'] = $activePrice;
							$result['total'] = $total;
							$result['clsName'] = $clsName;
							$result['onClick'] = 'cancel_order(\'' . $tradeid . '\',' . "1" . ')';
							$response[] = $result;
						}
					}
				}
			} else {
				if ($apiReq == 'API_WISE_ORDERS') {
					$response = trans('app_lang.no_activeorder');
				} else {
					$response = 0;
				}
			}
		} else {
			if ($apiReq == 'API_WISE_ORDERS') {
				$response = trans('app_lang.no_activeorder');
			} else {
				$response = 0;
			}
		}
		return $response;
	}

	//To get stop orders
	public static function getStopOrders($from, $to, $uid, $apiReq = '') {
		if (!empty($uid)) {
			$stopOrders = CoinOrder::where('user_id', $uid)->where('firstCurrency', $from)->where('secondCurrency', $to)->whereIn('status', ['stoplimitorder', 'stoporder'])->select('id', 'Type', 'created_at', 'Amount', 'Price', 'trigger_price', 'fee_per', 'pair', 'ordertype', 'ledger_id')->orderBy('id', 'desc')->get();
			$response = "";
			if (!$stopOrders->isEmpty()) {
				foreach ($stopOrders as $active) {
					$type = $active->Type;
					$orderTime = date('Y-m-d H:i:s', strtotime($active->created_at));
					$amount = $active->Amount;
					$stoporderprice = $active->Price;
					$trigger_price = $active->trigger_price;
					$trade_id = $active->id;
					$ledger_id = $active->ledger_id;
					$feePer = $active->fee_per;
					$pair = $active->pair;
					$orderType = $active->ordertype;
					
					$getTrade = trade_digit($from, $to);
					$digit_amount = $getTrade->digit_amount;
					$digit_price = $getTrade->digit_price;

					$enc = $trade_id . '-'. $ledger_id;
					$tradeid = encrypText($enc);

					$filledAmount = number_format($amount, $digit_amount, '.', '');
					$stopPrice = number_format($stoporderprice, $digit_price, '.', '');

					if ($orderType == "stoplimitorder") {
						$limitPrice = number_format($trigger_price, $digit_price, '.', '');
						$total = $filledAmount * $limitPrice;
					} else {
						$total = $filledAmount * $stopPrice;
						$limitPrice = "-";
					}
					
					$feeAmount = ($total * $feePer) / 100;
					$clsName = ($type == "Buy") ? 'class="plus_value"' : 'class="minus_value"';
					
					$feeAmount = number_format($feeAmount, 8, '.', '');
					$total = number_format($total, 8, '.', '');

					if ($apiReq == 'API_WISE_ORDERS') {
						$result['pair'] = $from.'_'.$to;
						$result['datetime'] = $orderTime;
						$result['type'] = $type;
						$result['amount'] = $filledAmount;
						$result['price'] = $stopPrice;
						$result['total'] = $total;
						$result['orderid'] = $tradeid;
						$response[] = $result;
					} else {
						$result['pair'] = $from.'_'.$to;
						$result['datetime'] = $orderTime;
						$result['type'] = $type;
						$result['amount'] = $filledAmount;
						$result['price'] = $stopPrice;
						$result['total'] = $total;
						$result['clsName'] = $clsName;
						$result['onClick'] = 'cancel_order(\'' . $tradeid . '\',' . "1" . ')';
						$response[] = $result;
					}
				}
			} else {
				if ($apiReq == 'API_WISE_ORDERS') {
					$response = trans('app_lang.no_stoporder');
				} else {
					$response = 0;
				}
			}
		} else {
			if ($apiReq == 'API_WISE_ORDERS') {
				$response = trans('app_lang.no_stoporder');
			} else {
				$response = 0;
			}
		}

		return $response;
	}

	//To get my trade history
	public static function myHistory($from, $to, $uid, $apiReq = '') {
		$response = "";
		$pair = $from . "/" . $to;
		if (!empty($uid)) {
			$orders = OrderTemp::where(['firstCurrency' => $from, 'secondCurrency' => $to])->where(function ($q) use ($uid) {$q->where('buyerUserId', $uid)->orWhere('sellerUserId', $uid);})->select('sellerUserId', 'buyerUserId', 'askPrice', 'filledAmount', 'cancel_id', 'sellorderId', 'buyorderId', 'updated_at', 'buy_fee','sell_fee')->orderBy('updated_at', 'desc')->get();
			if (!$orders->isEmpty()) {
				$orders = $orders->toArray();
				foreach ($orders as $order) {
					$sellUser = $order['sellerUserId'];
					$buyUser = $order['buyerUserId'];
					$cancelId = $order['cancel_id'];
					$filledAmount = $order['filledAmount'];
					$askPrice = $order['askPrice'];
					$updatedAt = $order['updated_at'];
					$buy_fee = $order['buy_fee'];
					$sell_fee = $order['sell_fee'];
					
					$getTrade = trade_digit($from, $to);
					$digit_amount = $getTrade->digit_amount;
					$digit_price = $getTrade->digit_price;

					$total = $filledAmount * $askPrice;
					$status = ($cancelId != "") ? "Cancelled" : "Filled";

					$activeAmount = number_format($filledAmount, $digit_amount, '.', '');
					$buy_fee = number_format($buy_fee, $digit_amount, '.', '');
					$activePrice = number_format($askPrice, $digit_price, '.', '');
					$activeTotal = number_format($total, 8, '.', '');
					$sell_fee = number_format($sell_fee, 8, '.', '');

					$updatedTime = date('Y-m-d H:i:s', strtotime($updatedAt));
					$stsCls = ($status == "Cancelled") ? 'class="minus_value"' : 'class="plus_value"';
					if ($buyUser == $uid) {
						$type = "Buy";
						$fees = $buy_fee . " ".$from;
						$className = 'class="plus_value"';
						if ($sellUser == $uid) {
							$typ = "Sell";
							$fees = $sell_fee;
							$classNam = 'class="minus_value"';
							if ($apiReq == 'API_WISE_ORDERS') {
								$result['pair'] = $from.'_'.$to;
								$result['datetime'] = $updatedTime;
								$result['type'] = $typ;
								$result['amount'] = $activeAmount;
								$result['price'] = $activePrice;
								$result['total'] = $activeTotal;
								$result['status'] = $status;
								$response[] = $result;
							} else {
								$result['pair'] = $from.'_'.$to;
								$result['datetime'] = $updatedTime;
								$result['type'] = $typ;
								$result['amount'] = $activeAmount;
								$result['price'] = $activePrice;
								$result['total'] = $activeTotal;
								$result['className'] = $classNam;
								$result['stsCls'] = $stsCls;
								$result['status'] = $status;
								$response[] = $result;
							}
						}
					} else {
						$type = "Sell";
						$fees = $sell_fee . " " . $to;
						$className = 'class="minus_value"';
					}
					if ($apiReq == 'API_WISE_ORDERS') {
						$result['pair'] = $from.'_'.$to;
						$result['datetime'] = $updatedTime;
						$result['type'] = $type;
						$result['amount'] = $activeAmount;
						$result['price'] = $activePrice;
						$result['total'] = $activeTotal;
						$result['fees'] = $fees;
						$result['status'] = $status;
						$response[] = $result;
					} else {
						$result['pair'] = $from.'_'.$to;
						$result['datetime'] = $updatedTime;
						$result['type'] = $type;
						$result['amount'] = $activeAmount;
						$result['price'] = $activePrice;
						$result['total'] = $activeTotal;
						$result['fees'] = $fees;
						$result['className'] = $className;
						$result['stsCls'] = $stsCls;
						$result['status'] = $status;
						$response[] = $result;
					}
				}
			} else {
				if ($apiReq == 'API_WISE_ORDERS') {
					$response = trans('app_lang.No_Tradehistory');
				} else {
					$response = 0;
				}
			}
		} else {
			if ($apiReq == 'API_WISE_ORDERS') {
				$response = trans('app_lang.No_Tradehistory');
			} else {
				$response = 0;
			}
		}

		return $response;
	}

	//To get trade data
	public static function getTradeData($pair, $first, $second) {
		$x = array('price' => '0.00', 'volume' => '0.00', 'change' => '0.00', 'high' => '0.00', 'low' => '0.00', 'open' => '0.00', 'class' => "plus_value");
		$price = OrderTemp::where('pair', $pair)->where('cancel_id', 0)->select('askPrice')->orderBy('id', 'desc')->first();
		if ($price) {
			$digits = 8;
			$x['price'] = rtrim(rtrim(sprintf('%.'.$digits.'F', $price->askPrice), '0'), ".");
			$todayOpen = $price->askPrice;
			$yesterday = date('Y-m-d H:i:s', strtotime("-1 days"));
			$getPrice = OrderTemp::where('datetime', '>=', $yesterday)->where('cancel_id', 0)->where('pair', $pair)->select(DB::raw('SUM(askPrice * filledAmount) as volume'), DB::raw('askPrice as price'), DB::raw('MAX(askPrice) as high'), DB::raw('MIN(askPrice) as low'))->orderBy("id", "asc")->first();
			if ($getPrice) {
				$yesterPrice = $getPrice->price;
				$changeVal = $todayOpen - $yesterPrice;
				$arrow = ($todayOpen > $yesterPrice) ? "+" : "";
				$class = ($todayOpen >= $yesterPrice) ? "plus_value" : "minus_value";
				if($yesterPrice > 0) {
					$changePer = ($changeVal / $yesterPrice) * 100;
				} else {
					$changePer = ($changeVal / 1) * 100;
				}
				$changePer = $arrow . number_format((float) $changePer, 2, '.', '');
				$x['change'] = $changePer;
				$x['class'] = $class;
				$x['high'] = number_format((float) $getPrice->high, $digits, '.', '');
				$x['low'] = number_format((float) $getPrice->low, $digits, '.', '');
				$x['volume'] = number_format((float) $getPrice->volume, $digits, '.', '');
				$x['open'] = number_format((float) $getPrice->price, $digits, '.', '');
			}
		} else {
			$x['price'] = '0.00';
			$x['high'] = '0.00';
			$x['volume'] = '0.00';
			$x['low'] = '0.00';
			$x['change'] = '0.00';
			$x['open'] = '0.00';
			$x['class'] = 'plus_value';
		}
		$x['lastprice'] = pairDetails($pair,'last_price');
		return $x;
	}

	//create buy order
	public function createBuyorder(Request $request) {
		if (session('userId') != '') {
			$data = $request->all();
			$userId = session('userId');
			$pair = strip_tags($data['pair']);
			$pair1 = explode('/', $pair);
			$from_symbol = $pair1[0];
			$to_symbol = $pair1[1];
			$order_type = strip_tags($data['order']);
			$userDetails = User::where('id', $userId)->select('pro_user', 'auto_trade')->first();
			$pro_user = $userDetails->pro_user;
			$auto_trade = $userDetails->auto_trade;
			$sta = 1;

			if($sta && $auto_trade) {
				$trigger['trigger_id'] =	encrypText($userId);
				$trigger['type'] =	'buy';
				trigger_socket($trigger,'restrictwindow');

				$amount = strip_tags($data['amount']);
				$price = strip_tags($data['price']);
				
				$tradeFromSym = $from_symbol;
				$tradeToSym = $to_symbol;	

				$getTrade = TradePairs::where('from_symbol', $from_symbol)->where('to_symbol', $to_symbol)->select('fee_per', 'tfee_per','min_price', 'last_price','pair','digit_amount', 'digit_price', 't_status')->first();
				$digit_amount = $getTrade->digit_amount;
				$digit_price = $getTrade->digit_price;
				$table_price = $getTrade->last_price;
				$t_status = $getTrade->t_status;
				$tot = $amount * $price;

				if ($_SERVER['HTTP_HOST'] != "localhost") {
					$orderDetails = CoinOrder::where('firstCurrency', $from_symbol)->where('secondCurrency', $to_symbol)->where('user_id', $userId)->where('Type', 'sell')->whereIn('status', ['active','partially'])->where('ordertype', '!=', 'instant')->select('Price')->orderBy('Price', 'asc')->first();
					if(count($orderDetails)) {
						$row = $orderDetails->Price;
						if($row <= $price) {
							$response = array('status' => '0', 'msg' => 'Enter Price less than '. $row . ' ' . $to_symbol);
							echo json_encode($response);exit;
						}
					}
				}

				if ($order_type != "1") {
					$sell_rate = $table_price;
				}

				$limit = "0";
				if ($order_type == "market") {
					$getorder = self::checkActiveOrder($from_symbol, $to_symbol, 'Sell', $userId);
					if ($getorder == 0) {
						$ret = array('status' => '0', 'msg' => trans('app_lang.no_sell_order_available'));
						echo json_encode($ret);exit;
					}
					$price = $sell_rate;
					$order_typeval = "instant";
					$api_type = 'exchange limit';
					$order_status = "market";
				} else if ($order_type == "limit") {
					$order_typeval = "limit";
					$order_status = "active";
					$api_type = 'exchange limit';
				} else if ($order_type == "stoporder") {
					$order_typeval = "stoporder";
					$order_status = "stoporder";
					$api_type = 'exchange stop';
					if ($price <= $sell_rate) {
						$response = array('status' => '0', 'msg' => trans('app_lang.enter_above_market_price_buy_order'));
						echo json_encode($response);exit;
					}
				} 
				if ($amount != "" && $price != "") {
					if (is_numeric($amount) && is_numeric($price)) {
						if ($amount > 0 && $price > 0) {
							$feePer = $getTrade->fee_per;
							$tfeePer = $getTrade->tfee_per;
							$pairname = $getTrade->pair;
							$checkPrice = ($order_type == "3") ? $limit : $price;
							$subTotal = $amount * $checkPrice;
							$fee_amt = 0;
							
							$total = number_format($subTotal, 8, '.', '');
							$minAmt = $getTrade->min_price;
							$lastPrice = $getTrade->last_price;
							$minPrice = $lastPrice / 5;
							$maxPrice = $lastPrice * 5;
							if ($checkPrice < $minPrice) {
								$response = array('status' => '0', 'msg' => "Minimum Price is " . number_format($minPrice, $digit_price, '.', '') . ' ' . $to_symbol);
								echo json_encode($response);exit;
							}
							if ($checkPrice > $maxPrice) {
								$response = array('status' => '0', 'msg' => "Maximum Price is " . number_format($maxPrice, $digit_price, '.', '') . ' ' . $to_symbol);
								echo json_encode($response);exit;
							}
							if ($amount < $minAmt) {
								$response = array('status' => '0', 'msg' => trans('app_lang.min_trade_amount') . ' ' . $minAmt . ' ' . $pair1[0]);
								echo json_encode($response);exit;
							}
							$balance = TradeModel::fetchuserbalancebyId($userId, $tradeToSym);

							if ($total <= $balance) {
								if ($order_type != "market") {
									$updatesecondBalance = $balance - $total;
									$updatesecondBalance = number_format(trim($updatesecondBalance), 8, '.', '');
									$remarks = 'BuyOrder placed for '. $total . ' ' . $tradeToSym . ' Old balance: '. $balance;
									$updatedata = array($tradeToSym => $updatesecondBalance, 'remarks' => $remarks);
								} else {
									$updatedata = array();
								}
								$current_date = date('Y-m-d');
								$current_time = date('H:i:s');
								$datetime = date("Y-m-d H:i:s");
								$trdPrice = number_format($price, $digit_price, '.', '');
								$rand = self::randomstring();
								$data = array(
									'user_id' => $userId,
									'Amount' => number_format($amount, $digit_amount, '.', ''),
									'originalAmount' => number_format($amount, $digit_amount, '.', ''),
									'Price' => $trdPrice,
									'Total' => number_format($total, 8, '.', ''),
									'Fee' => number_format($fee_amt, 8, '.', ''),
									'firstCurrency' => $from_symbol,
									'secondCurrency' => $to_symbol,
									'Type' => "Buy",
									'orderDate' => $current_date,
									'orderTime' => $current_time,
									'datetime' => $datetime,
									'pair' => $pair,
									'status' => $order_status,
									'fee_per' => $feePer,
									'taker_fee_par' => $tfeePer,
									'trade_type_status' => 0,
									'ordertype' => $order_typeval,
									'inr_price' => 0,
									'stoporderprice' => number_format($price, $digit_price, '.', ''),
									'trigger_price' => number_format($limit, $digit_price, '.', ''),
									'liquidity_order' => 0,
									'pro_user' => $pro_user,
									'ledger_id' => $rand,
								);
								$create = DB::transaction(function () use ($userId, $updatedata, $data, $order_type) {
									if ($order_type != "market") {
										$updatequery = Wallet::where('user_id', $userId)->update($updatedata);
									}
									$create = CoinOrder::create($data);
									return $create;
								});
								if ($create) {
									$map = array();
									if ($order_typeval == "limit") {
										$map = TradeModel::mapping($create->id, $lastPrice);							
									} else if ($order_typeval == "instant") {
										$map = TradeModel::marketMapping($create->id, $lastPrice);
									}
									$response = array('status' => '1', 'msg' => trans('app_lang.buy_order_place_successfully'), 'order' => str_replace('.', '_', $trdPrice), 'trade' => $map);
								} else {
									$response = array('status' => '0', 'msg' => trans('failed_create_order'));
								}
							} else {
								$response = array('status' => '0', 'msg' => trans('app_lang.insufficint_balance'));
							}
						} else {
							$response = array('status' => '0', 'msg' => trans('app_lang.enter_valid_amount_price'));
						}
					} else {
						$response = array('status' => '0', 'msg' => trans('app_lang.enter_amount_price'));
					}
				} else {
					$response = array('status' => '0', 'msg' => trans('app_lang.enter_amount_price'));
				}
			} else {
				$response = array('status' => '0', 'msg' => 'Trade is under maintenance');
			}
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.login_failure'));
		}
		echo json_encode($response);
	}

	public function createSellorder(Request $request) {
		if (session('userId') != '') {
			$data = $request->all();
			$userId = session('userId');
			$pair = strip_tags($data['pair']);
			$pair1 = explode('/', $pair);
			$from_symbol = $pair1[0];
			$to_symbol = $pair1[1];
			$order_type = strip_tags($data['order']);
			$userDetails = User::where('id', $userId)->select('pro_user', 'auto_trade', 'country')->first();
			$pro_user = $userDetails->pro_user;
			$auto_trade = $userDetails->auto_trade;	
			$sta = 1;

			if($sta && $auto_trade) {
				$trigger['trigger_id'] =	encrypText($userId);
				$trigger['type'] =	'sell';
				trigger_socket($trigger,'restrictwindow');

				$limit = 0;
				$pair = strip_tags($data['pair']);
				$amount = strip_tags($data['amount']);
				$price = strip_tags($data['price']);
				$tradeFromSym = $from_symbol;
				$tradeToSym = $to_symbol;


				$getTrade = TradePairs::where('from_symbol', $from_symbol)->where('to_symbol', $to_symbol)->select('fee_per', 'tfee_per','min_price', 'last_price','pair','digit_amount', 'digit_price', 't_status')->first();
				$digit_amount = $getTrade->digit_amount;
				$digit_price = $getTrade->digit_price;
				$table_price = $getTrade->last_price;
				$t_status = $getTrade->t_status;

				if ($_SERVER['HTTP_HOST'] != "localhost") {
					$orderDetails = CoinOrder::where('firstCurrency', $from_symbol)->where('secondCurrency', $to_symbol)->where('user_id', $userId)->where('Type', 'buy')->whereIn('status', ['active','partially'])->where('ordertype', '!=', 'instant')->select('Price')->orderBy('Price', 'desc')->first();
					if(count($orderDetails)) {
						$row = $orderDetails->Price;
						if($row >= $price) {
							$response = array('status' => '0', 'msg' => 'Enter Price more than '. $row . ' ' . $to_symbol);
							echo json_encode($response);exit;
						}
					}
				}

				if ($order_type != "1") {
					$buy_rate = $table_price;
				}
				if ($order_type == "market") {
					$getorder = self::checkActiveOrder($from_symbol, $to_symbol, 'buy', $userId);
					if ($getorder == 0) {
						$response = array('status' => '0', 'msg' => trans('app_lang.no_buy_order'));
						echo json_encode($response);exit;
					}
					$price = $buy_rate;
					$order_typeval = "instant";
					$order_status = "market";
					$api_type = 'exchange market';
				} else if ($order_type == "limit") {
					$order_typeval = "limit";
					$order_status = "active";
					$api_type = 'exchange limit';
				} else if ($order_type == "stoporder") {
					$order_typeval = "stoporder";
					$order_status = "stoporder";
					$api_type = 'exchange stop';
					if ($price >= $buy_rate) {
						$response = array('status' => '0', 'msg' => trans('app_lang.enter_below_market_price_sell_order'));
						echo json_encode($response);exit;
					}
				}
				if ($amount != "" && $price != "") {
					if (is_numeric($amount) && is_numeric($price)) {
						if ($amount > 0 && $price > 0) {
							$getTrade = TradePairs::where('from_symbol', $from_symbol)->where('to_symbol', $to_symbol)->select('fee_per', 'tfee_per', 'min_price', 'last_price', 'pair')->first();
							$feePer = $getTrade->fee_per;
							$tfeePer = $getTrade->tfee_per;
							$pairname = $getTrade->pair;
							$checkPrice = ($order_type == "3") ? $limit : $price;
							$subTotal = $amount * $checkPrice;
							$fee_amt = 0;
							$total = $subTotal;
							$minAmt = $getTrade->min_price;
							$lastPrice = $getTrade->last_price;
							$minPrice = $lastPrice / 5;
							$maxPrice = $lastPrice * 5;
							if ($checkPrice < $minPrice) {
								$response = array('status' => '0', 'msg' => "Minimum Price is " . number_format($minPrice, $digit_price, '.', '') . ' ' . $to_symbol);
								echo json_encode($response);exit;
							}
							if ($checkPrice > $maxPrice) {
								$response = array('status' => '0', 'msg' => "Maximum Price is " . number_format($maxPrice, $digit_price, '.', '') . ' ' . $to_symbol);
								echo json_encode($response);exit;
							}
							if ($amount < $minAmt) {
								$response = array('status' => '0', 'msg' => trans('app_lang.min_trade_amount') . ' ' . $minAmt . ' ' . $pair1[0]);
								echo json_encode($response);exit;
							}
							$balance = TradeModel::fetchuserbalancebyId($userId, $tradeFromSym);
							if ($amount <= $balance) {
								if ($order_type != "market") {
									$updatefirstBalance = $balance - ($amount);
									$updatefirstBalance = number_format(trim($updatefirstBalance), 8, '.', '');
									$remarks = 'SellOrder placed for '. $amount . ' ' . $tradeFromSym . ' Old balance: '. $balance;
									$updatedata = array($tradeFromSym => $updatefirstBalance, 'remarks' => $remarks);
								} else {
									$updatedata = array();
								}
								$current_date = date('Y-m-d');
								$current_time = date('H:i:s');
								$datetime = date("Y-m-d H:i:s");
								$trdPrice = number_format($price, $digit_price, '.', '');
								$rand = self::randomstring();
								
								$data = array(
									'user_id' => $userId,
									'Amount' => number_format($amount, $digit_amount, '.', ''),
									'originalAmount' => number_format($amount, $digit_amount, '.', ''),
									'Price' => $trdPrice,
									'Total' => number_format($total, 8, '.', ''),
									'Fee' => number_format($fee_amt, 8, '.', ''),
									'firstCurrency' => $from_symbol,
									'secondCurrency' => $to_symbol,
									'Type' => "Sell",
									'orderDate' => $current_date,
									'orderTime' => $current_time,
									'datetime' => $datetime,
									'pair' => $pair,
									'status' => $order_status,
									'fee_per' => $feePer,
									'taker_fee_par' => $tfeePer,
									'trade_type_status' => 0,
									'ordertype' => $order_typeval,
									'inr_price' => 0,
									'stoporderprice' => number_format($price, $digit_price, '.', ''),
									'trigger_price' => number_format($limit, $digit_price, '.', ''),
									'liquidity_order' => 0,
									'pro_user' => $pro_user,
									'ledger_id' => $rand,
								);
								$create = DB::transaction(function () use ($userId, $updatedata, $data, $order_type) {
									if ($order_type != "market") {
										$updatequery = Wallet::where('user_id', $userId)->update($updatedata);
									}
									$create = CoinOrder::create($data);
									return $create;
								});
								if ($create) {
									if ($order_typeval == "limit") {
										$map = TradeModel::mapping($create->id, $lastPrice);			
									} else if ($order_typeval == "instant") {
										$map = TradeModel::marketMapping($create->id, $lastPrice);
									}
									$response = array('status' => '1', 'msg' => trans('app_lang.sell_order_placed_success'), 'order' => str_replace('.', '_', $trdPrice), 'trade' => $map);
								} else {
									$response = array('status' => '0', 'msg' => "Failed to create an order");
								}
							} else {
								$response = array('status' => '0', 'msg' => trans('app_lang.insufficint_balance'), 'amt' => $amount, 'fee' => $fee_amt);
							}
						} else {
							$response = array('status' => '0', 'msg' => trans('app_lang.enter_valid_amount_price'));
						}
					} else {
						$response = array('status' => '0', 'msg' => trans('app_lang.enter_valid_amount_price'));
					}
				} else {
					$response = array('status' => '0', 'msg' => trans('app_lang.enter_amount_price'));
				}
			} else {
				$response = array('status' => '0', 'msg' => 'Trade is under maintenance');
			}
		} else {
			$response = array('status' => '0', 'msg' => trans('app_lang.login_failure'));
		}
		echo json_encode($response);
	}

	public static function checkActiveOrder($first, $second, $type, $userid) {
		return CoinOrder::where('firstCurrency', $first)->where('secondCurrency', $second)->whereIn('status', ['active', 'partially'])->where('Type', $type)->where('user_id', '!=', $userid)->count();
	}

	public function cancelOrder(Request $request) {
		if (session('userId') != '') {
			$data = $request->all();
			$userId = session('userId');
			$dec = decrypText(strip_tags($data['tradeid']));
			$res = explode('-', $dec);
			$id = $res[0];
			$rand = $res[1];
			$date = self::datecheck($rand);
			if($date) {
				$result_data = array('status' => '0', 'msg' => 'Invalid Request');
			} else {
				$res = CoinOrder::where('id', $id)->where('ledger_id', $rand)->select('status', 'Type', 'Price', 'firstCurrency', 'secondCurrency')->first();
				if(!empty($res)) {
					$status = $res->status;
					$firstCurrency = $res->firstCurrency;
					$secondCurrency = $res->secondCurrency;
					if ($status == "cancelled" || $status == "filled") {
						$msg = trans('app_lang.already_cancelled');
						$result_data = array('status' => '0', 'msg' => $msg);
					} else {
						$result = DB::transaction(function () use ($id) {
							CoinOrder::where('id', $id)->whereIn('status', ['active', 'partially', 'stoporder'])->update(['status' => "cancelled", 'tradetime' => date('Y-m-d H:i:s')]);
							$res_order = TradeModel::remove_active_model($id);
							return $res_order;
						});
						$msg = "Order cancelled successfully";
						$result_data = array('status' => '1', 'msg' => $msg, 'ordertype' => strtolower($res->Type), 'order' => str_replace('.', '_', $res->Price), 'trade' => array());
					}
				} else {
					$result_data = array('status' => '0', 'msg' => 'Invalid Request');
				}
			}
		} else {
			$msg = trans('app_lang.login_failure');
			$result_data = array('status' => '2', 'msg' => $msg);
		}
		echo json_encode($result_data);
	}

	public static function datecheck($date) {
		if (preg_match("/\d{4}-[01]\d-[0-3]\d [0-2]\d:[0-5]\d:[0-5]\d/",$date)) {
			return true;
		} else {
			return false;
		}
	}

	public function cancelAllActiveOrder(Request $request) {
		if (session('userId') != '') {
			$userId = session('userId');
			$data = $request->all();
			$pair = $data['pair'];
			$res = explode('/', $pair);
			$from_symbol = $res[0];
			$to_symbol = $res[1];

			$result = CoinOrder::where('user_id', $userId)->where('firstCurrency', $from_symbol)->where('secondCurrency', $to_symbol)->whereIn('status', ['active', 'partially'])->select('id','status', 'Type', 'Price', 'firstCurrency', 'secondCurrency')->get();
			if(count($result) > 0) {
				foreach ($result as $res) {				
					$status = $res->status;
					$id = $res->id;
					$firstCurrency = $res->firstCurrency;
					$secondCurrency = $res->secondCurrency;
					if ($status == "cancelled" || $status == "filled") {
						$msg = trans('app_lang.already_cancelled');
						$result_data = array('status' => '0', 'msg' => $msg);
					} else {
						$result = DB::transaction(function () use ($id) {
							CoinOrder::where('id', $id)->whereIn('status', ['active', 'partially'])->update(['status' => "cancelled", 'tradetime' => date('Y-m-d H:i:s')]);
							$res_order = TradeModel::remove_active_model($id);
							return $res_order;
						});
						$msg = "Order cancelled successfully";
						$result_data = array('status' => '1', 'msg' => $msg, 'ordertype' => strtolower($res->Type), 'order' => str_replace('.', '_', $res->Price), 'trade' => array());
					}
				}
			} else {
				$msg = 'No active Orders';
				$result_data = array('status' => '0', 'msg' => $msg);
			}
		} else {
			$msg = trans('app_lang.login_failure');
			$result_data = array('status' => '2', 'msg' => $msg);
		}
		echo json_encode($result_data);
	}

	public function cancelAllStopOrder(Request $request) {
		if (session('userId') != '') {
			$userId = session('userId');
			$data = $request->all();
			$pair = $data['pair'];
			$res = explode('/', $pair);
			$from_symbol = $res[0];
			$to_symbol = $res[1];

			$result = CoinOrder::where('user_id', $userId)->where('firstCurrency', $from_symbol)->where('secondCurrency', $to_symbol)->whereIn('status', ['stoporder'])->select('id','status', 'Type', 'Price', 'firstCurrency', 'secondCurrency')->get();
			if(count($result) > 0) {
				foreach ($result as $res) {				
					$status = $res->status;
					$id = $res->id;
					$firstCurrency = $res->firstCurrency;
					$secondCurrency = $res->secondCurrency;
					if ($status == "cancelled" || $status == "filled") {
						$msg = trans('app_lang.already_cancelled');
						$result_data = array('status' => '0', 'msg' => $msg);
					} else {
						$result = DB::transaction(function () use ($id) {
							CoinOrder::where('id', $id)->whereIn('status', ['stoporder'])->update(['status' => "cancelled", 'tradetime' => date('Y-m-d H:i:s')]);
							$res_order = TradeModel::remove_active_model($id);
							return $res_order;
						});
						$msg = "Order cancelled successfully";
						$result_data = array('status' => '1', 'msg' => $msg, 'ordertype' => strtolower($res->Type), 'order' => str_replace('.', '_', $res->Price), 'trade' => array());
					}
				}
			} else {
				$msg = 'No active Orders';
				$result_data = array('status' => '2', 'msg' => $msg);
			}
		} else {
			$msg = trans('app_lang.login_failure');
			$result_data = array('status' => '2', 'msg' => $msg);
		}
		echo json_encode($result_data);
	}

	public static function coinPairs($type = '') {
		$userId = session('userId');
		$response = $coinImg = array();
		$upArrow = URL::to('public/frontend/img/tri1.png');
		$downArrow = URL::to('public/frontend/img/trig.png');
		$yesterday = date('Y-m-d H:i:s', strtotime("-1 day"));
		

		$pairDetails = DB::select("select c.image, c.currency_name,b.id, b.from_symbol, b.to_symbol, (sum(askPrice * filledAmount)) as volume, a.askPrice as yesterday_price, MAX(a.askPrice) as high, MIN(a.askPrice) as low,b.last_price, b.change FROM ".PREFIX.ORDERTEMP." a right join ".PREFIX.TRADEPAIRS." b on a.firstCurrency = b.from_symbol and a.secondCurrency = b.to_symbol and a.created_at >= '" . $yesterday . "' and a.cancel_id = 0 left join ".PREFIX.CURRENCY." c on c.currency_symbol=b.from_symbol where b.site_status = 1 GROUP BY b.id ORDER BY b.id ASC");
		foreach ($pairDetails as $pairs) {
			$fromSymbol = $pairs->from_symbol;
			$toSymbol = $pairs->to_symbol;
			$pairChange = $pairs->change;
			$forName = $fromSymbol . '/' . $toSymbol;
			$forUrl	 = $fromSymbol . '_' . $toSymbol;
			$coin = $curname = $pairs->currency_name;

			$getTrade = TradePairs::where('from_symbol', $fromSymbol)->where('to_symbol', $toSymbol)->where('site_status', 1)->select('fee_per', 'tfee_per', 'min_price','minamt', 'digit_amount', 'digit_price', 'last_price', 'low', 'high', 'base_volume', 'change')->first();


			$high = ($pairs->high == "" || $pairs->high == 0) ? $getTrade->high : $pairs->high;
			$low = ($pairs->low == "" || $pairs->low == 0) ? $getTrade->low : $pairs->low;
			$lastPrice = ($pairs->last_price == "" || $pairs->last_price == 0) ? $getTrade->last_price : $pairs->last_price;

			// $lastPrice = $pairs->last_price;
			$upArrow = '<i class="fa fa-arrow-up"></i>';
			$downArrow = '<i class="fa fa-arrow-down"></i>';

			$yesterPrice = $pairs->yesterday_price;
			if ($yesterPrice <= 0) {
				$changePer = $pairChange;
				$arrow = $upArrow;
				$sym = "+";
				$cls = "plus_value";
			} else {
				$changePrice = ($lastPrice - $yesterPrice) / $yesterPrice;
				$changePer = $changePrice * 100;
				$arrow = ($lastPrice >= $yesterPrice) ? $upArrow : $downArrow;
				$sym = ($lastPrice >= $yesterPrice) ? "+" : "";
				$cls = ($lastPrice >= $yesterPrice) ? "plus_value" : "minus_value";
			}
			$changePer = $arrow . " " . number_format($changePer, 2, '.', '') . '%';

			$lastPrice = rtrim(rtrim(sprintf('%.8F', $lastPrice), '0'), ".");
			// $volume = ($pairs->volume == "") ? "0.00" : number_format($pairs->volume, 4, '.', '');
			$volume = ($pairs->volume == "" || $pairs->volume == 0) ? $getTrade->base_volume : $pairs->volume;
			$coinImg[] = strtolower($toSymbol) . ".png";
			if (!in_array($fromSymbol, $coinImg)) {
				$coinImg[] = strtolower($fromSymbol) . ".png";
			}
			$favorites = dashboard_fav($userId);
			$fav = 0;
			if (in_array($forUrl, $favorites)) {
				$fav = 1;
			}
			$ifav = ($fav == 1) ? "fas fa-star" : "far fa-star";
			$response['scroll'][] = array('pair' => $forName,'pairs' => $forUrl,  'change' => $changePer, 'volume' => $volume, 'price' => $lastPrice, 'coin' => $coin);
			if($type != 3) {
				switch ($toSymbol) {
					case 'BTC':
					if (in_array($forUrl, $favorites)) {
						if($type == 1) {
							$response['FAV'][] = '<tr id="pair_'.$forUrl.'" class="pair-tab favpair_'.$forUrl.'"><td onclick="changepair(\'' . $forUrl . '\')"><i class="fas fa-star" id="'. $forUrl.'" onclick="favchk(\'' . $forUrl . '\',this)"></i> '.$forName.'</td><td onclick="changepair(\'' . $forUrl . '\')">'.$curname.'</td><td class="lastPrice_'.$forUrl.'">'.number_format($lastPrice, 8, '.', '').'</td><td onclick="changepair(\'' . $forUrl . '\')"><span class="px-1 font_14 changeCls"><span id="changePer1" class="'.$cls.' changePer_'.$forUrl.'">'.$changePer.'</span></span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="high24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($high, 8, '.', '').'</span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="low24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($low, 8, '.', '').'</span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="volume24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($volume, 8, '.', '').'</span></td></tr>';
						} else {
							$response['FAV'][] = '<tr id="pair_'.$forUrl.'" class="pair-tab favpair_'.$forUrl.'"><td onclick="changepair(\'' . $forUrl . '\')"><i class="fas fa-star" aria-hidden="true" id="'. $forUrl.'" onclick="favchk(\'' . $forUrl . '\',this)"></i> '.$forName.'</td><td onclick="changepair(\'' . $forUrl . '\')" class="text-right lastPrice_'.$forUrl.'">'.number_format($lastPrice, 8, '.', '').'</td><td onclick="changepair(\'' . $forUrl . '\')" class="text-right"><span class="px-1 font_14 changeCls"><span id="changePer1" class="'.$cls.' changePer_'.$forUrl.'">'.$changePer.'</span></span></td></tr>';
						}
						$fav = 1;
					}
					if($type == 1) {
						$response['BTC'][] = '<tr id="pair_'.$forUrl.'" class="pair-tab"><td onclick="changepair(\'' . $forUrl . '\')"><i class="'.$ifav.'" aria-hidden="true" id="'. $forUrl.'" onclick="favchk(\'' . $forUrl . '\',this)"></i> '.$forName.'</td><td onclick="changepair(\'' . $forUrl . '\')">'.$curname.'</td><td onclick="changepair(\'' . $forUrl . '\')" class="lastPrice_'.$forUrl.'">'.number_format($lastPrice, 8, '.', '').'</td><td onclick="changepair(\'' . $forUrl . '\')"><span class="px-1 font_14 changeCls"><span id="changePer1" class="'.$cls.' changePer_'.$forUrl.'">'.$changePer.'</span></span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="high24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($high, 8, '.', '').'</span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="low24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($low, 8, '.', '').'</span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="volume24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($volume, 8, '.', '').'</span></td></tr>';
					} else {
						$response['BTC'][] = '<tr id="pair_'.$forUrl.'" class="pair-tab"><td onclick="changepair(\'' . $forUrl . '\')"><i class="'.$ifav.'" aria-hidden="true" id="'. $forUrl.'" onclick="favchk(\'' . $forUrl . '\',this)"></i> '.$forName.'</td><td onclick="changepair(\'' . $forUrl . '\')" class="text-right lastPrice_'.$forUrl.'">'.number_format($lastPrice, 8, '.', '').'</td><td onclick="changepair(\'' . $forUrl . '\')" class="text-right"><span class="px-1 font_14 changeCls"><span id="changePer1" class="'.$cls.' changePer_'.$forUrl.'">'.$changePer.'</span></span></td></tr>';
					}
					break;
					case 'USDT':
					if (in_array($forUrl, $favorites)) {
						if($type == 1) { 
							$response['FAV'][] = '<tr id="pair_'.$forUrl.'" class="pair-tab favpair_'.$forUrl.'"><td onclick="changepair(\'' . $forUrl . '\')"><i class="fas fa-star" id="'. $forUrl.'" onclick="favchk(\'' . $forUrl . '\',this)"></i> '.$forName.'</td><td onclick="changepair(\'' . $forUrl . '\')">'.$curname.'</td><td  onclick="changepair(\'' . $forUrl . '\')" class="lastPrice_'.$forUrl.'">'.number_format($lastPrice, 8, '.', '').'</td><td onclick="changepair(\'' . $forUrl . '\')" class="text-right"><span class="px-1 font_14 changeCls"><span id="changePer1" class="'.$cls.' changePer_'.$forUrl.'">'.$changePer.'</span></span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="high24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($high, 8, '.', '').'</span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="low24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($low, 8, '.', '').'</span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="volume24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($volume, 8, '.', '').'</span></td></tr>';
						} else {
							$response['FAV'][] = '<tr id="pair_'.$forUrl.'" class="pair-tab favpair_'.$forUrl.'"><td onclick="changepair(\'' . $forUrl . '\')"><i class="fas fa-star" aria-hidden="true" id="'. $forUrl.'" onclick="favchk(\'' . $forUrl . '\',this)"></i> '.$forName.'</td><td onclick="changepair(\'' . $forUrl . '\')" class="text-right lastPrice_'.$forUrl.'">'.number_format($lastPrice, 8, '.', '').'</td><td onclick="changepair(\'' . $forUrl . '\')" class="text-right"><span class="px-1 font_14 changeCls"><span id="changePer1" class="'.$cls.' changePer_'.$forUrl.'">'.$changePer.'</span></span></td></tr>';
						}
						$fav = 1;
					}
					if($type == 1) {
						$response['USDT'][] = '<tr id="pair_'.$forUrl.'" class="pair-tab"><td onclick="changepair(\'' . $forUrl . '\')"><i class="'.$ifav.'" aria-hidden="true" id="'. $forUrl.'" onclick="favchk(\'' . $forUrl . '\',this)"></i> '.$forName.'</td><td onclick="changepair(\'' . $forUrl . '\')">'.$curname.'</td><td onclick="changepair(\'' . $forUrl . '\')" class="lastPrice_'.$forUrl.'">'.number_format($lastPrice, 8, '.', '').'</td><td onclick="changepair(\'' . $forUrl . '\')"><span class="px-1 font_14 changeCls"><span id="changePer1" class="'.$cls.' changePer_'.$forUrl.'">'.$changePer.'</span></span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="high24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($high, 8, '.', '').'</span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="low24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($low, 8, '.', '').'</span></td><td onclick="changepair(\'' . $forUrl . '\')"  class=""><span class="volume24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($volume, 8, '.', '').'</span></td></tr>';
					} else {
						$response['USDT'][] = '<tr id="pair_'.$forUrl.'" class="pair-tab"><td onclick="changepair(\'' . $forUrl . '\')"><i class="'.$ifav.'" aria-hidden="true" id="'. $forUrl.'" onclick="favchk(\'' . $forUrl . '\',this)"></i> '.$forName.'</td><td onclick="changepair(\'' . $forUrl . '\')" class="text-right lastPrice_'.$forUrl.'">'.number_format($lastPrice, 8, '.', '').'</td><td onclick="changepair(\'' . $forUrl . '\')" class="text-right"><span class="px-1 font_14 changeCls"><span id="changePer1" class="'.$cls.' changePer_'.$forUrl.'">'.$changePer.'</span></span></td></tr>';
					}
					break;
					case 'INR':
					if (in_array($forUrl, $favorites)) {
						if($type == 1) { 
							$response['FAV'][] = '<tr id="pair_'.$forUrl.'" class="pair-tab favpair_'.$forUrl.'"><td onclick="changepair(\'' . $forUrl . '\')"><i class="fas fa-star" id="'. $forUrl.'" onclick="favchk(\'' . $forUrl . '\',this)"></i> '.$forName.'</td><td onclick="changepair(\'' . $forUrl . '\')">'.$curname.'</td><td onclick="changepair(\'' . $forUrl . '\')" class="lastPrice_'.$forUrl.'">'.number_format($lastPrice, 2, '.', '').'</td><td onclick="changepair(\'' . $forUrl . '\')"><span class="px-1 font_14 changeCls"><span id="changePer1" class="'.$cls.' changePer_'.$forUrl.'">'.$changePer.'</span></span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="high24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($high, 2, '.', '').'</span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="low24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($low, 2, '.', '').'</span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="volume24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($volume, 2, '.', '').'</span></td></tr>';
						} else {
							$response['FAV'][] = '<tr id="pair_'.$forUrl.'" class="pair-tab favpair_'.$forUrl.'"><td onclick="changepair(\'' . $forUrl . '\')"><i class="fas fa-star" aria-hidden="true" id="'. $forUrl.'" onclick="favchk(\'' . $forUrl . '\',this)"></i> '.$forName.'</td><td onclick="changepair(\'' . $forUrl . '\')" class="text-right lastPrice_'.$forUrl.'">'.number_format($lastPrice, 2, '.', '').'</td><td onclick="changepair(\'' . $forUrl . '\')" class="text-right"><span class="px-1 font_14 changeCls"><span id="changePer1" class="'.$cls.' changePer_'.$forUrl.'">'.$changePer.'</span></span></td></tr>';
						}
						$fav = 1;
					}
					if($type == 1) {
						$response['INR'][] = '<tr id="pair_'.$forUrl.'" class="pair-tab"><td onclick="changepair(\'' . $forUrl . '\')"><i class="'.$ifav.'" aria-hidden="true" id="'. $forUrl.'" onclick="favchk(\'' . $forUrl . '\',this)"></i> '.$forName.'</td><td onclick="changepair(\'' . $forUrl . '\')">'.$curname.'</td><td onclick="changepair(\'' . $forUrl . '\')" class="lastPrice_'.$forUrl.'">'.number_format($lastPrice, 2, '.', '').'</td><td onclick="changepair(\'' . $forUrl . '\')"><span class="px-1 font_14 changeCls"><span id="changePer1" class="'.$cls.' changePer_'.$forUrl.'">'.$changePer.'</span></span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="high24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($high, 2, '.', '').'</span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="low24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($low, 2, '.', '').'</span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="volume24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($volume, 2, '.', '').'</span></td></tr>';
					} else {
						$response['INR'][] = '<tr id="pair_'.$forUrl.'" class="pair-tab"><td onclick="changepair(\'' . $forUrl . '\')"><i class="'.$ifav.'" aria-hidden="true" id="'. $forUrl.'"  onclick="favchk(\'' . $forUrl . '\',this)"></i> '.$forName.'</td><td onclick="changepair(\'' . $forUrl . '\')" class="text-right lastPrice_'.$forUrl.'">'.number_format($lastPrice, 2, '.', '').'</td><td onclick="changepair(\'' . $forUrl . '\')" class="text-right"><span class="px-1 font_14 changeCls"><span id="changePer1" class="'.$cls.' changePer_'.$forUrl.'">'.$changePer.'</span></span></td></tr>';
					}
					break;
					case 'ETH':
					if (in_array($forUrl, $favorites)) {
						if($type == 1) { 
							$response['FAV'][] = '<tr id="pair_'.$forUrl.'" class="pair-tab favpair_'.$forUrl.'"><td onclick="changepair(\'' . $forUrl . '\')"><i class="fas fa-star" id="'. $forUrl.'" onclick="favchk(\'' . $forUrl . '\',this)"></i> '.$forName.'</td><td onclick="changepair(\'' . $forUrl . '\')">'.$curname.'</td><td onclick="changepair(\'' . $forUrl . '\')" class="lastPrice_'.$forUrl.'">'.number_format($lastPrice, 2, '.', '').'</td><td onclick="changepair(\'' . $forUrl . '\')"><span class="px-1 font_14 changeCls"><span id="changePer1" class="'.$cls.' changePer_'.$forUrl.'">'.$changePer.'</span></span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="high24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($high, 2, '.', '').'</span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="low24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($low, 2, '.', '').'</span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="volume24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($volume, 2, '.', '').'</span></td></tr>';
						} else {
							$response['FAV'][] = '<tr id="pair_'.$forUrl.'" class="pair-tab favpair_'.$forUrl.'"><td onclick="changepair(\'' . $forUrl . '\')"><i class="fas fa-star" aria-hidden="true" id="'. $forUrl.'" onclick="favchk(\'' . $forUrl . '\',this)"></i> '.$forName.'</td><td onclick="changepair(\'' . $forUrl . '\')" class="text-right lastPrice_'.$forUrl.'">'.number_format($lastPrice, 2, '.', '').'</td><td onclick="changepair(\'' . $forUrl . '\')" class="text-right"><span class="px-1 font_14 changeCls"><span id="changePer1" class="'.$cls.' changePer_'.$forUrl.'">'.$changePer.'</span></span></td></tr>';
						}
						$fav = 1;
					}
					if($type == 1) {
						$response['ETH'][] = '<tr id="pair_'.$forUrl.'" class="pair-tab"><td onclick="changepair(\'' . $forUrl . '\')"><i class="'.$ifav.'" aria-hidden="true" id="'. $forUrl.'" onclick="favchk(\'' . $forUrl . '\',this)"></i> '.$forName.'</td><td onclick="changepair(\'' . $forUrl . '\')">'.$curname.'</td><td onclick="changepair(\'' . $forUrl . '\')" class="lastPrice_'.$forUrl.'">'.number_format($lastPrice, 2, '.', '').'</td><td onclick="changepair(\'' . $forUrl . '\')"><span class="px-1 font_14 changeCls"><span id="changePer1" class="'.$cls.' changePer_'.$forUrl.'">'.$changePer.'</span></span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="high24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($high, 2, '.', '').'</span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="low24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($low, 2, '.', '').'</span></td><td onclick="changepair(\'' . $forUrl . '\')" class=""><span class="volume24hr_'.$forUrl.' '.$cls.' clrCls_'.$forUrl.'">'.number_format($volume, 2, '.', '').'</span></td></tr>';
					} else {
						$response['ETH'][] = '<tr id="pair_'.$forUrl.'" class="pair-tab"><td onclick="changepair(\'' . $forUrl . '\')"><i class="'.$ifav.'" aria-hidden="true" id="'. $forUrl.'"  onclick="favchk(\'' . $forUrl . '\',this)"></i> '.$forName.'</td><td onclick="changepair(\'' . $forUrl . '\')" class="text-right lastPrice_'.$forUrl.'">'.number_format($lastPrice, 2, '.', '').'</td><td onclick="changepair(\'' . $forUrl . '\')" class="text-right"><span class="px-1 font_14 changeCls"><span id="changePer1" class="'.$cls.' changePer_'.$forUrl.'">'.$changePer.'</span></span></td></tr>';
					}
					break;
					default:
					break;
				}
			}
		}
		return $response;
	}

	function addfav(Request $request) {
		$data = $request->all();
		$pair = strip_tags($data['pair']);
		$userId = session('userId');
		$row = DB::table(PAIRFAV)->where('user_id', $userId)->where('pair', $pair)->select('status')->first();
		$count = count($row);
		if ($count == 0) {
			$data = array(
				'user_id' => $userId,
				'pair' => $pair,
				'status' => '1',
			);
			$createOrder = DB::table(PAIRFAV)->insert($data);
			echo '1';
		} else {
			$status = $row->status;
			$sta = ($status == 0) ? 1 : 0;
			DB::table(PAIRFAV)->where('user_id', $userId)->where('pair', $pair)->update(['status' => $sta]);
			echo '0';
		}
	}

	public function chartapi($coin, $type) {
		if ($type == "symbols") {
			echo '{"name":"' . $coin . '","exchange-traded":"'.SITENAME.'","exchange-listed":"'.SITENAME.'","timezone":"America/New_York","minmov":1,"minmov2":0,"pointvalue":1,"session":"0930-1630","has_intraday":true,"has_no_volume":false,"description":"' . $coin . '","type":"stock","supported_resolutions":["1","5","15","30","60","D","2D","3D","W","3W","M","6M"],"pricescale":100000000,"volume_precision":9,"ticker":"' . $coin . '"}';
			exit();
		}
		if ($type == "config") {
			echo '{"supports_search":true,"supports_group_request":false,"supports_marks":true,"supports_timescale_marks":true,"supports_time":true,"exchanges":[{"value":"","name":"All Exchanges","desc":""},{"value":"'.SITENAME.'","name":"'.SITENAME.'","desc":"'.SITENAME.'"},{"value":"NYSE","name":"NYSE","desc":"NYSE"},{"value":"NCM","name":"NCM","desc":"NCM"},{"value":"NGM","name":"NGM","desc":"NGM"}],"symbols_types":[{"name":"All types","value":""},{"name":"Stock","value":"stock"},{"name":"Index","value":"index"}],"supported_resolutions":["1","5","15","30","60","D","2D","3D","W","3W","M","6M"]}';
			exit();
		}
		if ($type == "history") {
			$from = $_GET['from'];
			$to = $_GET['to'];
			$pair = str_replace("_", "/", $coin);
			$res = self::chartData($pair, $from, $to);
			echo $res;
		}
	}

	public static function chartData($pair, $from, $to) {
		$res = explode('/', $pair);
		$from_symbol = $res[0];
		$to_symbol = $res[1];
		$coins = $from_symbol.$to_symbol;
		$order_book = array();
		$getSite = SiteSettings::where('id','1')->select('trade_api')->first();
		$trade_api = $getSite->trade_api;
		$inr_spread = Tradepairs::where('pair_name', $pair)->select('spread')->first()->spread;
		if($trade_api == 1) {
			$order_book = array('LTCBTC', 'ETHBTC', 'BCHBTC', 'DASHBTC', 'XRPBTC', 'BTCUSDT', 'LTCUSDT', 'BCHUSDT', 'DASHUSDT', 'ETHUSDT', 'XRPUSDT', 'LTCETH','DASHETH','XRPETH','BTCINR','LTCINR','ETHINR','XRPINR','BCHINR','DASHINR');
		} 
		if (in_array($coins, $order_book)) {
			$resolution = $_GET['resolution'];
			if (in_array($resolution, array('1', '5', '15', '30'))) {
				$seconds = $resolution * 60;
				$resolution = $resolution . 'm';
			} else if ($resolution == 60) {
				$seconds = $resolution * 60;
				$resolution = '1h';
			} else if ($resolution == 120) {
				$seconds = $resolution * 60;
				$resolution = '2h';
			} else if ($resolution == 240) {
				$seconds = $resolution * 60;
				$resolution = '4h';
			} else if ($resolution == 360) {
				$seconds = $resolution * 60;
				$resolution = '6h';
			} else if ($resolution == 720) {
				$seconds = $resolution * 60;
				$resolution = '12h';
			} else if ($resolution == '1D') {
				$seconds = 24 * 60 * 60;
				$resolution = '1d';
			} else if ($resolution == '1W') {
				$seconds = 7 * 24 * 60 * 60;
				$resolution = '1w';
			} else if ($resolution == '1M') {
				$seconds = 30 * 7 * 24 * 60 * 60;
				$resolution = '1M';
			} else if ($resolution == 'D') {
				$seconds = 24 * 60 * 60;
				$resolution = '1d';
			} else {
				$seconds = 60 * 60;
				$resolution = '1h';
			}
			$res = self::get_chart_data($from, $to, $resolution, $coins, $seconds, $to_symbol, $inr_spread);
			return $res;
		} else {
			$groupBy = (is_numeric($_GET['resolution'])) ? "unix_timestamp(ot.created_at) div " . ($_GET['resolution'] * 60) : 'DATE_FORMAT(ot.created_at, "%Y-%m-%d")'; 

			$query = DB::select('SELECT DATE_FORMAT(ot.created_at, "%Y-%m-%d %H:%i") as t_date, MIN(ot.askPrice) as low ,MAX(ot.askPrice) as high, SUM(ot.filledAmount * ot.askPrice) as volume, ot.askPrice as open, (SELECT nt.askPrice FROM '.PREFIX.ORDERTEMP.' as nt WHERE nt.id=MAX(ot.id)) as close FROM '.PREFIX.ORDERTEMP.' as ot WHERE ot.pair="' . $pair . '" AND unix_timestamp(ot.created_at) BETWEEN ' . $from . ' AND ' . $to . ' AND ot.cancel_id = 0 GROUP BY ' . $groupBy . ' ORDER BY ot.created_at ASC');


			if (!$query) {
				$out = array('s' => 'no_data');
				return json_encode($out, JSON_PRETTY_PRINT);
			}
			foreach ($query as $que) {
				$o[] = $que->open;
				$c[] = $que->close;
				$l[] = $que->low;
				$h[] = $que->high;
				$v[] = $que->volume;
				$t[] = strtotime($que->t_date);
			}
			$out = array('t' => $t, 'o' => $o, 'h' => $h, 'l' => $l, 'c' => $c, 'v' => $v, 's' => 'ok');
		}
		return json_encode($out, JSON_PRETTY_PRINT);
	}

	public static function get_chart_data($from, $to, $resolution, $coins, $seconds, $to_symbol, $inr_spread) {
		$length = round(abs($to - $from) / $seconds, 2);
		$limit = 1000;
		$iteration = array();
		$last_time = $from;
		for ($i = 1; $i <= $length; $i += $limit) {
			$upto = $last_time + ($limit * $seconds);
			$iteration[] = array('from' => $last_time, 'to' => $upto);
			$last_time = $upto;
		}
		if (empty($iteration)) {
			$iteration[] = array('from' => $from, 'to' => $to);
		}
		if($to_symbol == 'INR') {
			$inr_price = get_inr_price('USDT');
			$spread = $inr_spread;
		} else {
			$inr_price = 1;
			$spread = 0;
		}

		if($coins == 'BTCINR') {
			$coins = 'BTCUSDT';
		} elseif($coins == 'ETHINR') {
			$coins = 'ETHUSDT';
		} elseif($coins == 'LTCINR') {
			$coins = 'LTCUSDT';
		} elseif($coins == 'BCHINR') {
			$coins = 'BCHUSDT';
		} elseif($coins == 'DASHINR') {
			$coins = 'DASHUSDT';
		}elseif($coins == 'XRPINR') {
			$coins = 'XRPUSDT';
		}

		$all_chart_data = array();
		foreach ($iteration as $value) {
			$to = $value['to'] * 1000;
			$from = $value['from'] * 1000;
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, "https://www.binance.com/api/v1/klines?symbol=" . $coins . "&interval=" . $resolution . "&limit=1000&startTime=" . $from . "&endTime=" . $to);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_HEADER, 0);
			$que = curl_exec($ch);
			curl_close($ch);
			$que = json_decode($que, true);
			if (!isset($que['msg'])) {
				array_push($all_chart_data, $que);
			}
		}

		if (!empty($all_chart_data)) {
			if (count($all_chart_data) != 0) {
				foreach ($all_chart_data as $val) {
					foreach ($val as $value) {
						$o[] = ($value[1] * $inr_price) + $spread;
						$c[] = ($value[4] * $inr_price) + $spread;
						$l[] = ($value[3] * $inr_price) + $spread;
						$h[] = ($value[2] * $inr_price) + $spread;
						$v[] = ($value[5] * $inr_price) + $spread;
						$t[] = round($value[6] / 1000);
					}
				}
			}
			$out = array('t' => $t, 'o' => $o, 'h' => $h, 'l' => $l, 'c' => $c, 'v' => $v, 's' => 'ok');
			return json_encode($out, JSON_NUMERIC_CHECK);
		} else {
			$out = array('s' => 'no_data');
			return json_encode($out, JSON_PRETTY_PRINT);
		}
	}


	/*public static function chartData($pair, $from, $to) {
		$res = explode('/', $pair);
		$from_symbol = $res[0];
		$to_symbol = $res[1];
		$coins = $from_symbol.$to_symbol;
		$groupBy = (is_numeric($_GET['resolution'])) ? "unix_timestamp(ot.created_at) div " . ($_GET['resolution'] * 60) : 'DATE_FORMAT(ot.created_at, "%Y-%m-%d")';
		$query = DB::select('SELECT DATE_FORMAT(ot.created_at, "%Y-%m-%d %H:%i") as t_date, MIN(ot.askPrice) as low ,MAX(ot.askPrice) as high, SUM(ot.filledAmount * ot.askPrice) as volume, ot.askPrice as open, (SELECT nt.askPrice FROM '.PREFIX.ORDERTEMP.' as nt WHERE nt.id=MAX(ot.id)) as close FROM '.PREFIX.ORDERTEMP.' as ot WHERE ot.pair="' . $pair . '" AND unix_timestamp(ot.created_at) BETWEEN ' . $from . ' AND ' . $to . ' AND ot.cancel_id = 0 GROUP BY ' . $groupBy . ' ORDER BY ot.created_at ASC');

		if (!$query) {
			$out = array('s' => 'no_data');
			return json_encode($out, JSON_PRETTY_PRINT);
		}
		foreach ($query as $que) {
			$o[] = $que->open;
			$c[] = $que->close;
			$l[] = $que->low;
			$h[] = $que->high;
			$v[] = $que->volume;
			$t[] = strtotime($que->t_date);
		}
		$out = array('t' => $t, 'o' => $o, 'h' => $h, 'l' => $l, 'c' => $c, 'v' => $v, 's' => 'ok');
		return json_encode($out, JSON_PRETTY_PRINT);
	}*/

	public function check_user_login(Request $request) {
		$userId = session('userId');
		if ($userId == '') {
			echo 0;
		} else {
			echo 1;
		}
		exit;
	}

	public function future_trading() {
		return view('frontend.common.comingsoon');
	}	

	public static function randomstring() {
		$length = 10;
		$characters = '123456789';
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, strlen($characters) - 1)];
		}
		$res = CoinOrder::where(['ledger_id' => $randomString])->count();
		if ($res) {
			return randomstring();
		}

		return $randomString;
	}

	public function dummyCancelAllActiveOrder($userId = '') {
		$result = CoinOrder::where('user_id', $userId)->whereIn('status', ['partially'])->select('id','status', 'Type', 'Price','api_id', 'firstCurrency', 'secondCurrency')->get();
		if(count($result) > 0) {
			foreach ($result as $res) {				
				$status = $res->status;
				$id = $res->id;
				$api_id = $res->api_id;
				$firstCurrency = $res->firstCurrency;
				$secondCurrency = $res->secondCurrency;
				if ($status == "cancelled" || $status == "filled") {
					$msg = trans('app_lang.already_cancelled');
					$result_data = array('status' => '0', 'msg' => $msg);
				} else {
					$result = DB::transaction(function () use ($id) {
						CoinOrder::where('id', $id)->whereIn('status', ['partially'])->update(['status' => "cancelled", 'tradetime' => date('Y-m-d H:i:s')]);
						$res_order = TradeModel::remove_active_model($id);
						return $res_order;
					});
					$msg = "Order cancelled successfully";
					$result_data = array('status' => '1', 'msg' => $msg, 'ordertype' => strtolower($res->Type), 'order' => str_replace('.', '_', $res->Price), 'trade' => array());
				}
			}
		} else {
			$msg = 'No active Orders';
			$result_data = array('status' => '0', 'msg' => $msg);
		}
		echo json_encode($result_data);
	}	

	public function trunk1() {
		$depthbuy = file_get_contents(public_path('depth/depthjson/BCHBTC/depth_buy.json')); 
		$depthbuy = (string) $depthbuy;
		$depthbuy = str_replace('{', '[', $depthbuy);
		$depthbuy = str_replace('}', ']', $depthbuy);
		$depthbuy = str_replace('"', '', $depthbuy);
		print_r($depthbuy);die;
	}
	public function update_lastprice($pair_name, $last_price, $high, $low, $changeper,$volume) { 
		$res = explode('_', $pair_name); 
		$first_symbol = $from_symbol = $res[0];
		$from_symbol = ($from_symbol == 'USDC') ? 'USDT' : $from_symbol;
		$second_symbol = $to_symbol = $res[1];
		$pri = $last_price;
		/*if($to_symbol == 'USDT') { 
				TradePairs::where('trading_pair', $pair)->update(['last_price' => $last_price,'high' => $high,'low' => $low,'change' => $changeper,'base_volume' => $volume]); 
			 
		}  else if($to_symbol == 'BTC') {
			if($last_price > 0) { 
				TradePairs::where('trading_pair', $pair_name)->update(['last_price' => $price,'high' => $high,'low' => $low,'change' => $changeper,'base_volume' => $volume]);
				Currency::where('currency_symbol', $from_symbol)->update(['btc_value' => $last_price]);
			} 
		}*/
		if($last_price > 0) { 
			TradePairs::where('trading_pair', $pair_name)->update(['last_price' => $last_price,'high' => $high,'low' => $low,'change' => $changeper,'base_volume' => $volume]);
			Currency::where('currency_symbol', $from_symbol)->update(['btc_value' => $last_price]);
		} 
		echo $pair_name;
	}

}