<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Http\Controllers\CryptoAddress;
use App\Http\Controllers\Front\Trades;
use App\Model\AdminNotification;
use App\Model\BlockIP;
use App\Model\Cms;
use App\Model\ConsumerVerification;
use App\Model\CoinAddress;
use App\Model\Currency;
use App\Model\Deposit;
use App\Model\DepositSettings;
use App\Model\EmailTemplate;
use App\Model\ExchangePairs;
use App\Model\Faq;
use App\Model\CoinOrder;
use App\Model\Googleauthenticator;
use App\Model\LoginAttempt;
use App\Model\News;
use App\Model\SiteSettings;
use App\Model\Subscribe;
use App\Model\Support;
use App\Model\TradePairs;
use App\Model\Trade;
use App\Model\User;
use App\Model\OrderTemp;
use App\Model\UserActivity;
use App\Model\UserNotification;
use App\Model\Wallet;
use App\Model\Withdraw;
use App\Model\WithdrawSettings;
use App\Model\SiteWallet;
use App\Model\Helpcategory;
use Twilio\Rest\Client;

use App\Model\Wallet\ConnectEth; 
use Config;
use DateTime;
use DateInterval;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Mail;
use Redirect;
use Session;
use URL;
use Validator;

class Home extends Controller {
	public function __construct() {
	}

	public function index() {
		$pairs = coinPairs('INR');
		return view('frontend.common.index')->with('pairs', $pairs);
	}

	public function getMarkets() {
		$data = Input::all();
		$to_symbol = $data['currency'];
		$pairs = coinPairs($to_symbol);
		echo json_encode($pairs);exit;
	}

	public function register() {
		if (session('userId') != '') {
			return Redirect::to('dashboard');
		}
		if (isset($_GET['referid'])) {
			$referId = strip_tags($_GET['referid']);
			session(['refer_id' => $referId]);
		}
		return view('frontend.common.register');
	}

	public function register_show() {
		$data = Input::all();
		$emailid = strip_tags($data['register_email']);
		if (!empty($emailid)) {
			return Redirect::to('register?emailid=' . $emailid);
		} else {
			return Redirect::to('');
		}
	}

	public function checkusernameExists(Request $request) {
		$first = strip_tags($request['first_name']);
		$getCount = User::where('consumer_name', $first)->count();
		echo ($getCount > 0) ? "false" : "true";
	}

	public function checkMobileExists(Request $request) {
		$userId = session('userId');
		$phone = strip_tags($request['phone']);
		if ($userId) {
			$getCount = User::where('phone', $phone)->where('status', 'active')->where('id', '!=', $userId)->count();
		} else {
			$getCount = User::where('phone', $phone)->where('status', 'active')->count();
		}
		echo ($getCount > 0) ? "false" : "true";
	}

	public function checkEmailExists(Request $request) {
		$email = explode('@', strip_tags(strtolower($request['email'])));
		$first = encrypText($email[0]);
		$second = encrypText($email[1]);
		$getCount = User::where('user_mail_id', $first)->where('unusual_user_key', $second)->count();
		echo ($getCount > 0) ? "false" : "true";
	}

	public function signup() {
		$data = Input::all();
		unset($data['g-recaptcha-response']);
		unset($data['hiddenRecaptcha']);
		$Validation = Validator::make($data, User::$userSignupRule, User::$userSignupMsg);
		if ($Validation->fails()) {
			foreach ($Validation->messages()->getMessages() as $field_name => $message) {
				Session::flash('error', $message[0]);
				return Redirect::to('register');
			}
		}
		if ($data == array_filter($data)) {
			$email = explode('@', strip_tags(strtolower($data['email'])));
			$first = encrypText($email[0]);
			$second = encrypText($email[1]);
			$checkEmail = User::where('user_mail_id', $first)->where('unusual_user_key', $second)->count();
			if ($checkEmail > 0) {
				Session::flash('error', trans('app_lang.Email already exists'));
				return Redirect::to('/');
			}
			if (strip_tags($data['confirm_pwd']) != strip_tags($data['pwd'])) {
				Session::flash('error', trans('app_lang.Password doesnt match!'));
				return Redirect::to('register');
			}
			$userName = strip_tags($data['first_name']);
			$checkName = User::where('consumer_name', $userName)->count();
			if ($checkName > 0) {
				Session::flash('error', trans('app_lang.username_exists'));
				return Redirect::to('/');
			}
			$mobileNumber = strip_tags($data['phone']);
			$checkPhone = User::where('phone', $mobileNumber)->where('status', 'active')->count();
			if ($checkPhone > 0) {
				Session::flash('error', trans('app_lang.mobile_exists'));
				return Redirect::to('/');
			} else {
				$checkPhone1 = User::where('phone', $mobileNumber)->where('status', 'inactive')->count();
				if ($checkPhone1 > 0) {
					User::where('phone', $mobileNumber)->where('status', 'inactive')->update(['phone' => '']);
				}
			}
			$refer_id = isset($data['refer_id']) ? strip_tags($data['refer_id']) : '';
			$password = encrypText(strip_tags($data['confirm_pwd']));
			$expire = date('Y-m-d H:i:s', strtotime("+10 days"));
			$userinfo['consumer_name'] = $userName;
			$userinfo['user_mail_id'] = $first;
			$userinfo['unusual_user_key'] = $second;
			$userinfo['user_protect_key'] = $password;
			$userinfo['ip_address'] = Controller::getIpAddress();
			$userinfo['status'] = 'inactive';
			$userinfo['tfa_status'] = 'disable';
			$userinfo['phone'] = $mobileNumber;
			$userinfo['verified_status'] = 0;
			$userinfo['refer_id'] = User::randomReferNumber(6);
			$rand = time() . '12' . mt_rand(0, 999999);
			$userinfo['mailcode'] = $rand;
			$userinfo['referrer_id'] = $refer_id;
			$userinfo['expire_at'] = $expire;
			$userinfo['tickets'] = serialize(array($password));
			if (session('refer_id') != 0) {
				$referId = strip_tags(session('refer_id'));
				if (strlen($referId) > 6) {
					Session::flash('error', trans('app_lang.Please use valid referral code'));
					return Redirect::back();
				}
				$userinfo['referrer_id'] = $referId;
			}

			$result = User::create($userinfo);
			if ($result) {
				$userId = $result->id;
				ConsumerVerification::create(['user_id' => $userId]);
				$id = encrypText($result->id);
				$rid = encrypText($rand);
				$securl = URL::to('activateEmail/' . $id . '/' . $rid);

				$getEmail = EmailTemplate::where('id', 1)->first();
				$getSiteDetails = Controller::getEmailTemplateDetails();
				$info = array('###USER###' => '', '###LINK###' => $securl, '###registerverify_link###' => $securl);
				$replace = array_merge($getSiteDetails, $info);

				$emaildata = array('content' => strtr($getEmail->template, $replace));
				$toDetails['useremail'] = $data['email'];
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails['contact_mail_id'];
				$toDetails['name'] = $getSiteDetails['site_name'];

				$sendEmail = Controller::sendEmail($emaildata, $toDetails);

				if (count(Mail::failures()) > 0) {
					Session::flash('error', trans('app_lang.Email sending failed.'));
					return Redirect::to('register');
				} else {
					$msg1 = "New User signed up with ".SITENAME." with username " . $userinfo['consumer_name'] . " and email " . $data['email'];
					$insdata = array('admin_id' => 1, 'type' => 'New-user', 'message' => $msg1, 'status' => 'unread');
					AdminNotification::create($insdata);
					Session::flash('success', trans('app_lang.Registration Successful and Activation link has been sent to registered email address.'));
					return Redirect::to('login');
				}

			} else {
				Session::flash('error', trans('app_lang.Failed to create User'));
				return Redirect::to('register');
			}
		} else {
			Session::flash('error', trans('app_lang.Please fill all fields'));
			return Redirect::to('register');
		}
	}

	public function resendEmail() {
		$data = Input::all();
		if ($data) {
			$email = explode('@', strip_tags(strtolower($data['email'])));
			$first = encrypText($email[0]);
			$second = encrypText($email[1]);
			$user = User::where('user_mail_id', $first)->where('unusual_user_key', $second)->where('status', 'inactive')->select('id', 'user_mail_id', 'unusual_user_key', 'consumer_name')->first();
			if (count($user)) {
				$email_id = decrypText($user->user_mail_id) . "@" . decrypText($user->unusual_user_key);
				$username = $user->consumer_name;
				$rand = time() . '12' . mt_rand(0, 999999);
				$rid = encrypText($rand);
				$id = $user->id;
				$ids = encrypText($id);
				$expire = date('Y-m-d H:i:s', strtotime("+10 days"));
				User::where('id', $id)->update(['mailcode' => $rand, 'expire_at' => $expire]);
				$securl = URL::to('activateEmail/' . $ids . '/' . $rid);
				$getEmail = EmailTemplate::where('id', 1)->first();
				$getSiteDetails = Controller::getEmailTemplateDetails();
				$info = array('###USER###' => '', '###LINK###' => $securl, '###registerverify_link###' => $securl);
				$replace = array_merge($getSiteDetails, $info);
				$emaildata = array('content' => strtr($getEmail->template, $replace));
				$toDetails['useremail'] = $email_id;
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails['contact_mail_id'];
				$toDetails['name'] = $getSiteDetails['site_name'];
				$sendEmail = Controller::sendEmail($emaildata, $toDetails);
				if (count(Mail::failures()) > 0) {
					Session::flash('error', 'Mail Resend Failed!');
					return Redirect::to('register');
				} else {
					$msg1 = "New User signed up with ".SITENAME." with username " . $username . " and email " . $email_id;
					$insdata = array('admin_id' => 1, 'type' => 'New-user-ResendMail', 'message' => $msg1, 'status' => 'unread');
					AdminNotification::create($insdata);
					Session::flash('success', 'Mail Resend Successfully!');
					return Redirect::to('register');
				}
			} else {
				Session::flash('error', 'Not a proper activation mail');
				return Redirect::to('register');
			}
		}
	}

	public function checkInactiveEmail(Request $request) {
		$email = explode('@', strip_tags(strtolower($request['email'])));
		$first = encrypText($email[0]);
		$second = encrypText($email[1]);
		$getCount = User::where('user_mail_id', $first)->where('unusual_user_key', $second)->where('status', 'inactive')->count();
		echo ($getCount > 0) ? "true" : "false";
	}

	public function activateEmail($id, $rid) {
		if (session('userId') != '') {return Redirect::to('dashboard');}
		$userId = decrypText($id);
		$rid = decrypText($rid);
		$signup = User::select('user_mail_id', 'unusual_user_key', 'mailcode', 'consumer_name', 'expire_at')->where('id', $userId)->where('status', 'inactive')->first();
		if ($signup) {
			$expire = $signup->expire_at; 
			$now = date('Y-m-d H:i:s');
			if($now < $expire) {
				if ($signup->mailcode == $rid) {
					Wallet::create(['user_id' => $userId, 'created_at' => date('Y-m-d H:i:s'), 'remarks' => 'Wallet creation']);
					$update = User::where('id', $userId)->update(['status' => 'active']);
					if ($update) {
						Session::flash('success', 'Email activated Successfully.');
					} else {
						Session::flash('error', 'Email not activated.');
					}
				} else {
					Session::flash('error', 'Invalid Link');
				}
			} else {
				Session::flash('error', 'Link Expired');
			}
		} else {
			Session::flash('error', 'Email already activated.');
		}
		return Redirect::to('login');
	}

	public function login() {
		if (session('userId') != '') {
			return Redirect::to('dashboard');
		}
		return view('frontend.common.login');
	}

	public function userLogin(Request $request) {
		$data = $request->all();
		unset($data['g-recaptcha-response']);
		unset($data['hiddenRecaptcha']);
		$Validation = Validator::make($data, User::$userLoginRule);
		if ($Validation->fails()) {
			Session::flash('error', $Validation->messages());
			return Redirect::to('login');
		}
		if ($data == array_filter($data)) {
			$password = encrypText(strip_tags($data['password']));
			if (strpos($data['email'], '@') !== FALSE) {
				$userEmail = strip_tags(strtolower($data['email']));
				$email = explode('@', $userEmail);
				$first = encrypText($email[0]);
				$second = encrypText($email[1]);
				$login_result = User::where('user_mail_id', $first)->where('unusual_user_key', $second)->where('user_protect_key', $password)->first();
				if ($login_result) {
					$useremail_show = $userEmail;
					$login = $login_result;
				} else {
					$useremail_show = "";
					$login = User::where('consumer_name', $data['email'])->where('user_protect_key', $password)->first();
				}
			} else {
				$login = User::where('consumer_name', $data['email'])->where('user_protect_key', $password)->first();
				$useremail_show = "";
			}
			if ($login) {
				if ($login['status'] == "active") {
					if ($login['tfa_status'] == "enable") {
						$loginId = encrypText($login['id']);
						return Redirect::to("tfaVerification/" . $loginId);
					}
					if ($login['otp_status'] == 1) {
						$loginId = encrypText($login['id']);
						return Redirect::to("otpVerification/" . $loginId);
					}
					$ip = Controller::getIpAddress();
					$lastLogin = UserActivity::where('user_id', $login['id'])->where('activity', 'Login')->where('ip_address', $_SERVER['REMOTE_ADDR'])->first();

					if (!$lastLogin) {

						$notf_msg = trans('app_lang.noty_new_device_login');
						$notf_msg2 = trans('app_lang.hi');

						$msg1 = $notf_msg2 . " " . $login['consumer_name'] . ", " . $notf_msg;
						$insdata = array('user_id' => $login['id'], 'type' => 'New-Device-Login', 'message' => $msg1, 'status' => 'unread');
						UserNotification::create($insdata);
						if ($login['notify_new_device']) {
							$getEmail = EmailTemplate::where('id', 23)->first();
							$getSiteDetails = Controller::getEmailTemplateDetails();
							$info = array('###USER###' => $login['consumer_name']);
							$info['###IP###'] = Controller::getIpAddress();

							$replace = array_merge($getSiteDetails, $info);
							$emaildata = array('content' => strtr($getEmail->template, $replace));

							$toDetails['useremail'] = $useremail_show;
							$toDetails['subject'] = $getEmail->subject;
							$toDetails['from'] = $getSiteDetails['contact_mail_id'];
							$toDetails['name'] = $getSiteDetails['site_name'];
							$sendEmail = Controller::sendEmail($emaildata, $toDetails);

						}
					}

					$geolocation_show = Controller::getLocation();
					$result_show = explode('##', $geolocation_show);
					$cntry = ($result_show[0]) ? $result_show[0] : "";
					$activity['country'] = $cntry;
					$activity['city'] = ($result_show[1]) ? $result_show[1] : $cntry;
					$activity['os'] = Controller::getPlatform();
					$activity['ip_address'] = $ip;
					$activity['browser_name'] = Controller::getBrowser();
					$activity['activity'] = "Login";
					$activity['user_id'] = $login['id'];
					UserActivity::create($activity);
					$randnum = randomString(10);
					$token = $login['id'] . time() . rand(10, 100);
					User::where('id', $login['id'])->update(['session_id' => $randnum, 'token' => $token, 'login_status' => 1]);
					LoginAttempt::where('ip_address', $ip)->where('status', 'new')->update(['status' => 'old']);
					session(['userId' => $login['id'], 'userName' => $login['consumer_name'], 'Randnum' => $randnum]);
					if(session('type') == '') {
						Session::flash('success', trans('app_lang.You are successfully logged in.'));
						return Redirect::to('dashboard');
					} else {
						if(session('type') == 'rejectWithdraw') {
							$transid = session('wtransId');
							$user_id = session('wuserId');
							$code = session('wcode');
							return Redirect::to('rejectWithdraw/'.$transid.'/'.$user_id.'/'.$code);
						} else if(session('type') == 'confirmWithdraw') {
							$transid = session('wtransId');
							$user_id = session('wuserId');
							$code = session('wcode');
							return Redirect::to('confirmWithdraw/'.$transid.'/'.$user_id.'/'.$code);
						}
					}
				} elseif ($login['status'] == "inactive") {
					Session::flash('error', trans('app_lang.Please activate your account from registered email.'));
					return Redirect::to('login');
				} else {
					Session::flash('error', trans('app_lang.Your account deactivated by admin.'));
					return Redirect::to('login');
				}
			} else {
				$username = encrypText($data['email']);
				$password = encrypText($password);
				$ip = Controller::getIpAddress();
				$os = Controller::getPlatform();
				$browser = Controller::getBrowser();
				$getCount = LoginAttempt::where('ip_address', $ip)->where('status', 'new')->count();
				if ($getCount >= 5) {
					$getBlockCount = BlockIP::where('ip_addr', $ip)->where('status', 'active')->count();
					if ($getBlockCount == 0) {
						$updata = array('ip_addr' => $ip, 'status' => 'active');
						BlockIP::create($updata);
					} else {
						BlockIP::where('ip_addr', $ip)->update(['status' => 'active']);
					}
				}
				$createAttempt = array('ip_address' => $ip, 'os' => $os, 'browser' => $browser, 'status' => 'new', 'username' => $username, 'password' => $password);
				LoginAttempt::create($createAttempt);
				Session::flash('error', trans('app_lang.Invalid login credentials!'));
				return Redirect::to('login');
			}
		} else {
			Session::flash('error', 'Please fill all the fields');
			return Redirect::to('login');
		}
	}

	public function tfaVerification($id) {
		if (session('userId') != '') {
			return Redirect::to('dashboard');
		}
		$getContent = Cms::whereIn('id', [1, 2, 3, 4, 5, 6, 7, 10, 12, 13, 22, 8])->select('content', 'title')->get();
		$Sitesettings = Sitesettings::where('id', 1)->get();
		return view('frontend.common.tfa_login')->with('uid', $id)->with('content', $getContent)->with('Sitesettings', $Sitesettings);
	}

	public function sendLoginOtp(Request $request) {
		$data = $request->all();
		if (isset($data['token'])) {
			$userId = decrypText(strip_tags($data['token']));
			$user = User::where('id', $userId)->select('user_mail_id', 'unusual_user_key', 'consumer_name', 'phone')->first();
			if ($user) {
				$phone = ltrim($user->phone, '0');
				$first = decrypText($user->user_mail_id);
				$second = decrypText($user->unusual_user_key);
				$email = $first . "@" . $second;

				$key = TWOFACTORKEY;
				$otp = randomInteger(6);
				$url = "http://2factor.in/API/V1/" . $key . "/ADDON_SERVICES/SEND/TSMS";
				$data = ['From' => TWOFACTORSENDER, 'To' => $phone, 'TemplateName' => 'sms_otp', 'VAR1' => $otp];

				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
				$response = curl_exec($ch);
				curl_close($ch);

				$getEmail = EmailTemplate::where('id', 39)->first();
				$getSiteDetails = Controller::getEmailTemplateDetails();
				$info = array('###USER###' => $user->consumer_name, '###OTP###' => $otp);
				$replace = array_merge($getSiteDetails, $info);
				$emaildata = array('content' => strtr($getEmail->template, $replace));

				$toDetails['useremail'] = $email;
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails['contact_mail_id'];
				$toDetails['name'] = $getSiteDetails['site_name'];
				$sendEmail = Controller::sendOtpEmail($emaildata, $toDetails);

				$res = json_decode($response, true);
				if ((isset($res['Status']) && $res['Status'] == "Success") || $sendEmail) {
					User::where('id', $userId)->update(['otp_phone' => $phone, 'mobile_otp' => encrypText($otp)]);
					echo "success";
				} else {
					echo "Failed to send OTP";
				}
			} else {
				echo "Invalid User";
			}
		} else {
			echo "Invalid Request";
		}
	}

	public function otpVerification($id) {
		if (session('userId') != '') {
			return Redirect::to('dashboard');
		}
		$uid = decrypText($id);
		$user = User::where('id', $uid)->select('phone', 'consumer_name', 'user_mail_id', 'unusual_user_key')->first();
		$getContent = Cms::whereIn('id', [1, 2, 3, 4, 5, 6, 7, 10, 12, 13, 22, 8])->select('content', 'title')->get();
		$Sitesettings = Sitesettings::where('id', 1)->get();
		$ip = Controller::getIpAddress();
		if ($user) {
			$key = TWOFACTORKEY;
			$otp = randomInteger(6);
			$phone = ltrim($user->phone, '0');
			$first = decrypText($user->user_mail_id);
			$second = decrypText($user->unusual_user_key);
			$email = $first . "@" . $second;
			$url = "http://2factor.in/API/V1/" . $key . "/ADDON_SERVICES/SEND/TSMS";
			$data = ['From' => TWOFACTORSENDER, 'To' => $phone, 'TemplateName' => 'sms_otp', 'VAR1' => $otp];

			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
			$response = curl_exec($ch);
			curl_close($ch);

			$getEmail = EmailTemplate::where('id', 39)->first();
			$getSiteDetails = Controller::getEmailTemplateDetails();
			$info = array('###USER###' => $user->consumer_name, '###OTP###' => $otp);
			$replace = array_merge($getSiteDetails, $info);
			$emaildata = array('content' => strtr($getEmail->template, $replace));

			$toDetails['useremail'] = $email;
			$toDetails['subject'] = $getEmail->subject;
			$toDetails['from'] = $getSiteDetails['contact_mail_id'];
			$toDetails['name'] = $getSiteDetails['site_name'];
			$sendEmail = Controller::sendOtpEmail($emaildata, $toDetails);

			$res = json_decode($response, true);
			if ((isset($res['Status']) && $res['Status'] == "Success") || $sendEmail) {
				User::where('id', $uid)->update(['mobile_otp' => encrypText($otp)]);
			} else {
				$geoLoc = Controller::getLocation();
				$resGeo = explode('##', $geoLoc);
				$cntry = ($resGeo[0]) ? $resGeo[0] : "";
				$city = ($resGeo[1]) ? $resGeo[1] : $cntry;
				$activity = ['country' => $cntry, 'city' => $city, 'os' => Controller::getPlatform(), 'ip_address' => $ip, 'browser_name' => Controller::getBrowser(), 'activity' => 'Login', 'user_id' => $uid];
				UserActivity::create($activity);
				$randnum = randomString(10);
				$token = $uid . time() . rand(10, 100);
				User::where('id', $uid)->update(['session_id' => $randnum, 'token' => $token, 'login_status' => 1]);
				LoginAttempt::where('ip_address', $ip)->where('status', 'new')->update(['status' => 'old']);
				session(['userId' => $uid, 'userName' => $user->consumer_name, 'Randnum' => $randnum]);
				if(session('type') == '') {
					Session::flash('success', trans('app_lang.You are successfully logged in.'));
					return Redirect::to('dashboard');
				} else {
					if(session('type') == 'rejectWithdraw') {
						$transid = session('wtransId');
						$user_id = session('wuserId');
						$code = session('wcode');
						return Redirect::to('rejectWithdraw/'.$transid.'/'.$user_id.'/'.$code);
					} else if(session('type') == 'confirmWithdraw') {
						$transid = session('wtransId');
						$user_id = session('wuserId');
						$code = session('wcode');
						return Redirect::to('confirmWithdraw/'.$transid.'/'.$user_id.'/'.$code);
					}
				}
			}
			return view('frontend.common.otp_login')->with('uid', $id)->with('content', $getContent)->with('Sitesettings', $Sitesettings);
		} else {
			Session::flash('error', "Invalid User");
			return Redirect::to('login');
		}
	}

	public function otpLogin() {
		$data = Input::all();
		if ($data == array_filter($data)) {
			$userId = decrypText(strip_tags($data['uid']));
			$getUser = User::where('id', $userId)->select('id', 'mobile_otp', 'consumer_name', 'user_mail_id', 'unusual_user_key', 'notify_new_device')->first();
			$otp = strip_tags($data['otp']);
			$first = decrypText($getUser->user_mail_id);
			$second = decrypText($getUser->unusual_user_key);
			$useremail_show = $first . "@" . $second;

			if (encrypText($otp) == $getUser->mobile_otp) {
				$ip = Controller::getIpAddress();
				$geoLoc = Controller::getLocation();
				$resGeo = explode('##', $geoLoc);
				$cntry = ($resGeo[0]) ? $resGeo[0] : "";
				$city = ($resGeo[1]) ? $resGeo[1] : $cntry;
				$activity = ['country' => $cntry, 'city' => $city, 'os' => Controller::getPlatform(), 'ip_address' => $ip, 'browser_name' => Controller::getBrowser(), 'activity' => 'Login', 'user_id' => $userId];
				UserActivity::create($activity);
				$randnum = randomString(10);
				$token = $userId . time() . rand(10, 100);
				User::where('id', $userId)->update(['session_id' => $randnum, 'mobile_otp' => '', 'token' => $token, 'login_status' => 1]);
				LoginAttempt::where('ip_address', $ip)->where('status', 'new')->update(['status' => 'old']);
				session(['userId' => $userId, 'userName' => $getUser->consumer_name, 'Randnum' => $randnum]);
				$lastLogin = UserActivity::where('user_id', $userId)->where('activity', 'Login')->where('ip_address', $ip)->first();
				if (!$lastLogin) {
					$notf_msg = trans('app_lang.noty_new_device_login');
					$notf_msg2 = trans('app_lang.hi');
					$msg1 = $notf_msg2 . " " . $getUser->consumer_name . ", " . $notf_msg;
					if ($getUser->notify_new_device) {
						$getEmail = EmailTemplate::where('id', 23)->first();
						$getSiteDetails = Controller::getEmailTemplateDetails();
						$info = array('###USER###' => $getUser['consumer_name']);
						$info['###IP###'] = Controller::getIpAddress();

						$replace = array_merge($getSiteDetails, $info);
						$emaildata = array('content' => strtr($getEmail->template, $replace));

						$toDetails['useremail'] = $useremail_show;
						$toDetails['subject'] = $getEmail->subject;
						$toDetails['from'] = $getSiteDetails['contact_mail_id'];
						$toDetails['name'] = $getSiteDetails['site_name'];
						$sendEmail = Controller::sendEmail($emaildata, $toDetails);
					}
					$insdata = array('user_id' => $userId, 'type' => 'New-Device-Login', 'message' => $msg1, 'status' => 'unread');
					UserNotification::create($insdata);
				}

				if(session('type') == '') {
					Session::flash('success', trans('app_lang.You are successfully logged in.'));
					return Redirect::to('dashboard');
				} else {
					if(session('type') == 'rejectWithdraw') {
						$transid = session('wtransId');
						$user_id = session('wuserId');
						$code = session('wcode');
						return Redirect::to('rejectWithdraw/'.$transid.'/'.$user_id.'/'.$code);
					} else if(session('type') == 'confirmWithdraw') {
						$transid = session('wtransId');
						$user_id = session('wuserId');
						$code = session('wcode');
						return Redirect::to('confirmWithdraw/'.$transid.'/'.$user_id.'/'.$code);
					}
				}
			} else {
				Session::flash('error', 'Invalid authentication key.');
				return Redirect::to('login');
			}
		} else {
			Session::flash('error', 'Please try again.');
			return Redirect::back();
		}
	}

	public function tfaLogin() {
		$data = Input::all();
		if ($data == array_filter($data)) {
			$userId = decrypText(strip_tags($data['uid']));
			$tfaDetails = User::where('id', $userId)->select('id', 'secret', 'consumer_name', 'user_mail_id', 'unusual_user_key', 'notify_new_device')->first();
			$secret = $tfaDetails->secret;
			$code = $data['auth_key'];
			$first = decrypText($tfaDetails->user_mail_id);
			$second = decrypText($tfaDetails->unusual_user_key);
			$useremail_show = $first . "@" . $second;
			require_once app_path('Model/Googleauthenticator.php');
			$googleAuth = new Googleauthenticator();
			$verify = $googleAuth->verifyCode($secret, $code, $discrepancy = 2);
			if ($verify == 1) {
				$ip = Controller::getIpAddress();
				$geolocation_show = Controller::getLocation();
				$result_show = explode('##', $geolocation_show);
				if ($result_show[0]) {
					$activity['country'] = $result_show[0];
				}

				if ($result_show[1]) {
					$activity['city'] = $result_show[1];
				} else {
					$activity['city'] = $result_show[0];
				}

				$activity['ip_address'] = $ip;
				$activity['os'] = Controller::getPlatform();
				$activity['browser_name'] = Controller::getBrowser();
				$activity['activity'] = "Login";
				$activity['user_id'] = $tfaDetails->id;

				$randnum = randomString(10);
				$token = $userId  . time() . rand(10, 100);
				User::where('id', $userId)->update(['session_id' => $randnum, 'token' => $token, 'login_status' => 1]);

				session(['userId' => $tfaDetails->id, 'userName' => $tfaDetails->consumer_name, 'Randnum' => $randnum]);

				$lastLogin = UserActivity::where('user_id', $tfaDetails->id)->where('activity', 'Login')->where('ip_address', $_SERVER['REMOTE_ADDR'])->first();
				UserActivity::create($activity);

				if (!$lastLogin) {
					$getCount_notify = User::where('id', $userId)->select('consumer_name', 'id', 'user_mail_id', 'unusual_user_key', 'notify_tfa')->first();
					$notf_msg = trans('app_lang.noty_new_device_login');
					$notf_msg2 = trans('app_lang.hi');

					$msg1 = $notf_msg2 . " " . $getCount_notify['consumer_name'] . ", " . $notf_msg;
					if ($tfaDetails->notify_new_device) {
						$getEmail = EmailTemplate::where('id', 23)->first();
						$getSiteDetails = Controller::getEmailTemplateDetails();
						$info = array('###USER###' => $tfaDetails['consumer_name']);
						$info['###IP###'] = Controller::getIpAddress();

						$replace = array_merge($getSiteDetails, $info);
						$emaildata = array('content' => strtr($getEmail->template, $replace));

						$toDetails['useremail'] = $useremail_show;
						$toDetails['subject'] = $getEmail->subject;
						$toDetails['from'] = $getSiteDetails['contact_mail_id'];
						$toDetails['name'] = $getSiteDetails['site_name'];
						$sendEmail = Controller::sendEmail($emaildata, $toDetails);

					}
					$insdata = array('user_id' => $userId, 'type' => 'New-Device-Login', 'message' => $msg1, 'status' => 'unread');
					UserNotification::create($insdata);
				}

				if(session('type') == '') {
					Session::flash('success', trans('app_lang.You are successfully logged in.'));
					return Redirect::to('dashboard');
				} else {
					if(session('type') == 'rejectWithdraw') {
						$transid = session('wtransId');
						$user_id = session('wuserId');
						$code = session('wcode');
						return Redirect::to('rejectWithdraw/'.$transid.'/'.$user_id.'/'.$code);
					} else if(session('type') == 'confirmWithdraw') {
						$transid = session('wtransId');
						$user_id = session('wuserId');
						$code = session('wcode');
						return Redirect::to('confirmWithdraw/'.$transid.'/'.$user_id.'/'.$code);
					}
				}
			} else {
				Session::flash('error', 'Invalid authentication key.');
				return Redirect::back();
			}
		} else {
			Session::flash('error', 'Please try again.');
			return Redirect::back();
		}
	}

	public function logout() {
		if (session('userId') != '') {
			$ip = Controller::getIpAddress();
			$geolocation_show = Controller::getLocation();
			$result_show = explode('##', $geolocation_show);
			if ($result_show[0]) {
				$activity['country'] = $result_show[0];
			}

			if ($result_show[1]) {
				$activity['city'] = $result_show[1];
			} else {
				$activity['city'] = $result_show[0];
			}
			$activity['ip_address'] = $ip;
			$activity['browser_name'] = Controller::getBrowser();
			$activity['activity'] = "Logout";
			$activity['user_id'] = session('userId');
			$activity['os'] = Controller::getPlatform();
			UserActivity::create($activity);
			Session::flush();
			Session::flash('success', trans('app_lang.Logged out'));
			return Redirect::to('login');
		} else {
			Session::flash('error', trans('app_lang.Session Expired!'));
			return Redirect::to('login');
		}
	}

	public function forgotPassword() {
		if (session('userId') != '') {
			return Redirect::to('dashboard');
		}
		return view('frontend.common.forgotPassword');
	}

	public function sendForgotEmail(Request $request) {
		$data = $request->all();
		unset($data['g-recaptcha-response']);
		unset($data['hiddenRecaptcha']);
		$Validation = Validator::make($data, User::$forgotRule);
		if ($Validation->fails()) {
			$result_data = array('status' => '0', 'msg' => 'Email required');
			echo json_encode($result_data);exit;
		}
		if ($data == array_filter($data)) {
			if (strpos($data['email'], '@') !== FALSE) {
				$email = explode('@', strip_tags(strtolower($data['email'])));
				$first = encrypText($email[0]);
				$second = encrypText($email[1]);
				$login_result = User::where('user_mail_id', $first)->where('unusual_user_key', $second)->first();
				if ($login_result) {
					$useremail = $email[0] . "@" . $email[1]; 
					$getDetail = $login_result;
				} else {
					$getDetail = User::where('consumer_name', $data['email'])->first();
					$useremail = "";
				}
			} else {
				$getDetail = User::where('consumer_name', $data['email'])->first();
				if ($getDetail) {
					$first = decrypText($getDetail->user_mail_id);
					$second = decrypText($getDetail->unusual_user_key);
					$useremail = $first . "@" . $second;
				} else {
					$getDetail = "";
				}
			}

			if ($getDetail) {
				if ($getDetail->status == 'active') {
					$id = encrypText($getDetail->id);
					$generateCode = User::randomString(8);
					$randomCode = encrypText($generateCode);

					$randnum = randomString(10);
					$token = $getDetail->id . time() . rand(10, 100);

					$update = User::where('id', $getDetail->id)->update(['forgot_code' => $randomCode, 'forgot_status' => 'active', 'session_id' => $randnum, 'token' => $token]);
					$securl = URL::to('resetPassword/' . $id . '/' . $randomCode);

					$getEmail = EmailTemplate::where('id', 2)->first();
					$getSiteDetails = Controller::getEmailTemplateDetails();
					$info = array('###USER###' => $getDetail->consumer_name, '###LINK###' => $securl);
					$replace = array_merge($getSiteDetails, $info);
					$emaildata = array('content' => strtr($getEmail->template, $replace));
					$toDetails['useremail'] = $useremail;
					$toDetails['subject'] = $getEmail->subject;
					$toDetails['from'] = $getSiteDetails['contact_mail_id'];
					$toDetails['name'] = $getSiteDetails['site_name'];

					$sendEmail = Controller::sendEmail($emaildata, $toDetails);
					if (count(Mail::failures()) > 0) {
						$result_data = array('status' => '0', 'msg' => 'Please Try Again');
					} else {
						$result_data = array('status' => '1', 'msg' => 'Reset password Link has sent to your registered email');
					}
				} else {
					$result_data = array('status' => '0', 'msg' => "Before Activate Your account .You Not able reset Password");
				}
			} else {
				$result_data = array('status' => '0', 'msg' => 'Invalid Email ID or Username');
			}
		} else {
			$result_data = array('status' => '0', 'msg' => 'Please Field the All the Field!');
		}
		echo json_encode($result_data);
	}

	public function resetPassword($arg1, $arg2) {
		if (session('userId') != '') {
			return Redirect::to('login');
		} else {
			$userId = decrypText(strip_tags($arg1));
			$getDetail = User::select('id', 'forgot_status')
			->where('id', $userId)
			->where('forgot_code', strip_tags($arg2))
			->where('forgot_status', 'active')->first();
			if ($getDetail) {
				$data['fcode'] = strip_tags($arg2);
				$data['ucode'] = strip_tags($arg1);
				return view('frontend.common.resetPassword')->with('data', $data);
			} else {
				Session::flash('error', trans('app_lang.Invalid/Expired URL'));
				return Redirect::to('login');
			}
		}
	}

	public function updatePassword() {
		$data = Input::all();
		unset($data['g-recaptcha-response']);
		unset($data['hiddenRecaptcha']);
		$Validation = Validator::make($data, User::$resetRule);
		if ($Validation->fails()) {
			Session::flash('error', $Validation->messages());
			return Redirect::to('login');
		}
		if ($data == array_filter($data)) {
			$new_pwd = strip_tags($data['pwd']);
			$cnfirm_pwd = strip_tags($data['confirm_pwd']);
			$fcode = strip_tags($data['fcode']);
			$userId = decrypText(strip_tags($data['ucode']));
			if ($new_pwd == $cnfirm_pwd) {
				$getDetail = User::select('id', 'tickets')->where('id', $userId)->where('forgot_code', $data['fcode'])->where('forgot_status', 'active')->first();
				if ($getDetail) {
					$password = encrypText($cnfirm_pwd);
					$passtickets = $getDetail->tickets;

					$tickets = unserialize($passtickets);
					if (in_array($password, $tickets)) {
						Session::flash('error', 'You are not supposed to use last 5 passwords');
						return Redirect::back();
						exit;
					}

					if (is_array($tickets)) {
						array_unshift($tickets, $password);
						$old_passwords = array_slice($tickets, 0, 5);
					} else {
						$old_passwords = array($password);
					}

					$old_passwords = serialize($old_passwords);
					$randnum = randomString(10);
					$token = $userId . time() . rand(10, 100);
					$update = User::where('id', $userId)->update(['user_protect_key' => $password, 'forgot_code' => "", 'forgot_status' => 'deactive', 'tickets' => $old_passwords, 'session_id' => $randnum, 'token' => $token]);

					if ($update) {
						Session::flash('success', trans('app_lang.Password Reset Successfully'));
						return Redirect::to('login');
					} else {
						Session::flash('error', trans('app_lang.Please Try Again'));
					}
				} else {
					Session::flash('error', trans('app_lang.Invalid/Expired URL'));
				}
			} else {
				Session::flash('error', trans('app_lang.Password doesnt match!'));
			}
		} else {
			Session::flash('error', trans('app_lang.Fill All the Field'));
		}
		return Redirect::to('login');
	}

	//CMS
	public function aboutUs() {
		$getContent = Cms::where('id', 18)->select('content', 'title')->first();
		return view('frontend.common.cms')->with('content', $getContent);
	}

	public function termsConditions() {
		$getContent = Cms::where('id', 19)->select('content', 'title')->first();
		return view('frontend.common.cms')->with('content', $getContent);
	}
	public function privacy() {
		$getContent = Cms::where('id', 20)->select('content', 'title')->first();
		return view('frontend.common.cms')->with('content', $getContent);
	}

	public function announcement() {
		$getContent = Cms::where('id', 23)->select('content', 'title')->first();
		return view('frontend.common.cms')->with('content', $getContent);
	}
	public function risk() {
		$getContent = Cms::where('id', 24)->select('content', 'title')->first();
		return view('frontend.common.cms')->with('content', $getContent);
	}

	public function faq() {
		$getFaq = Faq::where('status', 'active')->orderBy('id', 'DESC')->get();
		return view('frontend.common.faq')->with('ques', $getFaq);
	}

	public function howitwork() {
		$getContent = Cms::where('id', 21)->first();
		return view('frontend.common.cms')->with('content', $getContent);
	}

	public function refund() {
		$getContent = Cms::where('id', 34)->select('content', 'title')->first();
		return view('frontend.common.cms')->with('content', $getContent);
	}

	public function news() {
		$getFaq = News::where('status', 'active')->orderBy('id', 'DESC')->get();
		$getContent = Cms::whereIn('id', [1, 2, 3, 4, 5, 6, 7, 10, 12, 13, 22, 8])->select('content', 'title')->get();
		$Sitesettings = Sitesettings::where('id', 1)->get();
		return view('frontend.common.news')->with('content', $getContent)->with('Sitesettings', $Sitesettings)->with('news_data', $getFaq);
	}

	public function news_details($id) {
		$id = decrypText($id);
		$news = News::where('status', 'active')->where('id', $id)->first();
		if ($news) {
			return view('frontend.common.news_details')->with('newsdata', $news);
		}
		Session::flash('error', "Invalid news");return Redirect::back();
	}

	public function contactUs() {
		$helpcategory = Helpcategory::all();
		$getContent = Cms::whereIn('id', [1, 2, 3, 4, 5, 6, 7, 10, 12, 13, 22, 11])->select('content', 'title')->get();
		$Sitesettings = Sitesettings::where('id', 1)->get();
		return view('frontend.common.contact')->with('content', $getContent)->with('Sitesettings', $Sitesettings)->with('category', $helpcategory);
	}

	public function contactSubmit() {
		$data = Input::all();
		unset($data['g-recaptcha-response']);
		unset($data['hiddenRecaptcha']);
		$validate = Validator::make($data, [
			'useremail' => "required|email|indisposable",
			'subject' => 'required|min:3',
			'message' => 'required',
			'username' => 'required',
		], [
			'useremail.required' => 'Enter email address',
			'useremail.email' => 'Enter valid email address',
			'username.required' => 'Enter Your Username',
			'message.required' => 'Enter Message',
			'subject.required' => 'Enter Subject',
			'subject.min' => 'Enter atleast 3 characters',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				Session::flash('error', $msg[0]);
				return Redirect::back();
			}
		}
		$name = trim(strip_tags($data['username']));
		$email = trim(strip_tags($data['useremail']));
		$subject = trim(strip_tags($data['subject']));
		$message = trim(strip_tags($data['message']));

		$prevoiusOrder = Support::where('email', $email)->select('created_at')->orderBy('id', 'desc')->first();
		if($prevoiusOrder) {
			$datetime1 = new DateTime();
			$datetime2 = new DateTime($prevoiusOrder->created_at);
			$interval = $datetime1->diff($datetime2);
			$hours = $interval->format('%h');
			if($hours < 1) {				
				Session::flash('error', 'Please try again later');
				return Redirect::back();
			}
		} 

		$subject = self::cleanStr($subject);
		$message = self::cleanStr($message);

		$userdata = array('user_name' => $name,
			'email' => $email,
			'subject' => $subject,
			'message' => $message,
			'status' => 'unread',
			'read_status' => 'unread',
		);

		$insertData = Support::create($userdata);

		if ($insertData) {
			$getEmail = EmailTemplate::where('id', 22)->first();
			$getSiteDetails = Controller::getEmailTemplateDetails();
			$info = array('###USER###' => $name, '###MESSAGE###' => $message, '###EMAIL###' => $email, '###SUBJECT###' => $subject);
			$replace = array_merge($getSiteDetails, $info);
			$emaildata = array('content' => strtr($getEmail->template, $replace));
			$toDetails['useremail'] = $email;
			$toDetails['subject'] = $getEmail->subject;
			$toDetails['from'] = $getSiteDetails['contact_mail_id'];
			$toDetails['name'] = $getSiteDetails['site_name'];
			$sendEmail = Controller::sendEmail($emaildata, $toDetails);

			$getEmail1 = EmailTemplate::where('id', 50)->first();
			$emaildata1 = array('content' => strtr($getEmail1->template, $replace));
			$toDetails1['useremail'] = $email;
			$toDetails1['subject'] = $getEmail1->subject;
			$toDetails1['from'] = $getSiteDetails['contact_mail_id'];
			$toDetails1['name'] = $getSiteDetails['site_name'];
			$sendEmail = Controller::sendEmail($emaildata1, $toDetails1);
			
			Session::flash('success', 'Contact request submitted successfully');
		} else {
			Session::flash('error', 'Please try again later');
		}
		return Redirect::back();
	}

	function cleanStr($string) {
		$string = preg_replace('/[^a-zA-Z0-9_ -]/s', '', $string);
		return $string;
	}

	public function checkNewsEmailExists(Request $request) {
		$email = strip_tags($request['email']);
		$getCount = Subscribe::where('email', $email)->where('status', '0')->count();
		echo ($getCount > 0) ? "false" : "true";
	}

	public function subscribeusers() {
		$data = Input::all();

		$validate = Validator::make($data, [
			'email' => "required|email|indisposable",
		], [
			'email.required' => 'Please Enter email address',
			'email.email' => 'Please Enter valid email address',
			'email.indisposable' => 'Disposable email addresses are not allowed',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				Session::flash('error', $msg[0]);
				return Redirect::back();
			}
		}

		if ($data == array_filter($data)) {
			$subscribe['email'] = strip_tags($data['email']);
			$checkEmail = Subscribe::where('email', $subscribe['email'])->where('status', '0')->count();
			if ($checkEmail > 0) {
				Session::flash('error', trans('app_lang.Email already subscribed newsletter.'));
				return Redirect::to('');
			} else {
				Subscribe::create($subscribe);
				Session::flash('success', trans('app_lang.subscribed_success'));
				return Redirect::to('');
			}
		} else {
			Session::flash('error', trans('app_lang.Failed to subscribe!'));
			return Redirect::to('');
		}
	}

	function setlanguage(Request $request) {
		$set_lang = $request['lan'];
		if ($set_lang != "") {
			$session_arr = array('language' => $set_lang);
			Session::put($session_arr);
		} else {
			$set_lang = "en";
			$session_arr = array('language' => $set_lang);
			Session::put($session_arr);
		}
		echo "ok";
	}

	public function site_under_maintenance() {
		$getSite = SiteSettings::where('id', 1)->select('site_status', 'maintenance_text')->first();
		if ($getSite->site_status == 0) {
			$content = $getSite->maintenance_text;
			return view('frontend.common.maintenance')->with('content', $content);
		} else {
			return Redirect::to('');
		}
	}

	public function no_js() {
		return view('frontend.common.no_js');
	}

	public function page404() {
		return view('frontend.common.page404');
	}

	public function market() {
		$pairs = TradePairs::select('trading_pair')->where('site_status', 1)->first();
		$pair = $pairs->trading_pair;
		return view('frontend.common.market')->with('tradePair', $pair);
	}

	public function fees() {
		$currency = Currency::where('status', '1')->where('c_status', '0')->select('currency_name','currency_symbol', 'confirmations')->get()->map(function ($curr) {return ['key' => $curr->currency_symbol, 'value' => $curr];})->pluck('value', 'key')->toArray();
		$deposit = DepositSettings::get()->map(function ($curr) {return ['key' => $curr->currency, 'value' => $curr];})->pluck('value', 'key')->toArray();

		$withdraw = WithdrawSettings::get()->map(function ($curr) {return ['key' => $curr->currency, 'value' => $curr];})->pluck('value', 'key')->toArray();

		$tradepair = TradePairs::where('site_status','1')->select('pair_name', 'from_symbol','minamt','fee_per','tfee_per','site_status', 'min_price')->get()->toArray();

		$buyexchangepairs = ExchangePairs::select('from_symbol', 'to_symbol','min_amt','max_amt' ,'trade_fee','status')->get()->map(function ($pair) {return ['key' => $pair->from_symbol . '/'. $pair->to_symbol, 'value' => $pair];})->pluck('value', 'key')->toArray();

		return view('frontend.common.fees')->with('currency',$currency)->with('deposit',$deposit)->with('withdraw',$withdraw)->with('tradepair',$tradepair)->with('buyexchangepairs',$buyexchangepairs);
	}

	public function ipblock() {
		$remote = !empty($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '127.0.0.1';
		$ip = !empty($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $remote;
		$checkIp = BlockIP::where('ip_addr', $ip)->where('status', 'active')->count();
		if ($checkIp > 0) {
			return view('frontend.common.ipblock');
		} else {
			return Redirect::to('/');
		}
	}

	public function test($currency = '') { 
		echo  decrypText('cjNYNDlvdjFwR3JYWnZ0YUpsakNDQT09');
		die;
			/*$getEmail = EmailTemplate::where('id', 1)->first();
			$getSiteDetails = Controller::getEmailTemplateDetails();
			$info = array('###USER###' => '');
			$replace = array_merge($getSiteDetails, $info);

			$emaildata = array('content' => strtr($getEmail->template, $replace));
			$toDetails['useremail'] = 'ramya.m@pulsehyip.com';
			$toDetails['subject'] = $getEmail->subject;
			$toDetails['from'] = $getSiteDetails['contact_mail_id'];
			$toDetails['name'] = $getSiteDetails['site_name'];

			echo $sendEmail = Controller::sendEmail($emaildata, $toDetails);*/

			/*if ($currency == "BTC" || $currency == "LTC" || $currency == "BCH" || $currency == "DASH") {
				$encrypt = encrypText($currency);
				$getFile = file_get_contents(app_path('Model/BfuiSGvKthvPYsVa/' . $encrypt . '.php'));
				$data = explode(" || ", $getFile);
				$connParams = array(
					'user' => decrypText($data[0]),
					'password' => decrypText($data[1]),
					'ip' => decrypText($data[2]),
					'port' => decrypText($data[3]),
				);
				$getAddr = connectJsonRpc($connParams, "getnewaddress", array());
				$address = $getAddr['result'];
				$response = array('status' => 1, 'address' => $address, 'tag' => "", 'hex' => "");
			} else if ($currency == "ETH") {
				$key = decrypText(Config::get('cookie.ETH.key'));
				$getAddr = ConnectEth::ethFunctions("createAddr", array('key' => $key));
				if ($getAddr['type'] == "success") {
					$response = array('status' => 1, 'address' => $getAddr['result'], 'tag' => "", 'hex' => "");
				} else {
					$response = array('status' => 0);
				}
			} else if ($currency == "XRP") {
				$address = self::randomstring($currency);
				$response = array('status' => 1, 'address' => '', 'tag' => $address, 'hex' => "");
			} else {
				$response = array('status' => 2, 'address' => $currency . "sampleaddress", 'tag' => "", 'hex' => "");
			}
			return $response;*/

		 
	}
}