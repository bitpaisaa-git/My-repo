<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Model\CoinOrder;
use App\Model\Currency;
use App\Model\EmailTemplate;
use App\Model\ExchangeModel; 
use App\Model\OrderTemp; 
use App\Model\TradeModel;
use App\Model\User;
use App\Model\Wallet;
use App\Model\Withdraw;

use Config;
use DB;
use Validator;

class Cron extends Controller {

	public function __construct() {
	}

	public function notify_email() {
		$emailgloballist = User::where('country', 'India')->select('user_mail_id', 'unusual_user_key', 'id','consumer_name')->where('email_status','0')->limit(1)->get();
		foreach ($emailgloballist as $emaillist) {
			$user_id = $emaillist->id;
			$usermail = decrypText($emaillist->user_mail_id) . '@' . decrypText($emaillist->unusual_user_key);
			$getEmail = EmailTemplate::where('id', 21)->first();
			$getSiteDetails = Controller::getEmailTemplateDetails();
			$info = array('###SUBJECT###' => 'News Letter');
			$replace = array_merge($getSiteDetails, $info);
			$emaildata = array('content' => strtr($getEmail->template, $replace));
			$toDetails['useremail'] = $usermail;
			$toDetails['subject'] = $getEmail->subject;
			$toDetails['from'] = $getSiteDetails['contact_mail_id'];
			$toDetails['name'] = $getSiteDetails['site_name'];
			$sendEmail = Controller::sendEmail($emaildata, $toDetails);	
			User::where('id', $user_id)->update(['email_status' => 1]);		
			echo $emaillist->consumer_name." -> Updated"."<br>";
		}
	}

	public function auto_cancel_withdraw() {
		$now = date('Y-m-d H:i:s');
		$withdrawDetails = Withdraw::where('expire_at', '<', $now)->where('status', 'in progress')->select('id', 'status', 'amount', 'currency', 'payment_method', 'user_id')->get();
		if (count($withdrawDetails) > 0) {
			foreach ($withdrawDetails as $value) {
				$id = $value->id;
				$user_id = $value->user_id;
				$status = $value->status;
				$amount = $value->amount;
				$currency = $value->currency;
				$balance = Wallet::where('user_id', $user_id)->select($currency)->first();
				$usrbal = $balance->$currency;
				$updatebalance = $usrbal + $amount;
				$updatebalance = number_format($updatebalance, 8, '.', '');
				$update = Withdraw::where('id', $id)->where('status', 'in progress')->update(['status' => 'cancelled', 'cancelled_by' => 'Timeout', 'approve_date' => $now, 'equiv_inr' => '0']);
				if ($update) {
					$remarks = 'Withdraw request auto cancelled for ' . $amount . ' ' . $currency . ' Old balance: ' . $usrbal;
					Wallet::where('user_id', $user_id)->update([$currency => $updatebalance, 'remarks' => $remarks]);
					$getUser = User::where('id', $user_id)->select('consumer_name', 'user_mail_id', 'unusual_user_key')->first();
					$usermail = decrypText($getUser->user_mail_id) . '@' . decrypText($getUser->unusual_user_key);

					$getEmail = EmailTemplate::where('id', 12)->first();
					$getSiteDetails = Controller::getEmailTemplateDetails();
					$info = array('###USER###' => $getUser->consumer_name, '###AMT###' => $amount . " " . $currency, '###REASON###' => 'Timeout Issue');
					$replace = array_merge($getSiteDetails, $info);
					$emaildata = array('content' => strtr($getEmail->template, $replace));
					$toDetails['useremail'] = $usermail;
					$toDetails['subject'] = $getEmail->subject;
					$toDetails['from'] = $getSiteDetails['contact_mail_id'];
					$toDetails['name'] = $getSiteDetails['site_name'];
					$sendEmail = Controller::sendEmail($emaildata, $toDetails);
				}
			}
			echo "Updated";exit;
		} else {
			echo "Not Updated";exit;
		}
	}

	public function filled_email_status() {
		$emailgloballist  = CoinOrder::where('admin_st','0')->where('status','filled')->where('email_status', '0')->select('id', 'user_id', 'Amount', 'Price', 'firstCurrency', 'secondCurrency')->limit(10)->get();
		foreach ($emailgloballist as $emaillist) {
			$user_id = $emaillist->user_id;
			$id = $emaillist->id;
			$userDetails = User::where('id', $user_id)->select('consumer_name', 'user_mail_id', 'unusual_user_key')->first();
			$consumer_name = $userDetails->consumer_name;
			$usermail = decrypText($userDetails->user_mail_id) . '@' . decrypText($userDetails->unusual_user_key);
			$amount = $emaillist->Amount;
			$orderTemp = OrderTemp::where('sellorderId',$id)->orWhere('buyorderId',$id)->select(DB::raw("SUM(askPrice) as sum, COUNT(askPrice) as count"))->first();
			$aver_price = $orderTemp->sum / $orderTemp->count;
			$price = number_format($aver_price, 8, '.', '');
			$firstCurrency = $emaillist->firstCurrency;
			$secondCurrency = $emaillist->secondCurrency;
			$getEmail = EmailTemplate::where('id', 44)->first();
			$getSiteDetails = Controller::getEmailTemplateDetails();
			$info = array('###USER###' => $consumer_name, '###AMOUNT###' => $amount, '###PRICE###' => $price, '###FIRSTCURRENCY###' => $firstCurrency, '###SECONDCURRENCY###' => $secondCurrency);
			$replace = array_merge($getSiteDetails, $info);
			$emaildata = array('content' => strtr($getEmail->template, $replace));
			$toDetails['useremail'] = $usermail;
			$toDetails['subject'] = $getEmail->subject;
			$toDetails['from'] = $getSiteDetails['contact_mail_id'];
			$toDetails['name'] = $getSiteDetails['site_name'];
			$sendEmail = Controller::sendEmail($emaildata, $toDetails);	
			CoinOrder::where('id', $id)->update(['email_status' => 1]);		
		}
	}
	
	public function trackOrdersList(){
		echo "BuyOrders<br>";
		echo $cur_date =  date('Y-m-d H:i:s');
		echo "<br>";
		echo $check_date =  date('Y-m-d H:i:s', strtotime('-12 minutes'));

		$buy_order_vol_query = "SELECT ".PREFIX.COINORDER.".firstCurrency,".PREFIX.COINORDER.".id,".PREFIX.COINORDER.".ordertype,".PREFIX.COINORDER.".updated_at,".PREFIX.COINORDER.".created_at,".PREFIX.COINORDER.".pair,".PREFIX.COINORDER.".status, ".PREFIX.COINORDER.".user_id, ".PREFIX.COINORDER.".Amount, SUM(".PREFIX.ORDERTEMP.".filledAmount) as sumdata FROM ".PREFIX.COINORDER." left join ".PREFIX.ORDERTEMP." on ".PREFIX.COINORDER.".id = ".PREFIX.ORDERTEMP.".buyorderId WHERE ".PREFIX.COINORDER.".status IN ('partially', 'filled', 'cancelled') and ".PREFIX.COINORDER.".is_overlap=0 and  ".PREFIX.COINORDER.".updated_at > '".$check_date."' and ".PREFIX.COINORDER.".updated_at < '".$cur_date."'  and ".PREFIX.COINORDER.".Type = 'Buy' GROUP by ".PREFIX.ORDERTEMP.".buyorderId having ".PREFIX.COINORDER.".Amount < sumdata limit 10";
		$buy_order_vol = DB::select(DB::raw($buy_order_vol_query));
		echo "<pre>"; print_r($buy_order_vol); echo "</pre>";

		if(count($buy_order_vol)){
			foreach ($buy_order_vol as $key => $value) {
				echo $user_id = $value->user_id;	
				$user = User::where('id', $user_id)->select('consumer_name', 'user_mail_id', 'unusual_user_key')->first();
				$first = decrypText($user->user_mail_id);
				$name = $user->consumer_name;
				$second = decrypText($user->unusual_user_key);
				$email = $first . "@" . $second;
				echo "<br>";
				echo $value->sumdata.' - '.$value->Amount;
				$disable = DB::transaction(function() use($user_id,$value)
				{
					User::where('id',$user_id)->update(array('auto_with'=>0,'auto_trade'=>0));
					return CoinOrder::where('id',$value->id)->update(array('is_overlap'=>1));
				});
				if($disable){
					echo "string";
					self::trackOrd($name,$email,$value,'Buy');
				}else{
					echo "--";
				}
			}
		}

		echo "SellOrders<br>";
		$sell_order_vol_query = "SELECT ".PREFIX.COINORDER.".firstCurrency,".PREFIX.COINORDER.".id,".PREFIX.COINORDER.".Amount,".PREFIX.COINORDER.".ordertype,".PREFIX.COINORDER.".updated_at,".PREFIX.COINORDER.".created_at,".PREFIX.COINORDER.".pair,".PREFIX.COINORDER.".status, ".PREFIX.COINORDER.".user_id, ".PREFIX.COINORDER.".Total, SUM(".PREFIX.ORDERTEMP.".filledAmount) as sumdata FROM ".PREFIX.COINORDER." left join ".PREFIX.ORDERTEMP." on ".PREFIX.COINORDER.".id = ".PREFIX.ORDERTEMP.".sellorderId WHERE ".PREFIX.COINORDER.".status IN ('partially', 'filled', 'cancelled') and  ".PREFIX.COINORDER.".is_overlap=0  and ".PREFIX.COINORDER.".updated_at > '".$check_date."' and ".PREFIX.COINORDER.".updated_at < '".$cur_date."'  and ".PREFIX.COINORDER.".Type = 'Sell' GROUP by ".PREFIX.ORDERTEMP.".sellorderId having ".PREFIX.COINORDER.".Amount < sumdata limit 10";
		$sell_order_vol = DB::select(DB::raw($sell_order_vol_query));
		echo "<pre>"; print_r($sell_order_vol); echo "</pre>";
		if(count($sell_order_vol)){
			foreach ($sell_order_vol as $key => $value) {
				echo $user_id = $value->user_id;	
				$user = User::where('id', $user_id)->select('consumer_name', 'user_mail_id', 'unusual_user_key')->first();
				$first = decrypText($user->user_mail_id);
				$name = $user->consumer_name;
				$second = decrypText($user->unusual_user_key);
				$email = $first . "@" . $second;
				echo "<br>";
				echo $value->sumdata.' - '.$value->Amount;
				$disable = DB::transaction(function() use($user_id,$value)
				{
					User::where('id',$user_id)->update(array('auto_with'=>0,'auto_trade'=>0));
					return CoinOrder::where('id',$value->id)->update(array('is_overlap'=>1));
				});
				if($disable){
					echo "string";
					self::trackOrd($name,$email,$value,'Sell');
				}else{
					echo "--";
				}
			}
		}
	}
	
	public function trackOrd($user,$email,$trade,$type){
		$getEmail = EmailTemplate::where('id', 51)->first();
		$getSiteDetails = Controller::getEmailTemplateDetails();
		$pair = $trade->pair;
		$red = $trade->sumdata-$trade->Amount;
		if($type == 'Buy'){
			$msg = 'User received excess amount in buy order.Reduction amount is '.$red.' '.$trade->firstCurrency;
		}else{
			$msg = 'User received excess amount in sell order.Reduction amount is '.$red.' '.$trade->firstCurrency;
		}
		$amt = 'Actual Amount '.$trade->Amount.' '.$trade->firstCurrency;
		$ex = 'Excess Amount '.$trade->sumdata.' '.$trade->firstCurrency;
		$info = array('###USER###' => $user, '###EMAIL###' => $email,'###AMOUNT###'=>$amt,'###EAMOUNT###'=>$ex,'###PAIR###'=>$pair,'###DATETIME###'=>date('Y-m-d H:i:s'),'###TYPE###'=>$type,'###MSG###'=>$msg);
		$replace = array_merge($getSiteDetails, $info);
		$emaildata = array('content' => strtr($getEmail->template, $replace));

		$toDetails['subject'] = $getEmail->subject;
		$toDetails['useremail'] = $toDetails['from'] = $getSiteDetails['contact_mail_id'];
		$toDetails['name'] = $getSiteDetails['site_name'];
		$cc =  $getSiteDetails['staff'];
		$bcc =  decrypText(EMAILID);
		$sendEmail = Controller::sendEmail($emaildata, $toDetails,$cc, $bcc);
	}

	public function auto_cancel_exchange() {
		$now = date('Y-m-d H:i:s');
		$exchange_cancel = DB::table(EXCHANGE . ' as e')->leftjoin(USERINFO . ' as u', 'u.id', '=', 'e.user_id')->where('e.expired_at', '<', $now)->where('e.status', 'pending')->select('e.id', 'e.user_id', 'e.amount', 'e.from_symbol', 'e.to_symbol', 'e.fees', 'e.total', 'u.user_mail_id', 'u.unusual_user_key', 'u.consumer_name')->get();
		foreach ($exchange_cancel as $exchange) {
			$id = $exchange->id;
			$user_id = $exchange->user_id;
			$from_symbol = $cur = $exchange->from_symbol;
			$amount = $exchange->amount;
			$email = decrypText($exchange->user_mail_id) . '@' . decrypText($exchange->unusual_user_key);

			$balance = Wallet::where('user_id', $user_id)->select($cur)->first()->$cur;
			$updateBal = $balance + $amount;
			$remarks = 'Exchange request cancelled for ' . $amount . ' ' . $cur . ' Old balance: ' . $balance;

			$updateData = array('status' => 'cancelled', 'reject_reason' => 'Timeout Issue', 'email_status' => '1');

			$result = DB::transaction(function () use ($id, $user_id, $updateData, $cur, $updateBal, $remarks) {
				ExchangeModel::where('id', $id)->update($updateData);
				Wallet::where('user_id', $user_id)->update([$cur => $updateBal, 'remarks' => $remarks]);
				return true;
			});

			if ($result) {
				$info = array('###AMOUNT###' => $exchange->amount . " " . $exchange->from_symbol, '###FEES###' => $exchange->fees . " " . $exchange->to_symbol, '###TOTAL###' => $exchange->total . " " . $exchange->to_symbol, '###REASON###' => 'Timeout Issue', '###NAME###' => $exchange->consumer_name);
				$getEmail = EmailTemplate::where('id', 37)->first();
				$getSiteDetails = Controller::getEmailTemplateDetails();
				$replace = array_merge($getSiteDetails, $info);
				$emaildata = array('content' => strtr($getEmail->template, $replace));
				$toDetails['useremail'] = $email;
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails['contact_mail_id'];
				$toDetails['name'] = $getSiteDetails['site_name'];
				$sendEmail = Controller::sendEmail($emaildata, $toDetails, '', '');
				echo "<br>Updated";
			}
		}
	} 

	public function binanceapi() {
		$getCurrency = Currency::where('status', '1')->where('currency_symbol', '!=', 'INR')->select('currency_symbol', 'inr_value')->get()->map(function ($curr) {return ['key' => $curr->currency_symbol, 'value' => $curr->inr_value];})->pluck('value', 'key')->toArray();
		$usdt = $getCurrency['USDT'];
		$inr = ($usdt > 0) ? $usdt : 1; 
		foreach ($getCurrency as $key => $value) {
			$currency_symbol = $key;
			if($currency_symbol == 'USDT') {
				$usdt_value = binanceTicker('BTC', 'USDT');
				$btc_value = 1 / $usdt_value;
				$btc_value = number_format($btc_value, 8, '.', '');
				$inr_value = $btc_value * $inr;
				Currency::where('currency_symbol', 'INR')->update(['btc_value' => $inr_value]);
			} else {
				$btc_value = binanceTicker($currency_symbol, 'BTC');
			}
			Currency::where('currency_symbol', $currency_symbol)->update(['btc_value' => $btc_value]);
		}
		echo "Updated";
	}	

	public function getCoingecko($toSym) {
		$tradePairs = Currency::select('id', 'currency_name', 'currency_symbol')->get();
		foreach ($tradePairs as $key => $value) {
			$id = $value->id;
			$currency_name = $value->currency_name;
			$currency_symbol = $value->currency_symbol;
			$price = coingecko($currency_name, $currency_symbol, $toSym);
			if($price > 0) {
				Currency::where('id', $id)->update([$toSym.'_value' => $price]);
			}
		}
		echo "Updated";
	}

	public function convert_inr() {
		$price = wazirx_conv('usdt', 'inr');
		if ($price > 0) {
			Currency::where('currency_symbol', 'USDT')->update(['inr_value' => $price]);
			echo $price;
		}	
	}

 
}