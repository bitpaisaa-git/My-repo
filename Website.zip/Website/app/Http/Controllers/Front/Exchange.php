<?php
namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Model\ConsumerVerification;
use App\Model\EmailTemplate;
use App\Model\ExchangeModel;
use App\Model\ExchangePairs;
use App\Model\SiteSettings;
use App\Model\TradePairs;
use App\Model\User;
use App\Model\Wallet;
use DateTime;
use DB;
use Illuminate\Support\Facades\Input;
use Redirect;
use Session;
use URL;
use Validator;

class Exchange extends Controller {

	public function __construct() {
		$this->Url = ADMINURL;
	}

	public function exchange() {
		$sta = 1;
		if ($sta) {
			$id = session('userId');
			$wcwr = encrypText($id);
			$tradepairs = TradePairs::where('site_status', '1')->select('id', 'from_symbol', 'to_symbol')->orderBy('id', 'asc')->first();
			$from_symbol = $tradepairs->from_symbol;
			$to_symbol = $tradepairs->to_symbol;
			$pairid = $tradepairs->id;

			$buyexchangepairs = ExchangePairs::where('status', '1')->orderBy('eid', 'asc')->get()->map(function ($curr) {return ['key' => $curr->from_symbol . $curr->to_symbol, 'value' => $curr];})->pluck('value', 'key')->toArray();

			$sellexchangepairs = ExchangePairs::where('status', '1')->where('from_symbol', 'ETH')->orderBy('eid', 'asc')->get()->map(function ($curr) {return ['key' => $curr->to_symbol, 'value' => $curr];})->pluck('value', 'key')->toArray();

			$exchangepair = ExchangePairs::where('status', '1')->orderBy('eid', 'asc')->get()->toArray();
			$results = self::arraygroupBy($exchangepair, 'to_symbol');
			if ($id) {
				$profile_update = ConsumerVerification::where('user_id', $id)->select('profile_update')->first()->profile_update;
				if ($profile_update == 1) {
					$user = User::where('id', $id)->first();
					$wallet = Wallet::where('user_id', $id)->first()->toArray();
					$type = 1;
					$cls = 'col-xl-9';
				} else {
					Session::flash('error', trans('app_lang.Please complete your profile details'));
					return Redirect::to('/settings?name=profile');
				}
			} else {
				$user = $wallet = '';
				$type = 0;
				$cls = 'col-xl-12';
			}

			$exchangetime = Sitesettings::where('id', 1)->select('exchangetime')->first()->exchangetime;
			$min = self::minutes($exchangetime);
			$minutes = number_format($min);
			return view('frontend.exchange.exchange', compact('user', 'pairid', 'buyexchangepairs', 'sellexchangepairs', 'wallet', 'type', 'cls', 'results', 'wcwr', 'minutes'));
		} else {
			return view('frontend.common.comingsoon');
		}
	}

	function minutes($time) {
		$time = explode(':', $time);
		return ($time[0] * 60) + ($time[1]) + ($time[2] / 60);
	}

	public function arraygroupBy($array, $key) {
		$return = array();
		foreach ($array as $val) {
			$return[$val[$key]][$val['from_symbol']] = $val;
		}
		return $return;
	}

	public function makeexchange() {
		$sta = 1;
		if ($sta) {
			$id = session('userId');
			if ($id) {
				$data = Input::all();
				$extype = $data['extype'];

				$trigger['trigger_id'] = encrypText($id);
				$trigger['type'] = $extype;
				trigger_socket($trigger, 'restrictwindow');

				$validate = Validator::make($data, [
					'from_currency' => "required",
					'to_currency' => "required",
					'amount' => "required|numeric",
				], [
					'from_currency.required' => 'Choose From Currency',
					'to_currency.required' => 'Choose To Currency',
					'amount.required' => 'Enter amount',
					'amount.numeric' => 'Enter valid amount',
				]);

				if ($validate->fails()) {
					foreach ($validate->messages()->getMessages() as $val => $msg) {
						$response = array('status' => '0', 'result' => $msg[0]);
						echo json_encode($response);exit;
					}
				}

				$prevoiusOrder = ExchangeModel::where('user_id', $id)->select('created_at')->orderBy('id', 'desc')->first();
				if ($prevoiusOrder) {
					$datetime1 = new DateTime();
					$datetime2 = new DateTime($prevoiusOrder->created_at);
					$interval = $datetime1->diff($datetime2);
					$mins = $interval->format('%i');
					if ($mins < 1) {
						$response = array('status' => '0', 'result' => 'Please try again after sometime');
						echo json_encode($response);exit;
					}
				}

				if ($extype == 'buy') {
					$bal_symbol = $from_symbol = $data['from_currency'];
					$to_symbol = $data['to_currency'];
				} else {
					$bal_symbol = $from_symbol = $data['from_currency'];
					$to_symbol = $data['to_currency'];
				}
				$amount = $data['amount'];

				if ($amount < 0) {
					$response = array('status' => '0', 'result' => 'Enter valid amount');
					echo json_encode($response);exit;
				}

				$digit = $digit1 = 8;
				$site = SiteSettings::where('id', 1)->select('exchangetime')->first();
				if ($extype == 'buy') {
					$exchangepair = ExchangePairs::where('from_symbol', $from_symbol)->where('to_symbol', $to_symbol)->select('last_price', 'trade_fee', 'from_symbol_id', 'to_symbol_id', 'min_amt', 'max_amt')->first();
				} else {
					$exchangepair = ExchangePairs::where('from_symbol', $to_symbol)->where('to_symbol', $from_symbol)->select('last_price', 'trade_fee', 'from_symbol_id', 'to_symbol_id', 'min_amt', 'max_amt')->first();
				}
				if ($extype == 'buy') {
					$last_price = $exchangepair->last_price;
					$last_price = number_format($last_price, $digit1, '.', '');
				} else {
					$price = $exchangepair->last_price;
					if ($price > 0) {
						$last_price = 1 / $price;
					} else {
						$last_price = 0;
					}
					$last_price = number_format($last_price, $digit1, '.', '');
				}

				if ($last_price == 0) {
					$response = array('status' => '0', 'result' => 'Please try again later');
					echo json_encode($response);exit;
				}

				$trade_fee = $exchangepair->trade_fee;
				$from_symbol_id = $exchangepair->from_symbol_id;
				$min_amt = $exchangepair->min_amt;
				$max_amt = $exchangepair->max_amt;
				$total = $amount * $last_price;

				$fees = $total * $trade_fee / 100;

				$final = $total - $fees;
				$balance = Wallet::where('user_id', $id)->select($bal_symbol)->first()->$bal_symbol;

				if ($amount > $balance) {
					$response = array('status' => '0', 'result' => 'You have insufficient balance');
					echo json_encode($response);exit;
				}

				if ($amount < $min_amt) {
					$response = array('status' => '0', 'result' => 'Enter amount more than minimum value');
					echo json_encode($response);exit;
				}

				if ($amount > $max_amt) {
					$response = array('status' => '0', 'result' => 'Enter amount less than maximum value');
					echo json_encode($response);exit;
				}

				$updateBal = $balance - $amount;
				$remarks = 'Exchange request placed for ' . $amount . ' ' . $bal_symbol . ' Old balance: ' . $balance;
				$update = Wallet::where('user_id', $id)->update([$bal_symbol => $updateBal, 'remarks' => $remarks]);
				if ($update) {
					$newdate = date('Y-m-d H:i:s');
					$etimestamp = strtotime($newdate . ' + ' . date('H', strtotime($site->exchangetime)) . ' hour ' . date('i', strtotime($site->exchangetime)) . ' minute ' . date('s', strtotime($site->exchangetime)) . ' second');
					$etime = date('Y-m-d H:i:s', $etimestamp);
					$create = array(
						'user_id' => $id,
						'from_symbol' => $from_symbol,
						'to_symbol' => $to_symbol,
						'type' => $extype,
						'amount' => $amount,
						'fees' => $fees,
						'fee_per' => $trade_fee,
						'total' => $final,
						'status' => 'pending',
						'ip_address' => $_SERVER['REMOTE_ADDR'],
						'created_at' => date('Y-m-d H:i:s'),
						'expired_at' => $etime,
					);
					$result = ExchangeModel::create($create);
					$lastid = encrypText($result->id);
					$link1 = url($this->Url . '/exchange_confim/' . $lastid);
					$link2 = url($this->Url . '/exchange_cancel/' . $lastid);
					$email = get_user_email($id);

					$amount = number_format($amount, $digit, '.', ',');
					$fees = number_format($fees, $digit1, '.', ',');
					$final = number_format($final, $digit1, '.', ',');

					$info = array('###AMOUNT###' => $amount . " " . $from_symbol, '###FEES###' => $fees . " " . $to_symbol, '###TOTAL###' => $final . " " . $to_symbol, '###LINK1###' => $link1, '###LINK2###' => $link2, '###NAME###' => getUserName($id), '###USER###' => $email);
					$getEmail = EmailTemplate::where('id', 35)->first();
					$getSiteDetails = Controller::getEmailTemplateDetails();
					$replace = array_merge($getSiteDetails, $info);
					$emaildata = array('content' => strtr($getEmail->template, $replace));
					$toDetails['useremail'] = $getSiteDetails['contact_mail_id'];
					$toDetails['subject'] = $getEmail->subject;
					$toDetails['from'] = $getSiteDetails['contact_mail_id'];
					$toDetails['name'] = $getSiteDetails['site_name'];
					$sendEmail = Controller::sendEmail($emaildata, $toDetails, '', '');
					if ($sendEmail) {
						$response = array('status' => '1', 'result' => 'Your order has been submited');
					} else {
						$response = array('status' => '0', 'result' => 'Please try again later');
					}
					echo json_encode($response);exit;
				} else {
					$response = array('status' => '0', 'result' => 'Please try again later');
					echo json_encode($response);exit;
				}
			} else {
				$response = array('status' => '0', 'result' => 'Please login to continue');
				echo json_encode($response);exit;
			}
		}
	}

	// fetch exchange history details
	public function exchange_history() {
		$id = session('userId');
		if ($id) {
			$totalrecords = intval(Input::get('totalrecords'));
			$draw = Input::get('draw');
			$start = Input::get('start');
			$length = Input::get('length');
			$sorttype = Input::get('order');
			$sort_col = $sorttype['0']['column'];
			$sort_type = $sorttype['0']['dir'];
			$search = Input::get('search');
			$from_date = Input::get('from');
			$to_date = Input::get('to');
			$search = $search['value'];

			if ($sort_col == '1') {
				$sort_col = 'created_at';
			} else if ($sort_col == '2') {
				$sort_col = 'type';
			} else if ($sort_col == '3') {
				$sort_col = 'from_symbol';
			} else if ($sort_col == '2') {
				$sort_col = 'to_symbol';
			} else if ($sort_col == '3') {
				$sort_col = 'amount';
			} else if ($sort_col == '4') {
				$sort_col = 'fees';
			} else if ($sort_col == '5') {
				$sort_col = 'total';
			} else if ($sort_col == '6') {
				$sort_col = 'status';
			} else {
				$sort_col = "id";
			}
			if ($sort_type == 'asc') {
				$sort_type = 'desc';
			} else {
				$sort_type = 'asc';
			}

			$data = $orders = array();
			$exchange = ExchangeModel::where('user_id', $id);
			if ($search != '') {
				$exchange = $exchange->where(function ($q) use ($search) {
					$q->where('from_symbol', 'like', '%' . $search . '%')->orWhere('to_symbol', 'like', '%' . $search . '%')->orWhere('amount', 'like', '%' . $search . '%')->orWhere('fees', 'like', '%' . $search . '%')->orWhere('total', 'like', '%' . $search . '%')->orWhere('status', 'like', '%' . $search . '%')->orWhere('type', 'like', '%' . $search . '%')->orWhere('created_at', 'like', '%' . $search . '%');}
				);
			}

			if ($from_date) {
				$exchange = $exchange->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
			}

			if ($to_date) {
				$exchange = $exchange->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
			}

			$exchange_count = $exchange->count();
			if ($exchange_count) {

				$exchange = $exchange->select('from_symbol', 'to_symbol', 'amount', 'fees', 'total', 'status', 'created_at', 'id', 'type', 'expired_at', 'user_id');

				$orders = $exchange->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
			}
			$data = array();
			$no = $start + 1;

			if ($exchange_count) {
				foreach ($orders as $r) {
					if ($r['status'] == 'confirmed') {
						$completed = URL::to('public/frontend/img/tick.png');
						$status = '<img src="' . $completed . '" alt="Completed" title="Completed">';
					} else if ($r['status'] == 'pending') {
						$pending = URL::to('public/frontend/img/pending.png');
						$status = '<img src="' . $pending . '" alt="Pending" title="Pending">';
					} else {
						$cancel = URL::to('public/frontend/img/cancel.png');
						$status = '<img src="' . $cancel . '" alt="Cancelled" title="Cancelled">';
					}

					$digits = $digits1 = 8;

					$amount = number_format($r['amount'], $digits, '.', '');
					$fees = number_format($r['fees'], $digits1, '.', '');
					$total = number_format($r['total'], $digits1, '.', '');

					array_push($data, array(
						$no,
						$r['created_at'],
						ucfirst($r['type']),
						$r['from_symbol'],
						$r['to_symbol'],
						$amount . " " . $r['from_symbol'],
						$fees . " " . $r['to_symbol'],
						$total . " " . $r['to_symbol'],
						$status,
					));
					$no++;
				}
				echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $exchange_count, 'recordsFiltered' => $exchange_count, 'data' => $data));
			} else {

				echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $exchange_count, 'recordsFiltered' => $exchange_count, 'data' => array()));
			}
		}
	}	
}