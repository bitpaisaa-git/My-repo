<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Http\Controllers\CryptoAddress;
use App\Model\AddCoins;
use App\Model\AdminBank;
use App\Model\AdminNotification;
use App\Model\Cms;
use App\Model\CoinAddress;
use App\Model\CoinOrder;
use App\Model\CoinProfit;
use App\Model\ConsumerVerification;
use App\Model\Country;
use App\Model\Currency;
use App\Model\Deposit;
use App\Model\PaypalDeposit;
use App\Model\DepositSettings;
use App\Model\EmailTemplate;
use App\Model\Faq;
use App\Model\Googleauthenticator;
use App\Model\Helpcategory;
use App\Model\HelpCentre;
use App\Model\OrderTemp;
use App\Model\PendingDeposit;
use App\Model\ReferralCommision;
use App\Model\SavedAddress;
use App\Model\SiteSettings;
use App\Model\Tokendetail;
use App\Model\TradeModel;
use App\Model\TradePairs;
// use App\Model\Transaction;
use App\Model\Transfer;
use App\Model\User;
use App\Model\UserActivity;
use App\Model\UserBank;
use App\Model\UserNotification;
use App\Model\Wallet;
use App\Model\Withdraw;
use App\Model\WithdrawSettings;
use App\Model\Paytm;

use PayPal\Auth\OAuthTokenCredential;
use PayPal\Api\Payer;
use PayPal\Api\Item;
use PayPal\Api\ItemList;
use PayPal\Api\RedirectUrls;
use PayPal\Api\Payment;
use PayPal\Api\Amount;
use PayPal\Api\Transaction;
use PayPal\Api\PaymentExecution;
use PayPal\Rest\ApiContext;

use Cloudinary;
use Config;
use DateTime;
use DB;
use Hash;
use PaytmWallet;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Mail;
use Redirect;
use Session;
use URL;
use Validator;
use Paypal;

class Users extends Controller {
	private $_api_context;
	public function __construct() {



		/*$this->_api_context = new ApiContext(new OAuthTokenCredential(
            
		    'AR_7vyh1wb6OktpWG0MegAgzikwQGFKpG4eLqYKJoKY6qOs-VPy8qJ0VDDZBetnwlE49exrSVvBTPRF-',
            'EMt5RJKOFr2WCYWvj1QY5LmT6kixkFQK4wmbhMJc6wNZZPjoOutiOS06ICYoSalG_OzMhMJLLoi7M_Uw'
        ));*/
        $this->_api_context = new ApiContext(new OAuthTokenCredential(
            
		    'AdDmtMGfcnloxIagUd0YJG6BLHnCEqxELt6S5ToX6NTY9GPCetk5w-YvsnZQlrGHCEWCvQ2-SxsHk7wW',
            'ELwMaW5gdQfc8eIdGy2qtIjwQ0-UiStxf4_8cBBZjVoYDQvSh1F0GNlHCplw_rb2dZpehhi2454yRKpg'
        ));

		$this->Url = ADMINURL;
		$getFile = file_get_contents(app_path('Model/cJfcgPqrCW.php'));
		$data = explode(" || ", $getFile);

		Cloudinary::config(array(
			"cloud_name" => decrypText($data[0]),
			"api_key" => decrypText($data[1]),
			"api_secret" => decrypText($data[2]),
		));
	}

	public function dashboard() {
		if (session('userId') != '') {
			$userId = session('userId');
			
			$transaction = $transactions = array();
			$getUserDetails = User::where('id', $userId)->first();
			$verification = ConsumerVerification::where('user_id', $userId)->first();
			$wallet = Wallet::where('user_id', $userId)->select("INR")->first();
			
			$first = decrypText($getUserDetails['user_mail_id']);
			$second = decrypText($getUserDetails['unusual_user_key']);
			$useremailid = $first . "@" . $second;

			$depositHistory = Deposit::where('user_id', $userId)->where('status', 'completed')->orderBy('id', 'desc')->select('currency', 'reference_no', 'transaction_number', 'amount', 'created_at', 'status')->limit(5)->get();
			if (!empty($depositHistory)) {
				foreach ($depositHistory as $value) {
					$completed = URL::to('public/frontend/img/tick.png');
					$status = '<img src="' . $completed . '" alt="Completed" title="Completed">';
					$digits = 8;
					$amount = number_format($value->amount, $digits, '.', '');
					array_push($transaction, array(
						'type' => 'Deposit',
						'currency' => $value->currency,
						'transaction_id' => $value->reference_no,
						'amount' => $amount,
						'status' => $status,
						'created_at' => date($value->created_at),
					));
				}
				self::array_sort_by_column($transaction, 'created_at');
			} else {
				array_push($transaction, array());
			}
			$WithdrawHistory = Withdraw::where('user_id', $userId)->where('status', 'completed')->orderBy('id', 'desc')->select('currency', 'reference_no', 'amount', 'created_at', 'status', 'transaction_number', 'fees_amt')->limit(5)->get();

			if (!empty($WithdrawHistory)) {
				foreach ($WithdrawHistory as $value) {
					$completed = URL::to('public/frontend/img/tick.png');
					$status = '<img src="' . $completed . '" alt="Completed" title="Completed">';
					$digits = 8;
					$amount = number_format($value->amount, $digits, '.', '');
					array_push($transaction, array(
						'type' => 'Withdraw',
						'currency' => $value->currency,
						'transaction_id' => $value->reference_no,
						'amount' => $amount,
						'status' => $status,
						'created_at' => date($value->created_at),
					));
				}
				self::array_sort_by_column($transaction, 'created_at');
			} else {
				array_push($transaction, array());
			}

			$inr_value = get_inr_price('USDT');
			$inr_price = 1 / $inr_value;
			$inr_price = number_format($inr_price, 2, '.', '');
			$usd_price = number_format($inr_value, 2, '.', '');

			$depsettings = DepositSettings::where("currency", 'USDT')->where('currency_type', 'Fiat')->select('fees', 'fee_type', 'status')->first();
			$withsettings = WithdrawSettings::where("currency", 'USDT')->where('currency_type', 'Fiat')->select('min', 'max', 'currency', 'fee', 'status', 'standard', 'fee_type')->first();

			$inrdepsettings = DepositSettings::where("currency", 'INR')->where('currency_type', 'Fiat')->select('fees', 'fee_type', 'status', 'instant', 'min', 'standard','paytm','cca','paypal')->first();
			$inrwithSettings = WithdrawSettings::where('currency', 'INR')->select('status', 'standard', 'instant', 'neft', 'fee', 'fee_type', 'min', 'max', 'neft_min', 'neft_max', 'instant_min', 'instant_max', 'withdraw_limit_day')->first();

			$transfersettings = DepositSettings::where("currency", 'INR')->where('currency_type', 'Transfer')->select('status', 'standard', 'instant', 'fees', 'fee_type', 'min', 'max')->first();
			
			$adminbank = AdminBank::where('status', 'active')->select('acc_name', 'bank_code', 'acc_number', 'bank_name')->orderBy('id', 'asc')->get()->map(function ($bank) {return ['key' => $bank->acc_number, 'value' => $bank];})->pluck('value', 'key')->toArray();

			$userbank = UserBank::where('user_id', $userId)->where('status', '1')->orderBy('id', 'asc')->select('id', 'acc_name', 'acc_number', 'bank_name', 'bank_branch', 'bank_swift', 'country', 'currency', 'status', 'beneId_status')->get()->map(function ($bank) {return ['key' => $bank->acc_number, 'value' => $bank];})->pluck('value', 'key')->toArray();
			$instantwith = count($userbank);

			$instantSta = 1;
			return view('frontend.users.dashboard')->with('profile', $getUserDetails)->with('email', $useremailid)->with('verification', $verification)->with('WithdrawHistory', $WithdrawHistory)->with('depositHistory', $depositHistory)->with('transactions', $transaction)->with('wallet', $wallet)->with('wcwr', encrypText($userId))->with('transfersettings', $transfersettings)->with('adminbank', $adminbank)->with('userbank', $userbank)->with('withsettings', $withsettings)->with('depsettings', $depsettings)->with('inrdepsettings', $inrdepsettings)->with('inrwithSettings', $inrwithSettings)->with('instantwith', $instantwith)->with('instantSta', $instantSta)->with('usd_price', $usd_price)->with('inr_price', $inr_price);
		}
		Session::flash('error', trans('app_lang.Please login to continue'));
		return Redirect::to('login');
	}

	public function userBalChart($type = '') {
		if (session('userId') != '') {
			$userId = session('userId');
			if ($type == 'spot') {
				$balance_val = Wallet::where('user_id', $userId)->first();
				$currency = Currency::where('status', '1')->select('currency_symbol')->get();
				foreach ($currency as $cur) {
					$inorders = userInorder($cur->currency_symbol, $userId);
					$result[$cur->currency_symbol] = $inorders;
				}
				$others = ($balance_val->LTC + $result['LTC']) + ($balance_val->USDT + $result['USDT']) + ($balance_val->BCH + $result['BCH']) + ($balance_val->DASH + $result['DASH']) + ($balance_val->XRP + $result['XRP']);

				$chart = array(array('users' => 'BTC', 'value' => ($balance_val->BTC + $result['BTC'])), array('users' => 'ETH', 'value' => ($balance_val->ETH + $result['ETH'])), array('users' => 'INR', 'value' => ($balance_val->INR + $result['INR'])), array('users' => 'Alt coins', 'value' => $others));
			} 
			echo json_encode($chart);
		} else {
			Session::flash('error', trans('app_lang.Please login to continue'));
			return Redirect::to('login');
		}
	}

	public function getPortfolio() {
		if (session('userId') != '') {
			$userId = session('userId');
			$data = Input::all();
			$value = $data['value'];
			$update = Wallet::where('user_id', $userId)->update(['value' => $value, 'remarks' => 'Value updated']);
			if ($update) {
				$ret = array('status' => '1', 'msg' => 'Updated Successfully');
				echo json_encode($ret);exit;
			}
		} else {
			$ret = array('status' => '0', 'msg' => trans('app_lang.Please login to continue'));
			echo json_encode($ret);exit;
		}
	}

	public function login_history() {
		$id = session('userId');
		$totalrecords = intval(Input::get('totalrecords'));
		$draw = Input::get('draw');
		$start = Input::get('start');
		$length = Input::get('length');
		$sorttype = Input::get('order');
		$sort_col = $sorttype['0']['column'];
		$sort_type = $sorttype['0']['dir'];
		$search = Input::get('search');
		$from_date = Input::get('from');
		$to_date = Input::get('to');
		$search = $search['value'];

		if ($sort_col == '1') {
			$sort_col = 'browser_name';
		} else if ($sort_col == '3') {
			$sort_col = 'created_at';
		} else if ($sort_col == '4') {
			$sort_col = 'os';
		} else if ($sort_col == '5') {
			$sort_col = 'ip_address';
		} else {
			$sort_col = "id";
		}
		if ($sort_type == 'asc') {
			$sort_type = 'desc';
		} else {
			$sort_type = 'asc';
		}

		$data = $orders = array();
		$login = UserActivity::where('user_id', $id);
		if ($search != '') {
			$login = $login->where(function ($q) use ($search) {
				$q->where('browser_name', 'like', '%' . $search . '%')->orWhere('created_at', 'like', '%' . $search . '%')->orWhere('os', 'like', '%' . $search . '%')->orWhere('ip_address', 'like', '%' . $search . '%');}
			);
		}

		if ($from_date) {
			$login = $login->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
		}

		if ($to_date) {
			$login = $login->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
		}

		$login_count = $login->count();
		if ($login_count) {

			$login = $login->select('browser_name', 'created_at', 'os', 'country', 'ip_address');

			$orders = $login->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
		}

		$data = array();
		$no = $start + 1;

		if ($login_count) {
			foreach ($orders as $r) {
				if ($r['browser_name'] == 'Firefox') {
					$firefox = URL::to('public/frontend/img/firefox.png');
					$img = '<img src="' . $firefox . '" alt="Firefox">';
				} else {
					$chrome = URL::to('public/frontend/img/chrome.png');
					$img = '<img src="' . $chrome . '">';
				}
				array_push($data, array(
					$img,
					$r['created_at'],
					ucfirst($r['os']),
					ucfirst($r['country']),
					$r['ip_address'],
				));
				$no++;
			}

			echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $login_count, 'recordsFiltered' => $login_count, 'data' => $data));
		} else {

			echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $login_count, 'recordsFiltered' => $login_count, 'data' => array()));
		}
	}

	public function transfer() {
		if (session('userId') != '') {
			$userId = session('userId');
			$data = Input::all();
			$validate = Validator::make($data, [
				'username' => "required",
				'amount' => "required|numeric",
				'with_pass' => "required",
			], [
				'username.required' => 'Enter username',
				'amount.required' => 'Enter amount',
				'amount.numeric' => 'Enter valid amount',
				'with_pass.required' => 'Enter withdraw password',
			]);

			if ($validate->fails()) {
				foreach ($validate->messages()->getMessages() as $val => $msg) {
					Session::flash('error', $msg[0]);
					return Redirect::to('dashboard');
				}
			}

			$trigger['trigger_id'] = encrypText($userId);
			$trigger['type'] = 'transfer';
			trigger_socket($trigger, 'restrictwindow');

			$currency = 'INR';
			$details = DepositSettings::where('currency', $currency)->where('currency_type', 'Transfer')->select('fees', 'fee_type', 'min', 'max', 'status')->first();

			if ($details->status == 1) {
				$prevoiusOrder = Transfer::where('user_id', $userId)->select('created_at')->orderBy('id', 'desc')->first();
				if ($prevoiusOrder) {
					$datetime1 = new DateTime();
					$datetime2 = new DateTime($prevoiusOrder->created_at);
					$interval = $datetime1->diff($datetime2);
					$mins = $interval->format('%i');
					if ($mins < 1) {
						Session::flash('error', 'Please try again after sometime');
						return Redirect::back();
					}
				}

				$amount = $data['amount'];
				$withPass = $userId . strip_tags($data['with_pass']);

				if ($amount < 0) {
					Session::flash('error', 'Enter valid amount');
					return Redirect::to('dashboard');
				}

				$fees = $fee_amt = $details->fees;
				$fee_type = $details->fee_type;
				$min = $details->min;
				$max = $details->max;
				if ($fee_type == 'amount') {
					if ($amount <= $fees) {
						Session::flash('error', 'Enter amount more than fees value');
						return Redirect::to('dashboard');
					}
				}
				$userdetails = User::where('id', $userId)->select('user_mail_id', 'unusual_user_key', 'consumer_name', 'auto_with', 'with_status', 'with_pass')->first();
				$now = date('Y-m-d H:i:s');
				$username = $data['username'];
				$details = User::where('consumer_name', $username)->select('id')->first();
				if ($userdetails->auto_with == 1) {
					if ($userdetails->with_status == 1) {
						if (!Hash::check($withPass, $userdetails->with_pass)) {
							Session::flash('error', 'Invalid withdraw password');
							return Redirect::back();
						}

						if ($details) {
							$user_id = $details->id;
							if ($user_id != $userId) {
								$senduserBal = Wallet::where('user_id', $userId)->select($currency)->first()->$currency;
								if ($senduserBal >= $amount) {
									if ($amount >= $min && $amount <= $max) {
										if ($fee_type == 'amount') {
											$total = $amount - $fees;
										} else {
											$fee_amt = ($amount * $fees) / 100;
											$total = $amount - $fee_amt;
										}
										if ($total >= '0.01') {
											$sendupBal = $senduserBal - $amount;
											$rand = randomString(34);
											$expire = date('Y-m-d H:i:s', strtotime("+10 days"));
											$create = array(
												'user_id' => $userId,
												'rec_user_id' => $user_id,
												'rec_user_name' => $username,
												'currency' => $currency,
												'amount' => $amount,
												'fee_per' => $fees,
												'fees' => $fee_amt,
												'fee_type' => $fee_type,
												'total' => $total,
												'code' => $rand,
												'status' => 'pending',
												'created_at' => $now,
												'expire_at' => $expire,
											);

											$remarks = 'Tranfer initiated for ' . $amount . ' INR'. ' Old balance: '. $senduserBal;
											$update = DB::transaction(function () use ($userId, $currency, $sendupBal, $create, $remarks) {
												Transfer::create($create);
												Wallet::where('user_id', $userId)->update([$currency => $sendupBal, 'remarks' => $remarks]);
												return true;
											});

											$info = array('###USER###' => $userdetails->consumer_name, '###OTP###' => $rand);
											$getEmail = EmailTemplate::where('id', 38)->first();
											$getSiteDetails = Controller::getEmailTemplateDetails();
											$replace = array_merge($getSiteDetails, $info);
											$emaildata = array('content' => strtr($getEmail->template, $replace));
											$toDetails['useremail'] = decrypText($userdetails->user_mail_id) . '@' . decrypText($userdetails->unusual_user_key);
											$toDetails['subject'] = $getEmail->subject;
											$toDetails['from'] = $getSiteDetails['contact_mail_id'];
											$toDetails['name'] = $getSiteDetails['site_name'];

											$sendEmail = Controller::sendEmail($emaildata, $toDetails);
											if ($update) {
												Session::flash('success', 'Transferred Successfully');
											} else {
												Session::flash('error', 'Please try again later');
											}
										} else {
											Session::flash('error', 'Your Transfer Amount should be Minimum 0.01');
										}
									} else {
										Session::flash('error', 'Enter the amount Minimum Amount ' . $min . ' ' . $currency . " - Maximum Amount " . $max . ' ' . $currency);
									}
								} else {
									Session::flash('error', 'Insufficient Balance');
								}
							} else {
								Session::flash('error', 'You should not enter your username');
							}
						} else {
							Session::flash('error', 'Username not exists');
						}
					} else {
						Session::flash('error', 'Please enable withdraw password');
						return Redirect::to('settings?type=security');
					}
				} else {
					Session::flash('error', 'Please try again later');
				}
			} else {
				Session::flash('error', 'Transfer Under Maintenance');
			}
			return Redirect::to('dashboard');
		} else {
			Session::flash('error', trans('app_lang.Please login to continue'));
			return Redirect::to('dashboard');
		}
	}

	public function transfer_redeem() {
		if (session('userId') != '') {
			$userId = session('userId');
			$data = Input::all();
			$validate = Validator::make($data, [
				'code' => "required",
				'with_pass' => "required",
			], [
				'code.required' => 'Enter code',
				'with_pass.required' => 'Enter withdraw password',
			]);

			if ($validate->fails()) {
				foreach ($validate->messages()->getMessages() as $val => $msg) {
					Session::flash('error', $msg[0]);
					return Redirect::to('dashboard');
				}
			}

			$currency = 'INR';
			$details = DepositSettings::where('currency', $currency)->where('currency_type', 'Transfer')->select('status')->first();

			if ($details->status == 1) {
				$userdetails = User::where('id', $userId)->select('with_status', 'with_pass')->first();
				$prevoiusOrder = Transfer::where('rec_user_id', $userId)->where('redemption_at', '!=', NULL)->select('redemption_at')->orderBy('id', 'desc')->first();
				if ($prevoiusOrder) {
					$datetime1 = new DateTime();
					$datetime2 = new DateTime($prevoiusOrder->redemption_at);
					$interval = $datetime1->diff($datetime2);
					$mins = $interval->format('%i');
					if ($mins < 1) {
						Session::flash('error', 'Please try again after sometime');
						return Redirect::back();
					}
				}

				$trigger['trigger_id'] = encrypText($userId);
				$trigger['type'] = 'redeem';
				trigger_socket($trigger, 'restrictwindow');

				$code = $data['code'];
				$withPass = $userId . strip_tags($data['with_pass']);
				$now = date('Y-m-d H:i:s');
				if ($userdetails->with_status == 1) {
					if (!Hash::check($withPass, $userdetails->with_pass)) {
						Session::flash('error', 'Invalid withdraw password');
						return Redirect::back();
					}

					if ($code) {
						$transfer = Transfer::where('code', $code)->where('status', 'pending')->first();
						if ($transfer) {
							$transId = $transfer->id;
							$user_id = $transfer->user_id;
							$rec_user_id = $transfer->rec_user_id;
							$expire = $transfer->expire_at;
							$original = $transfer->amount;
							if ($expire >= $now) {
								if ($user_id != $userId) {
									if ($userId == $rec_user_id) {
										$fees = $fee_amt = $transfer->fee_per;
										$fee_type = $transfer->fee_type;
										$amount = $transfer->total;
										if ($fee_type == 'amount') {
											$total = $amount - $fees;
										} else {
											$fee_amt = ($amount * $fees) / 100;
											$total = $amount - $fee_amt;
										}
										if ($total >= '0.01') {
											$recuserBal = Wallet::where('user_id', $rec_user_id)->select('INR')->first()->INR;
											$recupBal = $recuserBal + $total;
											$remarks = 'Redeem completed for ' . $total . ' INR'. ' Old balance: '. $recuserBal;

											$theftdata = array('user_id' => $user_id, 'theftAmount' => $fee_amt, 'theftCurrency' => $currency, 'type' => 'Transfer fees');
											$theftdata1 = array('user_id' => $rec_user_id, 'theftAmount' => $fee_amt, 'theftCurrency' => $currency, 'type' => 'Transfer fees');

											$update = DB::transaction(function () use ($rec_user_id, $recupBal, $transId, $now, $remarks, $theftdata, $theftdata1) {
												Wallet::where('user_id', $rec_user_id)->update(['INR' => $recupBal, 'remarks' => $remarks]);
												Transfer::where('id', $transId)->update(['status' => 'completed', 'redemption_at' => $now, 'code' => '']);
												CoinProfit::create($theftdata);
												CoinProfit::create($theftdata1);
												return true;
											});
											Session::flash('success', 'Redeemed Successfully');
										} else {
											Session::flash('error', 'Your Received Amount should be  Minimum 0.01');
										}
									} else {
										Session::flash('error', 'Invalid Code');
									}
								} else {
									Session::flash('error', 'You should not use this code for yourself');
								}
							} else {
								$senduserBal = Wallet::where('user_id', $user_id)->select('INR')->first()->INR;
								$sendupBal = $senduserBal + $original;
								$remarks = 'Transfer reverted for ' . $original . ' INR'. ' Old balance: '. $senduserBal;
								$update = DB::transaction(function () use ($user_id, $sendupBal, $code, $now, $remarks) {
									Wallet::where('user_id', $user_id)->update(['INR' => $sendupBal, 'remarks' => $remarks]);
									Transfer::where('code', $code)->update(['status' => 'cancelled', 'code' => '', 'redemption_at' => $now]);
									return true;
								});
								Session::flash('error', 'Code Expired');
							}
						} else {
							Session::flash('error', 'Transfer already processed');
						}
					} else {
						Session::flash('error', 'Please try again later');
					}
				} else {
					Session::flash('error', 'Please enable withdraw password');
					return Redirect::to('settings?type=security');
				}
			} else {
				Session::flash('error', 'Transfer Under Maintenance');
			}
			return Redirect::to('dashboard');
		} else {
			Session::flash('error', trans('app_lang.Please login to continue'));
			return Redirect::to('dashboard');
		}
	}

	public function checknameExists(Request $request) {
		$userId = session('userId');
		$first = strip_tags($request['first_name']);
		$getCount = User::where('consumer_name', $first)->where('id', '!=', $userId)->count();
		echo ($getCount > 0) ? "true" : "false";
	}

	public function checkcodeExists(Request $request) {
		$userId = session('userId');
		$code = strip_tags($request['code']);
		$getCount = Transfer::where('code', $code)->where('status', 'pending')->count();
		echo ($getCount > 0) ? "true" : "false";
	}

	public function usdt_bankdeposit() {
		if (session('userId') != '') {
			$userId = session('userId');
			$getDetail = User::select('verified_status', 'consumer_name', 'tfa_status', 'secret', 'user_mail_id', 'unusual_user_key')->where('id', $userId)->first();
			$ip = Controller::getIpAddress();
			if ($getDetail->verified_status == 3) {
				$data = Input::all();
				$validate = Validator::make($data, [
					'inrvalue' => "required|numeric",
					'usdvalue' => "required|numeric",
					'transaction_ref' => "required",
				], [
					'transaction_ref.required' => 'Please Enter transaction number',
					'inrvalue.required' => 'Please Enter amount',
					'inrvalue.numeric' => 'Please Enter valid amount',
					'usdvalue.required' => 'Please Enter amount',
					'usdvalue.numeric' => 'Please Enter valid amount',
				]);

				if ($validate->fails()) {
					foreach ($validate->messages()->getMessages() as $val => $msg) {
						Session::flash('error', $msg[0]);
						return Redirect::back();
					}
				}

				if (empty($data['transaction_ref'])) {
					Session::flash('error', trans('app_lang.enter_valid_transaction_number'));
					return Redirect::back();
				}

				$count = Deposit::where('reference_no', strip_tags($data['transaction_ref']))->where('status', '!=', 'cancelled')->count();
				if ($count > 0) {
					Session::flash('error', 'Reference number already exists');
					return Redirect::back();
				}

				$ip = Controller::getIpAddress();
				$amount = $data['usdvalue'];
				$currency = 'USDT';
				$getLimit = DepositSettings::where('currency', $currency)->where('currency_type', 'Fiat')->select('min', 'max', 'fees', 'fee_type')->first();
				$minLimit = $getLimit->min;
				$maxLimit = $getLimit->max;
				$fee_amt = $fees = $getLimit->fees;
				$fee_type = $getLimit->fee_type;
				if ($fee_type == 'amount') {
					if ($amount <= $fee_amt) {
						Session::flash('error', 'USDT amount must be more than fees amount');
						return Redirect::back();
					}
				}

				if ($amount >= $minLimit && $amount <= $maxLimit) {
					if ($fee_type == 'amount') {
						$total = $amount - $fees;
					} else {
						$fee_amt = ($amount * $fees) / 100;
						$total = $amount - $fee_amt;
					}

					$fee_amt = number_format($fee_amt, 2, '.', '');
					$fees = number_format($fees, 2, '.', '');
					$total = number_format($total, 2, '.', '');
					if ($total >= '0.01') {

						if ($_FILES['receipt_ref']['name'] != "") {
							$fileExtensions = ['jpeg', 'jpg', 'png'];
							$fileName = $_FILES['receipt_ref']['name'];
							$fileType = $_FILES['receipt_ref']['type'];
							$fileExtension = strtolower(explode('.', $fileName)[1]);
							$mimeImage = mime_content_type($_FILES["receipt_ref"]['tmp_name']);
							$explode = explode('/', $mimeImage);

							if (!in_array($fileExtension, $fileExtensions)) {
								Session::flash('error', trans('app_lang.Invalid file type.'));
								return Redirect::back();
							} else {
								if ($explode[0] != "image") {
									Session::flash('error', trans('app_lang.Invalid file type. Only image files are accepted.'));
									return Redirect::back();
								}
								$cloudUpload = \Cloudinary\Uploader::upload($_FILES["receipt_ref"]['tmp_name']);
								if ($cloudUpload) {
									$proof = $cloudUpload['secure_url'];
								} else {
									Session::flash('error', $cloudUpload["error"]["message"]);
									return Redirect::back();
								}
							}
						} else {
							Session::flash('error', trans('app_lang.You must submit reference proof.'));
							return Redirect::back();
						}

						$transaction_number = User::randomString(8);
						$adminBank = AdminBank::where('acc_number', strip_tags($data['admin_bank']))->select('acc_name', 'acc_number', 'bank_code', 'bank_name', 'bank_branch', 'bank_country')->first();
						$encodeBankDetails = json_encode($adminBank);

						$depositData = array('currency_type' => 'fiat', 'amount' => strip_tags($amount), 'reference_no' => strip_tags($data['transaction_ref']), 'payment_method' => 'bank', 'status' => 'pending', 'user_id' => $userId, 'ip_addr' => $ip, 'currency' => $currency, 'transaction_number' => $transaction_number, 'fees' => $fee_amt, 'fee_per' => $fees, 'total' => $total, 'proof' => $proof, 'dep_bank_info' => $encodeBankDetails);
						$createDeposit = Deposit::create($depositData);
						$txId = $createDeposit->id;
						if ($createDeposit) {
							$depositId = encrypText($txId);
							$uId = encrypText($userId);
							$securl1 = URL::to($this->Url . '/confirmDeposit/' . $depositId . '/' . $uId);
							$securl2 = URL::to($this->Url . '/rejectDeposit/' . $depositId . '/' . $uId);

							$getProfile = User::getProfile($userId);
							$getEmail = EmailTemplate::where('id', 5)->first();
							$getSiteDetails = Controller::getEmailTemplateDetails();
							$info = array('###USER###' => $getProfile['user']->consumer_name, '###LINK1###' => $securl1, '###LINK2###' => $securl2, '###AMT###' => $amount . ' ' . $currency, '###REF###' => $data['transaction_ref'], '###MESSAGE###' => '', '###ADDRESS###' => '', '###MESSAGE1###' => '');
							$replace = array_merge($getSiteDetails, $info);

							$emaildata = array('content' => strtr($getEmail->template, $replace));
							$toDetails['useremail'] = $getSiteDetails['contact_mail_id'];
							$toDetails['subject'] = $getEmail->subject;
							$toDetails['from'] = $getSiteDetails['contact_mail_id'];
							$toDetails['name'] = $getSiteDetails['site_name'];

							$sendEmail = Controller::sendEmail($emaildata, $toDetails);

							if (count(Mail::failures()) > 0) {
								Session::flash('error', trans('app_lang.Email sending failed.'));
							} else {
								$msg1 = $getProfile['user']->consumer_name . " have requested deposit for the amount of " . $amount . " " . $currency;
								$insdata = array('admin_id' => 1, 'type' => 'Deposit', 'message' => $msg1, 'status' => 'unread');
								AdminNotification::create($insdata);

								Session::flash('success', $amount . " " . $currency . ' Deposit request sent to admin');
							}
						} else {
							Session::flash('error', trans('app_lang.Failed to update.'));
						}
					} else {
						Session::flash('error', 'Your Received Amount Minimum 0.01 ' . $currency);
					}
					return Redirect::back();
				} else {
					Session::flash('error', "Please enter the amount Minimum Amount " . $minLimit . " " . $currency . " - Maximum Amount" . $maxLimit . " " . $currency);
					return Redirect::back();
				}
			} else {
				Session::flash('error', trans('app_lang.Your KYC documents not verified yet.'));
				return Redirect::to('settings?type=kyc');
			}
		} else {
			Session::flash('error', trans('app_lang.Please login to continue'));
			return Redirect::to('login');
		}
	}

	public function usdt_bankwithdraw() {
		if (session('userId') != '') {
			$userId = session('userId');
			$data = Input::all();
			$validate = Validator::make($data, [
				'inrvalue1' => "required|numeric",
				'usdvalue1' => "required|numeric",
				'usdt_with_pass' => "required",
			], [
				'inrvalue1.required' => 'Please Enter amount',
				'inrvalue1.numeric' => 'Please Enter valid amount',
				'usdvalue1.required' => 'Please Enter amount',
				'usdvalue1.numeric' => 'Please Enter valid amount',
				'usdt_with_pass.required' => 'Please Enter withdraw password',
			]);

			if ($validate->fails()) {
				foreach ($validate->messages()->getMessages() as $val => $msg) {
					Session::flash('error', $msg[0]);
					return Redirect::back();
				}
			}

			$currency = strip_tags($data['fiat_currency']);
			$user_acc = strip_tags($data['user_bank']);
			$withPass = $userId . strip_tags($data['usdt_with_pass']);

			$getDetail = User::select('id', 'consumer_name', 'tfa_status', 'secret', 'user_mail_id', 'unusual_user_key', 'verified_status', 'mobile_otp', 'otp_status', 'country', 'with_status', 'with_pass')->where('id', $userId)->with('wallet')->first();

			if ($getDetail->verified_status != 3) {
				Session::flash('error', trans('app_lang.Please verify your KYC documents.'));
				return Redirect::to('settings?type=kyc');
			}

			if ($getDetail->tfa_status == 'enable') {
				require_once app_path('Model/Googleauthenticator.php');
				$googleAuth = new Googleauthenticator();
				$verify = $googleAuth->verifyCode($getDetail->secret, $data['fiat_auth_key'], $discrepancy = 2);
				if ($verify == 1) {
					goto next;
				} else {
					Session::flash('error', trans('app_lang.Invalid authentication key.'));
					return Redirect::back();
				}
			} else {
				if ($getDetail->country == 'India') {
					$userotp = decrypText($getDetail->mobile_otp);
					if ($getDetail->otp_status == 1) {
						$otp = $data['fiat_otp'];
						if ($userotp == $otp) {
							goto next;
						} else {
							Session::flash('error', 'Invalid OTP');
							return Redirect::back();
						}
					} else {
						Session::flash('error', 'Enter OTP');
						return Redirect::back();
					}
				} else {
					Session::flash('error', trans('app_lang.enable_tfa'));
					return Redirect::to('settings?type=security');
				}
			}
			next:

			if ($getDetail->with_status == 0) {
				Session::flash('error', 'Please enable Withdraw Password');
				return Redirect::to('settings?type=security');
			}

			if (!Hash::check($withPass, $getDetail->with_pass)) {
				Session::flash('error', 'Invalid withdraw password');
				return Redirect::back();
			}

			$amount = strip_tags($data['usdvalue1']);

			$data['payment_method'] = "bank";

			$getBankDetails = UserBank::where('user_id', $userId)->where('acc_number', $user_acc)->select('acc_number', 'acc_name', 'bank_iban', 'bank_branch', 'bank_name', 'bank_swift', 'country', 'postal')->first();
			if (empty($getBankDetails)) {
				Session::flash('error', trans('app_lang.Please add bank for selected currency'));
				return Redirect::back();
			}
			$encodeBankDetails = json_encode($getBankDetails);

			$settings = WithdrawSettings::where('currency', strip_tags($currency))->where('currency_type', 'Fiat')->first();
			$userbalance = $getDetail->wallet;
			$balance = $userbalance->$currency;
			if ($balance >= $amount) {
				if ($amount >= $settings->min && $amount <= $settings->max) {
					$limitDay = $settings->withdraw_limit_day;
					$getWithdrawCount = Withdraw::where('user_id', $userId)->whereDate('created_at', date('Y-m-d'))->where('currency', $currency)->whereIn('status', ['completed', 'pending', 'in progress'])->sum('amount');
					if ($getWithdrawCount < $limitDay) {
						$fee_type = $settings->fee_type;
						$fee_per = $fee_amt = $settings->fee;
						if ($fee_type == 'amount') {
							if ($amount > $fee_amt) {
								$total = $amount - $fee_amt;
							} else {
								Session::flash('error', 'Enter amount more than fees amount');
								return Redirect::back();
							}
						} else {
							$fee_amt = ($amount * $fee_amt) / 100;
							$total = $amount - $fee_amt;
						}
						if ($total >= '0.01') {
							$ip = Controller::getIpAddress();
							$conv_price = get_inr_price('USDT');
							$insdata = array('amount' => $amount, 'currency' => $currency, 'payment_method' => $data['payment_method'], 'fee_per' => $fee_per, 'status' => 'in progress', 'user_id' => $userId, 'ip_addr' => $ip, 'conv_price' => $conv_price);
							$transaction_number = User::randomString(8);
							$insdata['transaction_number'] = $transaction_number;

							$insdata['withdraw_bank_info'] = $encodeBankDetails;
							$insdata['fees_amt'] = number_format($fee_amt, 2, '.', '');
							$insdata['total'] = number_format($total, 2, '.', '');
							$rand = time() . '12' . mt_rand(0, 999999);
							$insdata['rcode'] = $rand;
							$insdata['expire_at'] = date('Y-m-d H:i:s', strtotime("+10 minutes"));
							$createWithdraw = Withdraw::create($insdata);
							$txId = $createWithdraw->id;

							$updatebalance = $balance - $amount;
							$updatebalance = number_format($updatebalance, 2, '.', '');

							$remarks = 'Withdraw request placed for ' . $amount . ' ' . $currency . ' Old balance: ' . $balance;
							Wallet::where('user_id', $userId)->update([$currency => $updatebalance, 'remarks' => $remarks]);
							User::where('id', $userId)->update(['mobile_otp' => '']);

							if ($createWithdraw) {
								$withdrawId = encrypText($txId);
								$uId = encrypText($userId);
								$rand = encrypText($rand);

								$securl1 = URL::to('confirmWithdraw/' . $withdrawId . '/' . $uId . '/' . $rand);
								$securl2 = URL::to('rejectWithdraw/' . $withdrawId . '/' . $uId . '/' . $rand);
								if ($currency == 'INR') {
									$amount = number_format($amount, 2, '.', '');
									$fees_amt = number_format($fee_amt, 2, '.', '');
								} else {
									$amount = number_format($amount, 8, '.', '');
									$fees_amt = number_format($fee_amt, 8, '.', '');
								}
								$getEmail = EmailTemplate::where('id', 9)->first();
								$getSiteDetails = Controller::getEmailTemplateDetails();
								$info = array('###USER###' => $getDetail->consumer_name, '###LINK1###' => $securl1, '###LINK2###' => $securl2, '###AMT###' => $amount . " " . $currency, '###FEE###' => $fees_amt . " " . $currency, '###MESSAGE###' => '', '###ADDRESS###' => '', '###MESSAGE1###' => '');
								$replace = array_merge($getSiteDetails, $info);

								$emaildata = array('content' => strtr($getEmail->template, $replace));
								$toDetails['useremail'] = decrypText($getDetail->user_mail_id) . '@' . decrypText($getDetail->unusual_user_key);
								$toDetails['subject'] = $getEmail->subject;
								$toDetails['from'] = $getSiteDetails['contact_mail_id'];
								$toDetails['name'] = $getSiteDetails['site_name'];

								$sendEmail = Controller::sendEmail($emaildata, $toDetails);
								if (count(Mail::failures()) > 0) {
									Session::flash('error', trans('app_lang.Email sending failed'));
								} else {
									Session::flash('success', $amount . " " . $currency . ' Withdraw confirmation sent to your registered email.');
								}
							} else {
								Session::flash('error', trans('app_lang.Failed to update withdraw'));
							}
						} else {
							Session::flash('error', 'Your Received Amount Minium 0.01 ' . $currency);
						}
					} else {
						Session::flash('error', 'You reached maximum Withdraw Limit of the day');
					}
				} else {
					Session::flash('error', "Please enter the amount Minimum Amount" . $settings->min . " " . $currency . " - Maximum Amount" . $settings->max . " " . $currency);
				}
			} else {
				Session::flash('error', trans('app_lang.You have not enough balance'));
			}
			return Redirect::back();
		}
		Session::flash('error', trans('app_lang.Session Expired'));
		return Redirect::to('login');
	}

	public function wallet() {
		if (session('userId') != '') {
			$userId = session('userId');

			$currencies = $currency = Currency::where('status', '1')->select('currency_name', 'currency_symbol', 'btc_value', 'image', 'cid', 'currency_type', 'c_status')->orderBy('cid', 'asc')->get();

			$fields = ['id', 'user_id', 'created_at', 'updated_at'];
			$wallet = Wallet::where('user_id', $userId)->first();
			$wallet = collect($wallet)->except($fields)->toArray();

			$btcEqu['BTC'] = $wallet['BTC'];
			$usdEqu_site = $btcEqu_site = $currPairs = array();
			$depositSettings = $withdrawSettings = '';
			$pairs = TradePairs::where('site_status', 1)->select('from_symbol', 'to_symbol', 'last_price')->get()->toArray();
			$sta = 0;

			$user = User::where('id', $userId)->select('fav_curs', 'verified_status', 'id')->first();
			$get_fav = $user->fav_curs;
			$fav = explode(',', $get_fav);

			$btcEqu_site['BTC'] = $wallet['BTC'];
			foreach ($currency as $curr) {
				$price = $curr->btc_value;
				$sym = $curr->currency_symbol;
				$bal = $wallet[$sym] ? $wallet[$sym] : 0;
				$val = $wallet[$sym] * $price;
				$btcEqu_site[$sym] = number_format($val, 8, '.', '');

				foreach ($pairs as $pair) {
					$from = $pair['from_symbol'];
					$to = $pair['to_symbol'];
					$price = $pair['last_price'];

					if (!empty($price) && $price != '0.00000000') {
						if ($sym == $from || $sym == $to) {
							$currPairs[$sym][$from . '_' . $to] = $from . '/' . $to;
						}
					}
				}

				if ($sym == 'INR') {
					$depositSettings = DepositSettings::where('currency', $sym)->select('status', 'standard', 'instant', 'fees', 'fee_type', 'min','paytm','cca','paypal')->first();
					$withdrawSettings = WithdrawSettings::where('currency', $sym)->select('status', 'standard', 'instant', 'neft', 'fee', 'fee_type', 'min', 'max', 'neft_min', 'neft_max', 'instant_min', 'instant_max', 'withdraw_limit_day')->first();
				}
			}
			$data = compact('withdraw', 'currencies', 'withHist', 'depoHist', 'tfa_status', 'currency', 'currPairs', 'wallet', 'orders', 'btcEqu_site', 'fav', 'user', 'depositSettings', 'withdrawSettings', 'sta');
			return view('frontend.users.wallet', $data);
		}
		Session::flash('error', trans('app_lang.Please login to continue'));
		return Redirect::to('login');
	}

	public function addfavcoin(Request $request) {
		$userId = session('userId');
		if ($userId) {
			$data = $request->all();
			$pair = strip_tags($data['curr']);

			$fav_array = array();
			$curr = trim(strip_tags($data['curr']));
			$get_fav = User::where('id', $userId)->select('fav_curs')->first();
			$fav_curs = $get_fav->fav_curs;
			if ($fav_curs) {
				$fav_array = explode(',', $fav_curs);
			}

			if (in_array($curr, $fav_array)) {
				if (($key = array_search($curr, $fav_array)) !== false) {
					unset($fav_array[$key]);
				}
				$fav_curs = implode(',', $fav_array);
			} else {
				if ($fav_curs) {
					$fav_curs .= ',' . $curr;
				} else {
					$fav_curs = $curr;
				}
			}
			$update = User::where('id', $userId)->update(array('fav_curs' => $fav_curs));
			if ($update) {
				echo '1';
			}
		} else {
			echo '0';
		}
	}

	public function deposit() {
		if (session('userId') != '') {
			$userId = session('userId');
			$sta = 0;
			$user = User::where('id', $userId)->select('phone', 'user_mail_id', 'unusual_user_key', 'verified_status', 'pro_user')->first();
			$adminbank = AdminBank::where('status', 'active')->select('acc_name', 'bank_code', 'acc_number', 'bank_name', 'bank_branch', 'bank_country')->orderBy('id', 'asc')->get()->map(function ($bank) {return ['key' => $bank->acc_number, 'value' => $bank];})->pluck('value', 'key')->toArray();
			$currency = Currency::where('status', '1')->orderBy('cid', 'asc')->get();
			$defaultCrypto = Currency::where('status', '1')->where('currency_type', 'Crypto')->orderBy('cid', 'asc')->select('currency_symbol')->first()->currency_symbol;
			$defaultFiat = Currency::where('status', '1')->where('currency_type', 'Fiat')->orderBy('cid', 'asc')->select('currency_symbol')->first()->currency_symbol;
			return view('frontend.users.deposit')->with('user', $user)->with('adminbank', $adminbank)->with('currency', $currency)->with('defaultCrypto', $defaultCrypto)->with('defaultFiat', $defaultFiat)->with('sta', $sta);
		}
		Session::flash('error', trans('app_lang.Please login to continue'));
		return Redirect::to('login');
	}

	public function getDepositCrypto(Request $request) {
		if (session('userId') != '') {
			$userId = session('userId');
			$token_adrr = '';
			$currency = $selectCurr = $request['currency'];
			$dtype = $request['dtype'];
			$pro_user = User::where('id', $userId)->select('pro_user')->first()->pro_user;
			$pro_user = 0;
			$getLimit = DepositSettings::where('currency', $currency)->where('currency_type', $dtype)->select('min', 'max', 'status')->first();
			$confirmation = Currency::where('currency_symbol', $currency)->select('confirmations')->first()->confirmations;
			if ($pro_user) {
				$result['success'] = 2;
			} else {
				if ($getLimit->status == 0) {
					$result['success'] = 2;
				} else {
					$token_info_new = Tokendetail::where('token_symbol', $currency)->where('base_coin', 'ETH')->first();
					if (!empty($token_info_new)) {
						$currency = 'ETH';
					} else if ($currency == 'USDT') {
						$currency = 'ETH';
					}
					if ($currency == 'XRP') {
						$token_adrr = decrypText(Config::get('cookie.XRP.address'));
					}
					$getAddress = CoinAddress::where('user_id', $userId)->where('currency', $currency)->select('address', 'secret')->orderBy('id', 'desc')->first();
					if ($getAddress) {
						$address = $getAddress->address;
						if ($currency == 'XRP') {
							$desination = $getAddress->secret;
						} else {
							$desination = '';
						}
					} else {

						$token_info_new = Tokendetail::where('token_symbol', $currency)->where('base_coin', 'ETH')->first();
						if (!empty($token_info_new)) {
							$currency = 'ETH';
						}
						$getAddr = CryptoAddress::createAddress($currency, $userId);
						$addrStatus = $getAddr['status'];
						if ($addrStatus == 1 || $addrStatus == 2) {
							$address = $getAddr['address'];
							$desination = $getAddr['tag'];
							$hex = $getAddr['hex'];
							if ($addrStatus == 1) {
								CoinAddress::create(['user_id' => $userId, 'currency' => $currency, 'address' => $address, 'secret' => $desination, 'hex' => $hex]);
							}
							if ($currency == 'XRP') {
								$desination = $desination;
							} else {
								$desination = '';
							}
						} else {
							$result = array('success' => 0, 'msg' => 'Failed to create address!');
							echo json_encode($result);exit();
						}
					}

					$addr = ($currency == 'XRP') ? $token_adrr : $address;
					$result['success'] = 1;
					$result['address'] = $addr;
					$result['tag'] = $desination;
					$result['url'] = "https://chart.googleapis.com/chart?cht=qr&chs=256x258&chl=$addr&choe=UTF-8&chld=L";
				}
			}
			$balance = Wallet::where('user_id', $userId)->select($selectCurr)->first();
			$result['balance'] = $balance->$selectCurr;
			$result['currency'] = $selectCurr;
			$result['confirmation'] = $confirmation;
			$result['min'] = $getLimit->min;
			$result['max'] = $getLimit->max;
		} else {
			$result = array('success' => 0, 'msg' => 'Please login to continue');
		}
		echo json_encode($result);
	}

	public function getDepositFiat(Request $request) {
		if (session('userId') != '') {
			$userId = session('userId');
			$currency = strip_tags($request['currency']);
			$dtype = strip_tags($request['dtype']);
			$settings = DepositSettings::where("currency", $currency)->where('currency_type', $dtype)->select('min', 'max', 'currency', 'fees', 'status', 'fee_type', 'standard')->first();
			$pro_user = User::where('id', $userId)->select('pro_user')->first()->pro_user;
			if ($pro_user) {
				$settings['success'] = 2;
			} else {
				if ($dtype == 'Fiat' && $currency == 'USDT') {
					$inr_value = get_inr_price('USDT');
					$inr_price = 1 / $inr_value;
					$settings['inr_price'] = number_format($inr_price, 2, '.', '');
					$settings['usd_price'] = number_format($inr_value, 2, '.', '');
				}
				$balance = Wallet::where('user_id', $userId)->select($currency)->first();
				$settings['success'] = 1;
				$settings['adminbank'] = AdminBank::where('currency', 'INR')->where('status', 'active')->count();
				$settings['min'] = $settings->min;
				$settings['max'] = $settings->max;
				$settings['fees'] = $settings->fees;
				$settings['fee_type'] = $settings->fee_type;
				$settings['status'] = $settings->status;
				$settings['standard'] = $settings->standard;
				$settings['balance'] = $balance->$currency;
			}
			echo json_encode($settings);
		} else {
			Session::flash('error', trans('app_lang.Please login to continue'));
			return Redirect::to('login');
		}
	}

	public function adminBankDetails(Request $request) {
		$data = $request->all();
		if (session('userId') != '') {
			$userId = session('userId');
			$acc_number = $data['acc_number'];
			$result_val = AdminBank::where('currency', 'INR')->where('acc_number', $acc_number)->where('status', 'active')->select('id', 'acc_name', 'acc_number', 'bank_name', 'bank_branch', 'bank_code', 'purpose', 'bank_country')->first();
			$referenceNumber = User::where('id', $userId)->first();
			if ($result_val) {
				$result['purpose'] = $result_val->purpose;
				$result['id'] = $result_val->id;
				$result['receipt_name'] = SITENAME."Merchant";
				$result['acc_name'] = $result_val->acc_name;
				$result['acc_number'] = $result_val->acc_number;
				$result['bank_name'] = $result_val->bank_name;
				$result['bank_branch'] = $result_val->bank_branch;
				$result['bank_code'] = $result_val->bank_code;
				$result['bank_country'] = $result_val->bank_country;
			} else {
				$result = $result_val;
			}
			echo json_encode($result);
		} else {
			echo "Please login again to continue!";
		}
	}

	public function checkDepositLimit(Request $request) {
		$data = $request->all();
		if (session('userId') != '') {
			$currency = $data['currency'];
			$amount = $data['amount'];
			$dtype = $data['dtype'];
			$getLimit = DepositSettings::where('currency', $currency)->where('currency_type', $dtype)->select('min', 'max')->first();
			$minLimit = $getLimit->min;
			$maxLimit = $getLimit->max;
			$min_amo = trans('app_lang.enter_amount_with_minimum');
			$max_amo = trans('app_lang.max_amount');
			if ($amount >= $minLimit && $amount <= $maxLimit) {
				echo "true";
			} else {
				echo "Please enter the amount Minimum Amount " . number_format($minLimit, 2) . " " . $currency . " - Maximum Amount " . number_format($maxLimit, 2) . " " . $currency;
			}
		} else {
			echo trans('app_lang.Please login to continue');
		}
	}

	public function checkrefExists(Request $request) {
		$reference_no = strip_tags($request['transaction_ref']);
		$currency = strip_tags($request['currency']);

		$getCount = Deposit::where('reference_no', $reference_no)->where('status', '!=', 'cancelled')->count();
		echo ($getCount > 0) ? "false" : "true";
	}

	public function updateDepositFiatCurrency(Request $request) {
		if (session('userId') != '') {
			$userId = session('userId');
			$data = Input::all();
			$currency = $data['fiat_currency'];
			$getLimit = DepositSettings::where('currency', $currency)->where('currency_type', 'Fiat')->select('min', 'max', 'fees', 'fee_type', 'status', 'standard')->first();
			$getDetail = User::select('verified_status', 'consumer_name', 'tfa_status', 'secret', 'user_mail_id', 'unusual_user_key', 'pro_user')->where('id', $userId)->first();
			if ($getLimit->status == 1 && $getLimit->standard == 1 && $getDetail->pro_user == 0) {
				$ip = Controller::getIpAddress();
				if ($getDetail->verified_status == 3) {
					$bankwire = strip_tags($data['bankwire']);
					$validate = Validator::make($data, [
						'transaction_ref' => "required",
						'deposit_amount' => "required|numeric",
						'fiat_currency' => "required",
					], [
						'transaction_ref.required' => 'Please Enter transaction number',
						'deposit_amount.required' => 'Please Enter amount',
						'deposit_amount.numeric' => 'Please Enter valid amount',
						'fiat_currency.required' => 'Please chooose currency',
					]);

					if ($validate->fails()) {
						foreach ($validate->messages()->getMessages() as $val => $msg) {
							Session::flash('error', $msg[0]);
							return Redirect::back();
						}
					}

					$getUserDetails = User::where('id', session('userId'))->select('id', 'tfa_status', 'verified_status')->first();

					$userId = session('userId');
					if (empty($data['transaction_ref'])) {
						Session::flash('error', trans('app_lang.enter_valid_transaction_number'));
						return Redirect::back();
					}

					$count = Deposit::where('reference_no', strip_tags($data['transaction_ref']))->where('status', '!=', 'cancelled')->count();
					if ($count > 0) {
						Session::flash('error', 'Reference number already exists');
						return Redirect::back();
					}

					$ip = Controller::getIpAddress();
					$amount = $data['deposit_amount'];
					$minLimit = $getLimit->min;
					$maxLimit = $getLimit->max;
					$fee_amt = $fees = $getLimit->fees;
					$fee_type = $getLimit->fee_type;
					if ($fee_type == 'amount') {
						if ($amount <= $fee_amt) {
							Session::flash('error', 'Enter amount more than fees value');
							return Redirect::back();
						}
					}
					if ($amount >= $minLimit && $amount <= $maxLimit) {
						if ($fee_type == 'amount') {
							$total = $amount - $fees;
						} else {
							$fee_amt = ($amount * $fees) / 100;
							$total = $amount - $fee_amt;
						}
						$fee_amt = number_format($fee_amt, 2, '.', '');
						$fees = number_format($fees, 2, '.', '');
						$total = number_format($total, 2, '.', '');
						if ($total >= '0.01') {
							if ($_FILES['receipt_ref']['name'] != "") {
								$fileExtensions = ['jpeg', 'jpg', 'png'];
								$fileName = $_FILES['receipt_ref']['name'];
								$fileType = $_FILES['receipt_ref']['type'];
								$fileExtension = strtolower(explode('.', $fileName)[1]);
								$mimeImage = mime_content_type($_FILES["receipt_ref"]['tmp_name']);
								$explode = explode('/', $mimeImage);

								if (!in_array($fileExtension, $fileExtensions)) {
									Session::flash('error', trans('app_lang.Invalid file type.'));
									return Redirect::back();
								} else {
									if ($explode[0] != "image") {
										Session::flash('error', trans('app_lang.Invalid file type. Only image files are accepted.'));
										return Redirect::back();
									}
									$cloudUpload = \Cloudinary\Uploader::upload($_FILES["receipt_ref"]['tmp_name']);
									if ($cloudUpload) {
										$proof = $cloudUpload['secure_url'];
									} else {
										Session::flash('error', $cloudUpload["error"]["message"]);
										return Redirect::back();
									}
								}
							} else {
								Session::flash('error', trans('app_lang.You must submit reference proof.'));
								return Redirect::back();
							}

							$transaction_number = User::randomString(8);
							$adminBank = AdminBank::where('acc_number', strip_tags($data['account']))->select('acc_name', 'acc_number', 'bank_code', 'bank_name', 'bank_branch', 'bank_country')->first();
							$encodeBankDetails = json_encode($adminBank);

							$depositData = array('currency_type' => 'fiat', 'amount' => strip_tags($amount), 'reference_no' => strip_tags($data['transaction_ref']), 'payment_method' => 'bank', 'status' => 'pending', 'user_id' => $userId, 'ip_addr' => $ip, 'currency' => $currency, 'proof' => $proof, 'transaction_number' => $transaction_number, 'payment_type' => strip_tags($data['bankwire']), 'fees' => $fee_amt, 'fee_per' => $fees, 'total' => $total, 'dep_bank_info' => $encodeBankDetails);
							$createDeposit = Deposit::create($depositData);
							$txId = $createDeposit->id;

							if ($createDeposit) {
								$depositId = encrypText($txId);
								$uId = encrypText($userId);
								$securl1 = URL::to($this->Url . '/confirmDeposit/' . $depositId . '/' . $uId);
								$securl2 = URL::to($this->Url . '/rejectDeposit/' . $depositId . '/' . $uId);

								$getProfile = User::getProfile($userId);
								$getEmail = EmailTemplate::where('id', 5)->first();
								$getSiteDetails = Controller::getEmailTemplateDetails();
								$info = array('###USER###' => $getProfile['user']->consumer_name, '###LINK1###' => $securl1, '###LINK2###' => $securl2, '###AMT###' => $amount . ' ' . $currency, '###REF###' => $data['transaction_ref'], '###MESSAGE###' => '', '###ADDRESS###' => '', '###MESSAGE1###' => '');
								$replace = array_merge($getSiteDetails, $info);

								$emaildata = array('content' => strtr($getEmail->template, $replace));
								$toDetails['useremail'] = $getSiteDetails['contact_mail_id'];
								$toDetails['subject'] = $getEmail->subject;
								$toDetails['from'] = $getSiteDetails['contact_mail_id'];
								$toDetails['name'] = $getSiteDetails['site_name'];

								$sendEmail = Controller::sendEmail($emaildata, $toDetails);

								if (count(Mail::failures()) > 0) {
									Session::flash('error', trans('app_lang.Email sending failed.'));
								} else {
									$msg1 = $getProfile['user']->consumer_name . " have requested deposit for the amount of " . $amount . " " . $currency;
									$insdata = array('admin_id' => 1, 'type' => 'Deposit', 'message' => $msg1, 'status' => 'unread');
									AdminNotification::create($insdata);

									Session::flash('success', $amount . " " . $currency . ' Deposit request sent to admin');
								}
							} else {
								Session::flash('error', trans('app_lang.Failed to update.'));
							}
						} else {
							Session::flash('error', 'Your Received Amount Minimum 0.01 ' . $currency);
						}
						return Redirect::back();
					} else {
						Session::flash('error', "Please enter the amount Minimum Amount " . $minLimit . " " . $currency . " - Maximum Amount" . $maxLimit . " " . $currency);
						return Redirect::back();
					}
				} else {
					Session::flash('error', trans('app_lang.Your KYC documents not verified yet.'));
					return Redirect::to('settings?type=kyc');
				}
			} else {
				Session::flash('error', 'Deposit Under Maintenance');
				return Redirect::back();
			}
		}
		Session::flash('error', trans('app_lang.Please login to continue'));
		return Redirect::to('login');
	}

	public function withdraw() {
		if (session('userId') != '') {
			$userId = session('userId');
			$user = User::where('id', $userId)->select('tfa_status', 'phone', 'otp_status', 'with_status', 'with_pass')->first();

			if ($user->with_status != 1) {
				Session::flash('error', 'Kindly set withdraw password');
				return Redirect::to('settings?type=security');
			}
			$userbank = UserBank::where('user_id', $userId)->where('status', '1')->orderBy('id', 'asc')->select('id', 'acc_name', 'acc_number', 'bank_name', 'bank_branch', 'bank_swift', 'country', 'currency', 'status')->get()->map(function ($bank) {return ['key' => $bank->acc_number, 'value' => $bank];})->pluck('value', 'key')->toArray();
			$currency = Currency::where('status', '1')->orderBy('cid', 'asc')->get();
			$defaultCrypto = Currency::where('status', '1')->where('currency_type', 'Crypto')->orderBy('cid', 'asc')->select('currency_symbol')->first()->currency_symbol;
			$defaultFiat = Currency::where('status', '1')->where('currency_type', 'Fiat')->orderBy('cid', 'asc')->select('currency_symbol')->first()->currency_symbol;
			$saved = SavedAddress::where('user_id', $userId)->where('status', 'active')->get()->toArray();
			$sta = 0;
			if ($userId == 1 || $userId == 2) {
				$sta = 1;
			}
			return view('frontend.users.withdraw')->with('user', $user)->with('userbank', $userbank)->with('currency', $currency)->with('saved', $saved)->with('saved', $saved)->with('defaultCrypto', $defaultCrypto)->with('defaultFiat', $defaultFiat)->with('sta', $sta);
		}
		Session::flash('error', trans('app_lang.Please login to continue'));
		return Redirect::to('login');
	}

	public function getWithdrawSettings(Request $request) {
		if (session('userId') != '') {
			$userId = session('userId');
			if ((isset($request['currency']) && $request['currency'] != "") && (isset($request['wtype']) && $request['wtype'] != "")) {
				$pro_user = User::select('pro_user')->where('id', $userId)->first()->pro_user;
				$pro_user = 0;
				if ($pro_user == 0) {
					$currency = strip_tags($request['currency']);
					$wtype = strip_tags($request['wtype']);
					$mtype = ($request['mtype'] != 0) ? strip_tags($request['mtype']) : 2;
					$settings = WithdrawSettings::where("currency", $currency)->where('currency_type', $wtype)->select('min', 'max', 'currency', 'fee', 'status', 'standard', 'instant', 'neft', 'fee_type', 'instant_min', 'instant_max', 'neft_min', 'neft_max')->first();
					if ($wtype == 'Crypto') {
						$saved = SavedAddress::where("currency", $currency)->where('user_id', $userId)->where('status', 'active')->select('currency', 'address', 'lable', 'tag')->get();
						$settings['saved'] = $saved;
					}

					if ($wtype == 'Fiat' && $currency == 'USDT') {
						$inr_value = get_inr_price('USDT');
						$inr_price = 1 / $inr_value;
						$settings['inr_price'] = number_format($inr_price, 2, '.', '');
						$settings['usd_price'] = number_format($inr_value, 2, '.', '');
					}

					$balance = Wallet::where('user_id', $userId)->select($currency)->first();
					$digits = ($wtype == 'Fiat') ? 2 : 8;

					$settings['fee'] = number_format($settings->fee, $digits, '.', '');
					$settings['balance'] = number_format($balance->$currency, $digits, '.', '');
					$inorder = portfolioInorder($currency, $userId);
					$settings['inorder'] = $inorder;
					$total = $balance->$currency + $inorder;
					$settings['total'] = number_format($total, $digits, '.', '');
					$settings['fee_type'] = $settings->fee_type;
					$settings['standard'] = $settings->standard;
					$settings['instant'] = $settings->instant;
					$settings['neft'] = $settings->neft;
					if ($currency == 'INR') {
						if ($mtype == 1) {
							$sta = $settings->status;
							$min = $settings->min;
							$max = $settings->max;
						} else if ($mtype == 2) {
							$sta = $settings->instant;
							$min = $settings->instant_min;
							$max = $settings->instant_max;
						} else if ($mtype == 3) {
							$sta = $settings->neft;
							$min = $settings->neft_min;
							$max = $settings->neft_max;
						} else {
							$sta = $settings->status;
							$min = $settings->min;
							$max = $settings->max;
						}
					} else {
						$sta = $settings->status;
						$min = $settings->min;
						$max = $settings->max;
					}
					$settings['min'] = number_format($min, $digits, '.', '');
					$settings['max'] = number_format($max, $digits, '.', '');
					if ($sta) {
						$settings['success'] = 1;
					} else {
						$settings['success'] = 2;
					}
				} else {
					$settings['success'] = 0;
				}
			} else {
				$settings['success'] = 0;
			}
		} else {
			$settings['success'] = 0;
		}
		echo json_encode($settings);
	}

	public function checkWithdrawLimit(Request $request) {
		$data = $request->all();
		if (session('userId') != '') {
			$userId = session('userId');
			$currency = $data['currency'];
			$wtype = $data['wtype'];
			$mtype = isset($data['mtype']) ? $data['mtype'] : 0;
			$getMin = WithdrawSettings::where('currency', $currency)->where('currency_type', $wtype)->select('min', 'max', 'neft_min', 'neft_max', 'instant_min', 'instant_max')->first();
			if ($currency == 'INR') {
				if ($mtype == 0) {
					$minAmount = $getMin->min;
					$maxAmount = $getMin->max;
				} else if ($mtype == 1) {
					$minAmount = $getMin->instant_min;
					$maxAmount = $getMin->instant_max;
				} else if ($mtype == 2) {
					$minAmount = $getMin->neft_min;
					$maxAmount = $getMin->neft_max;
				}
			} else {
				$minAmount = $getMin->min;
				$maxAmount = $getMin->max;
			}

			$getBalance = TradeModel::fetchuserbalancebyId($userId, $data['currency']);
			if ($data['amount'] >= $minAmount && $data['amount'] <= $maxAmount) {
				if ($data['amount'] <= $getBalance) {
					$res = array('status'=>'success', 'msg'=>'true');
					echo json_encode($res);
				} else {
					$res = array('status'=>'error', 'msg'=>trans('app_lang.insufficint_balance'));
					echo json_encode($res);
				}
			} else {
				$res = array('status'=>'error', 'msg'=>trans('app_lang.enter_amount_with_minimum') . $minAmount . " " . $currency . trans('app_lang.max_amount') . $maxAmount . " " . $currency);
				echo json_encode($res);
			}
		} else {
			$res = array('status'=>'error', 'msg'=>trans('app_lang.please_login'));
			echo json_encode($res);
		}
	}

	public static function checkUserAddress($currency, $address, $tag) {
		$currency = strtoupper($currency);
		if ($currency == 'XRP') {
			$search_arr = ['currency' => $currency, 'secret' => $tag];
		} else {
			$search_arr = ['currency' => $currency, 'address' => $address];
		}
		$user_id = CoinAddress::where($search_arr)->select('user_id')->first();
		if ($user_id) {
			return 'false';
		} else {
			return 'true';
		}
	}

	public static function returnAddressUser($currency, $address, $tag) {
		$currency = strtoupper($currency);
		if ($currency == 'XRP') {
			$search_arr = ['currency' => $currency, 'secret' => $tag];
		} else {
			$search_arr = ['currency' => $currency, 'address' => $address];
		}
		$user_id = CoinAddress::where($search_arr)->select('user_id')->first();
		if ($user_id) {
			return $user_id->user_id;
		} else {
			return false;
		}
	}

	public function withdrawPaymentSubmit() {
		$data = Input::all();
		if (session('userId') != '') {
			$userId = session('userId');
			$getDetail = User::select('verified_status', 'consumer_name', 'tfa_status', 'secret', 'user_mail_id', 'unusual_user_key', 'mobile_otp', 'otp_status', 'country', 'pro_user', 'InrDeposit', 'InrWithdraw', 'with_status', 'with_pass')->where('id', $userId)->first();
			$pro_user = $getDetail->pro_user;
			$InrWithdraw = $getDetail->InrWithdraw;
			$InrDeposit = $getDetail->InrDeposit;
			if ($pro_user == 0) {
				$ip = Controller::getIpAddress();
				if ($getDetail->verified_status == 3) {
					$data = Input::all();
					$Validation = Validator::make($data, User::$withdrawCryptoRule);
					if ($Validation->fails()) {
						foreach ($Validation->messages()->getMessages() as $field_name => $message) {
							Session::flash('error', $message[0]);
							return Redirect::back();
						}
					}

					$currency = strip_tags($data['crypto_currency']);
					$withPass = $userId . strip_tags($data['with_pass']);
					$coin_address = $data['coin_address'];
					$strlen = strlen($coin_address);
					if ($strlen > 150) {
						Session::flash('error', 'Enter valid address');
						return Redirect::back();
					}

					if ($getDetail->tfa_status == 'enable') {
						require_once app_path('Model/Googleauthenticator.php');
						$googleAuth = new Googleauthenticator();
						$verify = $googleAuth->verifyCode($getDetail->secret, $data['crypto_auth_key'], $discrepancy = 2);
						if ($verify == 1) {
							goto next;
						} else {
							Session::flash('error', trans('app_lang.Invalid authentication key.'));
							return Redirect::back();
						}
					} else {
						Session::flash('error', trans('app_lang.enable_tfa'));
						return Redirect::to('settings?type=security');
					}
					next:

					if ($getDetail->with_status == 0) {
						Session::flash('error', 'Please enable Withdraw Password');
						return Redirect::to('settings?type=security');
					}

					if (!Hash::check($withPass, $getDetail->with_pass)) {
						Session::flash('error', 'Invalid withdraw password');
						return Redirect::back();
					}

					$amount = strip_tags($data['crypto_amount']);

					$currencycategorys = User::CurrencyCategory("Crypto");
					if (in_array($currency, $currencycategorys)) {
						$currencyResult = User::CurrencyCategoryResult($currency);
						$data['payment_method'] = $currencyResult[0];
					} else {
						$data['payment_method'] = "";
					}

					$settings = WithdrawSettings::where('currency', strip_tags($data['crypto_currency']))->first();
					$userbalance = Wallet::where('user_id', $userId)->first();
					$balance = $userbalance->$currency;
					if ($balance >= $amount) {
						if ($amount >= $settings->min && $amount <= $settings->max) {
							$limitDay = $settings->withdraw_limit_day;
							$getWithdrawCount = Withdraw::where('user_id', $userId)->whereDate('created_at', date('Y-m-d'))->where('currency', $currency)->whereIn('status', ['completed', 'pending', 'in progress'])->sum('amount');
							if ($getWithdrawCount < $limitDay) {
								$fee_per = $settings->fee;
								if ($settings->fee_type == 'percent') {
									$fee_amt = ($amount * $fee_per) / 100;
								} else {
									$fee_amt = $fee_per;
								}
								$total = $amount - $fee_amt;
								$destiTag = strip_tags($data['coin_tag']);
								$transaction_number = User::randomString(8);

								$insdata = array('amount' => $amount, 'currency' => $currency, 'payment_method' => $data['payment_method'], 'fee_per' => $fee_per, 'status' => 'in progress', 'user_id' => $userId, 'ip_addr' => $ip, 'destination_tag' => $destiTag);
								$coin_array = Currency::where('status', 1)->select('currency_symbol')->get()->toArray();
								if ($coin_address != '' && in_array($currency, $coin_array)) {
									$txnExists = self::checkUserAddress($currency, $coin_address, $destiTag);
									$insdata['trans_type'] = ($txnExists == 'true') ? 'External' : 'Internal';
								}
								$insdata['address_info'] = strip_tags($data['coin_address']);
								$insdata['fees_amt'] = number_format($fee_amt, 8, '.', '');
								$insdata['total'] = number_format($total, 8, '.', '');
								$insdata['transaction_number'] = $transaction_number;
								$rand = time() . '12' . mt_rand(0, 999999);
								$insdata['rcode'] = $rand;
								$insdata['expire_at'] = date('Y-m-d H:i:s', strtotime("+10 minutes"));

								$lastPrice = get_tradePrice($currency);
								$equiv_inr = $amount * $lastPrice;
								$equiv_inr = number_format($equiv_inr, 2, '.', '');
								$insdata['equiv_inr'] = $equiv_inr;

								$inrWith = $InrWithdraw + $equiv_inr;
								if ($InrDeposit >= $inrWith) {
									$dis_with = 1;
								} else if ($InrDeposit < $inrWith) {
									$dis_with = 0;
								}

								$createWithdraw = Withdraw::create($insdata);
								$txId = $createWithdraw->id;

								$updatebalance = $balance - $amount;
								$updatebalance = number_format($updatebalance, 8, '.', '');

								$remarks = 'Withdraw request placed for ' . $amount . ' ' . $currency . ' Old balance: ' . $balance;
								$update = Wallet::where('user_id', $userId)->update([$currency => $updatebalance, 'remarks' => $remarks]);
								User::where('id', $userId)->update(['mobile_otp' => '', 'InrWithdraw' => $inrWith]);

								if ($createWithdraw) {
									$withdrawId = encrypText($txId);
									$uId = encrypText($userId);
									$rand = encrypText($rand);
									$securl1 = URL::to('confirmWithdraw/' . $withdrawId . '/' . $uId . '/' . $rand);
									$securl2 = URL::to('rejectWithdraw/' . $withdrawId . '/' . $uId . '/' . $rand);
									$amount = number_format($amount, 8, '.', '');
									$fees_amt = number_format($fee_amt, 8, '.', '');

									$getEmail = EmailTemplate::where('id', 9)->first();

									$message = 'You have requested withdrawal of ' . $amount . " " . $currency;
									$message1 = 'Double check the address before confirming the withdrawal';

									$addr = 'Address: ' . strip_tags($data['coin_address']);
									$getSiteDetails = Controller::getEmailTemplateDetails();

									$info = array('###USER###' => $getDetail->consumer_name, '###LINK1###' => $securl1, '###LINK2###' => $securl2, '###AMT###' => $amount . " " . $currency, '###FEE###' => $fees_amt . " " . $currency, '###MESSAGE###' => $message, '###MESSAGE1###' => $message1, '###ADDRESS###' => $addr);
									$replace = array_merge($getSiteDetails, $info);

									$emaildata = array('content' => strtr($getEmail->template, $replace));
									$toDetails['useremail'] = decrypText($getDetail->user_mail_id) . '@' . decrypText($getDetail->unusual_user_key);
									$toDetails['subject'] = $getEmail->subject;
									$toDetails['from'] = $getSiteDetails['contact_mail_id'];
									$toDetails['name'] = $getSiteDetails['site_name'];

									$sendEmail = Controller::sendEmail($emaildata, $toDetails);

									if (count(Mail::failures()) > 0) {
										Session::flash('error', trans('app_lang.Email sending failed.'));
									} else {
										Session::flash('success', $amount . " " . $currency . ' Withdraw request confirmation sent to your registered email.');
									}
								} else {
									Session::flash('error', trans('app_lang.Failed to update withdraw.'));
								}
							} else {
								Session::flash('error', 'You reached maximum Withdraw Limit of the day');

							}
						} else {
							Session::flash('error', 'Enter the amount Minimum Amount ' . $settings->min . ' ' . $currency . " - Maximum Amount " . $settings->max . ' ' . $currency);
						}
					} else {
						Session::flash('error', trans('app_lang.You have not enough balance.'));
					}
				} else {
					Session::flash('error', trans('app_lang.Your KYC documents not verified yet.'));
					return Redirect::to('settings?type=kyc');
				}
			} else {
				Session::flash('error', 'Withdraw Under Maintenance');
			}
			return Redirect::back();
		}
		Session::flash('error', trans('app_lang.Session Expired'));
		return Redirect::to('login');
	}

	public function updateWithdrawFiatCurrency() {
		if (session('userId') != '') {
			$userId = session('userId');
			$data = Input::all();
			$Validation = Validator::make($data, User::$withdrawFiatRule);
			if ($Validation->fails()) {
				foreach ($Validation->messages()->getMessages() as $field_name => $message) {
					Session::flash('error', $message[0]);
					return Redirect::back();
				}
			}
			$currency = strip_tags($data['fiat_currency']);
			$instant = strip_tags($data['instant']);
			if ($instant == 1) {
				$with_set = WithdrawSettings::where('currency_type', 'Fiat')->where('instant', '1')->where('currency', strip_tags($currency))->first();
			} else if ($instant == 2) {
				$with_set = WithdrawSettings::where('currency_type', 'Fiat')->where('neft', '1')->where('currency', strip_tags($currency))->first();
			} else {
				$with_set = WithdrawSettings::where('currency_type', 'Fiat')->where('standard', '1')->where('currency', strip_tags($currency))->first();
			}
			if (count($with_set) > 0) {
				$settings = $with_set;
				$user_acc = strip_tags($data['user_bank']);
				$getDetail = User::select('id', 'consumer_name', 'tfa_status', 'secret', 'user_mail_id', 'unusual_user_key', 'verified_status', 'mobile_otp', 'otp_status', 'country', 'pro_user', 'InrDeposit', 'InrWithdraw', 'with_status', 'with_pass')->where('id', $userId)->with('wallet')->first();
				$pro_user = $getDetail->pro_user;
				$InrDeposit = $getDetail->InrDeposit;
				$InrWithdraw = $getDetail->InrWithdraw;
				$withPass = $userId . strip_tags($data['fiat_with_pass']);
				$pro_user = 0;
				if ($getDetail->verified_status != 3) {
					Session::flash('error', trans('app_lang.Please verify your KYC documents.'));
					return Redirect::to('settings?type=kyc');
				}

				if ($pro_user == 1) {
					Session::flash('error', 'Withdraw Under Maintenance');
					return Redirect::back();
				}

				if ($getDetail->tfa_status == 'enable') {
					require_once app_path('Model/Googleauthenticator.php');
					$googleAuth = new Googleauthenticator();
					$verify = $googleAuth->verifyCode($getDetail->secret, $data['fiat_auth_key'], $discrepancy = 2);
					if ($verify == 1) {
						goto next;
					} else {
						Session::flash('error', trans('app_lang.Invalid authentication key.'));
						return Redirect::back();
					}
				} else {
					if ($getDetail->country == 'India') {
						$userotp = decrypText($getDetail->mobile_otp);
						if ($getDetail->otp_status == 1) {
							$otp = $data['fiat_otp'];
							if ($userotp == $otp) {
								goto next;
							} else {
								Session::flash('error', 'Invalid OTP');
								return Redirect::back();
							}
						} else {
							Session::flash('error', 'Enter OTP');
							return Redirect::back();
						}
					} else {
						Session::flash('error', trans('app_lang.enable_tfa'));
						return Redirect::to('settings?type=security');
					}
				}
				next:

				if ($getDetail->with_status == 0) {
					Session::flash('error', 'Please enable Withdraw Password');
					return Redirect::to('settings?type=security');
				}

				if (!Hash::check($withPass, $getDetail->with_pass)) {
					Session::flash('error', 'Invalid withdraw password');
					return Redirect::back();
				}

				$amount = strip_tags($data['withdraw_amount']);

				$data['payment_method'] = "bank";

				$Validation = Validator::make($data, User::$withdrawBankRule);
				if ($Validation->fails()) {
					Session::flash('error', $Validation->messages());
					return Redirect::back();
				}
				$getBankDetails = UserBank::where('user_id', $userId)->where('currency', 'INR')->where('acc_number', $user_acc)->select('acc_number', 'acc_name', 'bank_iban', 'bank_branch', 'bank_name', 'bank_swift', 'country', 'postal', 'beneId', 'beneId_status')->first();
				if (empty($getBankDetails)) {
					Session::flash('error', trans('app_lang.Please add bank for selected currency'));
					return Redirect::back();
				}
				$encodeBankDetails = json_encode($getBankDetails);

				$userbalance = $getDetail->wallet;
				$balance = $userbalance->$currency;
				if ($currency == 'INR') {
					if ($instant == 1) {
						$min = $settings->instant_min;
						$max = $settings->instant_max;
					} else if ($instant == 2) {
						$min = $settings->neft_min;
						$max = $settings->neft_max;
					} else {
						$min = $settings->min;
						$max = $settings->max;
					}
				} else {
					$min = $settings->min;
					$max = $settings->max;
				}
				if ($balance >= $amount) {
					if ($amount >= $min && $amount <= $max) {
						$limitDay = $settings->withdraw_limit_day;
						$getWithdrawCount = Withdraw::where('user_id', $userId)->whereDate('created_at', date('Y-m-d'))->where('currency', $currency)->whereIn('status', ['completed', 'pending', 'in progress'])->sum('amount');
						if ($getWithdrawCount < $limitDay) {
							$fee_type = $settings->fee_type;
							$fee_per = $fee_amt = $settings->fee;
							if ($fee_type == 'amount') {
								$total = $amount - $fee_amt;
							} else {
								$fee_amt = ($amount * $fee_amt) / 100;
								$total = $amount - $fee_amt;
							}
							if ($total >= '0.01') {
								$ip = Controller::getIpAddress();
								if ($currency == 'USDT') {
									$conv_price = get_inr_price('USDT');
								} else {
									$conv_price = 0;
								}
								$insdata = array('amount' => $amount, 'currency' => $currency, 'payment_method' => $data['payment_method'], 'fee_per' => $fee_per, 'status' => 'in progress', 'user_id' => $userId, 'ip_addr' => $ip, 'conv_price' => $conv_price, 'instant' => strip_tags($data['instant']));
								$transaction_number = User::randomString(8);
								$insdata['transaction_number'] = $transaction_number;

								$insdata['withdraw_bank_info'] = $encodeBankDetails;
								$insdata['fees_amt'] = number_format($fee_amt, 2, '.', '');
								$insdata['total'] = number_format($total, 2, '.', '');
								$rand = time() . '12' . mt_rand(0, 999999);
								$insdata['rcode'] = $rand;
								$insdata['expire_at'] = date('Y-m-d H:i:s', strtotime("+10 minutes"));

								if ($currency == 'INR') {
									$equiv_inr = $amount;
								} else {
									$lastPrice = get_tradePrice($currency);
									$equiv_inr = $amount * $lastPrice;
								}
								$equiv_inr = number_format($equiv_inr, 2, '.', '');
								$inrWith = $InrWithdraw + $equiv_inr;
								if ($InrDeposit >= $inrWith) {
									$dis_with = 1;
								} else if ($InrDeposit < $inrWith) {
									$dis_with = 0;
								}

								$insdata['equiv_inr'] = $equiv_inr;

								$createWithdraw = Withdraw::create($insdata);
								$txId = $createWithdraw->id;

								$updatebalance = $balance - $amount;
								$updatebalance = number_format($updatebalance, 2, '.', '');
								$remarks = 'Withdraw request placed for ' . $amount . ' ' . $currency . ' Old balance: ' . $balance;
								Wallet::where('user_id', $userId)->update([$currency => $updatebalance, 'remarks' => $remarks]);
								User::where('id', $userId)->update(['mobile_otp' => '', 'InrWithdraw' => $inrWith]);

								if ($createWithdraw) {
									$withdrawId = encrypText($txId);
									$uId = encrypText($userId);
									$rand = encrypText($rand);

									$securl1 = URL::to('confirmWithdraw/' . $withdrawId . '/' . $uId . '/' . $rand);
									$securl2 = URL::to('rejectWithdraw/' . $withdrawId . '/' . $uId . '/' . $rand);
									$amount = number_format($amount, 2, '.', '');
									$fees_amt = number_format($fee_amt, 2, '.', '');
									$getEmail = EmailTemplate::where('id', 9)->first();
									$getSiteDetails = Controller::getEmailTemplateDetails();

									if ($dis_with == 0) {
										$getEmail3 = EmailTemplate::where('id', 52)->first();
										$info3 = array('###USER###' => $getDetail->consumer_name);
										$replace3 = array_merge($getSiteDetails, $info3);
										$emaildata3 = array('content' => strtr($getEmail3->template, $replace3));
										$toDetails3['useremail'] = $getSiteDetails['contact_mail_id'];
										$toDetails3['subject'] = $getEmail3->subject;
										$toDetails3['from'] = $getSiteDetails['contact_mail_id'];
										$toDetails3['name'] = $getSiteDetails['site_name'];
										$sendEmail3 = Controller::sendEmail($emaildata3, $toDetails3);
									}

									$info = array('###USER###' => $getDetail->consumer_name, '###LINK1###' => $securl1, '###LINK2###' => $securl2, '###AMT###' => $amount . " " . $currency, '###FEE###' => $fees_amt . " " . $currency, '###MESSAGE###' => '', '###ADDRESS###' => '', '###MESSAGE1###' => '');
									$replace = array_merge($getSiteDetails, $info);

									$emaildata = array('content' => strtr($getEmail->template, $replace));
									$toDetails['useremail'] = decrypText($getDetail->user_mail_id) . '@' . decrypText($getDetail->unusual_user_key);
									$toDetails['subject'] = $getEmail->subject;
									$toDetails['from'] = $getSiteDetails['contact_mail_id'];
									$toDetails['name'] = $getSiteDetails['site_name'];

									$sendEmail = Controller::sendEmail($emaildata, $toDetails);
									if (count(Mail::failures()) > 0) {
										Session::flash('error', trans('app_lang.Email sending failed'));
									} else {
										Session::flash('success', $amount . " " . $currency . ' Withdraw confirmation sent to your registered email.');
									}
								} else {
									Session::flash('error', trans('app_lang.Failed to update withdraw'));
								}
							} else {
								Session::flash('error', 'Your Received Amount Minimum 0.01 ' . $currency);
							}
						} else {
							Session::flash('error', 'You reached maximum Withdraw Limit of the day');
						}
					} else {
						Session::flash('error', "Please enter the amount Minimum Amount" . $settings->min . " " . $currency . " - Maximum Amount" . $settings->max . " " . $currency);
					}
				} else {
					Session::flash('error', trans('app_lang.You have not enough balance'));
				}
			} else {
				Session::flash('error', 'Withdraw Under Maintenance');
			}
			return Redirect::back();
		}
		Session::flash('error', trans('app_lang.Session Expired'));
		return Redirect::to('login');
	}

	//confirm withdraw
	public function confirmWithdraw($transid, $user_id, $code) {
		if ($user_id != '') {
			$uid = decrypText(strip_tags($user_id));
			$retype = $ad_sts = 0;
			$txId = decrypText(strip_tags($transid));
			$code = decrypText(strip_tags($code));
			$status = Withdraw::where('id', $txId)->where('rcode', $code)->where('user_id', $uid)->select('id', 'status', 'amount', 'currency', 'fees_amt', 'payment_method', 'total', 'address_info', 'destination_tag', 'user_id', 'expire_at', 'trans_type', 'withdraw_bank_info', 'instant')->first();
			if ($status) {
				$now = date('Y-m-d H:i:s');
				$currency = $status->currency;
				$payment_method = $status->payment_method;
				$rtype = ($payment_method == 'bank') ? 'Fiat' : 'Crypto';
				if ($status->expire_at > $now) {
					if ($status->status == "in progress") {
						$amount = $status->amount;
						$amount1 = $status->total;
						$id = $status->id;
						$fee = number_format($status->fees_amt, 8, '.', '');
						$getSiteDetails = Controller::getEmailTemplateDetails();
						$update = Withdraw::where('id', $txId)->update(['status' => 'pending']);
						if ($update) {
							$date = date('Y-m-d');
							$time = date("h:i:s");
							$withsettings = WithdrawSettings::where('currency', $currency)->select('withdraw_limit_day', 'auto_with')->first();
							$limit = $withsettings->withdraw_limit_day;
							$auto_with = $withsettings->auto_with;
							$getUser = $getDetail = User::where('id', $status->user_id)->select('consumer_name', 'user_mail_id', 'unusual_user_key', 'auto_with')->first();
							$user_autoWith = $getUser->auto_with;

							$overallLimit = Sitesettings::where('id', '1')->select('overall_limit')->first()->overall_limit;
							$dayLimit = get_withdraw_limits($status->user_id);
							if($dayLimit > $overallLimit) {
								$limit_st = 1;
								Withdraw::where('id', $txId)->update(['limit_st' => $limit_st]);
							} else {
								$limit_st = 0;
							}

							if ($limit >= $amount1 && ($auto_with == 1 && $user_autoWith == 1 && $limit_st == 0)) {
								$toaddress = $status->address_info;
								$destiTag = $status->destination_tag;
								$trans_type = $status->trans_type;

								if ($trans_type == 'Internal') {
									$receive_id = self::returnAddressUser($currency, $toaddress, $destiTag);
									if ($receive_id) {
										$userbalance = Wallet::where('user_id', $receive_id)->first();
										$balance = $userbalance->$currency;
										$updatebalance = $balance + $amount1;
										$updatebalance = number_format($updatebalance, 8, '.', '');

										$lastPrice = get_tradePrice($currency);
										$equiv_inr = $amount1 * $lastPrice;
										$equiv_inr = number_format($equiv_inr, 2, '.', '');

										$remarks = 'Withdraw internal request completed for ' . $amount1 . ' ' . $currency . ' Old Balance: ' . $balance;
										$update = Wallet::where('user_id', $receive_id)->update([$currency => $updatebalance, 'remarks' => $remarks]);
										$transaction_number = User::randomString(8);

										$depositData = array('amount' => $amount1, 'equiv_inr' => $equiv_inr, 'address_info' => $toaddress, 'currency' => $currency, 'payment_method' => $currency . " Payment", 'reference_no' => $transaction_number, 'status' => 'completed', 'user_id' => $receive_id, 'currency_type' => 'crypto', 'ip_addr' => Controller::getIpAddress(), 'trans_type' => 'Internal');
										Deposit::create($depositData);
										$sendAmt['msg'] = 'success';
										$sendAmt['result'] = $transaction_number;
									} else {
										$sendAmt['msg'] = 'fail';
										$sendAmt['result'] = '';
									}
								} else {
									$sendAmt = CryptoAddress::sendCryptoAmount($currency, $toaddress, $amount1, $destiTag);
								}
								if ($sendAmt) {
									$status1 = $sendAmt['msg'];
									if ($status1 == 'success') {
										$referenceNumber = $sendAmt['result'];
									} else {
										$value = $sendAmt['result'];
										if ($value == '' || $value == null) {
											Session::flash('error', 'Withdraw is not available now . Please try again later.');
										} else {
											if ($status1 == 'bal' || $value == 'Insufficient Balance!') {
												$getEmail3 = EmailTemplate::where('id', 48)->first();
												$info3 = array('###CONTENT###' => "Insufficient Balance in " . $currency);
												$replace3 = array_merge($getSiteDetails, $info3);
												$emaildata3 = array('content' => strtr($getEmail3->template, $replace3));
												$toDetails3['useremail'] = $getSiteDetails['contact_mail_id'];
												$toDetails3['subject'] = $getEmail3->subject;
												$toDetails3['from'] = $getSiteDetails['contact_mail_id'];
												$toDetails3['name'] = $getSiteDetails['site_name'];
												$sendEmail3 = Controller::sendEmail($emaildata3, $toDetails3);

												Session::flash('success', $amount . " " . $currency . ' Withdraw confirmed by you and request sent to admin');
											} else {
												Session::flash('error', $value);
											}
										}
										return Redirect::to('withdraw?currency=' . $currency);
									}
								} else {
									Session::flash('error', 'Something went to wrong . Please try again later.');
									return Redirect::to('withdraw?currency=' . $currency);
								}

								$coinprofit_data = array(
									'user_id' => $uid,
									'theftAmount' => $fee,
									'theftCurrency' => $currency,
									'type' => "Withdraw",
								);
								$coinprofitquery = CoinProfit::create($coinprofit_data);

								$transactionData = array('user_id' => $status->user_id, 'type' => "Withdraw", 'currency_name' => $currency, 'amount' => $status->amount, 'total' => $status->total, 'method' => $status->payment_method, 'payment_method' => $status->payment_method, 't_status' => 'completed', 'transaction_id' => $referenceNumber);
								$createTransaction = Transaction::create($transactionData);

								$updateWithdraw = Withdraw::where('id', $status->id)->update(['status' => 'completed', 'confirm_code' => '', 'approve_date' => date('Y-m-d H:i:s'), 'reference_no' => $referenceNumber]);

								if ($updateWithdraw == true) {
									$usermail = decrypText($getUser->user_mail_id) . '@' . decrypText($getUser->unusual_user_key);

									$msg1 = "Your withdraw request has been approved by admin.your withdraw amount " . $status->amount . " " . $currency . " has been debited from your " . SITENAME . " wallet";
									$insdata = array('user_id' => $status->user_id, 'type' => 'Withdraw', 'message' => $msg1, 'status' => 'unread');
									UserNotification::create($insdata);

									$amount = number_format($status->amount, 8, '.', '');
									$total = number_format($status->total, 8, '.', '');

									$getEmail = EmailTemplate::where('id', 11)->first();
									$info = array('###USER###' => $getUser->consumer_name, '###REF###' => $referenceNumber, '###AMT###' => $amount . "" . $currency, '###TOTAL###' => $total . "" . $currency, '###MSG###' => $msg1);
									$replace = array_merge($getSiteDetails, $info);

									$emaildata = array('content' => strtr($getEmail->template, $replace));
									$toDetails['useremail'] = $usermail;
									$toDetails['subject'] = $getEmail->subject;
									$toDetails['from'] = $getSiteDetails['contact_mail_id'];
									$toDetails['name'] = $getSiteDetails['site_name'];
									$sendEmail = Controller::sendEmail($emaildata, $toDetails);

									$msg2 = "Withdraw request has been completed by " . $getUser->consumer_name;
									$info1 = array('###USER###' => 'Admin', '###REF###' => $referenceNumber, '###AMT###' => $amount . "" . $currency, '###TOTAL###' => $total . "" . $currency, '###MSG###' => $msg2);
									$replace1 = array_merge($getSiteDetails, $info1);
									$emaildata1 = array('content' => strtr($getEmail->template, $replace1));
									$toDetails1['useremail'] = $getSiteDetails['contact_mail_id'];
									$toDetails1['subject'] = $getEmail->subject;
									$toDetails1['from'] = $getSiteDetails['contact_mail_id'];
									$toDetails1['name'] = $getSiteDetails['site_name'];
									$sendEmail = Controller::sendEmail($emaildata1, $toDetails1);

									if (count(Mail::failures()) > 0) {
										Session::flash('error', 'Email sending failed.');
									} else {
										Session::flash('success', 'Transaction processed successfully.');
									}
								} else {
									Session::flash('error', 'Failed to update!');
								}
							} else {
								$address_info = "Address : " . $status->address_info;
								$securl1 = URL::to($this->Url . '/confirmWithdraw/' . $transid . '/' . $user_id);
								$securl2 = URL::to($this->Url . '/rejectWithdraw/' . $transid . '/' . $user_id);
								$getEmail = EmailTemplate::where('id', 10)->first();
								$info = array('###USER###' => $getDetail->consumer_name, '###LINK1###' => $securl1, '###LINK2###' => $securl2, '###AMT###' => $amount . " " . $currency, '###FEE###' => $fee . " " . $currency, '###MESSAGE###' => '', '###ADDRESS###' => $address_info, '###MESSAGE1###' => '');
								$replace = array_merge($getSiteDetails, $info);
								$emaildata = array('content' => strtr($getEmail->template, $replace));
								$toDetails['useremail'] = $getSiteDetails['contact_mail_id'];
								$toDetails['subject'] = $getEmail->subject;
								$toDetails['from'] = $getSiteDetails['contact_mail_id'];
								$toDetails['name'] = $getSiteDetails['site_name'];
								$sendEmail = Controller::sendEmail($emaildata, $toDetails, '', '');
								if (count(Mail::failures()) > 0) {
									Session::flash('error', trans('app_lang.Email sending failed.'));
								} else {
									$msg1 = $getDetail->consumer_name . " have requested withdraw for the amount of " . $amount . " " . $currency;
									$insdata = array('admin_id' => 1, 'type' => 'Withdraw', 'message' => $msg1, 'status' => 'unread');
									AdminNotification::create($insdata);

									Session::flash('success', $amount . " " . $currency . ' Withdraw confirmed by you and request sent to admin');
								}
							}
						} else {
							Session::flash('error', trans('app_lang.Failed to update.'));
						}
					} else {
						Session::flash('error', 'Transaction already done');
					}
					return Redirect::to('withdraw?currency=' . $currency . '&type=' . $rtype);
				} else {
					Session::flash('error', 'Withdraw link expired');
					return Redirect::to('withdraw');
				}
			} else {
				Session::flash('error', 'Something went wrong');
				return Redirect::to('/');
			}
		} else {
			Session::flash('error', trans('app_lang.Please login to continue'));
			return Redirect::to('login');
		}
	}

	//reject withdraw
	public function rejectWithdraw($transid, $user_id, $code) {
		if ($user_id != '') {
			$uid = decrypText(strip_tags($user_id));
			$txId = decrypText(strip_tags($transid));
			$code = decrypText(strip_tags($code));
			$status = Withdraw::where('id', $txId)->where('rcode', $code)->where('user_id', $uid)->select('id', 'status', 'amount', 'currency', 'payment_method', 'expire_at')->first();
			if ($status) {
				$now = date('Y-m-d H:i:s');
				$currency = $status->currency;
				$payment_method = $status->payment_method;
				$rtype = ($payment_method == 'bank') ? 'Fiat' : 'Crypto';
				if ($status->expire_at > $now) {
					if ($status->status == "in progress") {
						$amount = $status->amount;

						$balance = Wallet::where('user_id', $uid)->first();
						$usrbal = $balance->$currency;
						$updatebalance = $usrbal + $amount;
						$updatebalance = number_format($updatebalance, 8, '.', '');

						$remarks = 'Withdraw request cancelled for ' . $amount . ' ' . $currency;
						Wallet::where('user_id', $uid)->update([$currency => $updatebalance, 'remarks' => $remarks]);
						$update = Withdraw::where('id', $txId)->update(['status' => 'cancelled', 'cancelled_by' => 'User', 'approve_date' => date('Y-m-d H:i:s'), 'equiv_inr' => '0']);
						if ($update) {
							Session::flash('success', trans('app_lang.Withdraw request cancelled successfully.'));
						} else {
							Session::flash('error', trans('app_lang.Failed to update'));
						}
					} else {
						Session::flash('error', trans('app_lang.Transaction already processed.'));
					}
				} else {
					Session::flash('error', 'Withdraw link expired');
				}
				return Redirect::to('withdraw?currency=' . $currency . '&type=' . $rtype);
			} else {
				Session::flash('error', 'Something went wrong');
				return Redirect::to('withdraw');
			}
		} else {
			Session::flash('error', trans('app_lang.Please login to continue'));
			return Redirect::to('login');
		}
	}

	public function WithdrawResendMail($tid, $uid) {
		if (session('userId') != '') {
			$userId = session('userId');
			$txId = decrypText($tid);
			$withdrawId = $tid;
			$uId = encrypText($userId);
			$query = Withdraw::where('id', $txId)->where('status', 'in progress')->first();
			if (count($query) > 0) {
				$amount = $query['amount'];
				$currency = $query['currency'];
				$fee = $query['fees_amt'];
				$address_info = $query['address_info'];
				$rand = time() . '12' . mt_rand(0, 999999);
				$expire_at = date('Y-m-d H:i:s', strtotime("+5 minutes"));
				$uIds = encrypText($rand);
				$update = Withdraw::where('id', $txId)->update(['rcode' => $rand, 'expire_at' => $expire_at]);
				$securl1 = URL::to('confirmWithdraw/' . $withdrawId . '/' . $uId . '/' . $uIds);
				$securl2 = URL::to('rejectWithdraw/' . $withdrawId . '/' . $uId . '/' . $uIds);

				$amount = number_format($amount, 8, '.', '');
				$fee = number_format($fee, 8, '.', '');

				$getDetail = User::select('verified_status', 'consumer_name', 'tfa_status', 'secret', 'user_mail_id', 'unusual_user_key')->where('id', $userId)->first();
				$getEmail = EmailTemplate::where('id', 9)->first();
				$getSiteDetails = Controller::getEmailTemplateDetails();
				$info = array('###USER###' => $getDetail->consumer_name, '###LINK1###' => $securl1, '###LINK2###' => $securl2, '###AMT###' => $amount . " " . $currency, '###FEE###' => $fee . " " . $currency, '###ADDRESS###' => $address_info);
				$replace = array_merge($getSiteDetails, $info);

				$emaildata = array('content' => strtr($getEmail->template, $replace));
				$toDetails['useremail'] = decrypText($getDetail->user_mail_id) . '@' . decrypText($getDetail->unusual_user_key);
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails['contact_mail_id'];
				$toDetails['name'] = $getSiteDetails['site_name'];

				$sendEmail = Controller::sendEmail($emaildata, $toDetails);
				$ip = Controller::getIpAddress();

				$notf_msg1 = trans('app_lang.hi');
				$notf_msg2 = trans('app_lang.resend_email_withdraw');
				$notf_msg3 = trans('app_lang.withdraw_resend_mail');

				$msg1 = $notf_msg1 . " ," . $notf_msg2 . ' ' . $uid . "!";
				if (count(Mail::failures()) > 0) {
					echo '0';
				} else {
					echo '1';
				}
			} else {
				echo '2';
			}
		}
	}

	public function addAddress() {
		if (session('userId') != '') {
			$userId = session('userId');
			$data = Input::all();
			$Validation = Validator::make($data, [
				'add_curr' => 'required',
				'add_address' => 'required',
				'lable' => 'required',
			], [
				'add_curr.required' => 'Currency required',
				'add_address.required' => 'Address required',
				'lable.required' => 'Lable required',
			]);
			if ($Validation->fails()) {
				foreach ($Validation->messages()->getMessages() as $field => $message) {
					$response = array('success' => 0, 'message' => $message[0]);
					echo json_encode($response);exit;
				}
			}

			$now = date('Y-m-d H:i:s');
			$currency = strip_tags($data['add_curr']);
			$address = strip_tags($data['add_address']);
			$getCount = SavedAddress::where('address', $address)->where('currency', $currency)->where('user_id', $userId)->count();
			if ($getCount) {
				$response = array('success' => 0, 'message' => 'Address already exist');
				echo json_encode($response);exit;
			}
			if (isset($data['add_tag'])) {
				$tag = strip_tags($data['add_tag']);
			} else {
				$tag = '';
			}
			$lable = strip_tags($data['lable']);
			$create = array(
				'user_id' => $userId,
				'currency' => $currency,
				'status' => 'active',
				'address' => $address,
				'lable' => $lable,
				'tag' => $tag,
				'created_at' => $now,
			);
			$result = SavedAddress::create($create);
			if ($result) {
				$response = array('success' => 1, 'message' => "Address saved successfully");

			} else {
				$response = array('success' => 0, 'message' => "Please try again");
			}
			echo json_encode($response);exit;
		}
		$response = array('success' => 0, 'message' => "Login and continue");

		echo json_encode($response);exit;
	}

	public function deleteAddress() {
		if (session('userId') != '') {
			$userId = session('userId');
			$data = Input::all();
			$Validation = Validator::make($data, [
				'delete_curr' => 'required',
				'delete_address' => 'required',
			], [
				'delete_curr.required' => 'Currency required',
				'delete_address.required' => 'Address required',
			]);
			if ($Validation->fails()) {
				foreach ($Validation->messages()->getMessages() as $field => $message) {
					$response = array('success' => 0, 'message' => $message[0]);
					echo json_encode($response);exit;
				}
			}
			$currency = strip_tags($data['delete_curr']);
			$address = strip_tags($data['delete_address']);
			$getAddress = SavedAddress::where('address', $address)->where('currency', $currency)->where('user_id', $userId);
			$getCount = $getAddress->count();
			if ($getCount) {
				$result = $getAddress->delete();
				$response = array('success' => 1, 'message' => "Address deleted successfully");
			} else {
				$response = array('success' => 0, 'message' => "Invalid Address");
			}
		} else {
			$response = array('success' => 0, 'message' => "Login and continue");
		}
		echo json_encode($response);exit;
	}

	public function checkAddress(Request $request) {
		$userId = session('userId');
		$address = strip_tags($request['address']);
		$currency = strip_tags($request['currency']);
		$getCount = SavedAddress::where('address', $address)->where('currency', $currency)->where('user_id', $userId)->count();
		echo ($getCount > 0) ? "false" : "true";
	}

	public function checkAccnoExists(Request $request) {
		$userId = session('userId');
		$acc_number = strip_tags($request['account_number']);
		$update_type = strip_tags($request['type']);
		if ($update_type == 2) {
			$getCount = UserBank::where('acc_number', $acc_number)->where('user_id', '!=', $userId)->count();
		} else {
			$getCount = UserBank::where('acc_number', $acc_number)->count();
		}
		echo ($getCount > 0) ? "false" : "true";
	}

	public function updateBank() {
		if (session('userId') != '') {
			$data = Input::all();
			$userId = session('userId');
			$Validation = Validator::make($data, [
				'ifsc_number' => 'required',
				'bank_name' => 'required',
				'account_number' => 'required',
				'account_name' => 'required',
				'bank_branch' => 'required',
			], [
				'ifsc_number.required' => 'IFSC required',
				'bank_name.required' => 'Bank Name required',
				'account_number.required' => 'Account Number required',
				'account_name.required' => 'Account Name required',
				'bank_branch.required' => 'Bank Branch required',
			]);
			if ($Validation->fails()) {
				foreach ($Validation->messages()->getMessages() as $field => $message) {
					Session::flash('error', $message[0]);
					return Redirect::back();
				}
			}

			$getProfile = User::getProfile($userId);
			$currency = 'INR';
			$type = strip_tags($data['update_type']);
			$bankId = strip_tags($data['bankId']);

			if ($_FILES['bank_proof']['name'] != "") {
				$fileExtensions = ['jpeg', 'jpg', 'png'];
				$fileName = $_FILES['bank_proof']['name'];
				$fileType = $_FILES['bank_proof']['type'];

				if (($_FILES['bank_proof']['size'] >= 1048576) || ($_FILES["bank_proof"]["size"] == 0)) {
					Session::flash('error', 'File too large. File must be less than 1MB');
					return Redirect::to('settings?type=bank');
				}

				$explode = explode('.', $fileName);
				$extension = end($explode);
				$fileExtension = strtolower($extension);
				$mimeImage = mime_content_type($_FILES["bank_proof"]['tmp_name']);
				$explode = explode('/', $mimeImage);

				if (!in_array($fileExtension, $fileExtensions)) {
					Session::flash('error', trans('app_lang.Invalid file type. Only image files are accepted.'));
					return Redirect::back();
				} else {
					if ($explode[0] != "image") {
						Session::flash('error', trans('app_lang.Invalid file type. Only image files are accepted.'));
						return Redirect::back();
					}
					$cloudUpload = \Cloudinary\Uploader::upload($_FILES["bank_proof"]['tmp_name']);
					if ($cloudUpload) {
						$bank_proof = $cloudUpload['secure_url'];
					} else {
						Session::flash('error', $cloudUpload["error"]["message"]);
						return Redirect::to('settings?type=bank');
					}
				}
			} else {
				if ($type != 2) {
					Session::flash('error', 'You must submit bank proof.');
					return Redirect::to('settings?type=bank');
				}
			}
			$bank_swift = strip_tags($data['ifsc_number']);
			$insdata = array('bank_name' => strip_tags($data['bank_name']), 'bank_swift' => strtoupper($bank_swift), 'acc_name' => strip_tags($data['account_name']), 'acc_number' => strip_tags($data['account_number']), 'bank_branch' => strip_tags($data['bank_branch']), 'status' => '2', 'currency' => $currency, 'acc_type' => strip_tags($data['account_type']));
			if ($type == 2) {
				$bank_detail = UserBank::where('id', decrypText($bankId))->select('status', 'bank_proof')->first();
				$bank_status = $bank_detail->status;
				if ($bank_status != '1') {
					if ($_FILES['bank_proof']['name'] == "") {
						$insdata['bank_proof'] = $bank_detail->bank_proof;
					} else {
						$insdata['bank_proof'] = $bank_proof;
					}
					$createBank = UserBank::where('id', decrypText($bankId))->update($insdata);
					$msg1 = $getProfile['user']->consumer_name . " has updated bank details.";
					$sessionMessage = trans('app_lang.Bank details Updated Successfully');
				} else {
					Session::flash('error', 'Your bank account already verified by admin');
					return Redirect::to('settings?type=bank');
				}
			} else {
				$checkBank = UserBank::where('user_id', $userId)->where('currency', $currency)->count();
				if ($checkBank >= 5) {
					Session::flash('error', 'Bank limit reached');
					return Redirect::to('settings?type=bank');
				}

				$insdata['user_id'] = $userId;
				$insdata['bank_proof'] = $bank_proof;
				$createBank = UserBank::create($insdata);
				$msg1 = $getProfile['user']->consumer_name . " has added bank details.";
				$sessionMessage = trans('app_lang.Bank details Added Successfully');
			}
			if ($createBank) {
				$notifydata = array('admin_id' => 1, 'type' => 'KYC', 'message' => $msg1, 'status' => 'unread');
				AdminNotification::create($notifydata);
				Session::flash('success', $sessionMessage);
			} else {
				Session::flash('error', trans('app_lang.Failed to update.'));
			}
			return Redirect::to('settings?type=bank');
		}
		Session::flash('error', trans('app_lang.Please login to continue'));
		return Redirect::to('login');
	}

	public function getEditBankDetails(Request $request) {
		$bankId = $request['bankId'];
		if ($bankId != "") {
			$id = decrypText($bankId);
			$getBank = UserBank::where('id', $id)->select('currency', 'acc_name', 'acc_number', 'bank_name', 'bank_branch', 'bank_iban', 'bank_swift', 'country', 'postal', 'bank_proof', 'acc_type')->first();
			if ($getBank) {
				$getBank['ubid'] = $bankId;
				$response = array('success' => 1, 'message' => $getBank);
			} else {
				$response = array('success' => 0, 'message' => "No bank details found");
			}
		} else {
			$response = array('success' => 0, 'message' => "Invalid request");
		}
		echo json_encode($response);
	}

	public function deleteUserBank(Request $request) {
		$bankId = $request['bankId'];
		if ($bankId != "") {
			$tid = decrypText($bankId);
			$quote = UserBank::where(['id' => strip_tags($tid)])->delete();
			if ($quote) {
				$response = array('status' => 1, 'message' => trans('app_lang.bank_deleted_success'));
			} else {
				$response = array('status' => 0, 'message' => trans('app_lang.bank_deleted_fail'));
			}
		} else {
			$response = array('status' => 0, 'message' => "Invalid request");
		}
		echo json_encode($response);
	}

	public function settings() {
		if (session('userId') != '') {
			$base_url = URL::to('/');
			$userId = session('userId');

			require_once app_path('Model/Googleauthenticator.php');
			$googleAuth = new Googleauthenticator();

			$getProfile = User::where('id', $userId)->first();
			$first = decrypText($getProfile['user_mail_id']);
			$second = decrypText($getProfile['unusual_user_key']);
			$useremailid = $first . "@" . $second;

			if ($getProfile->secret == "" && $getProfile->tfa_url == "") {
				$secret = $googleAuth->createSecret();
				$tfaUrl = $googleAuth->getQRCodeGoogleUrl(SITENAME . "(" . $useremailid . ")", $secret);
				User::where('id', $userId)->update(['secret' => $secret, 'tfa_url' => $tfaUrl]);
				$getProfile['secret'] = $secret;
				$getProfile['tfa_url'] = $tfaUrl;
			}

			$country = Country::all();if ($country->isEmpty()) {$country = array();}

			$verification = ConsumerVerification::where('user_id', $userId)->first();

			$loginHistory = UserActivity::where('user_id', $userId)->orderBy('id', 'desc')->get();
			if ($loginHistory->isEmpty()) {$loginHistory = array();}

			$userbank = UserBank::where('user_id', $userId)->orderBy('id', 'desc')->select('id', 'acc_name', 'acc_number', 'bank_name', 'bank_branch', 'bank_swift', 'country', 'currency', 'status', 'beneId_status', 'user_id')->get();
			if ($userbank->isEmpty()) {$userbank = array();}

			$notify = UserNotification::where('user_id', $userId)->orderBy('id', 'desc')->get();
			return view('frontend.users.settings')->with('profile', $getProfile)->with('country', $country)->with('email', $useremailid)->with('base_url', $base_url)->with('verification', $verification)->with('history', $loginHistory)->with('notify', $notify)->with('userbank', $userbank);
		}
		return Redirect::to('login');
	}

	public function sendOtp(Request $request) {
		$userId = session('userId');
		$phone = strip_tags($request['phone']);
		$type = strip_tags($request['type']);
		if ($phone != "") {
			$user = User::where('id', $userId)->select('otp_phone', 'otp_status', 'user_mail_id', 'unusual_user_key', 'consumer_name')->first();
			if ($user) {
				if ($type == 1) {
					if ($user->otp_status == 1 && $user->otp_phone == $phone) {
						echo "Mobile number already verified";exit();
					}
					$exist = User::where('phone', $phone)->where('id', '!=', $userId)->count();
					if ($exist > 0) {
						echo "Mobile number already exists";exit();
					}
				}
				$first = decrypText($user->user_mail_id);
				$second = decrypText($user->unusual_user_key);
				$email = $first . "@" . $second;
				$phone = ltrim($phone, '0');

				$key = TWOFACTORKEY;
				$otp = randomInteger(6);
				$url = "http://2factor.in/API/V1/" . $key . "/ADDON_SERVICES/SEND/TSMS";
				$data = ['From' => TWOFACTORSENDER, 'To' => $phone, 'TemplateName' => 'sms_otp', 'VAR1' => $otp];

				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
				$response = curl_exec($ch);
				curl_close($ch);

				$getEmail = EmailTemplate::where('id', 39)->first();
				$getSiteDetails = Controller::getEmailTemplateDetails();
				$info = array('###USER###' => $user->consumer_name, '###OTP###' => $otp);
				$replace = array_merge($getSiteDetails, $info);
				$emaildata = array('content' => strtr($getEmail->template, $replace));

				$toDetails['useremail'] = $email;
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails['contact_mail_id'];
				$toDetails['name'] = $getSiteDetails['site_name'];
				$sendEmail = Controller::sendOtpEmail($emaildata, $toDetails);

				$res = json_decode($response, true);
				if ((isset($res['Status']) && $res['Status'] == "Success") || $sendEmail) {
					User::where('id', $userId)->update(['otp_phone' => $phone, 'mobile_otp' => encrypText($otp)]);
					echo "success";
				} else {
					echo "Failed to send OTP";
				}
			} else {
				echo "Invalid User";
			}
		} else {
			echo "Enter Phone number";
		}
	}

	public function updateProfile() {
		if (session('userId') != '') {
			$data = Input::all();
			$Validation = Validator::make($data, User::$profileRule);
			if ($Validation->fails()) {
				foreach ($Validation->messages()->getMessages() as $field_name => $message) {
					Session::flash('error', $message[0]);
					return Redirect::back();
				}
			} else {
				unset($data['profile_pic']);
				$userId = session('userId');
				$getUser = User::where('id', $userId)->select('profile_picture', 'otp_phone', 'mobile_otp', 'otp_status', 'country')->first();
				if ($getUser->country == 'India') {
					if ($getUser->otp_status == 1) {
						if (isset($data['otp']) && $data['otp'] != "") {
							$otp = strip_tags($data['otp']);
							if (encrypText($otp) != $getUser->mobile_otp) {
								Session::flash('error', "Invalid OTP");
								return Redirect::back();
							}
						} else {
							Session::flash('error', "Enter OTP");
							return Redirect::back();
						}

						if (strlen($data['phone']) != 10) {
							Session::flash('error', "Enter 10 digits only");
							return Redirect::back();
						}
					}
				}
				if ($_FILES['profile_pic']['name'] == "") {
					$profilePic = $getUser->profile_picture;
				} elseif ($_FILES['profile_pic']['name'] != "") {
					$fileExtensions = ['jpeg', 'jpg', 'png'];
					$fileName = $_FILES['profile_pic']['name'];
					$fileType = $_FILES['profile_pic']['type'];
					$explode = explode('.', $fileName);
					$extension = end($explode);
					$fileExtension = strtolower($extension);
					$mimeImage = mime_content_type($_FILES["profile_pic"]['tmp_name']);
					$explode = explode('/', $mimeImage);

					if (!in_array($fileExtension, $fileExtensions)) {
						Session::flash('error', trans('app_lang.Invalid file type. Only image files are accepted.'));
						return Redirect::back();
					} else {
						if ($explode[0] != "image") {
							Session::flash('error', trans('app_lang.Invalid file type. Only image files are accepted.'));
							return Redirect::back();
						}
						$cloudUpload = \Cloudinary\Uploader::upload($_FILES["profile_pic"]['tmp_name']);
						if ($cloudUpload) {
							$profilePic = $cloudUpload['secure_url'];
						} else {
							Session::flash('error', $cloudUpload["error"]["message"]);
							return Redirect::to('settings?type=profile');
						}
					}
				}
				if (strip_tags($data['country']) == 'India') {
					$otp_status = 1;
				} else {
					$otp_status = 0;
				}
				$userName = strip_tags($data['firstname']) . " " . strip_tags($data['lastname']);
				$result = User::where('id', $userId)->update(['first_name' => strip_tags($data['firstname']), 'last_name' => strip_tags($data['lastname']), 'address' => strip_tags($data['address']), 'city' => strip_tags($data['city']), 'state' => strip_tags($data['state']), 'country' => strip_tags($data['country']), 'dob' => strip_tags($data['dob']), 'profile_picture' => $profilePic, 'phone' => strip_tags($data['phone']), 'mobile_otp' => '', 'otp_status' => $otp_status]);
				if ($result) {
					ConsumerVerification::where('user_id', $userId)->update(['profile_update' => 1]);
					Session::flash('success', trans('app_lang.Profile updated successfully'));
					return Redirect::to('settings?type=profile');
				} else {
					Session::flash('error', trans('app_lang.Failed to update profile!'));
					return Redirect::to('settings?type=profile');
				}

			}
		}
		Session::flash('error', trans('app_lang.Please login to continue'));
		return Redirect::to('login');
	}

	public function checkUserPassword(Request $request) {
		if (session('userId') != '') {
			$pwd = encrypText($request['current_pwd']);
			$getCount = User::where('id', session('userId'))->where('user_protect_key', $pwd)->count();
			echo ($getCount == 1) ? "true" : "false";
		} else {
			echo "false";
		}
	}

	public function updateUserProfilePassword() {
		if (session('userId') != '') {
			$userId = session('userId');
			$profile_update = ConsumerVerification::where('user_id', $userId)->select('profile_update')->first()->profile_update;
			if ($profile_update != 1) {
				Session::flash('error', trans('app_lang.Please complete your profile details'));
				return Redirect::to('/settings?name=profile');
			}
			$data = Input::all();
			$Validation = Validator::make($data, User::$changePasswordRule);
			if ($Validation->fails()) {
				foreach ($Validation->messages()->getMessages() as $field_name => $message) {
					Session::flash('error', $message[0]);
				}
			} else {
				if ($data == array_filter($data)) {
					$userId = session('userId');
					$new_pwd = strip_tags($data['new_pwd']);
					$confirm_pwd = strip_tags($data['confirm_pwd']);
					$pwd = encrypText(strip_tags($data['current_pwd']));
					$getUser = User::where('id', $userId)->where('user_protect_key', $pwd)->select('tickets')->first();
					$getCount = count($getUser);
					if ($getCount == 1) {
						if ($new_pwd == $confirm_pwd) {
							$updateData = encrypText($confirm_pwd);
							$passtickets = $getUser->tickets;

							$tickets = unserialize($passtickets);
							if (in_array($updateData, $tickets)) {
								Session::flash('error', 'You are not supposed to use last 5 passwords');
								return Redirect::to('settings?type=password');
								exit;
							}

							if (is_array($tickets)) {
								array_unshift($tickets, $updateData);
								$old_passwords = array_slice($tickets, 0, 5);
							} else {
								$old_passwords = array($updateData);
							}

							$old_passwords = serialize($old_passwords);
							$randnum = randomString(10);

							$result = User::where('id', $userId)->update(['user_protect_key' => $updateData, 'changepassword_time' => time(), 'tickets' => $old_passwords, 'session_id' => $randnum]);

							if ($result) {
								$getCount_notify = User::where('id', $userId)->select('consumer_name', 'id', 'user_mail_id', 'unusual_user_key', 'notify_password')->first();
								if ($getCount_notify['notify_password'] == 1) {

									$first = decrypText($getCount_notify['user_mail_id']);
									$second = decrypText($getCount_notify['unusual_user_key']);
									$useremailid = $first . "@" . $second;
									$notf_msg2 = trans('app_lang.hi');
									$notf_msg3 = trans('app_lang.new_password_change_success');
									$msg1 = $notf_msg2 . " " . $getCount_notify['consumer_name'] . ", " . $notf_msg3;
									$insdata = array('user_id' => $getCount_notify['id'], 'type' => 'Change-Password', 'message' => $msg1, 'status' => 'unread');
									UserNotification::create($insdata);

									$getEmail = EmailTemplate::where('id', 24)->first();
									$getSiteDetails = Controller::getEmailTemplateDetails();
									$info = array('###USER###' => $getCount_notify['consumer_name']);

									$replace = array_merge($getSiteDetails, $info);

									$emaildata = array('content' => strtr($getEmail->template, $replace));
									$toDetails['useremail'] = $useremailid;
									$toDetails['subject'] = $getEmail->subject;
									$toDetails['from'] = $getSiteDetails['contact_mail_id'];
									$toDetails['name'] = $getSiteDetails['site_name'];

									$sendEmail = Controller::sendEmail($emaildata, $toDetails);
									if (count(Mail::failures()) > 0) {
										Session::flash('error', trans('app_lang.change_pwd_email_sending_failed'));
									} else {
										Session::flash('success', trans('app_lang.change_pwd_email_sending_success'));
									}
								}
								Session::flash('success', trans('app_lang.password_updated_success'));
							} else {
								Session::flash('error', trans('app_lang.Failed to update password!'));
							}
						} else {
							Session::flash('error', trans('app_lang.Password doesnt match!'));
						}
					} else {
						Session::flash('error', trans('app_lang.Incorrect old password'));
					}
				} else {
					Session::flash('error', trans('app_lang.Enter all fields'));
				}
			}
			return Redirect::to('settings?type=password');
		}
		Session::flash('error', trans('app_lang.Please login to continue'));
		return Redirect::to('login');
	}

	public function enableDisableTFa() {
		if (session('userId') != '') {
			$userId = session('userId');
			$profile_update = ConsumerVerification::where('user_id', $userId)->select('profile_update')->first()->profile_update;
			if ($profile_update != 1) {
				Session::flash('error', trans('app_lang.Please complete your profile details'));
				return Redirect::to('/settings?name=profile');
			}
			$data = Input::all();

			$getUserDetails = User::where('id', $userId)->first();
			$first = decrypText($getUserDetails['user_mail_id']);
			$second = decrypText($getUserDetails['unusual_user_key']);
			$useremailid = $first . "@" . $second;

			require_once app_path('Model/Googleauthenticator.php');
			$googleAuth = new Googleauthenticator();
			if ($googleAuth->verifyCode($data['secret_code'], $data['auth_key'], 1)) {
				if ($data['tfa_status'] == "disable") {
					$updateData = array('secret' => $data['secret_code'], 'tfa_url' => $data['tfa_url'], 'tfa_status' => 'enable');
					$msg = trans('app_lang.TFA enabled successfully');
					$type = 'TFA enabled';
					$notf_msg3 = 'You have enabled 2FA';
				} else {
					$secret = $googleAuth->createSecret();
					$tfaUrl = $googleAuth->getQRCodeGoogleUrl(SITENAME . "(" . $useremailid . ")", $secret);
					$updateData = array('secret' => $secret, 'tfa_url' => $tfaUrl, 'tfa_status' => 'disable');
					$type = 'TFA disabled';
					$msg = trans('app_lang.TFA disabled successfully');
					$notf_msg3 = 'You have disabled 2FA';
				}
				$result = User::where('id', $userId)->update($updateData);
				if ($result) {
					$notf_msg1 = trans('app_lang.hi');

					$ip = $_SERVER['REMOTE_ADDR'];
					$msg1 = $notf_msg1 . " ," . $notf_msg3 . "!";
					$insdata = array('user_id' => $userId, 'type' => 'New-user', 'message' => $msg1, 'status' => 'unread', 'ip' => $ip);
					UserNotification::create($insdata);

					if ($getUserDetails['notify_tfa'] == 1) {

						$getEmail = EmailTemplate::where('id', 25)->first();
						$getSiteDetails = Controller::getEmailTemplateDetails();
						$info = array('###USER###' => $getUserDetails['consumer_name'], '###TYPE###' => $type);

						$replace = array_merge($getSiteDetails, $info);

						$emaildata = array('content' => strtr($getEmail->template, $replace));
						$toDetails['useremail'] = $useremailid;
						$toDetails['subject'] = $getEmail->subject;
						$toDetails['from'] = $getSiteDetails['contact_mail_id'];
						$toDetails['name'] = $getSiteDetails['site_name'];

						$sendEmail = Controller::sendEmail($emaildata, $toDetails);

					}
					Session::flash('success', $msg);
				} else {
					Session::flash('error', trans('app_lang.Failed to update TFA verification.'));
				}
				return Redirect::to('settings?type=security');
			} else {
				Session::flash('error', trans('app_lang.Invalid 6-digit Authentication Code'));
				return Redirect::to('settings?type=security');
			}
		}
		Session::flash('error', trans('app_lang.Please login to continue'));
		return Redirect::to('login');
	}

	public function alertnotification(Request $request) {
		$userId = session('userId');
		$profile_update = ConsumerVerification::where('user_id', $userId)->select('profile_update')->first()->profile_update;
		if ($profile_update != 1) {
			$result_show = "2";
			echo $result_show;
		} else {
			$data = Input::all();
			$type = strip_tags($request['type']);
			$result_get = User::where('id', $userId)->first();
			$val = $result_get->$type;
			if ($val == '1') {
				$notf_msg = trans('app_lang.active_success');
				$message = $type . " " . $notf_msg;
				$val_res = "";
				$result_show = "0";
			} else {
				$notf_msg = trans('app_lang.deactive_fail');
				$message = $type . " " . $notf_msg;
				$val_res = "1";
				$result_show = "1";
			}
			if (!empty($type)) {
				$result = User::where('id', $userId)->update([$type => $val_res]);
				echo $result_show;
			}
		}
	}

	public function checkIdExists(Request $request) {
		$userId = session('userId');
		$id = strip_tags($request['idcard']);
		$getCount = ConsumerVerification::where('id_num', $id)->count();
		echo ($getCount > 0) ? "false" : "true";
	}

	public function updateKYC() {
		if (session('userId') != '') {
			$data = Input::all();
			$userId = session('userId');
			$getPictures = ConsumerVerification::where('user_id', $userId)->first();
			if ($getPictures->profile_update == 1) {
				$idStatus = ($getPictures->id_status == "") ? 0 : $getPictures->id_status;
				$idStatus1 = ($getPictures->id_status1 == "") ? 0 : $getPictures->id_status1;
				$addr_status = ($getPictures->addr_status == "") ? 0 : $getPictures->addr_status;

				$idProof = $getPictures->id_proof;
				$idProof1 = $getPictures->id_proof1;
				$add_proof = $getPictures->addr_proof;

				$idnum = isset($data['idnum']) ? strip_tags($data['idnum']) : $getPictures->id_num;

				if ($idStatus == 0 || $idStatus == 2) {
					/*$Validation = Validator::make($data, [
						'id_front' => "required|image",
					]);*/
					$Validation = Validator::make($data, [
					'id_front' => "required|image",
					], [
					'id_front.required' => 'Enter Valid ID Front',
					'id_front.image' => 'Given ID Front proof Must be an image', 
					]);
				}

				if ($idStatus1 == 0 || $idStatus1 == 2) {
					/*$Validation = Validator::make($data, [
						'id_back' => "required|image",
					]);*/
					$Validation = Validator::make($data, [
					'id_back' => "required|image",
					], [
					'id_back.required' => 'Enter Valid ID Back',
					'id_back.image' => 'Given ID Back proof Must be an image', 
					]);

				}

				if ($addr_status == 0 || $addr_status == 2) {
					/*$Validation = Validator::make($data, [
						'addr_proof_front' => "required|image",
					]);	*/				
					$Validation = Validator::make($data, [
					'addr_proof_front' => "required|image",
					], [
					'addr_proof_front.required' => 'Enter Valid Address proof',
					'addr_proof_front.image' => 'Given Address proof Must be an image', 
					]);
				}

				if ($Validation->fails()) {
					foreach ($Validation->messages()->getMessages() as $field_name => $message) {
						Session::flash('error', $message[0]);
						return Redirect::back();
					}
				}

				if ($idStatus != 3 && $idStatus != 1) {
					if ($_FILES['id_front']['name'] == "") {
						$idProof = $getPictures->id_proof;
					} elseif ($_FILES['id_front']['name'] != "") {
						$fileExtensions = ['jpeg', 'jpg', 'png'];
						$fileName = $_FILES['id_front']['name'];
						$fileType = $_FILES['id_front']['type'];
						$explode = explode('.', $fileName);
						$extension = end($explode);
						$fileExtension = strtolower($extension);
						$mimeImage = mime_content_type($_FILES["id_front"]['tmp_name']);
						$explode = explode('/', $mimeImage);

						if (!in_array($fileExtension, $fileExtensions)) {
							Session::flash('error', trans('app_lang.Invalid file extension.'));
							return Redirect::back();
						} else {
							if ($explode[0] != "image") {
								Session::flash('error', trans('app_lang.invalid_file_front_id'));
								return Redirect::back();
							}
							$cloudUpload = \Cloudinary\Uploader::upload($_FILES["id_front"]['tmp_name']);
							if ($cloudUpload) {
								$idProof = $cloudUpload['secure_url'];
								$idStatus = 1;
							} else {
								Session::flash('error', trans('app_lang.Error uploading front ID proof.'));
								return Redirect::back();
							}
						}
					}
				} else {
					$idProof = $getPictures->id_proof;
				}

				if ($idStatus1 != 3 && $idStatus1 != 1) {
					if ($_FILES['id_back']['name'] == "") {
						$idProof1 = $getPictures->id_proof1;
					} elseif ($_FILES['id_back']['name'] != "") {
						$fileExtensions = ['jpeg', 'jpg', 'png'];
						$fileName = $_FILES['id_back']['name'];
						$fileType = $_FILES['id_back']['type'];
						$explode = explode('.', $fileName);
						$extension = end($explode);
						$fileExtension = strtolower($extension);
						$mimeImage = mime_content_type($_FILES["id_back"]['tmp_name']);
						$explode = explode('/', $mimeImage);

						if (!in_array($fileExtension, $fileExtensions)) {
							Session::flash('error', trans('app_lang.Invalid file extension.'));
							return Redirect::back();
						} else {
							if ($explode[0] != "image") {
								Session::flash('error', trans('app_lang.invalid_file_back_id'));
								return Redirect::back();
							}
							$cloudUpload = \Cloudinary\Uploader::upload($_FILES["id_back"]['tmp_name']);
							if ($cloudUpload) {
								$idProof1 = $cloudUpload['secure_url'];
								$idStatus1 = 1;
							} else {
								Session::flash('error', trans('app_lang.Error uploading Back ID proof.'));
								return Redirect::back();
							}
						}
					}
				} else {
					$idProof1 = $getPictures->id_proof1;
				}

				if ($addr_status != 3 && $addr_status != 1) {
					if ($_FILES['addr_proof_front']['name'] == "") {
						$addr_proof_front = $getPictures->addr_proof;

					} elseif ($_FILES['addr_proof_front']['name'] != "") {
						$fileExtensions = ['jpeg', 'jpg', 'png'];
						$fileName = $_FILES['addr_proof_front']['name'];
						$fileType = $_FILES['addr_proof_front']['type'];
						$explode = explode('.', $fileName);
						$extension = end($explode);
						$fileExtension = strtolower($extension);
						$mimeImage = mime_content_type($_FILES["addr_proof_front"]['tmp_name']);
						$explode = explode('/', $mimeImage);

						if (!in_array($fileExtension, $fileExtensions)) {
							Session::flash('error', trans('app_lang.Invalid file extension.'));
							return Redirect::back();
						} else {
							if ($explode[0] != "image") {
								Session::flash('error', trans('app_lang.Invalid file type. Only image files are accepted.'));
								return Redirect::back();
							}
							$cloudUpload = \Cloudinary\Uploader::upload($_FILES["addr_proof_front"]['tmp_name']);
							if ($cloudUpload) {
								$addr_proof_front = $cloudUpload['secure_url'];
								$addr_status = 1;

							} else {
								Session::flash('error', trans('app_lang.Error uploading Address proof.'));
								return Redirect::back();
							}
						}
					}
				} else {
					$addr_proof_front = $getPictures->addr_proof;
				}

				if ($idStatus == 3 && $idStatus1 == 3 && $addr_status == 3) {
					$verifyStatus = 3;
				} else if ($idStatus == 2 || $idStatus1 == 2 || $addr_status == 2) {
					$verifyStatus = 2;
				} else {
					$verifyStatus = 1;
				}

				$result = ConsumerVerification::where('user_id', $userId)->update(['id_proof' => $idProof, 'addr_proof' => $addr_proof_front, 'id_status' => $idStatus, 'id_proof1' => $idProof1, 'id_status1' => $idStatus1, 'addr_status' => $addr_status, 'id_num' => $idnum]);

				if ($result) {
					User::where('id', $userId)->update(['verified_status' => $verifyStatus]);
					$getProfile = User::getProfile($userId);
					$msg1 = $getProfile['user']->consumer_name . " has submitted KYC document.";
					$insdata = array('admin_id' => 1, 'type' => 'KYC', 'message' => $msg1, 'status' => 'unread');
					AdminNotification::create($insdata);
					Session::flash('success', trans('app_lang.KYC Updated Successfully'));
				} else {
					Session::flash('error', trans('app_lang.Failed to update.'));
				}
				return Redirect::to('settings?type=kyc');

			} else {
				Session::flash('error', trans('app_lang.Please complete your profile details'));
				return Redirect::to('settings?type=profile');
			}
		}
		Session::flash('error', trans('app_lang.Please login to continue'));
		return Redirect::to('login');
	}

	public function enable_key() {
		if (session('userId') != '') {
			$userId = session('userId');

			$getUserDetails = User::where('id', $userId)->select('user_mail_id', 'unusual_user_key', 'consumer_name')->first();
			$first = decrypText($getUserDetails['user_mail_id']);
			$second = decrypText($getUserDetails['unusual_user_key']);
			$useremailid = $first . "@" . $second;

			$update = User::where('id', $userId)->update(['api_status' => '2']);

			$getEmail = EmailTemplate::where('id', 41)->first();
			$getSiteDetails = Controller::getEmailTemplateDetails();
			$info = array('###USER###' => $getUserDetails['consumer_name'], '###MAIL###' => $useremailid);

			$replace = array_merge($getSiteDetails, $info);

			$emaildata = array('content' => strtr($getEmail->template, $replace));
			$toDetails['useremail'] = $getSiteDetails['contact_mail_id'];
			$toDetails['subject'] = $getEmail->subject;
			$toDetails['from'] = $getSiteDetails['contact_mail_id'];
			$toDetails['name'] = $getSiteDetails['site_name'];
			$sendEmail = Controller::sendEmail($emaildata, $toDetails, '', '');
			if ($sendEmail) {
				Session::flash('success', 'API request send to admin Successfully');
			} else {
				Session::flash('error', 'Please try again!');
			}
			return Redirect::to('settings?type=security');
		}
	}

	public function with_password() {
		if (session('userId') != '') {
			$userId = session('userId');
			$data = Input::all();
			$validate = Validator::make($data, [
				'with_pass' => "required|min:6",
				'with_pass_confirm' => "required|min:6",
			], [
				'with_pass.required' => 'Please Enter withdraw password',
				'with_pass.min' => 'Please Enter minimum 6 characters',
				'with_pass_confirm.required' => 'Please Enter confirm withdraw password',
				'with_pass_confirm.min' => 'Please Enter minimum 6 characters',
			]);

			if ($validate->fails()) {
				foreach ($validate->messages()->getMessages() as $val => $msg) {
					Session::flash('error', $msg[0]);
					return Redirect::back();
				}
			}
			$with_pass = strip_tags($data['with_pass']);
			$with_pass_confirm = strip_tags($data['with_pass_confirm']);
			if ($with_pass == $with_pass_confirm) {
				$userdetails = User::where('id', $userId)->select('with_status')->first();
				if ($userdetails) {
					if ($userdetails->with_status == 0) {
						$pass = $userId . strip_tags($data['with_pass']);
						$encPass = Hash::make($pass);
						$update = User::where('id', $userId)->update(['with_pass' => $encPass, 'with_status' => 1]);
						if ($update) {
							Session::flash('success', 'Withdraw password enabled successfully');
						} else {
							Session::flash('error', 'Please try again later');
						}
					} else {
						Session::flash('error', 'Already enabled');
					}
				} else {
					Session::flash('error', 'Invalid user');
				}
			} else {
				Session::flash('error', 'Withdraw password and Confirm withdraw password should be same');
			}
			return Redirect::back();
		}
	}

	public function referral() {
		if (session('userId') != '') {
			$userId = session('userId');
			$getId = User::where('id', $userId)->select('refer_id')->first();
			$referId = $getId->refer_id;
			$referral['refer_id'] = $referId;

			$listUsers = User::where('referrer_id', $referId)->select('user_mail_id', 'unusual_user_key', 'created_at', 'status', 'consumer_name', 'refer_amount')->orderBy('id', 'desc')->get();
			if ($listUsers->isEmpty()) {
				$listUsers = array();
			}
			$referral['users'] = $listUsers;

			$referrralCommission = ReferralCommision::where('refer_by_id', $userId)->select('commision_fee', 'commision_fee', 'refer_by_id', 'created_at', 'user_id')->orderBy('refer_com_id', 'desc')->get();
			if ($referrralCommission->isEmpty()) {
				$referrralCommission = array();
			}
			$site = Sitesettings::where('id', 1)->select('fb_url', 'twitter_url', 'linkedin_url', 'tele_url', 'watsup_url')->first();
			return view('frontend.users.referral')->with('referral', $referral)->with('referrralCommission', $referrralCommission)->with('site', $site);
		}
		Session::flash('error', trans('app_lang.Please login to continue'));
		return Redirect::to('login');
	}

	public function history() {
		if (session('userId') != '') {
			$tradePairs = TradePairs::where('site_status', '1')->select('pair_name')->get();
			return view('frontend.users.history')->with('tradePairs', $tradePairs);
		}
		Session::flash('error', trans('app_lang.Please login to continue'));
		return Redirect::to('login');
	}

	public function deposit_history($type = 1, $curr = '') {
		$id = session('userId');
		$totalrecords = intval(Input::get('totalrecords'));
		$draw = Input::get('draw');
		$start = Input::get('start');
		$length = Input::get('length');
		$sorttype = Input::get('order');
		$sort_col = $sorttype['0']['column'];
		$sort_type = $sorttype['0']['dir'];
		$search = Input::get('search');
		$from_date = Input::get('from');
		$to_date = Input::get('to');
		$deposit_type = Input::get('deposit_type');
		$search = $search['value'];
		if ($sort_col == '2') {
			$sort_col = 'updated_at';
		} else if ($sort_col == '3') {
			$sort_col = 'currency';
		} else if ($sort_col == '4') {
			$sort_col = 'amount';
		} else if ($sort_col == '5') {
			$sort_col = 'fees';
		} else if ($sort_col == '6') {
			$sort_col = 'total';
		} else if ($sort_col == '7') {
			$sort_col = 'address_info';
		} else if ($sort_col == '8') {
			$sort_col = 'reference_no';
		} else if ($sort_col == '9') {
			$sort_col = 'status';
		} else {
			$sort_col = "id";
		}
		if ($sort_type == 'asc') {
			$sort_type = 'desc';
		} else {
			$sort_type = 'asc';
		}
		$data = $orders = array();

		if ($curr == '') {
			if ($deposit_type == "Bank") {
				$deposit = Deposit::where('user_id', $id)->where('payment_method', "Bank");
			} else {
				$deposit = Deposit::where('user_id', $id)->where('payment_method', '!=', "Bank");
			}
		} else {
			if ($deposit_type == "Bank") {
				$deposit = Deposit::where('user_id', $id)->where('currency', $curr)->where('payment_method', "Bank");
			} else {
				if ($curr == 'INR') {
					$deposit = Deposit::where('user_id', $id)->where('currency', $curr)->where('payment_method', "Bank");
				} else {
					$deposit = Deposit::where('user_id', $id)->where('currency', $curr)->where('payment_method', '!=', "Bank");
				}
			}
		}
		if ($search != '') {
			$deposit = $deposit->where(function ($q) use ($search) {
				$q->where('reference_no', 'like', '%' . $search . '%')->orWhere('currency', 'like', '%' . $search . '%')->orWhere('address_info', 'like', '%' . $search . '%')->orWhere('amount', 'like', '%' . $search . '%')->orWhere('fees', 'like', '%' . $search . '%')->orWhere('total', 'like', '%' . $search . '%')->orWhere('updated_at', 'like', '%' . $search . '%')->orWhere('status', 'like', '%' . $search . '%')->orWhere('payment_method', 'like', '%' . $search . '%')->orWhere('payment_type', 'like', '%' . $search . '%');}
			);
		}

		if ($from_date) {
			$deposit = $deposit->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
		}

		if ($to_date) {
			$deposit = $deposit->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
		}

		$deposit_count = $deposit->count();
		if ($deposit_count) {

			$deposit = $deposit->select('updated_at', 'address_info', 'transaction_number', 'currency', 'amount', 'fees', 'total', 'status', 'payment_method', 'reference_no', 'payment_type', 'trans_type');

			$orders = $deposit->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
		}

		$txUrl = array(
			'BTC' => 'https://live.blockcypher.com/btc/tx/',
			'ETH' => 'https://etherscan.io/tx/',
			'USDT' => 'https://etherscan.io/tx/',
			'LTC' => 'https://live.blockcypher.com/ltc/tx/',
			'BCH' => 'https://explorer.bitcoin.com/bch/tx/',
			'DASH' => 'https://live.blockcypher.com/dash/tx/', 
			'XRP' => 'https://bithomp.com/explorer/', 
		);

		$data = array();
		$no = $start + 1;

		if ($deposit_count) {
			foreach ($orders as $r) {
				$address = $r['address_info'];
				$tx = $r['reference_no'];
				$dcur = $r['currency'];
				if (($r['currency'] == 'INR' || $r['currency'] == 'USDT') && $r['payment_method'] == 'bank') {
					$amount = number_format($r['amount'], 2, '.', ',');
					$fees = number_format($r['fees'], 2, '.', ',');
					$total = number_format($r['total'], 2, '.', ',');
				} else {
					$amount = number_format($r['amount'], 8, '.', ',');
					$fees = $total = '-';
				}

				if ($r['payment_method'] == 'bank') {
					$trans_id = $tx;
					$pay_type = ($r['payment_type'] != '' && ($r['payment_type'] == 'cashfree' || $r['payment_type'] == '')) ? 'Instant' : $r['payment_type'];
					$payment = ($r['payment_type'] != '') ? "Bank" . '-' . $pay_type : 'Bank';
					$confirm = '-';
				} else {
					if ($r['trans_type'] == 'External') {
						$redirect = $txUrl[$dcur] . $tx;
						$trans_id = '<a class="word-break" href="' . $redirect . '" target="_blank">' . $tx . '</a>';
					} else {
						$trans_id = $tx;
					}
					$payment = "Wallet";
					$confirmations = Currency::where('currency_symbol', $dcur)->select('confirmations')->first()->confirmations;
					$confirm = "Confirmed";
				}

				if ($r['status'] == 'completed') {
					$completed = URL::to('public/frontend/img/tick.png');
					$status = '<img src="' . $completed . '" alt="Completed" title="Completed">';
				} else if ($r['status'] == 'pending') {
					$pending = URL::to('public/frontend/img/pending.png');
					$status = '<img src="' . $pending . '" alt="Pending" title="Pending">';
				} else if ($r['status'] == 'cancelled') {
					$cancel = URL::to('public/frontend/img/cancel.png');
					$status = '<img src="' . $cancel . '" alt="Cancelled" title="Cancelled">';
				} else {
					$status = '<span style="color:red">' . $r['status'] . '</span>';
				}

				$copy = '<input type="hidden" id="copy_tag_' . $no . '" value="' . $tx . '">';
				$cid = '#copy_tag_' . $no;

				$cImg = URL::to('public/frontend/icons/copy-sm.png');
				$copyImg = '<img src="' . $cImg . '" class="copy_trans mr-1" data-id="' . $cid . '" title="Copy">';
				$tid = '<div class="d-flex align-items-start">' . $copyImg . $copy . '<span title="' . $tx . '"></span>' . $trans_id . '</div>';
				array_push($data, array(
					$no,
					$r['updated_at'],
					$r['currency'],
					$payment,
					$amount,
					$fees,
					$total,
					$tid,
					$status,
					$confirm,
				));
				$no++;
			}

			echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $deposit_count, 'recordsFiltered' => $deposit_count, 'data' => $data));
		} else {

			echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $deposit_count, 'recordsFiltered' => $deposit_count, 'data' => array()));
		}
	}

	public function pending_deposit_history($type = 1, $curr = '') {
		$id = session('userId');
		$totalrecords = intval(Input::get('totalrecords'));
		$draw = Input::get('draw');
		$start = Input::get('start');
		$length = Input::get('length');
		$sorttype = Input::get('order');
		$sort_col = $sorttype['0']['column'];
		$sort_type = $sorttype['0']['dir'];
		$search = Input::get('search');
		$from_date = Input::get('from');
		$to_date = Input::get('to');
		$search = $search['value'];
		if ($sort_col == '2') {
			$sort_col = 'updated_at';
		} else if ($sort_col == '3') {
			$sort_col = 'currency';
		} else if ($sort_col == '4') {
			$sort_col = 'amount';
		} else if ($sort_col == '5') {
			$sort_col = 'address_info';
		} else if ($sort_col == '5') {
			$sort_col = 'reference_no';
		} else if ($sort_col == '6') {
			$sort_col = 'status';
		} else {
			$sort_col = "id";
		}
		if ($sort_type == 'asc') {
			$sort_type = 'desc';
		} else {
			$sort_type = 'asc';
		}
		$data = $orders = array();

		if ($curr == '') {
			$deposit = PendingDeposit::where('user_id', $id)->where('status', 'pending');
		} else {
			$deposit = PendingDeposit::where('user_id', $id)->where('currency', $curr)->where('status', 'pending');
		}
		if ($search != '') {
			$deposit = $deposit->where(function ($q) use ($search) {
				$q->where('reference_no', 'like', '%' . $search . '%')->orWhere('currency', 'like', '%' . $search . '%')->orWhere('address_info', 'like', '%' . $search . '%')->orWhere('amount', 'like', '%' . $search . '%')->orWhere('fees', 'like', '%' . $search . '%')->orWhere('total', 'like', '%' . $search . '%')->orWhere('updated_at', 'like', '%' . $search . '%')->orWhere('status', 'like', '%' . $search . '%')->orWhere('payment_method', 'like', '%' . $search . '%')->orWhere('payment_type', 'like', '%' . $search . '%');}
			);
		}

		if ($from_date) {
			$deposit = $deposit->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
		}

		if ($to_date) {
			$deposit = $deposit->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
		}

		$deposit_count = $deposit->count();
		if ($deposit_count) {

			$deposit = $deposit->select('updated_at', 'address_info', 'transaction_number', 'currency', 'amount', 'fees', 'total', 'status', 'payment_method', 'reference_no', 'payment_type', 'trans_type', 'block_confirm');

			$orders = $deposit->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
		}

		$data = array();
		$no = $start + 1;

		if ($deposit_count) {
			foreach ($orders as $r) {
				$address = $r['address_info'];
				$tx = $r['reference_no'];
				$amount = number_format($r['amount'], 9, '.', ',');
				$fees = $total = '-';
				$dcur = $r['currency'];
				$confirmations = Currency::where('currency_symbol', $dcur)->select('confirmations')->first()->confirmations;
				if ($r['trans_type'] == 'External') {
					$txUrl = array(
						'BTC' => 'https://live.blockcypher.com/btc/tx/',
						'ETH' => 'https://etherscan.io/tx/',
						'USDT' => 'https://etherscan.io/tx/',
						'LTC' => 'https://live.blockcypher.com/ltc/tx/',
						'BCH' => 'https://explorer.bitcoin.com/bch/tx/',
						'DASH' => 'https://live.blockcypher.com/dash/tx/', 
						'XRP' => 'https://bithomp.com/explorer/', 
					);
					$redirect = $txUrl[$dcur] . $tx;
					$trans_id = '<a class="word-break" href="' . $redirect . '" target="_blank">' . $tx . '</a>';
				} else {
					$trans_id = $tx;
				}

				if ($r['status'] == 'completed') {
					$completed = URL::to('public/frontend/img/tick.png');
					$status = '<img src="' . $completed . '" alt="Completed" title="Completed">';
				} else if ($r['status'] == 'pending') {
					$pending = URL::to('public/frontend/img/pending.png');
					$status = '<img src="' . $pending . '" alt="Pending" title="Pending">';
				} else if ($r['status'] == 'cancelled') {
					$cancel = URL::to('public/frontend/img/cancel.png');
					$status = '<img src="' . $cancel . '" alt="Cancelled" title="Cancelled">';
				} else {
					$status = '<span style="color:red">' . $r['status'] . '</span>';
				}

				$copy = '<input type="hidden" id="copy_tag_' . $no . '" value="' . $tx . '">';
				$cid = '#copy_tag_' . $no;

				$cImg = URL::to('public/frontend/icons/copy-sm.png');
				$copyImg = '<img src="' . $cImg . '" class="copy_trans mr-1" data-id="' . $cid . '" title="Copy">';
				$tid = '<div class="d-flex align-items-start">' . $copyImg . $copy . '<span title="' . $tx . '"></span>' . $trans_id . '</div>';

				array_push($data, array(
					$no,
					$r['updated_at'],
					$r['currency'],
					"Wallet",
					$amount,
					$fees,
					$total,
					$tid,
					$status,
					$r['block_confirm'] . '/' . $confirmations,
				));
				$no++;
			}

			echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $deposit_count, 'recordsFiltered' => $deposit_count, 'data' => $data));
		} else {

			echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $deposit_count, 'recordsFiltered' => $deposit_count, 'data' => array()));
		}
	}

	public function withdraw_history($type = 1, $curr = '') {
		$id = session('userId');
		$totalrecords = intval(Input::get('totalrecords'));
		$draw = Input::get('draw');
		$start = Input::get('start');
		$length = Input::get('length');
		$sorttype = Input::get('order');
		$sort_col = $sorttype['0']['column'];
		$sort_type = $sorttype['0']['dir'];
		$search = Input::get('search');
		$from_date = Input::get('from');
		$to_date = Input::get('to');
		$withdraw_type = Input::get('withdraw_type');
		$search = $search['value'];

		if ($sort_col == '2') {
			$sort_col = 'updated_at';
		} else if ($sort_col == '3') {
			$sort_col = 'currency';
		} else if ($sort_col == '4') {
			$sort_col = 'amount';
		} else if ($sort_col == '5') {
			$sort_col = 'fees_amt';
		} else if ($sort_col == '5') {
			$sort_col = 'total';
		} else if ($sort_col == '6') {
			$sort_col = 'address_info';
		} else if ($sort_col == '6') {
			$sort_col = 'reference_no';
		} else if ($sort_col == '7') {
			$sort_col = 'status';
		} else {
			$sort_col = "id";
		}
		if ($sort_type == 'asc') {
			$sort_type = 'desc';
		} else {
			$sort_type = 'asc';
		}

		$data = $orders = array();
		if ($curr == '') {
			if($type == 2) {
				if($withdraw_type == "Bank") {
					$withdraw = Withdraw::where('user_id', $id)->where('payment_method', "Bank");
				} else { 
					$withdraw = Withdraw::where('user_id', $id)->where('payment_method', "!=" ,"Bank");
				}
			} else {
				$withdraw = Withdraw::where('user_id', $id);
			}
		} else {
			if($type == 2) {
				if($withdraw_type == "Bank") {
					$withdraw = Withdraw::where('user_id', $id)->where('currency', $curr)->where('payment_method', "Bank");
				} else {
					$withdraw = Withdraw::where('user_id', $id)->where('currency', $curr)->where('payment_method', "!=" ,"Bank");
				}
			}  else {
				$withdraw = Withdraw::where('user_id', $id)->where('currency', $curr);
			}
		}
		if ($search != '') {
			$withdraw = $withdraw->where(function ($q) use ($search) {
				$q->where('reference_no', 'like', '%' . $search . '%')->orWhere('currency', 'like', '%' . $search . '%')->orWhere('address_info', 'like', '%' . $search . '%')->orWhere('amount', 'like', '%' . $search . '%')->orWhere('updated_at', 'like', '%' . $search . '%')->orWhere('status', 'like', '%' . $search . '%')->orWhere('fees_amt', 'like', '%' . $search . '%')->orWhere('total', 'like', '%' . $search . '%')->orWhere('payment_method', 'like', '%' . $search . '%');}
			);
		}

		if ($from_date) {
			$withdraw = $withdraw->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
		}

		if ($to_date) {
			$withdraw = $withdraw->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
		}

		$withdraw_count = $withdraw->count();
		if ($withdraw_count) {

			$withdraw = $withdraw->select('updated_at', 'address_info', 'transaction_number', 'currency', 'amount', 'status', 'fees_amt', 'id', 'reference_no', 'total', 'payment_method', 'user_id', 'trans_type', 'wallet_type');

			$orders = $withdraw->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
		}

		$txUrl = array(
			'BTC' => 'https://live.blockcypher.com/btc/tx/',
			'ETH' => 'https://etherscan.io/tx/',
			'USDT' => 'https://etherscan.io/tx/',
			'LTC' => 'https://live.blockcypher.com/ltc/tx/',
			'BCH' => 'https://explorer.bitcoin.com/bch/tx/',
			'DASH' => 'https://live.blockcypher.com/dash/tx/', 
			'XRP' => 'https://bithomp.com/explorer/', 
		);

		$data = array();
		$no = $start + 1;

		if ($withdraw_count) {
			foreach ($orders as $r) {
				$id = $r['id'];
				$user_id = $r['user_id'];
				$tx = $r['reference_no'];
				$wcur = $r['currency'];

				if ($r['currency'] == 'INR') {
					$amount = number_format($r['amount'], 2, '.', ',');
					$fees = number_format($r['fees_amt'], 2, '.', ',');
					$total = number_format($r['total'], 2, '.', ',');
					$address = '-';
				} else {
					$amount = number_format($r['amount'], 8, '.', ',');
					$fees = number_format($r['fees_amt'], 8, '.', ',');
					$total = number_format($r['total'], 8, '.', ',');
					$address = $r['address_info'];
				}

				if ($tx != '') {
					if ($r['payment_method'] == 'bank') {
						$payment = "Bank";
						$trans_id = $tx;
					} else {
						if ($r['trans_type'] == 'External') {
							$redirect = $txUrl[$wcur] . $tx;
							$trans_id = '<a class="word-break" href="' . $redirect . '" target="_blank">' . $tx . '</a>';
						} else {
							$trans_id = $tx;
						}
						$payment = "Wallet";
					}
				} else {
					$trans_id = $tx;
					$payment = ($r['payment_method'] == 'bank') ? 'Bank' : 'Wallet';
				}

				$url = URL::to('withdrawResendEmail/' . encrypText($id) . '/' . encrypText($user_id));
				if ($r['status'] == 'in progress') {
					$link = '<a class="resend_mail" data-id="' . encrypText($id) . '" data-id1="' . encrypText($user_id) . '" >Resend Mail</a>';
				} else {
					$link = '-';
				}

				if ($r['status'] == 'completed') {
					$completed = URL::to('public/frontend/img/tick.png');
					$status = '<img src="' . $completed . '" alt="Completed" title="Completed">';
				} else if ($r['status'] == 'in progress') {
					$inprogress = URL::to('public/frontend/img/inprogress.png');
					$status = '<img src="' . $inprogress . '" alt="Inprogress" title="Inprogress">';
				} else if ($r['status'] == 'pending') {
					$pending = URL::to('public/frontend/img/pending.png');
					$status = '<img src="' . $pending . '" alt="Pending" title="Pending">';
				} else if ($r['status'] == 'cancelled') {
					$cancel = URL::to('public/frontend/img/cancel.png');
					$status = '<img src="' . $cancel . '" alt="Cancelled" title="Cancelled">';
				} else {
					$status = '<span style="color:red">' . $r['status'] . '</span>';
				}

				if ($trans_id != '') {
					$copy = '<input type="hidden" id="copy_tag_' . $no . '" value="' . $tx . '">';
					$cid = '#copy_tag_' . $no;
					$cImg = URL::to('public/frontend/icons/copy-sm.png');
					$copyImg = '<img src="' . $cImg . '" class="copy_trans mr-1" data-id="' . $cid . '" title="Copy">';
					$tid = '<div class="d-flex align-items-start">' . $copyImg . $copy . '<span title="' . $tx . '"></span>' . $trans_id . '</div>';
				} else {
					$tid = '-';
				}

				$res = explode(' ', $r['updated_at']);
				$date = $res[0];
				$time = $res[1];
				$datetime = '<span>' . $date . '</span> <span>' . $time . '</span>';

				array_push($data, array(
					$no,
					$datetime,
					$r['currency'],
					$payment,
					$amount,
					$fees,
					$total,
					$tid,
					$status,
					$link,
				));
				$no++;
			}

			echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $withdraw_count, 'recordsFiltered' => $withdraw_count, 'data' => $data));
		} else {
			echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $withdraw_count, 'recordsFiltered' => $withdraw_count, 'data' => array()));
		}
	}

	public function open_history() {
		$id = session('userId');
		$totalrecords = intval(Input::get('totalrecords'));
		$draw = Input::get('draw');
		$start = Input::get('start');
		$length = Input::get('length');
		$sorttype = Input::get('order');
		$sort_col = $sorttype['0']['column'];
		$sort_type = $sorttype['0']['dir'];
		$search = Input::get('search');
		$from_date = Input::get('from');
		$to_date = Input::get('to');
		$search = $search['value'];
		$stype = Input::get('stype');

		if ($sort_col == '2') {
			$sort_col = 'created_at';
		} else if ($sort_col == '3') {
			$sort_col = 'Type';
		} else if ($sort_col == '4') {
			$sort_col = 'firstCurrency';
		} else if ($sort_col == '5') {
			$sort_col = 'secondCurrency';
		} else if ($sort_col == '6') {
			$sort_col = 'Amount';
		} else if ($sort_col == '7') {
			$sort_col = 'Price';
		} else if ($sort_col == '8') {
			$sort_col = 'Total';
		} else {
			$sort_col = "id";
		}
		if ($sort_type == 'asc') {
			$sort_type = 'desc';
		} else {
			$sort_type = 'asc';
		}

		$data = $orders = array();
		$open = CoinOrder::where('user_id', $id)->whereIn('status', ['active', 'partially'])->where('pair', $stype);
		if ($search != '') {
			$open = $open->where(function ($q) use ($search) {
				$q->where('Price', 'like', '%' . $search . '%')->orWhere('Amount', 'like', '%' . $search . '%')->orWhere('Type', 'like', '%' . $search . '%')->orWhere('firstCurrency', 'like', '%' . $search . '%')->orWhere('secondCurrency', 'like', '%' . $search . '%')->orWhere('status', 'like', '%' . $search . '%')->orWhere('Total', 'like', '%' . $search . '%')->orWhere('created_at', 'like', '%' . $search . '%')->orWhere('pair', 'like', '%' . $search . '%');}
			);
		}

		if ($from_date) {
			$open = $open->where('created_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
		}

		if ($to_date) {
			$open = $open->where('created_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
		}

		$open_count = $open->count();
		if ($open_count) {

			$open = $open->select('id', 'Price', 'Amount', 'Type', 'status', 'created_at', 'firstCurrency', 'secondCurrency');

			$orders = $open->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
		}

		$data = array();
		$no = $start + 1;

		if ($open_count) {
			foreach ($orders as $active) {
				$orderId = $active['id'];
				$activePrice = $active['Price'];
				$activeAmount = $active['Amount'];
				$type = $active['Type'];
				$orderTime = $active['created_at'];
				$status = $active['status'];
				$firstCurrency = $active['firstCurrency'];
				$secondCurrency = $active['secondCurrency'];
				if ($status == "active") {
					$filledAmount = $activeAmount;
				} else {
					$filledAmount = TradeModel::checkFilledAmount($orderId, $type);
					$filledAmount = ($filledAmount) ? $activeAmount - $filledAmount : $activeAmount;
				}
				$tradeid = encrypText($orderId);
				$filledAmount = number_format($filledAmount, 8, '.', '');

				$activePrice = number_format($activePrice, 8, '.', '');

				if ($type == "Buy") {
					$total = $filledAmount * $activePrice;
				} else {
					$total = $filledAmount * $activePrice;
				}
				$total = number_format($total, 8, '.', '');
				array_push($data, array(
					$no,
					$orderTime,
					$type,
					$firstCurrency,
					$secondCurrency,
					$filledAmount,
					$activePrice,
					$total,
				));
				$no++;
			}

			echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $open_count, 'recordsFiltered' => $open_count, 'data' => $data));
		} else {

			echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $open_count, 'recordsFiltered' => $open_count, 'data' => array()));
		}
	}

	public function completed_history() {
		$uid = session('userId');
		$totalrecords = intval(Input::get('totalrecords'));
		$draw = Input::get('draw');
		$start = Input::get('start');
		$length = Input::get('length');
		$sorttype = Input::get('order');
		$sort_col = $sorttype['0']['column'];
		$sort_type = $sorttype['0']['dir'];
		$search = Input::get('search');
		$from_date = Input::get('from');
		$to_date = Input::get('to');
		$search = $search['value'];
		$stype = Input::get('stype');

		if ($sort_col == '2') {
			$sort_col = 'updated_at';
		} else if ($sort_col == '3') {
			$sort_col = 'firstCurrency';
		} else if ($sort_col == '4') {
			$sort_col = 'secondCurrency';
		} else if ($sort_col == '5') {
			$sort_col = 'filledAmount';
		} else if ($sort_col == '6') {
			$sort_col = 'askPrice';
		} else {
			$sort_col = "id";
		}
		if ($sort_type == 'asc') {
			$sort_type = 'desc';
		} else {
			$sort_type = 'asc';
		}

		$data = $orders = array();
		$completed = OrderTemp::where('pair', $stype)->where(function ($q) use ($uid) {$q->where('buyerUserId', $uid)->orWhere('sellerUserId', $uid);});

		if ($search != '') {
			$completed = $completed->where(function ($q) use ($search) {
				$q->where('firstCurrency', 'like', '%' . $search . '%')->orWhere('secondCurrency', 'like', '%' . $search . '%')->orWhere('filledAmount', 'like', '%' . $search . '%')->orWhere('askPrice', 'like', '%' . $search . '%')->orWhere('updated_at', 'like', '%' . $search . '%');}
			);
		}

		if ($from_date) {
			$completed = $completed->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
		}

		if ($to_date) {
			$completed = $completed->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
		}

		$completed_count = $completed->count();
		if ($completed_count) {

			$completed = $completed->select('sellerUserId', 'buyerUserId', 'askPrice', 'filledAmount', 'cancel_id', 'sellorderId', 'buyorderId', 'updated_at', 'buy_fee', 'sell_fee', 'firstCurrency', 'secondCurrency', 'pair');

			$orders = $completed->skip($start)->take($length)->groupBy('id')->orderBy($sort_col, $sort_type)->get()->toArray();
		}

		$data = array();
		$no = $start + 1;

		if ($completed_count) {
			foreach ($orders as $order) {
				$sellUser = $order['sellerUserId'];
				$buyUser = $order['buyerUserId'];
				$cancelId = $order['cancel_id'];
				$filledAmount = $order['filledAmount'];
				$askPrice = $order['askPrice'];
				$updatedAt = $order['updated_at'];
				$buy_fee = $order['buy_fee'];
				$sell_fee = $order['sell_fee'];
				$from = $order['firstCurrency'];
				$to = $order['secondCurrency'];

				$total = $filledAmount * $askPrice;
				$status = ($cancelId != "") ? "Cancelled" : "Filled";

				$activeAmount = number_format($filledAmount, 8, '.', '');
				$activePrice = number_format($askPrice, 8, '.', '');
				$activeTotal = number_format($total, 8, '.', '');

				$stsCls = ($status == "Cancelled") ? 'class="minus_value"' : 'class="plus_value"';

				if ($status == "Cancelled") {
					$cancel = URL::to('public/frontend/img/cancel.png');
					$status = '<img src="' . $cancel . '" alt="Cancelled" title="Cancelled">';
				} else {
					$completed = URL::to('public/frontend/img/tick.png');
					$status = '<img src="' . $completed . '" alt="Completed" title="Completed">';
				}

				if ($buyUser == $uid) {
					$type = "Buy";
					$fees = $buy_fee . " " . $from;
					$className = 'class="plus_value"';
					if ($sellUser == $uid) {
						$type = "Sell";
						$fees = $sell_fee;
						$classNam = 'class="minus_value"';
					}
				} else {
					$type = "Sell";
					$fees = $sell_fee . " " . $to;
					$className = 'class="minus_value"';
				}

				array_push($data, array(
					$no,
					$updatedAt,
					$type,
					$from,
					$to,
					$activeAmount,
					$activePrice,
					$activeTotal,
					$status,
				));
				$no++;
			}
			echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $completed_count, 'recordsFiltered' => $completed_count, 'data' => $data));
		} else {

			echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $completed_count, 'recordsFiltered' => $completed_count, 'data' => array()));
		}
	}

	public function referral_history() {
		$id = session('userId');
		$totalrecords = intval(Input::get('totalrecords'));
		$draw = Input::get('draw');
		$start = Input::get('start');
		$length = Input::get('length');
		$sorttype = Input::get('order');
		$sort_col = $sorttype['0']['column'];
		$sort_type = $sorttype['0']['dir'];
		$search = Input::get('search');
		$from_date = Input::get('from');
		$to_date = Input::get('to');
		$search = $search['value'];

		if ($sort_col == '2') {
			$sort_col = 'created_at';
		} else if ($sort_col == '5') {
			$sort_col = 'commision_fee';
		} else {
			$sort_col = "refer_com_id";
		}
		if ($sort_type == 'asc') {
			$sort_type = 'desc';
		} else {
			$sort_type = 'asc';
		}

		$data = $orders = array();
		$referral = ReferralCommision::where('refer_by_id', $id);
		if ($search != '') {
			$referral = $referral->where(function ($q) use ($search) {
				$q->where('commision_fee', 'like', '%' . $search . '%')->orWhere('created_at', 'like', '%' . $search . '%');}
			);
		}

		if ($from_date) {
			$referral = $referral->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
		}

		if ($to_date) {
			$referral = $referral->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
		}

		$referral_count = $referral->count();
		if ($referral_count) {

			$referral = $referral->select('user_id', 'refer_currency', 'commision_fee', 'created_at');

			$orders = $referral->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
		}

		$data = array();
		$no = $start + 1;

		if ($referral_count) {
			foreach ($orders as $r) {
				$emailid = get_user_email($r['user_id']);
				array_push($data, array(
					$no,
					$r['created_at'],
					$emailid,
					$r['refer_currency'],
					$r['commision_fee'],
				));
				$no++;
			}

			echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $referral_count, 'recordsFiltered' => $referral_count, 'data' => $data));
		} else {

			echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $referral_count, 'recordsFiltered' => $referral_count, 'data' => array()));
		}
	}

	public function transfer_history() {
		$id = session('userId');
		$totalrecords = intval(Input::get('totalrecords'));
		$draw = Input::get('draw');
		$start = Input::get('start');
		$length = Input::get('length');
		$sorttype = Input::get('order');
		$sort_col = $sorttype['0']['column'];
		$sort_type = $sorttype['0']['dir'];
		$search = Input::get('search');
		$from_date = Input::get('from');
		$to_date = Input::get('to');
		$stype = Input::get('stype');
		$search = $search['value'];

		if ($sort_col == '2') {
			$sort_col = 'created_at';
		} else if ($sort_col == '3') {
			$sort_col = 'rec_user_name';
		} else if ($sort_col == '4') {
			$sort_col = 'amount';
		} else {
			$sort_col = "id";
		}
		if ($sort_type == 'asc') {
			$sort_type = 'desc';
		} else {
			$sort_type = 'asc';
		}

		$data = $orders = array();
		if ($stype == 'transfer') {
			$transfer = Transfer::where('user_id', $id);
		} else if ($stype == 'redeem') {
			$transfer = Transfer::where('rec_user_id', $id);
		} else {
			$transfer = Transfer::where('user_id', $id)->orWhere('rec_user_id', $id);
		}

		if ($search != '') {
			$transfer = $transfer->where(function ($q) use ($search) {
				$q->where('rec_user_name', 'like', '%' . $search . '%')->orWhere('amount', 'like', '%' . $search . '%')->orWhere('created_at', 'like', '%' . $search . '%')->orWhere('fees', 'like', '%' . $search . '%')->orWhere('total', 'like', '%' . $search . '%')->orWhere('status', 'like', '%' . $search . '%');}
			);
		}

		if ($from_date) {
			$transfer = $transfer->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
		}

		if ($to_date) {
			$transfer = $transfer->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
		}

		$transfer_count = $transfer->count();
		if ($transfer_count) {

			$transfer = $transfer->select('user_id', 'rec_user_id', 'amount', 'fees', 'total', 'currency', 'rec_user_name', 'created_at', 'status', 'fee_per', 'fee_type', 'redemption_at');

			$orders = $transfer->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
		}

		$data = array();
		$no = $start + 1;

		if ($transfer_count) {
			foreach ($orders as $r) {
				if ($r['status'] == 'completed') {
					$completed = URL::to('public/frontend/img/tick.png');
					$status = '<img src="' . $completed . '" alt="Completed" title="Completed">';
				} else if ($r['status'] == 'pending') {
					$pending = URL::to('public/frontend/img/pending.png');
					$status = '<img src="' . $pending . '" alt="Pending" title="Pending">';
				} else if ($r['status'] == 'cancelled') {
					$cancel = URL::to('public/frontend/img/cancel.png');
					$status = '<img src="' . $cancel . '" alt="Cancelled" title="Cancelled">';
				} else {
					$status = '<span style="color:red">' . $r['status'] . '</span>';
				}

				if ($id == $r['user_id']) {
					$fees = ($r['fees'] == 0) ? '-' : $r['fees'] . " " . $r['currency'];
					$total = ($r['total'] == 0) ? '-' : $r['total'] . " " . $r['currency'];
					array_push($data, array(
						$no,
						$r['created_at'],
						getUserName($r['user_id']),
						$r['rec_user_name'],
						$r['amount'] . " " . $r['currency'],
						$fees,
						$total,
						$status,
					));
					$no++;
				} else if ($id == $r['rec_user_id']) {
					$fees = $fee_amt = $r['fee_per'];
					$fee_type = $r['fee_type'];
					$amount = $r['total'];
					if ($fees == 0) {
						$total = $amount = $r['amount'];
					} else {
						if ($fee_type == 'amount') {
							$total = $amount - $fees;
						} else {
							$fee_amt = ($amount * $fees) / 100;
							$total = $amount - $fee_amt;
						}
					}

					$total = number_format($total, 2, '.', '');
					$fee_amt = number_format($fee_amt, 2, '.', '');

					array_push($data, array(
						$no,
						$r['created_at'],
						getUserName($r['user_id']),
						$r['rec_user_name'],
						$amount . " " . $r['currency'],
						$fee_amt . " " . $r['currency'],
						$total . " " . $r['currency'],
						$status,
					));
					$no++;
				}
			}

			echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $transfer_count, 'recordsFiltered' => $transfer_count, 'data' => $data));
		} else {

			echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $transfer_count, 'recordsFiltered' => $transfer_count, 'data' => array()));
		}
	}

	public function support() {
		if (session('userId') != '') {
			$userId = session('userId');
			$getFaq = Faq::where('status', 'active')->limit(5)->get();
			$getUserDetails = User::where('id', $userId)->select('tfa_status', 'verified_status', 'tfa_url', 'secret', 'user_mail_id', 'unusual_user_key', 'consumer_name')->first();
			$getTickets = HelpCentre::where('user_id', $userId)->orderBy('created_at', 'desc')->groupBy('reference_no')->select('user_id', 'ticket_status', 'subject', 'reference_no', 'created_at', 'id')->get();

			$helpcategory = Helpcategory::all();
			if ($getTickets->isEmpty()) {
				$getTickets = array();
			}
			$first = decrypText($getUserDetails['user_mail_id']);
			$second = decrypText($getUserDetails['unusual_user_key']);
			$useremailid = $first . "@" . $second;
			$getContent = Cms::whereIn('id', [17])->select('content', 'title')->get();
			return view('frontend.users.support')->with('profile', $getUserDetails)->with('tickets', $getTickets)->with('category', $helpcategory)->with('ques', $getFaq)->with('email', $useremailid)->with('content', $getContent);
		}
		Session::flash('error', trans('app_lang.Please login to continue'));
		return Redirect::to('login');
	}

	public function supportSubmit() {
		if (session('userId') != '') {
			$data = Input::all();
			$Validation = Validator::make($data, User::$helpRule);
			if ($Validation->fails()) {
				foreach ($Validation->messages()->getMessages() as $field => $message) {
					Session::flash('error', $message[0]);
					return Redirect::back();
				}
			}

			if ($_FILES['reference_proof']['name'] == "") {
				$image = "";
			} elseif ($_FILES['reference_proof']['name'] != "") {
				$fileExtensions = ['jpeg', 'jpg', 'png'];
				$fileName = $_FILES['reference_proof']['name'];
				$fileType = $_FILES['reference_proof']['type'];
				$explode = explode('.', $fileName);
				$extension = end($explode);
				$fileExtension = strtolower($extension);
				$mimeImage = mime_content_type($_FILES["reference_proof"]['tmp_name']);
				$explode = explode('/', $mimeImage);

				if (!in_array($fileExtension, $fileExtensions)) {
					Session::flash('error', trans('app_lang.Invalid file type. Only image files are accepted.'));
					return Redirect::back();
				} else {
					if ($explode[0] != "image") {
						Session::flash('error', trans('app_lang.Invalid file type. Only image files are accepted.'));
						return Redirect::back();
					}
					$cloudUpload = \Cloudinary\Uploader::upload($_FILES["reference_proof"]['tmp_name']);
					if ($cloudUpload) {
						$image = $cloudUpload['secure_url'];
					} else {
						Session::flash('error', $cloudUpload["error"]["message"]);
						return Redirect::back();
					}
				}
			}

			$help['user_id'] = session('userId');
			$help['emailid'] = strip_tags($data['emailid']);
			$help['subject'] = strip_tags($data['subject']);
			$help['description'] = strip_tags($data['description']);
			$help['image'] = $image;
			$help['status'] = "unread";
			$help['ticket_status'] = "active";
			$createHelp = HelpCentre::create($help);
			if ($createHelp) {
				$helpId = $createHelp->id;
				$update = HelpCentre::where('id', $helpId)->update(['reference_no' => $helpId]);
				$getUser = User::where('id', session('userId'))->select('consumer_name', 'user_mail_id', 'unusual_user_key')->first();
				$username = $getUser->consumer_name;
				$usermail = decrypText($getUser->user_mail_id) . '@' . decrypText($getUser->unusual_user_key);

				$msg1 = $username . " have raised new ticket regarding " . $data['subject'];
				$insdata = array('admin_id' => 1, 'type' => 'Support', 'message' => $msg1, 'status' => 'unread');
				AdminNotification::create($insdata);

				if ($update) {
					$getEmail = EmailTemplate::where('id', 42)->first();
					$getSiteDetails = Controller::getEmailTemplateDetails();
					$info = array('###USER###' => $username, '###MESSAGE###' => $data['description'], '###SUBJECT###' => $data['subject']);
					$replace = array_merge($getSiteDetails, $info);
					$emaildata = array('content' => strtr($getEmail->template, $replace));
					$toDetails['useremail'] = $getSiteDetails['contact_mail_id'];
					$toDetails['subject'] = $getEmail->subject;
					$toDetails['from'] = $getSiteDetails['contact_mail_id'];
					$toDetails['name'] = $getSiteDetails['site_name'];
					$sendEmail = Controller::sendEmail($emaildata, $toDetails);

					$getEmail1 = EmailTemplate::where('id', 50)->first();
					$emaildata1 = array('content' => strtr($getEmail1->template, $replace));
					$toDetails1['useremail'] = $usermail;
					$toDetails1['subject'] = $getEmail1->subject;
					$toDetails1['from'] = $getSiteDetails['contact_mail_id'];
					$toDetails1['name'] = $getSiteDetails['site_name'];
					$sendEmail = Controller::sendEmail($emaildata1, $toDetails1);

					Session::flash('success', trans('app_lang.Your query submitted to the Admin'));
					return Redirect::to('viewTicket/' . encrypText($helpId));
				} else {
					Session::flash('error', trans('app_lang.Failed to submit query.'));
					return Redirect::back();
				}
			} else {
				Session::flash('error', trans('app_lang.Please try again!'));
				return Redirect::back();
			}
		}
		Session::flash('error', trans('app_lang.Please login to continue'));
		return Redirect::to('login');
	}

	public function querySubmit() {
		if (session('userId') != '') {
			$data = Input::all();
			$Validation = Validator::make($data, User::$queryRule);
			if ($Validation->fails()) {
				foreach ($Validation->messages()->getMessages() as $field => $message) {
					Session::flash('error', $message[0]);
					return Redirect::back();
				}
			}

			$help['reference_no'] = $refno = decrypText(strip_tags($data['reference_no']));
			$status = HelpCentre::where('reference_no', $refno)->orderBy('created_at', 'desc')->select('ticket_status')->first()->ticket_status;
			if ($status == 'close') {
				Session::flash('error', 'Ticket has beed closed by admin');
				return Redirect::back();
			}

			if ($_FILES['reference_proof']['name'] == "") {
				$image = "";
			} elseif ($_FILES['reference_proof']['name'] != "") {
				$fileExtensions = ['jpeg', 'jpg', 'png'];
				$fileName = $_FILES['reference_proof']['name'];
				$fileType = $_FILES['reference_proof']['type'];
				$explode = explode('.', $fileName);
				$extension = end($explode);
				$fileExtension = strtolower($extension);
				$mimeImage = mime_content_type($_FILES["reference_proof"]['tmp_name']);
				$explode = explode('/', $mimeImage);

				if (!in_array($fileExtension, $fileExtensions)) {
					Session::flash('error', trans('app_lang.Invalid file type. Only image files are accepted.'));
					return Redirect::back();
				} else {
					if ($explode[0] != "image") {
						Session::flash('error', trans('app_lang.Invalid file type. Only image files are accepted.'));
						return Redirect::back();
					}
					$cloudUpload = \Cloudinary\Uploader::upload($_FILES["reference_proof"]['tmp_name']);
					if ($cloudUpload) {
						$image = $cloudUpload['secure_url'];
					} else {
						Session::flash('error', $cloudUpload["error"]["message"]);
						return Redirect::back();
					}
				}
			}

			$help['user_id'] = session('userId');
			$subject = $help['subject'] = strip_tags($data['subject']);
			$message = $help['description'] = strip_tags($data['description']);
			$help['image'] = $image;
			if (empty($data['customCheck1'])) {
				$help['status'] = "unread";
				$help['ticket_status'] = "active";
			} else {
				$help['status'] = "unread";
				$help['ticket_status'] = "close";
			}

			$createHelp = HelpCentre::create($help);

			$getUser = User::where('id', session('userId'))->select('consumer_name')->first();
			$username = $getUser->consumer_name;
			$msg1 = $username . " have raised new ticket regarding " . $data['subject'];
			$insdata = array('admin_id' => 1, 'type' => 'Support', 'message' => $msg1, 'status' => 'unread');
			AdminNotification::create($insdata);
			if ($createHelp) {
				$getEmail = EmailTemplate::where('id', 42)->first();
				$getSiteDetails = Controller::getEmailTemplateDetails();
				$info = array('###USER###' => $username, '###MESSAGE###' => $message, '###SUBJECT###' => $subject);
				$replace = array_merge($getSiteDetails, $info);
				$emaildata = array('content' => strtr($getEmail->template, $replace));
				$toDetails['useremail'] = $getSiteDetails['contact_mail_id'];
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails['contact_mail_id'];
				$toDetails['name'] = $getSiteDetails['site_name'];
				$sendEmail = Controller::sendEmail($emaildata, $toDetails);
				Session::flash('success', trans('app_lang.Your query submitted to the Admin'));
			} else {
				Session::flash('error', trans('app_lang.Failed to submit query.'));
			}
			return Redirect::back();
		}
		Session::flash('error', trans('app_lang.Please login to continue'));
		return Redirect::to('/');
	}

	public function listTicket() {
		if (session('userId') != '') {
			$userId = session('userId');
			$getTickets = HelpCentre::where('user_id', $userId)->orderBy('created_at', 'desc')->groupBy('reference_no')->select('user_id', 'ticket_status', 'subject', 'reference_no', 'created_at', 'id')->get();
			if ($getTickets->isEmpty()) {
				$getTickets = array();
			}
			return view('frontend.users.listsupport')->with('listtickets', $getTickets);
		}
		Session::flash('error', trans('app_lang.Please login to continue'));
		return Redirect::to('login');
	}

	public function viewSupport($id) {
		if (session('userId') != '') {
			$userId = session('userId');
			$getTickets = HelpCentre::where('user_id', $userId)->orderBy('created_at', 'desc')->groupBy('reference_no')->select('user_id', 'ticket_status', 'subject', 'reference_no', 'created_at', 'id')->get();
			$refId = decrypText($id);
			$getQuery = HelpCentre::where('reference_no', $refId)
			->orderBy('id', 'asc')->get();
			if ($getQuery->isEmpty()) {
				$getQuery = array();
			}

			$getQuery_closed = HelpCentre::where('reference_no', $refId)->where('ticket_status', 'close')
			->orderBy('id', 'asc')->count();

			$getUserDetails = User::where('id', $userId)->select('tfa_status', 'verified_status', 'tfa_url', 'secret', 'user_mail_id', 'unusual_user_key', 'consumer_name')->first();

			$first = decrypText($getUserDetails['user_mail_id']);
			$second = decrypText($getUserDetails['unusual_user_key']);
			$useremailid = $first . "@" . $second;

			$getContent = Cms::whereIn('id', [17])->select('content', 'title')->get();

			$helpcategory = Helpcategory::all();
			if ($getTickets->isEmpty()) {
				$getTickets = array();
			}

			$Sitesettings = Sitesettings::where('id', 1)->get();

			return view('frontend.users.support_details')->with('queries', $getQuery)->with('listtickets', $getTickets)->with('category', $helpcategory)->with('closed_status', $getQuery_closed)->with('Sitesettings', $Sitesettings)->with('profile', $getUserDetails)->with('email', $useremailid)->with('content', $getContent);
		}
		Session::flash('error', trans('app_lang.Please login to continue'));
		return Redirect::to('login');
	}

	public function addCoin() {
		if (session('userId') != '') {
			$getContent = Cms::whereIn('id', [44])->select('content', 'title')->get();

			$Sitesettings = Sitesettings::where('id', 1)->select('add_coin_fee_currency', 'add_coin_status', 'add_coin_fee_amount')->get();
			if ($Sitesettings[0]['add_coin_status'] == 0) {
				Session::flash('error', 'Unable to add coin');
				return Redirect::to('');
			}
			$addcoin_fee_currency = $Sitesettings[0]['add_coin_fee_currency'];
			$addcoin_fee_amount = $Sitesettings[0]['add_coin_fee_amount'];
			$balance = Wallet::where('user_id', session('userId'))->select($addcoin_fee_currency)->first();
			$currencydetails['currency'] = $addcoin_fee_currency;
			$currencydetails['currencyamount'] = $addcoin_fee_amount;

			if ($balance->$addcoin_fee_currency >= $addcoin_fee_amount) {
				return view('frontend.users.addcoin')->with('content', $getContent)->with('currencydetails', $currencydetails);
			} else {
				Session::flash('error', trans('app_lang.balance_not_enough'));
				return Redirect::to('');
			}
		} else {
			Session::flash('error', trans('app_lang.user_login_after_add_coin'));
			return Redirect::to('');
		}
	}

	public function addcoinUpdate() {
		if (session('userId') != '') {
			$userId = session('userId');
			$data = Input::all();

			//image upload
			if ($_FILES['coin_log_upload']['name'] != "") {
				$fileExtensions = ['jpeg', 'jpg', 'png'];
				$fileName = $_FILES['coin_log_upload']['name'];
				$fileType = $_FILES['coin_log_upload']['type'];
				$explode = explode('.', $fileName);
				$extension = end($explode);
				$fileExtension = strtolower($extension);
				$mimeImage = mime_content_type($_FILES["coin_log_upload"]['tmp_name']);
				$explode = explode('/', $mimeImage);

				if (!in_array($fileExtension, $fileExtensions)) {
					Session::flash('error', trans('app_lang.Invalid file type. Only image files are accepted.'));
					return Redirect::back();
				} else {
					if ($explode[0] != "image") {
						Session::flash('error', trans('app_lang.Invalid file type. Only image files are accepted.'));
						return Redirect::back();
					}
					$cloudUpload = \Cloudinary\Uploader::upload($_FILES["coin_log_upload"]['tmp_name']);
					if ($cloudUpload) {
						$coinimage = $cloudUpload['secure_url'];
					} else {
						Session::flash('error', $cloudUpload["error"]["message"]);
						return Redirect::to('addCoin');
					}
				}
			} else {
				$coinimage = '';
				$fileType = '';
			}

			$userinfo['coin_full_name'] = strip_tags($data['coin_full_name']);
			$userinfo['coin_ticket_symbol'] = strip_tags($data['coin_ticket_symbol']);
			$userinfo['coin_log_upload'] = $coinimage;
			$userinfo['coin_logo_status'] = 'yes';
			$userinfo['coin_type_ticker_symbol'] = strip_tags($data['coin_type_ticker_symbol']);
			$userinfo['coin_type'] = strip_tags($data['coin_type']);
			$userinfo['coin_website'] = strip_tags($data['coin_website']);
			$userinfo['announcement'] = strip_tags($data['announcement']);
			$userinfo['github_link'] = strip_tags($data['github_link']);
			$userinfo['explorer_link'] = strip_tags($data['explorer_link']);
			$userinfo['coin_swape'] = strip_tags($data['coin_swape']);
			$Sitesettings = Sitesettings::where('id', 1)->select('add_coin_fee_currency', 'add_coin_status', 'add_coin_fee_amount')->get();
			if ($Sitesettings[0]['add_coin_status'] == 0) {
				Session::flash('error', 'Unable to add coin');
				return Redirect::to('addCoin');
			} else {

				$data['addcoin_currencyname'] = $userinfo['addcoin_currencyname'] = $Sitesettings[0]['add_coin_fee_currency'];
				$data['addcoin_currencyamount'] = $userinfo['addcoin_currencyamount'] = $Sitesettings[0]['add_coin_fee_amount'];
			}

			$userinfo['add_user'] = $userId;
			$balance = Wallet::where('user_id', session('userId'))->select($data['addcoin_currencyname'])->first();

			$currname = $data['addcoin_currencyname'];
			$balance_update = ($balance->$currname) - (strip_tags($data['addcoin_currencyamount']));
			$update = Wallet::where('user_id', session('userId'))->update([$data['addcoin_currencyname'] => $balance_update, 'remarks' => 'New coin request added']);
			$result = AddCoins::create($userinfo);
			if ($result) {
				$getUserDetails = User::where('id', $userId)->select('user_mail_id', 'unusual_user_key', 'consumer_name')->first();

				$first = decrypText($getUserDetails['user_mail_id']);
				$second = decrypText($getUserDetails['unusual_user_key']);
				$useremail = $first . "@" . $second;

				$getEmail = EmailTemplate::where('id', 29)->first();
				$getSiteDetails = Controller::getEmailTemplateDetails();
				$info = array('###USER###' => $getUserDetails['consumer_name'], '###COINNAME###' => strip_tags($data['coin_full_name']), '###ADMINCURRENCY###' => strip_tags($data['addcoin_currencyname']), '###ADMINCURRENCYAMOUNT###' => strip_tags($data['addcoin_currencyamount']));
				$replace = array_merge($getSiteDetails, $info);

				$emaildata = array('content' => strtr($getEmail->template, $replace));
				$toDetails['useremail'] = $useremail;
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails['contact_mail_id'];
				$toDetails['name'] = $getSiteDetails['site_name'];

				$sendEmail = Controller::sendEmail($emaildata, $toDetails);
				if (count(Mail::failures()) > 0) {
					Session::flash('error', trans('app_lang.Email sending failed.'));
				} else {
					Session::flash('success', trans('app_lang.success_add_new_coin_check_mail'));
				}
			} else {
				Session::flash('error', trans('app_lang.failed_add_new_coin'));
			}
			return Redirect::to('addCoin');

		} else {
			return Redirect::to('');
		}
	}

	public function UserNotifyAll() {
		if (session('userId') != '') {
			$userId = session('userId');
			$notify = UserNotification::where('user_id', $userId)->orderBy('id', 'desc')->get();
			return view('frontend.users.usernotifyall')->with('notify', $notify);
		}
		Session::flash('error', trans('app_lang.Please login to continue'));
		return Redirect::to('login');
	}

	public function UserNotifyUpdate() {
		if (session('userId') != '') {
			$result = UserNotification::where('user_id', session('userId'))->where('status', 'unread')->update(['status' => 'read']);
			echo ($result) ? '1' : '0';
		} else {
			echo "0";
		}
	}

	public function updateNotify_read(Request $request) {
		$url_re = $request['url_re'];
		$id = $request['id'];
		if ($id != "") {
			$getBank = UserNotification::where('id', $id)->update(['status' => 'read']);

			if ($getBank) {
				$response = "1";
			} else {
				$response = "0";
			}
		} else {
			$response = "0";
		}
		echo $response;
	}

	//To sort array
	public function array_sort_by_column(&$array, $column, $direction = SORT_DESC) {
		$reference_array = array();
		foreach ($array as $key => $row) {
			$reference_array[$key] = $row[$column];
		}
		array_multisort($reference_array, $direction, $array);
	}
	 public function payment(Request $request)
    {

    	$data = Input::all();
		$validate = Validator::make($data, [
			'name' => 'required',
            'mobile' => 'required|numeric|digits:10|unique:customer,mobile',
            'amount' => 'required|numeric',
            'email' => 'required|email',
		], [
			'name.required' => 'Enter name',
			'mobile.required' => 'Enter mobile number',
			'amount' => 'Enter valid amount', 
			'email' => 'Enter valid email address', 
		]);
  		

      
        $userinfo['user_id'] = $userId = session('userId');
        $userinfo['name'] = $name = $data['name'];
        $userinfo['mobile'] = $mobile = $data['mobile'];
        $userinfo['email_id'] = $email = $data['email'];
        $userinfo['amount'] = $amount = $data['amount'];
        $userinfo['order_id'] = $order=$userId.'123'.time();

        $result = Paytm::create($userinfo);

        $securl1 = URL::to('/payment_status');
        $payment = PaytmWallet::with('receive');
        $payment->prepare([
          'order' =>$order,
          'user' => $name,
          'mobile_number' => $mobile,
          'email' => $email,
          'amount' => $amount,
          'callback_url' => $securl1
        ]);
        return $payment->receive();
    } 
    public function paymentCallback()
    {
        $transaction = PaytmWallet::with('receive');
        $response = $transaction->response();
        $order_id = $transaction->getOrderId(); 
        Paytm::where('order_id',$order_id)->update(['details'=>$transaction]); 
        /*if($transaction->isSuccessful()){
          EventRegistration::where('order_id',$order_id)->update(['status'=>2, 'transaction_id'=>$transaction->getTransactionId()]);


          dd('Payment Successfully Paid.');
        }else if($transaction->isFailed()){
          EventRegistration::where('order_id',$order_id)->update(['status'=>1, 'transaction_id'=>$transaction->getTransactionId()]);
          dd('Payment Failed.');
        }*/
    } 
     public function ccavenyepaymnt(Request $request)
    {

    	$data = Input::all();
		$validate = Validator::make($data, [
			'billing_name' => 'required',
            'billing_tel' => 'required|numeric|digits:10|unique:customer,mobile',
            'amount' => 'required|numeric',
            'billing_address' => 'required',
            'billing_zip' => 'required',
            'billing_state' => 'required',
            'billing_country' => 'required',
            'billing_email' => 'required|email',
		], [
			'billing_name.required' => 'Enter name',
			'billing_tel.required' => 'Enter mobile number',
			'amount.required' => 'Enter amount',
			'billing_address.required' => 'Enter valid address', 
			'billing_zip.required' => 'Enter valid zipcode', 
			'billing_state.required' => 'Enter valid state', 
			'billing_country.required' => 'Enter valid country', 
			'billing_email.required' => 'Enter valid email address', 
		]);
  		 
      	$merchant_data='';
      	$working_key = 'ECE09A4F7F7116B057B40E62730C88DB';
      	$access_code = 'AVTX04IC96BR60XTRB'; 
        $userinfo['user_id'] = $userId = session('userId');
        /*$userinfo['name'] = $name = $data['name'];
        $userinfo['mobile'] = $mobile = $data['mobile'];
        $userinfo['email_id'] = $email = $data['email'];
        $userinfo['amount'] = $amount = $data['amount'];*/
        $userinfo['order_id'] = $order=$userId.'123'.time();


        foreach ($data as $key => $value){
		$merchant_data.=$key.'='.$value.'&';
		}
		$merchant_data .= "order_id=".$order;

		$encrypted_data=encryptnew($merchant_data,$working_key); 
		/*$encrypted_data=decryptnew('3a3eb942d96e5fe6f6c9e57d8a4c535350f70db9a4689c5137e133aa9238fe3b5701820ed4cb2a210bb4605c50c2bfb2814344717f2404fd59e9620aa6e383786d617be91f76d5cea6b463f91c927ebbb802ce5f4369c409869cc03a75d495669f20679e4574600c5ac4be46adf8fe473c1547f14a1ee4ebd50806acd9adc954945e42a64fbb530c2b682e85a41c479d2bc098ed3184a3ce6502512270c7c6553b4228bce5a2aae9398fc88a2632a1712fd7f9dd3b81c3bfe4deecdbcd50cdb1832a7ddce498e0eca71686a585c07376c8dc5cd01572de2de6808457bad352434488bf7f07d08b05341e6149035b773f387804d04fa17b97d4bdf991bdeba61760152923481c075ea9f36fd4cc209082c0db51957646c591620c32c1274bd21a8752646fe48223611441d23b9207e4579a80ef62dff50f0615b6470a0eb1172c7ea792295bc730c7b652b8ec4dcf1f4932217a2749a5c6fc3e360fb21bebc7ee38aba0bb1e0b34b8130d1fdeed470fabcbcc72e7ed69ce6419b3d7446209a6e71e5db8700e98b946e0c7e502e25ffab06e84b3a53febe9daf33aa7d0ab867be2badb08bfb81b4fa900bf79b9e6ec55a7',$working_key); 
		print_r($encrypted_data);
		die;*/

		return view('frontend.users.ccavenue')->with('encrypted_data', $encrypted_data)->with('access_code', $access_code);
        
    } 

    public function paypalpayment(Request $request) {

    	$input_data = $request->all();
        $validate = Validator::make($input_data, [
            'billing_name' => 'required',
            'description' => 'required',
            'billing_tel' => 'required|numeric|digits:10|unique:customer,mobile',
            'amount' => 'required|numeric',
            'billing_address' => 'required',
            'billing_zip' => 'required',
            'billing_state' => 'required',
            'billing_country' => 'required',
            'billing_email' => 'required|email',
        ], [
            'billing_name.required' => 'Enter name',
            'description.required' => 'Enter description',
            'billing_tel.required' => 'Enter mobile number',
            'amount.required' => 'Enter amount',
            'billing_address.required' => 'Enter valid address', 
            'billing_zip.required' => 'Enter valid zipcode', 
            'billing_state.required' => 'Enter valid state', 
            'billing_country.required' => 'Enter valid country', 
            'billing_email.required' => 'Enter valid email address', 
        ]);

    	/*$this->_api_context->setConfig(array(
    						'mode' => 'sandbox',
    						'http.ConnectionTimeOut' => 30,
    						'log.LogEnabled' => true,
    						'log.LogLevel' => 'DEBUG',
    						'log.FileName' => 'storage/logs/paypal.log',
    						'log.LogLevel' => 'ERROR'
    					));*/
    	$payer = new Payer();
        $payer->setPaymentMethod('paypal');

        /*foreach($cart_items as $key => $cart_item)
        {   
            $item1[] = array(
                        "name" => $cart_item->item_name,
                        "sku"  => $cart_item->tool_code,
                        "description" => "Fabric Code: ".$cart_item->fabric_code,
                        "currency" => "USD",
                        "quantity" => $cart_item->quantity,
                        "price" => $cart_item->price
                    );  
        }*/

        $item1 = array(array( 'name' => $input_data['billing_name'],
                        'description' => $input_data['description'],
                        'currency' => $input_data['currency'],
                        'quantity' => '1',
                        'price' => $input_data['amount']
                    ));
        $order_details = array(
	                        'name'=>$input_data['billing_name'],
	                        'amount'=>$input_data['amount'],
	                        'description'=>$input_data['description'],
	                        'address'=>$input_data['billing_address'],
	                        'state'=>$input_data['billing_state'],
	                        'zip_code'=>$input_data['billing_zip'],
	                        'country'=>$input_data['billing_country'],
	                        'phone'=>$input_data['billing_tel'],
	                        'email'=>$input_data['billing_email'],
                        );
        
        session(array('deposit_details'=>$order_details));

        $itemList = new ItemList();
        $itemList->setItems($item1);

        /*$details['tax'] = "0";
        $details['shipping'] = '0';        
        $details['subtotal'] = $input_data['deposit_amount'];

        $amount['currency'] = "USD";
        $amount['total'] = $input_data['deposit_amount'];
        $amount['details'] = $details;*/
        
        $details['tax'] = "0";
        $details['shipping'] = '0';        
        $details['subtotal'] = $input_data['amount'];

        $amount['currency'] = $input_data['currency'];
        $amount['total'] = $input_data['amount'];
        $amount['details'] = $details; 

        $transaction['description'] =$input_data['description'];
        $transaction['amount'] = $amount;        
        $transaction['item_list'] = $itemList;
  			
        $redirectUrls = new RedirectUrls();
        $redirectUrls->setReturnUrl(url("paypalPaymentSuccess"))
        ->setCancelUrl(url("paypalPaymentCancel"));    
 
        $payment = new Payment();
        $payment->setIntent('Sale')
            ->setPayer($payer)
            ->setRedirectUrls($redirectUrls)
            ->setTransactions(array($transaction)); 

        try {
 
            $payment->create($this->_api_context);
 
        } catch (\PayPal\Exception\PPConnectionException $ex) {
        	Session::forget('deposit_details');
 
            if (\Config::get('app.debug')) {
 
                Session::flash('error', trans('app_lang.Something went wrong Please try again'));
				return Redirect::to('deposit');
 
            } else {
                Session::flash('error', trans('app_lang.Something went wrong Please try again'));
				return Redirect::to('deposit');
            }
        }


        foreach ($payment->getLinks() as $link) {
 
            if ($link->getRel() == 'approval_url') {
 
                $redirect_url = $link->getHref();
                break;
 
            }
 
        }

        session(['paypal_payment_id'=> $payment->getId()]);
 
        if (isset($redirect_url)) {
            return Redirect::away($redirect_url);
        }

        Session::forget('deposit_details');
        Session::flash('error', trans('app_lang.Something went wrong Please try again'));
		return Redirect::to('deposit');
    }


    public function paypalPaymentCancel() {
    	Session::flash('error', trans('app_lang.Payment has been cancelled'));
		return Redirect::to('dashboard');
    }

    public function paypalPaymentSuccess(Request $request) {
    	$input_data = $request->all();
    	/** Get the payment ID before session clear **/
        $payment_id = $input_data["paymentId"];
        $PayerID = $input_data["PayerID"];
        $token = $input_data["token"];

        if (empty($PayerID) || empty($token)) {
            Session::flash('error', trans('app_lang.Something went wrong Please try again'));
			return Redirect::to('dashboard');
        }
 
         $this->_api_context = new ApiContext(new OAuthTokenCredential(
            
		    'AdDmtMGfcnloxIagUd0YJG6BLHnCEqxELt6S5ToX6NTY9GPCetk5w-YvsnZQlrGHCEWCvQ2-SxsHk7wW',
            'ELwMaW5gdQfc8eIdGy2qtIjwQ0-UiStxf4_8cBBZjVoYDQvSh1F0GNlHCplw_rb2dZpehhi2454yRKpg'
        ));
        
        // $this->_api_context->setConfig(config('Dweoisn.paypal_settings'));
         $this->_api_context->setConfig(array(
    						'mode' => 'sandbox',
    						'http.ConnectionTimeOut' => 30,
    						'log.LogEnabled' => true,
    						'log.LogLevel' => 'DEBUG',
    						'log.FileName' => 'storage/logs/paypal.log',
    						'log.LogLevel' => 'ERROR'
    					));

        $payment = Payment::get($payment_id, $this->_api_context);

        $execution = new PaymentExecution();
        $execution->setPayerId($input_data['PayerID']);
 

        try {
 
            /**Execute the payment **/
            $result = $payment->execute($execution, $this->_api_context);            
 
        } catch (\PayPal\Exception\PPConnectionException $ex) {
 
            Session::flash('error', trans('app_lang.Something went wrong Please try again'));
			return Redirect::to('dashboard');
        }

        if ($result->getState() == 'approved') {
        	
        	$trans = $result->getTransactions();
            // print_r($trans);
            // print_r($trans[0]->amount);
            $transamount_obj = $trans[0]->amount;
            $transpayee_obj = $trans[0]->payee;
            $transitem_list_obj = $trans[0]->item_list;
            $transrelated_resources_obj = $trans[0]->related_resources;

            $transdescription_val = $trans[0]->description;
            $transsoft_descriptor_val = $trans[0]->soft_descriptor;
            $transcurrency_val =  $transamount_obj->currency;
            $transmerchant_id_val =  $transpayee_obj->merchant_id;
            $transemail_val =  $transpayee_obj->email;

            $transitems_obj =  $transitem_list_obj->items;
            $transname_val =  $transitems_obj[0]->name; 

            $transsale_obj =  $transrelated_resources_obj[0]->sale; 
            $transid_val =  $transsale_obj->id; 
            $transstate_val =  $transsale_obj->state; 
            $transpayment_mode_val =  $transsale_obj->payment_mode; 
            $transtransaction_fee_obj =  $transsale_obj->transaction_fee; 
            $transfee_obj =  $transtransaction_fee_obj->value; 
 
			$transexchange_rate_val =  $transsale_obj->exchange_rate; 
			$transparent_payment_val =  $transsale_obj->parent_payment; 
			$transcreate_time_val =  $transsale_obj->create_time; 
			$transupdate_time_val =  $transsale_obj->update_time;  
 
            // item info
            $Subtotal = $trans[0]->getAmount()->getDetails()->getSubtotal();
            $Tax = $trans[0]->getAmount()->getDetails()->getTax();

            $payer = $result->getPayer();

            // payer info //
            $PaymentMethod =$payer->getPaymentMethod();
            $PayerStatus =$payer->getStatus();
            $PayerMail =$payer->getPayerInfo()->getEmail();

            $relatedResources = $trans[0]->getRelatedResources();
            $sale = $relatedResources[0]->getSale();
            // sale info //
            $saleId = $sale->getId();
            $CreateTime = $sale->getCreateTime();
            $UpdateTime = $sale->getUpdateTime();
            $State = $sale->getState();
            $Total = $sale->getAmount()->getTotal();
            $user_id = session('userId');

            $deposit_details = Session::Get('deposit_details');
            $payment_id = Session::Get('paypal_payment_id');

            $wallet = PaypalDeposit::where('transaction_id', $saleId)->count();
            if($wallet==0){ 

            $transaction_details = array(
            				'userid'   => $user_id,
                            'transaction_id' => $saleId,
                            'payment_method' => 'PAYPAL',
                            'PayerStatus' => $PayerStatus,
                            'PayerMail' => $PayerMail,
                            'payment_id' => $payment_id,
                            'Total' => $Total,
                            'SubTotal' => $Subtotal,
                            'Tax' => $Tax,
                            'Payment_state' => $State,
                            'CreateTime' => $CreateTime,
                            'UpdateTime' => $UpdateTime,
                            'status' => 'pending',
                            'transdescription_val' => $transdescription_val,
							'transsoft_descriptor_val' => $transsoft_descriptor_val,
							'transcurrency_val' => $transcurrency_val,
							'transmerchant_id_val' => $transmerchant_id_val,
							'transemail_val' => $transemail_val,
							'transname_val' => $transname_val,
							'transid_val' => $transid_val,
							'transstate_val' => $transstate_val,
							'transpayment_mode_val' => $transpayment_mode_val,
							'transexchange_rate_val' => $transexchange_rate_val,
							'transparent_payment_val' => $transparent_payment_val,
							'transcreate_time_val' => $transcreate_time_val,
							'transupdate_time_val' => $transupdate_time_val
                        );
            $createDeposit = PaypalDeposit::create($transaction_details); 

            Session::flash('success', trans('app_lang.Payment Success'));
            return Redirect::to('dashboard');
        	}else{
        		 Session::flash('success', trans('app_lang.Payment error'));
            	return Redirect::to('dashboard');
        	}

        }
    }

    public function ccavenyepaymnt_status()
    {
        $transaction = PaytmWallet::with('receive');
        $response = $transaction->response();
        $order_id = $transaction->getOrderId(); 
        Paytm::where('order_id',$order_id)->update(['details'=>$transaction]); 
        /*if($transaction->isSuccessful()){
          EventRegistration::where('order_id',$order_id)->update(['status'=>2, 'transaction_id'=>$transaction->getTransactionId()]);


          dd('Payment Successfully Paid.');
        }else if($transaction->isFailed()){
          EventRegistration::where('order_id',$order_id)->update(['status'=>1, 'transaction_id'=>$transaction->getTransactionId()]);
          dd('Payment Failed.');
        }*/
    }    

}