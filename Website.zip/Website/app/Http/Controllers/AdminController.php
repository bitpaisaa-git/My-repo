<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Controllers\CryptoAddress;
use App\Model\AddCoins;
use App\Model\AdminActivity;
use App\Model\AdminBank;
use App\Model\AdminNotification;
use App\Model\AdminWallet;
use App\Model\BlockIP;
use App\Model\Cms;
use App\Model\CoinAddress;
use App\Model\CoinOrder;
use App\Model\CoinProfit;
use App\Model\ConsumerVerification;
use App\Model\Country;
use App\Model\Currency;
use App\Model\Deposit;
use App\Model\DepositSettings;
use App\Model\EmailTemplate;
use App\Model\ExchangeModel;
use App\Model\ExchangePairs;
use App\Model\Faq;
use App\Model\Googleauthenticator;
use App\Model\Helpcategory;
use App\Model\HelpCentre;
use App\Model\LoginAttempt; 
use App\Model\ManuProcess;
use App\Model\MetaContent;
use App\Model\News;
use App\Model\OrderTemp;  
use App\Model\ReferralCommision;
use App\Model\SiteSettings;
use App\Model\SubAdmin;
use App\Model\Subscribe;
use App\Model\SiteWallet;
use App\Model\Support;
use App\Model\Tokendetail;
use App\Model\TradePairs;
use App\Model\Transaction;
use App\Model\Transfer;
use App\Model\User;
use App\Model\UserActivity;
use App\Model\UserBank;
use App\Model\UserNotification;
use App\Model\Wallet;
use App\Model\Withdraw;
use App\Model\WithdrawSettings;
use App\Model\WhitelistIP;
 

use GeoIp2\Database\Reader;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Schema;
use Cloudinary;
use DateInterval;
use DatePeriod;
use DateTime;
use DB;
use Mail;
use Redirect;
use Response;
use Session;
use URL;
use Validator;
use Keygen\Keygen;

class AdminController extends Controller {
	public function __construct() {
		$this->Url = ADMINURL;
		if ($_SERVER['HTTP_HOST'] != "localhost") {
			if (!isset($_SERVER['PHP_AUTH_USER']) || (isset($_SERVER['PHP_AUTH_USER']) && ($_SERVER['PHP_AUTH_USER'] != 'BAdPnWiXZudhtGMs' || $_SERVER['PHP_AUTH_PW'] != 'POqrQpYByieqpsSaa'))) {
				header('WWW-Authenticate: Basic realm=" Auth"');
				header('HTTP/1.0 401 Unauthorized');
				echo 'Authentication Failed';exit;
			}
		}
		
		$getFile = file_get_contents(app_path('Model/cJfcgPqrCW.php'));
		$data = explode(" || ", $getFile);

		Cloudinary::config(array(
			"cloud_name" => decrypText($data[0]),
			"api_key" =>  decrypText($data[1]),
			"api_secret" =>  decrypText($data[2]),
		));
	}

	public function index() {
		if (session('adminId') != '') {
			$cur_date = date('Y-m-d');
			$data['pending_users'] = User::where('verified_status', '1')->count();
			$data['verified_users'] = User::where('verified_status', '3')->count();
			$data['unverified_users'] = User::where('verified_status', '0')->count();
			$data['new_users'] = User::where(DB::raw('DATE(created_at)'), $cur_date)->count();
			$data['total_users'] = User::count();
			$deposit_transaction = Deposit::all();
			$withdraw_transaction = Withdraw::all();
			$data['total_transactions'] = count($deposit_transaction) + count($withdraw_transaction);
			$data['pending_withdraw'] = Withdraw::where('status', 'pending')->count();
			$data['new_message'] = Support::where('status', 'unread')->count();
			$data['pending_deposit'] = Deposit::where('status', 'pending')->count();
			$res = HelpCentre::groupBy('reference_no')->where('user_id', '!=', 0)->get();
			$data['support'] = count($res);
			return view('admin.common.dashboard')->with('data', $data)->with('redirectUrl', $this->Url);
		}
		return view('admin.common.login')->with('redirectUrl', $this->Url);
	}	

	public function adminLogin() {
		$data = Input::all();
		$Validation = Validator::make($data, User::$adminLoginRule);
		if ($Validation->fails()) {
			Session::flash('error', $Validation->messages());
			return Redirect::to($this->Url);
		} 
		if ($data == array_filter($data)) {
			$email = explode('@', strip_tags($data['username']));
			$first = encrypText($email[0]);
			$second = encrypText($email[1]);
			$password = encrypText(strip_tags($data['user_pwd']));
			$pattern = encrypText(strip_tags($data['pattern_code']));

			$ip = Controller::getIpAddress();
			$browser = Controller::getBrowser();
			$platform = Controller::getPlatform();

			$login = SubAdmin::where('admin_desc', $first)->where('admin_sub_key', $second)->where('admin_key', $password)->where('admin_pattern', $pattern)->first();
			if ($login) {
				if ($login->status == "deactive") {
					Session::flash('error', 'You have been deactivated by Admin.');
					return Redirect::to($this->Url);
				}

				if ($login->tfa_status == "enable") {
					return Redirect::to($this->Url.'/tfaVerification/'.encrypText($login->id));
				}

				LoginAttempt::where('ip_address', $ip)->where('status', 'new')->update(['status' => 'old']);
				SubAdmin::where('id', $login['id'])->update(['login_status' => 'active']);

				$activity['ip_address'] = $ip;
				$activity['browser_name'] = $browser;
				$activity['os'] = $platform;
				$activity['activity'] = "Logged in";
				$activity['admin_id'] = $login['id'];
				AdminActivity::create($activity);

				session(['adminId' => $login['id'], 'adminName' => $login['admin_username'], 'adminRole' => $login['admin_role']]);
				if(session('atype') == '') {
					Session::flash('success', 'Login Success');
					return Redirect::to($this->Url);
				} else {
					if(session('atype') == 'rejectWithdraw') {
						$transid = session('watransId');
						$user_id = session('wauserId');
						return Redirect::to($this->Url.'/rejectWithdraw/'.$transid.'/'.$user_id);
					} else if(session('atype') == 'confirmWithdraw') {
						$transid = session('watransId');
						$user_id = session('wauserId');
						return Redirect::to($this->Url.'/confirmWithdraw/'.$transid.'/'.$user_id);
					} elseif(session('atype') == 'confirmDeposit') {
						$transid = session('watransId');
						$user_id = session('wauserId');
						return Redirect::to($this->Url.'/confirmDeposit/'.$transid.'/'.$user_id);
					} else if(session('atype') == 'rejectDeposit') {
						$transid = session('watransId');
						$user_id = session('wauserId');
						return Redirect::to($this->Url.'/rejectDeposit/'.$transid.'/'.$user_id);
					}
				}
			} else {
				$getCount = LoginAttempt::where('ip_address', $ip)->where('status', 'new')->count();
				if ($getCount >= 2) {
					$getBlockCount = BlockIP::where('ip_addr', $ip)->count();
					if ($getBlockCount == 0) {
						$updata = array('ip_addr' => $ip, 'status' => 'active');
						BlockIP::create($updata);
					} else {
						BlockIP::where('ip_addr', $ip)->update(['status' => 'active']);
					}
					$getEmail = EmailTemplate::where('id', 18)->first();
					$getSiteDetails = Controller::getEmailTemplateDetails();
					$info = array('###USER###' => 'Admin');
					$replace = array_merge($getSiteDetails, $info);
					$emaildata = array('content' => strtr($getEmail->template, $replace));
					$toDetails['useremail'] = $getSiteDetails['contact_mail_id'];
					$toDetails['subject'] = $getEmail->subject;
					$toDetails['from'] = $getSiteDetails['contact_mail_id'];
					$toDetails['name'] = $getSiteDetails['site_name'];

					$sendEmail = Controller::sendEmail($emaildata, $toDetails);
				}
				$createAttempt = array('ip_address' => $ip, 'os' => $platform, 'browser' => $browser, 'status' => 'new', 'username' => strip_tags($data['username']), 'password' => $data['user_pwd']);
				LoginAttempt::create($createAttempt);

				Session::flash('error', 'Invalid login credentials!');
				return Redirect::to($this->Url);
			}
		} else {
			Session::flash('error', 'Please fill all fields!');
			return Redirect::to($this->Url);
		}
	}

	public function tfaVerification($id) {
		if (session('adminId') != '') {
			return Redirect::to($this->Url);
		} else {
			return view('admin.common.tfa_login')->with('aid', $id)->with('redirectUrl', $this->Url);
		}
	}

	public function tfaLogin() {
		$data = Input::all();
		if ($data == array_filter($data)) { 
			$adminId = decrypText(strip_tags($data['aid']));
			$ip = Controller::getIpAddress();
			$browser = Controller::getBrowser();
			$platform = Controller::getPlatform();

			$tfaDetails = Subadmin::where('id', $adminId)->select('secret', 'tfa_status', 'admin_username', 'admin_role')->first(); 
			$secret = $tfaDetails->secret;
			$code = $data['auth_key']; 
			require_once app_path('Model/Googleauthenticator.php');
			$googleAuth = new Googleauthenticator();
			$verify = $googleAuth->verifyCode($secret, $code, $discrepancy = 1);
			if ($verify == 1) { 
				$notf_msg1 = trans('app_lang.hi');
				$activity['ip_address'] = $ip;
				$activity['browser_name'] = $browser;
				$activity['os'] = $platform;
				$activity['activity'] = "Logged in";
				$activity['admin_id'] = $adminId;
				AdminActivity::create($activity);
				session(['adminId' => $adminId, 'adminName' => $tfaDetails['admin_username'], 'adminRole' => $tfaDetails['admin_role']]);
				Session::flash('success', 'Login Success');
				return Redirect::to($this->Url);
			} else { 
				Session::flash('error', trans('app_lang.Invalid authentication key.'));
				return Redirect::to($this->Url.'/tfaVerification/'.encrypText($adminId));
			}
		} else {
			Session::flash('error', 'Please try again later');
			return Redirect::to($this->Url.'/tfaVerification/'.encrypText($adminId));
		}
	}

	//checkResetmail
	public function checkResetEmail(Request $request) {
		$email = explode('@', strip_tags($request['email_addr']));
		$first = encrypText($email[0]);
		$second = encrypText($email[1]);
		$getCount = SubAdmin::where('admin_desc', $first)->where('admin_sub_key', $second)->count();
		echo ($getCount == 1) ? "true" : "false";
	}

	public function forgotPassword(Request $request) {
		$data = $request->all();
		$validate = Validator::make($data, [
			'useremail' => "required|indisposable",
		], [
			'useremail.required' => 'Please Enter email',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$result_data = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($result_data); exit;
			}
		}

		if ($data == array_filter($data)) {
			$useremail = strip_tags($data['useremail']);
			$email = explode('@', $useremail);
			$first = encrypText($email[0]);
			$second = encrypText($email[1]);

			$getDetail = SubAdmin::select('id', 'admin_username')->where('admin_desc', $first)->where('admin_sub_key', $second)->first();
			if ($getDetail) {
				$id = encrypText($getDetail->id);
				$generateCode = User::randomString(8);
				$randomCode = encrypText($generateCode);
				$update = SubAdmin::where('id', $getDetail->id)->update(['admin_forgot_code' => $randomCode, 'admin_forgot_status' => 'active']);
				$securl = URL::to($this->Url.'/resetPassword/' . $id . '/' . $randomCode);

				$getEmail = EmailTemplate::where('id', 2)->first();
				$getSiteDetails = Controller::getEmailTemplateDetails();
				$info = array('###USER###' => $getDetail->admin_username, '###LINK###' => $securl);
				$replace = array_merge($getSiteDetails, $info);
				$emaildata = array('content' => strtr($getEmail->template, $replace));
				$toDetails['useremail'] = $useremail;
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails['contact_mail_id'];
				$toDetails['name'] = $getSiteDetails['site_name'];

				$sendEmail = Controller::sendEmail($emaildata, $toDetails);
				if (count(Mail::failures()) > 0) {
					$result_data = array('status' => '0', 'msg' => 'Please Try Again');
				} else {
					$result_data = array('status' => '1', 'msg' => 'Reset password Link has sent to Your Mail Id');
				}
			} else {
				$result_data = array('status' => '0', 'msg' => 'Invalid Email ID');
			}
		}
		echo json_encode($result_data);
	}

	public function forgotPattern(Request $request) {
		$data = $request->all();
		$validate = Validator::make($data, [
			'useremail' => "required|indisposable",
		], [
			'useremail.required' => 'Please Enter email',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				$result_data = array('status' => '0', 'msg' => $msg[0]);
				echo json_encode($result_data); exit;
			}
		}
		if ($data == array_filter($data)) {
			$useremail = trim(strip_tags($data['useremail']));
			$email = explode('@', $useremail);
			$first = encrypText($email[0]);
			$second = encrypText($email[1]);

			$getDetail = SubAdmin::select('id', 'admin_username')->where('admin_desc', $first)->where('admin_sub_key', $second)->first();
			if ($getDetail) {
				$id = encrypText($getDetail->id);
				$generateCode = User::randomString(8);
				$randomCode = encrypText($generateCode);
				$update = SubAdmin::where('id', $getDetail->id)->update(['forgot_pattern_code' => $randomCode, 'forgot_pattern_status' => 'active']);
				$securl = URL::to($this->Url.'/resetPattern/' . $id . '/' . $randomCode);

				$getEmail = EmailTemplate::where('id', 53)->first();
				$getSiteDetails = Controller::getEmailTemplateDetails();
				$info = array('###USER###' => $getDetail->admin_username, '###LINK###' => $securl);
				$replace = array_merge($getSiteDetails, $info);
				$emaildata = array('content' => strtr($getEmail->template, $replace));
				$toDetails['useremail'] = $useremail;
				$toDetails['subject'] = $getEmail->subject;
				$toDetails['from'] = $getSiteDetails['contact_mail_id'];
				$toDetails['name'] = $getSiteDetails['site_name'];

				$sendEmail = Controller::sendEmail($emaildata, $toDetails);
				if (count(Mail::failures()) > 0) {
					$result_data = array('status' => '0', 'msg' => 'Please Try Again');
				} else {
					$result_data = array('status' => '1', 'msg' => 'Reset pattern Link has sent to Your Mail Id');
				}
			} else {
				$result_data = array('status' => '0', 'msg' => 'Invalid Email ID');
			}
		}
		echo json_encode($result_data);
	}

	public function resetPassword($arg1, $arg2) {
		$id = decrypText($arg1);
		$getDetail = SubAdmin::select('id', 'admin_forgot_status')
		->where('id', $id)->first();
		if ($getDetail->admin_forgot_status == "active") {
			$data['fcode'] = $arg2;
			$data['ucode'] = $arg1;
			return view('admin.common.reset')->with('data', $data)->with('redirectUrl', $this->Url);
		} else {
			Session::flash('error', 'URL expired');
			return Redirect::to($this->Url);
		}
	}

	public function updatePassword() {
		$data = Input::all();
		$validate = Validator::make($data, User::$passwordRule);
		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				Session::flash('error', $msg[0]);
				return Redirect::to($this->Url);
			}
		}

		if ($data == array_filter($data)) {
			$new_pwd = strip_tags($data['new_pwd']);
			$cnfirm_pwd = strip_tags($data['cnfirm_pwd']);
			$fcode = strip_tags($data['fcode']);
			$userid = decrypText(strip_tags($data['ucode']));
			if ($new_pwd == $cnfirm_pwd) {
				$getDetail = SubAdmin::select('id', 'admin_forgot_status')->where('id', $userid)->first();
				if ($getDetail->admin_forgot_status == "active") {
					$password = encrypText($cnfirm_pwd);
					$update = SubAdmin::where('id', $userid)->update(['admin_key' => $password, 'admin_forgot_code' => "", 'admin_forgot_status' => 'deactive']);
					if ($update) {
						Session::flash('success', 'Password Reset Success');
						return Redirect::to($this->Url);
					} else {
						Session::flash('error', 'Please Try Again');
					}
				} else {
					Session::flash('error', 'Reset Url Expired');
				}
			} else {
				Session::flash('error', 'Password Must match');
			}
		} else {
			Session::flash('error', 'Fill All the Field');
		}
	}

	public function resetPattern($arg1, $arg2) {
		$id = decrypText($arg1);
		$getDetail = SubAdmin::where('forgot_pattern_status', 'active')->where('id', $id)->count();
		if ($getDetail == 1) {
			$data['fcode'] = $arg2;
			$data['ucode'] = $arg1;
			return view('admin.common.resetpattern')->with('data', $data)->with('redirectUrl', $this->Url);
		} else {
			Session::flash('error', 'URL expired');
			return Redirect::to($this->Url);
		}
	}

	public function updatePattern() {
		$data = Input::all();
		$validate = Validator::make($data, [
			'pattern_code' => 'required|min:3',
			'pattern_code_confirmation' => 'required|min:3',
		], [
			'pattern_code.required' => 'Enter pattern',
			'pattern_code.min' => 'Enter atleast 3 characters',
			'pattern_code_confirmation.required' => 'Enter confirm pattern',
		]);

		if ($validate->fails()) {
			foreach ($validate->messages()->getMessages() as $val => $msg) {
				Session::flash('error', $msg[0]);
				return Redirect::to($this->Url);
			}
		}
		if ($data == array_filter($data)) {
			$new_pwd = strip_tags($data['pattern_code']);
			$cnfirm_pwd = strip_tags($data['pattern_code_confirmation']);
			$fcode = strip_tags($data['fcode']);
			$userid = decrypText(strip_tags($data['ucode']));
			if ($new_pwd == $cnfirm_pwd) {
				$getDetail = SubAdmin::select('id', 'forgot_pattern_status')->where('id', $userid)->first();
				if ($getDetail->forgot_pattern_status == "active") {
					$pattern = encrypText($cnfirm_pwd);
					$update = SubAdmin::where('id', $userid)->update(['admin_pattern' => $pattern, 'forgot_pattern_code' => "", 'forgot_pattern_status' => 'deactive']);
					if ($update) {
						Session::flash('success', 'Pattern Reset Success');
					} else {
						Session::flash('error', 'Please Try Again');
					}
				} else {
					Session::flash('error', 'Reset Url Expired');
				}
			} else {
				Session::flash('error', 'Pattern Must match');
			}
		} else {
			Session::flash('error', 'Fill All the Field');
		}
		return Redirect::to($this->Url);
	}

	//dashboard chart functionalities
	public function userFromChart() {
		if (session('adminId') != '') {
			$verify = User::where('verified_status', 3)->count();
			$pending = User::where('verified_status', 1)->count();
			$rejected = User::where('verified_status', 2)->count();
			$unverified = User::where('verified_status', 0)->count();
			$chart = array(array('users' => 'KYC Verified', 'value' => $verify), array('users' => 'KYC pending', 'value' => $pending), array('users' => 'Unverified Users', 'value' => $unverified), array('users' => 'KYC Rejected', 'value' => $rejected));
			echo json_encode($chart);
		} else {
			Session::flash('error', 'Session Expired');
			return Redirect::to($this->Url);
		}
	}

	public function depWithChart() {
		if (session('adminId') != '') {
			$year = $_GET['year'];
			$currency = $_GET['currency'];
			$data = array(
				array('Month' => 'Jan',
					'Withdraw' => Controller::userTransactionDetails('Withdraw', $year . "-01-01", $year . "-01-31", $currency),
					'Deposit' => Controller::userTransactionDetails('Deposit', $year . "-01-01", $year . "-01-31", $currency)),
				array('Month' => 'Feb',
					'Withdraw' => Controller::userTransactionDetails('Withdraw', $year . "-02-01", $year . "-02-31", $currency),
					'Deposit' => Controller::userTransactionDetails('Deposit', $year . "-02-01", $year . "-02-31", $currency)),
				array('Month' => 'Mar',
					'Withdraw' => Controller::userTransactionDetails('Withdraw', $year . "-03-01", $year . "-03-31", $currency),
					'Deposit' => Controller::userTransactionDetails('Deposit', $year . "-03-01", $year . "-03-31", $currency)),
				array('Month' => 'Apr',
					'Withdraw' => Controller::userTransactionDetails('Withdraw', $year . "-04-01", $year . "-04-31", $currency),
					'Deposit' => Controller::userTransactionDetails('Deposit', $year . "-04-01", $year . "-04-31", $currency)),
				array('Month' => 'May',
					'Withdraw' => Controller::userTransactionDetails('Withdraw', $year . "-05-01", $year . "-05-31", $currency),
					'Deposit' => Controller::userTransactionDetails('Deposit', $year . "-05-01", $year . "-05-31", $currency)),
				array('Month' => 'Jun',
					'Withdraw' => Controller::userTransactionDetails('Withdraw', $year . "-06-01", $year . "-06-31", $currency),
					'Deposit' => Controller::userTransactionDetails('Deposit', $year . "-06-01", $year . "-06-31", $currency)),
				array('Month' => 'Jul',
					'Withdraw' => Controller::userTransactionDetails('Withdraw', $year . "-07-01", $year . "-07-31", $currency),
					'Deposit' => Controller::userTransactionDetails('Deposit', $year . "-07-01", $year . "-07-31", $currency)),
				array('Month' => 'Aug',
					'Withdraw' => Controller::userTransactionDetails('Withdraw', $year . "-08-01", $year . "-08-31", $currency),
					'Deposit' => Controller::userTransactionDetails('Deposit', $year . "-08-01", $year . "-08-31", $currency)),
				array('Month' => 'Sep',
					'Withdraw' => Controller::userTransactionDetails('Withdraw', $year . "-09-01", $year . "-09-31", $currency),
					'Deposit' => Controller::userTransactionDetails('Deposit', $year . "-09-01", $year . "-09-31", $currency)),
				array('Month' => 'Oct',
					'Withdraw' => Controller::userTransactionDetails('Withdraw', $year . "-10-01", $year . "-10-31", $currency),
					'Deposit' => Controller::userTransactionDetails('Deposit', $year . "-10-01", $year . "-10-31", $currency)),
				array('Month' => 'Nov',
					'Withdraw' => Controller::userTransactionDetails('Withdraw', $year . "-11-01", $year . "-11-31", $currency),
					'Deposit' => Controller::userTransactionDetails('Deposit', $year . "-11-01", $year . "-11-31", $currency)),
				array('Month' => 'Dec',
					'Withdraw' => Controller::userTransactionDetails('Withdraw', $year . "-12-01", $year . "-12-31", $currency),
					'Deposit' => Controller::userTransactionDetails('Deposit', $year . "-12-01", $year . "-12-31", $currency)),
			);
			echo json_encode($data);
		} else {
			Session::flash('error', 'Session Expired');
			return Redirect::to($this->Url);
		}
	}

	public function getDatesFromRange($start, $end, $format = 'Y-m-d') {
		$array = array();
		$interval = new DateInterval('P1D');
		$realEnd = new DateTime($end);
		$realEnd->add($interval);
		$period = new DatePeriod(new DateTime($start), $interval, $realEnd);
		foreach ($period as $date) {
			$array[] = $date->format($format);
		}
		return $array;
	}

	public function profitChart() {
		$year = $_GET['year'];
		$currency = $_GET['currency'];
		$type = $_GET['type'];
		if ($type == 'day') {
			$current_date = date("Y-m-d");
			$day = date('D', strtotime($current_date));
			$type = "Day";
			$data = array(array('Month' => $day . "-" . $current_date,
				'profit' => Controller::getProfitDetails($current_date, $current_date, $currency), "color" => "#FF0F00"));
		}
		if ($type == 'weekly') {
			$current_date = date("Y-m-d");
			$weeklyend_day = date('Y-m-d', strtotime('-6 days'));
			$filterdate = AdminController::getDatesFromRange($weeklyend_day, $current_date);
			$j = 1;
			foreach ($filterdate as $fil_date) {
				if ($j == 1) {
					$weekly_day_1 = $fil_date;
					$weekly_day_one = date('D', strtotime($weekly_day_1));
				} else if ($j == 2) {
					$weekly_day_2 = $fil_date;
					$weekly_day_two = date('D', strtotime($weekly_day_2));
				} else if ($j == 3) {
					$weekly_day_3 = $fil_date;
					$weekly_day_three = date('D', strtotime($weekly_day_3));
				} else if ($j == 4) {
					$weekly_day_4 = $fil_date;
					$weekly_day_four = date('D', strtotime($weekly_day_4));
				} else if ($j == 5) {
					$weekly_day_5 = $fil_date;
					$weekly_day_five = date('D', strtotime($weekly_day_5));
				} else if ($j == 6) {
					$weekly_day_6 = $fil_date;
					$weekly_day_six = date('D', strtotime($weekly_day_6));
				} else if ($j == 7) {
					$weekly_day_7 = $fil_date;
					$weekly_day_seven = date('D', strtotime($weekly_day_7));
				}
				$j++;
			}

			$data = array(array('Month' => $weekly_day_one . "-" . $weekly_day_1,
				'profit' => Controller::getProfitDetails($weekly_day_1, $weekly_day_1, $currency), "color" => "#FF0F00"),
			array('Month' => $weekly_day_two . "-" . $weekly_day_2,
				'profit' => Controller::getProfitDetails($weekly_day_2, $weekly_day_2, $currency), "color" => "#FF6600"),
			array('Month' => $weekly_day_three . "-" . $weekly_day_3,
				'profit' => Controller::getProfitDetails($weekly_day_3, $weekly_day_3, $currency), "color" => "#FF9E01"),
			array('Month' => $weekly_day_four . "-" . $weekly_day_4,
				'profit' => Controller::getProfitDetails($weekly_day_4, $weekly_day_4, $currency), "color" => "#FCD202"),
			array('Month' => $weekly_day_five . "-" . $weekly_day_5,
				'profit' => Controller::getProfitDetails($weekly_day_5, $weekly_day_5, $currency), "color" => "#F8FF01"),
			array('Month' => $weekly_day_six . "-" . $weekly_day_6,
				'profit' => Controller::getProfitDetails($weekly_day_6, $weekly_day_6, $currency), "color" => "#B0DE09"),
			array('Month' => $weekly_day_seven . "-" . $weekly_day_7,
				'profit' => Controller::getProfitDetails($weekly_day_7, $weekly_day_7, $currency), "color" => "#04D215"));

		} else if ($type == 'month') {
			$data = array(array('Month' => 'Jan',
				'profit' => Controller::getProfitDetails($year . "-01-01", $year . "-01-31", $currency), "color" => "#FF0F00"),
			array('Month' => 'Feb',
				'profit' => Controller::getProfitDetails($year . "-02-01", $year . "-02-31", $currency), "color" => "#FF6600"),
			array('Month' => 'Mar',
				'profit' => Controller::getProfitDetails($year . "-03-01", $year . "-03-31", $currency), "color" => "#FF9E01"),
			array('Month' => 'Apr',
				'profit' => Controller::getProfitDetails($year . "-04-01", $year . "-04-31", $currency), "color" => "#FCD202"),
			array('Month' => 'May',
				'profit' => Controller::getProfitDetails($year . "-05-01", $year . "-05-31", $currency), "color" => "#F8FF01"),
			array('Month' => 'Jun',
				'profit' => Controller::getProfitDetails($year . "-06-01", $year . "-06-31", $currency), "color" => "#B0DE09"),
			array('Month' => 'Jul',
				'profit' => Controller::getProfitDetails($year . "-07-01", $year . "-07-31", $currency), "color" => "#04D215"),
			array('Month' => 'Aug',
				'profit' => Controller::getProfitDetails($year . "-08-01", $year . "-08-31", $currency), "color" => "#0D8ECF"),
			array('Month' => 'Sep',
				'profit' => Controller::getProfitDetails($year . "-09-01", $year . "-09-31", $currency), "color" => "#0D52D1"),
			array('Month' => 'Oct',
				'profit' => Controller::getProfitDetails($year . "-10-01", $year . "-10-31", $currency), "color" => "#2A0CD0"),
			array('Month' => 'Nov',
				'profit' => Controller::getProfitDetails($year . "-11-01", $year . "-11-31", $currency), "color" => "#8A0CCF"),
			array('Month' => 'Dec',
				'profit' => Controller::getProfitDetails($year . "-12-01", $year . "-12-31", $currency), "color" => "#CD0D74"),
		);
		}
		echo json_encode($data);
	}	

	//decrease notification count
	public function decreaseNotifyCount() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				AdminNotification::where('status', 'unread')->update(['status' => 'read']);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		} else {
			Session::flash('error', 'Session Expired');
			return Redirect::to($this->Url);
		}
	}

	//CMS Functions
	public function viewCms($type) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 14);
			if ($permission == true) {
				$data = Cms::where('sub_type', $type)->where('status', 'active')->get();
				return view('admin.cms.cms')->with('cms_list', $data)->with('type', $type)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function cmsAdd() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 14);
			if ($permission == true) {
				return view('admin.cms.cmsadd')->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function cmsadded() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 14);
			if ($permission == true) {
				$data = Input::all();
				$Validation = Validator::make($data, SubAdmin::$cmsRule);
				if ($Validation->fails()) {
					Session::flash('error', $Validation->messages());
					return Redirect::back();
				}
				unset($data['_token']);

				$title = strip_tags($data['title']);
				$sub_title = $data['title_show'];
				$content = $data['content'];

				$data1['title'] = $title;
				$data1['content'] = $content;
				$data1['sub_type'] = $sub_title;
				$data1['status'] = 'active';
				$result = Cms::insert($data1);

				if ($result) {
					Session::flash('success', 'CMS Added Successfully');
					return Redirect::to($this->Url.'/viewcms/legal');

				} else {
					Session::flash('error', 'Failed to update.');
					return Redirect::to($this->Url.'/viewcms/legal');
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function cmsStatus($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 14);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$cms = Cms::where('id', $id)->first();
				$new_status = ($cms->status == "active") ? "deactive" : "active";
				$update = Cms::where('id', $id)->update(['status' => $new_status]);
				if ($update) {
					$new_stat = ($cms->status == "active") ? "Deactivated" : "Activated";
					$msg = "CMS " . $new_stat . " Successfully";
					Session::flash('success', $msg);
				} else {
					Session::flash('error', 'Please Try Again');
				}
				return Redirect::back();
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function cmsEdit($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 14);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$data = Cms::where('id', $id)->first();
				return view('admin.cms.cmsEdit')->with('cms', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function cmsUpdate() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 14);
			if ($permission == true) {
				$data = Input::all();
				$Validation = Validator::make($data, SubAdmin::$cmsRule);
				if ($Validation->fails()) {
					Session::flash('error', $Validation->messages());
					return Redirect::back();
				}
				if ($data == array_filter($data)) {
					$title = strip_tags($data['title']);
					$content = $data['content'];
					$id = decrypText(strip_tags($data['id']));
					if(isset($_FILES['cms_image']['name'])) {
						if ($_FILES['cms_image']['name'] == "") {
							$image = strip_tags($data['cms_old']);
						} elseif ($_FILES['cms_image']['name'] != "") {
							$fileExtensions = ['jpeg', 'jpg', 'png'];
							$fileName = $_FILES['cms_image']['name'];
							$fileType = $_FILES['cms_image']['type'];
							$explode = explode('.', $fileName);
							$extension = end($explode);
							$fileExtension = strtolower($extension);
							$mimeImage = mime_content_type($_FILES["cms_image"]['tmp_name']);
							$explode = explode('/', $mimeImage);

							if (!in_array($fileExtension, $fileExtensions)) {
								Session::flash('error', 'Invalid file type. Only image files are accepted.');
								return Redirect::back();
							} else {
								if ($explode[0] != "image") {
									Session::flash('error', 'Invalid file type. Only image files are accepted.');
									return Redirect::back();
								}
								$cloudUpload = \Cloudinary\Uploader::upload($_FILES["cms_image"]['tmp_name']);
								if ($cloudUpload) {
									$image = $cloudUpload['secure_url'];
								} else {
									Session::flash('error', $cloudUpload["error"]["message"]);
									return Redirect::back();
								}
							}
						}
					} else {
						$image = "";
					}

					if (!empty($data['id'])) {
						$result = Cms::where('id', $id)->update(['title' => $title, 'content' => $content, 'status' => 'active', 'image' => $image]);
					} else {
						$data['id'] = $id;
						$data['title'] = $title;
						$data['content'] = $content;
						$data['image'] = $image;
						$data['status'] = 'active';
						$result = Cms::insert($data);
					}
					if ($result) {
						Session::flash('success', 'CMS Updated Successfully');
					} else {
						Session::flash('error', 'Failed to update.');
					}
					return Redirect::back();
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//Email Actions
	public function viewEmail() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 13);
			if ($permission == true) {
				$data = EmailTemplate::all();
				return view('admin.email.email')->with('email_list', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function emailEdit($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 13);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$data = EmailTemplate::where('id', $id)->first();
				return view('admin.email.emailEdit')->with('email', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function emailUpdate() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 13);
			if ($permission == true) {
				$data = Input::all();
				$Validation = Validator::make($data, SubAdmin::$emailRule);
				if ($Validation->fails()) {
					Session::flash('error', $Validation->messages());
					return Redirect::to($this->Url.'/viewemail');
				}
				if ($data == array_filter($data)) {
					$email['name'] = strip_tags($data['name']);
					$email['subject'] = strip_tags($data['subject']);
					$email['template'] = $data['template'];
					$email['id'] = decrypText(strip_tags($data['id']));
					if (!empty($data['id'])) {
						$result = EmailTemplate::where('id', $email['id'])->update(['name' => $email['name'], 'subject' => $email['subject'], 'template' => $email['template']]);
					} else {
						$result = EmailTemplate::insert($email);
					}
					if ($result) {
						Session::flash('success', 'Email Updated Successfully');
					} else {
						Session::flash('error', 'Failed to update.');
					}
					return Redirect::to($this->Url.'/viewemail');
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//Contact us actions
	public function viewContactUs() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 11);
			if ($permission == true) {
				$data = Support::where('read_status', '!=', 'deleted')->orderBy('id', 'desc')->get();
				return view('admin.contact.contactUs')->with('contact_list', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function viewNewMessage() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 11);
			if ($permission == true) {
				$data = Support::where('status', 'unread')->orderBy('id', 'desc')->get();
				return view('admin.contact.contactUs')->with('contact_list', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function contactDelete($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 11);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$update = Support::where('id', $id)->update(['read_status' => 'deleted']);
				if ($update) {
					Session::flash('success', 'Contact Us details deleted successfully');
				} else {
					Session::flash('error', 'Failed to delete');
				}
				return Redirect::back();
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function contactReply($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 11);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				Support::where('id', $id)->update(['read_status' => 'read']);
				$data = Support::where('id', $id)->first();
				return view('admin.contact.contactReply')->with('contact', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function updateContact() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 11);
			if ($permission == true) {
				$data = Input::all();
				$id = decrypText(strip_tags($data['id']));
				$replymsg = strip_tags($data['reply']);
				$username = strip_tags($data['username']);
				$email = strip_tags($data['email']);
				$usermsg = strip_tags($data['user_msg']);
				$usersubject = strip_tags($data['user_sub']);
				if ($id != "") {
					$result = Support::where('id', $id)->update(['reply' => $replymsg, 'reply_date' => date('Y-m-d H:i:s'), 'status' => 'read']);
					if ($result) {
						$getEmail = EmailTemplate::where('id', 4)->first();
						$getSiteDetails = Controller::getEmailTemplateDetails();
						$info = array('###USER###' => $username, '###MESSAGE###' => $usermsg, '###REPLY###' => $replymsg, '###SUBJECT###' => $usersubject);
						$replace = array_merge($getSiteDetails, $info);

						$emaildata = array('content' => strtr($getEmail->template, $replace));
						$toDetails['useremail'] = $data['email'];
						$toDetails['subject'] = $getEmail->subject;
						$toDetails['from'] = $getSiteDetails['contact_mail_id'];
						$toDetails['name'] = $getSiteDetails['site_name'];

						$sendEmail = Controller::sendEmail($emaildata, $toDetails);
						if (count(Mail::failures()) > 0) {
							Session::flash('error', 'Email sending failed.');
							return Redirect::back();
						} else {
							Session::flash('success', 'Reply message sent to user.');
							return Redirect::to($this->Url.'/viewContactUs');
						}

					} else {
						Session::flash('error', 'Failed to update!');
						return Redirect::back();
					}
				} else {
					Session::flash('error', 'Failed to get user information.');
					return Redirect::back();
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function newcoinList() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 16);
			if ($permission == true) {
				$data = AddCoins::orderBy('addcoin_id','desc')->get();
				return view('admin.coin.newcoinList')->with('tickets', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//SUPPORT CATEGORY START
	public function viewsupportcategory() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 10);
			if ($permission == true) {
				$data = Helpcategory::orderBy('help_cat_id', 'DESC')->get();
				return view('admin.support.supportcategory')->with('fees', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function supportcategoryadd() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 10);
			if ($permission == true) {
				$data = TradePairs::all();
				return view('admin.support.supportcategoryadded')->with('fees', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function supportcategoryaddresult() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 10);
			if ($permission == true) {
				$data = Input::all();

				$time = date('d-m-Y');
				$updata = array('category_name' => strip_tags($data['from_amt']));
				$result = Helpcategory::create($updata);
				if ($result) {
					Session::flash('success', 'Details has been Added successfully');
				} else {
					Session::flash('error', 'Failed to Added!');
				}

				return Redirect::to($this->Url.'/viewsupportcategory');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function supportcategoryedit($id = NULL) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 10);
			if ($permission == true) {

				$data = Helpcategory::where('help_cat_id', $id)->first();

				return view('admin.support.supportcategoryEdit')->with('fees', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function supportcategoryupdate() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 10);
			if ($permission == true) {
				$data = Input::all();

				$id = strip_tags($data['id']);

				$updata = array('category_name' => strip_tags($data['from_amt']));
				$result = Helpcategory::where('help_cat_id', $id)->update($updata);
				if ($result) {
					Session::flash('success', 'Details has been updated successfully');
				} else {
					Session::flash('error', 'Failed to update!');
				}
				return Redirect::to($this->Url.'/viewsupportcategory');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function supportcategorystatus($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 10);
			if ($permission == true) {

				$user = Helpcategory::where('help_cat_id', $id)->select('status', 'category_name')->first();
				$new_status = ($user->status == "0") ? "1" : "0";
				$update = Helpcategory::where('help_cat_id', $id)->update(['status' => $new_status]);
				if ($update) {
					$new_stat = ($user->status == "0") ? "1" : "0";
					if ($new_stat == '1') {
						$new_stat_dis = "Deactive";
					} else {
						$new_stat_dis = "Active";
					}

					if (session('adminId') != 1) {
						$adminNotify['admin_id'] = 1;
						$adminNotify['type'] = "KYC";
						$adminNotify['message'] = session('adminName') . " has " . $new_stat . " " . $user->category_name . ".";
						$adminNotify['status'] = "unread";
						AdminNotification::create($adminNotify);
					}
					$msg = "Support Category " . $new_stat_dis . " Successfully";
					Session::flash('success', $msg);
				} else {
					Session::flash('error', 'Please Try Again');
				}
				return Redirect::to($this->Url.'/viewsupportcategory');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}
	//SUPPORT CATEGORY END

	//support ticket actions
	public function viewSupportTicket() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 10);
			if ($permission == true) {
				$data = HelpCentre::orderBy('id', 'desc')->where('user_id', '!=', 0)->groupBy('reference_no')->get();

				return view('admin.support.supportTicket')->with('tickets', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//support ticket actions
	public function viewNewSupport() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 10);
			if ($permission == true) {
				$data = HelpCentre::where('user_id', '!=', 0)->groupBy('reference_no')->where('ticket_status', 'active')->orderBy('id', 'desc')->get();
				return view('admin.support.supportTicket')->with('tickets', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function viewPendingSupport() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 10);
			if ($permission == true) {
				$data = HelpCentre::where('user_id', '!=', 0)->groupBy('reference_no')->where('ticket_status', 'close')->orderBy('id', 'desc')->get();
				return view('admin.support.supportTicket')->with('tickets', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function ticketReply($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 10);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				HelpCentre::where('id', $id)->where('status', 'unread')->update(['status' => 'read']);
				$data = HelpCentre::where('id', $id)->first();
				$getTickets = HelpCentre::where('reference_no', $data->reference_no)->get();
				return view('admin.support.supportTicketDetail')->with('ticket', $data)->with('lists', $getTickets)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function updateTicket() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 10);
			if ($permission == true) {
				$data = Input::all();
				$id = decrypText(strip_tags($data['id']));
				$refId = decrypText($data['reference_no']);
				$status = HelpCentre::where('reference_no',$refId)->orderBy('created_at', 'desc')->select('ticket_status')->first()->ticket_status;
				
				if($status == 'close') {
					Session::flash('error', 'Ticket has beed closed by user');
					return Redirect::back();
				}
				if ($_FILES['supportimage']['name'] == "") {
					$image = "";
				} elseif ($_FILES['supportimage']['name'] != "") {
					$fileExtensions = ['jpeg', 'jpg', 'png'];
					$fileName = $_FILES['supportimage']['name'];
					$fileType = $_FILES['supportimage']['type'];
					$explode = explode('.', $fileName);
					$extension = end($explode);
					$fileExtension = strtolower($extension);
					$mimeImage = mime_content_type($_FILES["supportimage"]['tmp_name']);
					$explode = explode('/', $mimeImage);

					if (!in_array($fileExtension, $fileExtensions)) {
						Session::flash('error', 'Invalid file type. Only image files are accepted.');
						return Redirect::back();
					} else {
						if ($explode[0] != "image") {
							Session::flash('error', 'Invalid file type. Only image files are accepted.');
							return Redirect::back();
						}
						$cloudUpload = \Cloudinary\Uploader::upload($_FILES["supportimage"]['tmp_name']);
						if ($cloudUpload) {
							$image = $cloudUpload['secure_url'];
						} else {
							Session::flash('error', $cloudUpload["error"]["message"]);
							return Redirect::back();
						}
					}
				}

				$help['user_id'] = 0;
				$help['subject'] = strip_tags($data['subject']);
				$help['description'] = strip_tags($data['content']);
				$help['status'] = "read";
				$help['ticket_status'] = "open";
				$help['image'] = $image;
				$help['reference_no'] = $refId;

				$createHelp = HelpCentre::create($help);

				if ($createHelp) {
					$ticketStatus = strip_tags($data['status']);
					if ($ticketStatus == "close") {
						$ticketStatus = "close";
					}
					$result = HelpCentre::where('reference_no', $refId)->update(['status' => 'read', 'ticket_status' => $ticketStatus]);
					if ($result) {
						$helpCentre = HelpCentre::where('reference_no',$refId)->orderBy('created_at', 'asc')->select('user_id', 'description')->first();
						$user_id = $helpCentre->user_id;
						$description = $helpCentre->description;

						$userDetails = User::where('id', $user_id)->select('consumer_name', 'user_mail_id', 'unusual_user_key')->first();
						$username = $userDetails->consumer_name;
						$email = decrypText($userDetails->user_mail_id) . '@' . decrypText($userDetails->unusual_user_key);
						$getEmail = EmailTemplate::where('id', 43)->first();
						$getSiteDetails = Controller::getEmailTemplateDetails();
						$info = array('###USER###' => $username, '###MESSAGE###' => $description, '###SUBJECT###' => $data['subject'], '###REPLY###' => $data['content']);
						$replace = array_merge($getSiteDetails, $info);
						$emaildata = array('content' => strtr($getEmail->template, $replace));
						$toDetails['useremail'] = $getSiteDetails['contact_mail_id'];
						$toDetails['subject'] = $getEmail->subject;
						$toDetails['from'] = $getSiteDetails['contact_mail_id'];
						$toDetails['name'] = $getSiteDetails['site_name'];
						$sendEmail = Controller::sendEmail($emaildata, $toDetails);

						Session::flash('success', 'Reply message updated successfully');
					} else {
						Session::flash('error', 'Failed to update!');
					}
				} else {
					Session::flash('error', 'Failed to update!');
				}
				return Redirect::back();
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//User Actions
	public function userList() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$data = 1;
				return view('admin.user.userList')->with('userlist', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function viewnewuser() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$data = 2;
				return view('admin.user.userList')->with('userlist', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function viewNotverifiedKYC() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$data = 3;
				return view('admin.user.userList')->with('userlist', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function viewPendingKYC() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$data = 4;
				return view('admin.user.userList')->with('userlist', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function viewVerifiedKYC() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$data = 5;
				return view('admin.user.userList')->with('userlist', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}


	public function userHistory($new) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$totalrecords = intval(Input::get('totalrecords'));
				$draw = Input::get('draw');
				$start = Input::get('start');
				$length = Input::get('length');
				$sorttype = Input::get('order');
				$sort_col = $sorttype['0']['column'];
				$sort_type = $sorttype['0']['dir'];
				$search = Input::get('search');
				$from_date = Input::get('from');
				$to_date = Input::get('to');
				$search = $search['value'];

				if ($sort_col == '1') {
					$sort_col = 'consumer_name';
				} else if ($sort_col == '4') {
					$sort_col = 'country';
				} else if ($sort_col == '5') {
					$sort_col = 'created_at';
				} else {
					$sort_col = "id";
				}
				if ($sort_type == 'asc') {
					$sort_type = 'desc';
				} else {
					$sort_type = 'asc';
				}
				$v_status = array('0' => 'Not Verified', '1' => 'Pending', '2' => 'Rejected', '3' => 'Verified');
				$data = $orders = $sch = array();
				if($new == 1) {
					$userHis = User::whereIn('status', ['inactive', 'active', 'deactive']);
				} else if($new == 2) {
					$cur_date = date('Y-m-d');
					$userHis = User::where(DB::raw('DATE(created_at)'), $cur_date);
				} else if($new == 3) {
					$userHis = User::where('verified_status', 0);
				} else if($new == 4) {
					$userHis = User::where('verified_status', 1);
				} else if($new == 5){
					$userHis = User::where('verified_status', 3);
				}
				if ($search != '') {
					$userHis = $userHis->where(function ($q) use ($search) {
						$q->where('consumer_name', 'like', '%' . $search . '%')->orWhere('created_at', 'like', '%' . $search . '%')->orWhere('country', 'like', '%' . $search . '%')->orWhere('user_mail_id', 'like', '%' . encrypText($search) . '%')->orWhere('unusual_user_key', 'like', '%' . encrypText($search) . '%')->orWhere('status', 'like', '%' . $search . '%')->orWhere('tfa_status', 'like', '%' . $search . '%')->orWhere('phone', 'like', '%' . $search . '%');}
					);
				}

				if ($from_date) {
					$userHis = $userHis->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
				}

				if ($to_date) {
					$userHis = $userHis->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
				}

				$userHis_count = $userHis->count();
				if ($userHis_count) {

					$userHis = $userHis->select('id', 'user_mail_id', 'unusual_user_key', 'status', 'consumer_name', 'country', 'created_at', 'verified_status', 'tfa_status', 'phone', 'cashfree_status', 'auto_with', 'auto_trade');

					$orders = $userHis->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
				}

				$data = array();
				$no = $start + 1;

				if ($userHis_count) {
					foreach ($orders as $r) {
						$userId = encrypText($r['id']);
						$remove = URL::to('public/admin_assets/images/remove-user-icon.png');
						$stsUrl = URL::to($this->Url.'/userStatus/'.$userId);
						$email = decrypText($r['user_mail_id']) . "@" . decrypText($r['unusual_user_key']);
						if ($r['status'] == "active") {
							$stsCls = "clsActive";
							$resend = '-';
							$title = "Deactivated";
							$changeStatus = '<a href="'.$stsUrl.'" class="userRemove"><img src="'.$remove.'" title="'.$title.'"></a>';							
						} else if ($r['status'] == "inactive") {
							$resendUrl = URL::to($this->Url.'/userResendStatus/'.$userId);
							$resend = '<a href="'.$resendUrl.'" class="clsCtlr  clsPending">Resend</a>';
							$stsCls = "clsInactive";
							$title = "Reactivate";
							$changeStatus = "<a onclick='alert('Admin can not able to activate before user activation!')' class='userRemove'><img src='".$remove."' title='".$title."'></a>";
						} else {
							$stsCls = "clsDeactive";
							$resend = '-';
							$title = "Reactivate";
							$changeStatus = '<a href="'.$stsUrl.'" class="userRemove"><img src="'.$remove.'" title="'.$title.'"></a>';
						}	

						if ($r['tfa_status'] == "enable") {
							$tfaCls = "clsEnable";
						} else {
							$tfaCls = "clsDisable";
						}
						$tfaUrl = URL::to($this->Url.'/userTfaStatus/'.$userId);
						if ($r['verified_status'] == "3") {
							$kycCls = "clsVerify";
						} else if ($r['verified_status'] == "1") {
							$kycCls = "clsPending";
						} else if ($r['verified_status'] == "0") {
							$kycCls = "clsNotVerify";
						} else {
							$kycCls = "clsReject";
						}

						if ($r['cashfree_status'] == 1) {
							$cashCls = "clsVerify";
							$cashSts = "verified";
						} else {
							$cashCls = "clsNotVerify";
							$cashSts = "pending";
						}

						if ($r['auto_with'] == "1") {
							$withCls = "clsEnable";
							$withTxt = "Enable";
						} else {
							$withCls = "clsDisable";
							$withTxt = "Disable";
						}

						if ($r['auto_trade'] == "1") {
							$tradeCls = "clsEnable";
							$tradeTxt = "Enable";
						} else {
							$tradeCls = "clsDisable";
							$tradeTxt = "Disable";
						}

						$withUrl = URL::to($this->Url.'/userWithStatus/'.$userId);
						$tradeUrl = URL::to($this->Url.'/userTradeStatus/'.$userId);

						$accstatus = '<a class="clsCtlr '.$stsCls .'">'.ucfirst($r['status']).'</a>';
						$tfastatus = '<a href="'.$tfaUrl.'" class="tfaCls clsCtlr '.$tfaCls .'">'.ucfirst($r['tfa_status']).'</a>';
						$kycstatus = '<a class="clsCtlr '.$kycCls .'">'.$v_status[$r['verified_status']].'</a>';
						$cashstatus = '<a class="clsCtlr ' . $cashCls . '">' . ucfirst($cashSts) . '</a>';
						$withstatus = '<a href="'.$withUrl.'" class="tfaCls clsCtlr '.$withCls .'">'.$withTxt.'</a>';
						$tradestatus = '<a href="'.$tradeUrl.'" class="tfaCls clsCtlr '.$tradeCls .'">'.$tradeTxt.'</a>';
						
						$viewUrl = URL::to($this->Url.'/userDetail/'.$userId);
						$viewUser = '<a href="'.$viewUrl.'" class="editUser"><span class="glyphicon glyphicon-eye-open" style="color: #4f5259; vertical-align: middle;" title="View"></span></a>';
						array_push($data, array(
							$no,
							$r['consumer_name'],
							$email,
							$r['country'],
							$r['phone'],
							$accstatus,
							$tfastatus,
							$kycstatus,
							$cashstatus,
							$withstatus,
							$resend,
							$changeStatus . " " . $viewUser,
						));
						$no++;
					}

					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $userHis_count, 'recordsFiltered' => $userHis_count, 'data' => $data));
				} else {

					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $userHis_count, 'recordsFiltered' => $userHis_count, 'data' => array()));
				}
			} 
		}
	}

	public function userStatus($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$user = User::where('id', $id)->select('status', 'consumer_name')->first();
				if ($user->status == 'inactive') {
					$wallet = array('user_id' => $id, 'remarks' => 'Wallet creation');
					Wallet::create($wallet);

					$address['BTC'] = "sampleaddress";
					foreach ($address as $key => $value) {
						$sec = "";
						$data = array('user_id' => $id, 'address' => $value, 'currency' => $key, 'secret' => $sec);
						CoinAddress::create($data);
					}
					$update = User::where('id', $id)->update(['status' => 'active']);
				} else {
					$new_status = ($user->status == "active") ? "deactive" : "active";
					$update = User::where('id', $id)->update(['status' => $new_status]);
				}
				if ($update) {
					$new_stat = ($user->status == "active") ? "Deactivated" : "Activated";
					if (session('adminId') != 1) {
						$adminNotify['admin_id'] = 1;
						$adminNotify['type'] = "KYC";
						$adminNotify['message'] = session('adminName') . " has " . $new_stat . " " . $user->consumer_name . ".";
						$adminNotify['status'] = "unread";
						AdminNotification::create($adminNotify);
					}
					$msg = "User " . $new_stat . " Successfully";
					Session::flash('success', $msg);
				} else {
					Session::flash('error', 'Please Try Again');
				}
				return Redirect::to($this->Url.'/viewuser');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function userResendStatus($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$ids = decrypText($id);
				$user = User::where('id', $ids)->where('status', 'inactive')->select('id', 'user_mail_id', 'unusual_user_key', 'consumer_name')->first();
				if (count($user)) {
					$email_id = decrypText($user->user_mail_id) . "@" . decrypText($user->unusual_user_key);
					$username = $user->consumer_name;
					$rand = time() . '12' . mt_rand(0, 999999);
					$rid = encrypText($rand);
					$expire = date('Y-m-d H:i:s', strtotime("+10 days"));
					User::where('id', $ids)->update(['mailcode' => $rand, 'expire_at' => $expire]);
					$securl = URL::to('activateEmail/' . $id .'/' .$rid);
					$getEmail = EmailTemplate::where('id', 1)->first();
					$getSiteDetails = Controller::getEmailTemplateDetails();
					$info = array('###USER###' => '', '###LINK###' => $securl, '###registerverify_link###' => $securl);
					$replace = array_merge($getSiteDetails, $info);
					$emaildata = array('content' => strtr($getEmail->template, $replace));
					$toDetails['useremail'] = $email_id;
					$toDetails['subject'] = $getEmail->subject;
					$toDetails['from'] = $getSiteDetails['contact_mail_id'];
					$toDetails['name'] = $getSiteDetails['site_name'];
					$sendEmail = Controller::sendEmail($emaildata, $toDetails);
					if (count(Mail::failures()) > 0) {
						Session::flash('error', 'Mail Resend Failed!');
						return Redirect::to($this->Url.'/viewuser');
					} else {
						$msg1 = "New User signed up with " . SITENAME." with username " . $username . " and email " . $email_id;
						$insdata = array('admin_id' => 1, 'type' => 'New-user-ResendMail', 'message' => $msg1, 'status' => 'unread');
						AdminNotification::create($insdata);
						Session::flash('success', 'Mail Resend Successfully!');
						return Redirect::to($this->Url.'/viewuser');
					}
				} else {
					Session::flash('error', 'User Donot have Real Records!');
					return Redirect::to($this->Url.'/viewuser');
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function userTfaStatus($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$user = User::where('id', $id)->select('id', 'tfa_status')->first();
				if ($user->tfa_status == "disable") {
					Session::flash('error', " Admin can't enable TFA for the user.");
					return Redirect::back();
				} else {
					$update = User::where('id', $id)->update(['tfa_status' => 'disable', 'secret' => '', 'tfa_url' => '']);
					if ($update) {
						$msg = "TFA status disabled Successfully";
						Session::flash('success', $msg);
					} else {
						Session::flash('error', 'Please Try Again');
					}
					return Redirect::back();
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function userWithStatus($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$user = User::where('id', $id)->select('id', 'auto_with')->first();
				$sta = ($user->auto_with == 0) ? 1 : 0;
				$msg = ($user->auto_with == 0) ? 'enabled' : 'disabled';
				$update = User::where('id', $id)->update(['auto_with' => $sta]);
				if ($update) {
					$msgs = "Withdraw status ".$msg." Successfully";
					Session::flash('success', $msgs);
				} else {
					Session::flash('error', 'Please Try Again');
				}
				return Redirect::back();
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function userWithPassStatus($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$user = User::where('id', $id)->where('with_status', '1')->select('id', 'with_status')->first();
				if($user) {
					$update = User::where('id', $id)->update(['with_status' => '0', 'with_pass' => NULL]);
					if ($update) {
						Session::flash('success', "Withdraw password disabled Successfully");
					} else {
						Session::flash('error', 'Please Try Again');
					}
				} else {
					Session::flash('error', 'Please Try Again');
				}
				return Redirect::back();
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function userTradeStatus($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$user = User::where('id', $id)->select('id', 'auto_trade')->first();
				$sta = ($user->auto_trade == 0) ? 1 : 0;
				$msg = ($user->auto_trade == 0) ? 'enabled' : 'disabled';
				$update = User::where('id', $id)->update(['auto_trade' => $sta]);
				if ($update) {
					$msgs = "Trade status ".$msg." Successfully";
					Session::flash('success', $msgs);
				} else {
					Session::flash('error', 'Please Try Again');
				}
				return Redirect::back();
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function userDetail($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$data = User::where('id', $id)->with('verification')->first();
				$address = CoinAddress::where('user_id', $id)->groupBy('currency')->get();
				return view('admin.user.singleUser')->with('userinfo', $data)->with('addresslist', $address)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function updateUserProfile() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$data = Input::all();
				$userId = decrypText($data['userId']);
				$data1 = array(
					'first_name' => $data['first_name'],
					'last_name' => $data['last_name'],
					'dob' => $data['dob'],
					'address' => $data['address'],
					'city' => $data['city'],
					'state' => $data['state'],
					'country' => $data['country'],
				);
				$update = User::where('id', $userId)->update($data1);
				if($update) {
					Session::flash('success', 'Profile Updated successfully');
				} else {
					Session::flash('error', 'Please try again later');
				}
				return Redirect::back();
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function verifyUserStatus() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$data = Input::all();
				$btt_type = $btt_type1 = 0;
				$user_id = decrypText(strip_tags($data['user_id']));
				$type = strip_tags($data['type']);
				$status = strip_tags($data['status']);
				$type1 = strip_tags($data['type1']);
				$rej = array('id_status' => 'id_reject', 'id_status1' => 'id_reject1', 'addr_status' => 'addr_reject');

				($status == "2") ? $reject = $data['reject_reason'] : $reject = "";
				if ($status == "3") {$reject = "";}

				$getSts = ConsumerVerification::where('user_id', $user_id)->select($type1)->first();
				if($getSts->$type1 != 1) {
					Session::flash('error', 'Invalid request');
					return Redirect::back();
				}
				$update = ConsumerVerification::where('user_id', $user_id)->update([$type1 => $status, $rej[$type1] => $reject]);
				if ($update) {
					$getDetail = User::select('id', 'consumer_name', 'user_mail_id', 'unusual_user_key', 'referrer_id', 'country')->where('id', $user_id)
					->with(['verification' => function ($query) {
						return $query->select('user_id', 'id_status', 'addr_status', 'id_status1');
					}])
					->first();
					$kyc = $getDetail->verification;
					$referrer_id = $getDetail->referrer_id;
					$useremail = decrypText($getDetail->user_mail_id) . '@' . decrypText($getDetail->unusual_user_key);
					$getSiteDetails = Controller::getEmailTemplateDetails();

					if ($kyc->id_status == 3 && $kyc->id_status1 == 3 && $kyc->addr_status == 3) {
						User::where('id', $user_id)->update(["verified_status" => 3, "auto_with" => 1]);
					}
					if ($kyc->id_status == 2 || $kyc->id_status1 == 2 || $kyc->addr_status == 2) {
						User::where('id', $user_id)->update(["verified_status" => 2]);
					}

					if ($kyc->id_status == 2 || $kyc->id_status1 == 2) {
						ConsumerVerification::where('user_id', $user_id)->update(['id_num' => '']);
					}

					$getEmail = EmailTemplate::where('id', 3)->first();
					$sts = array('2' => 'Rejected', '3' => 'Verified');

					if ($status == "2") {
						$info = array('###USER###' => $getDetail->consumer_name, '###TYPE###' => $type, '###STATUS###' => $sts[$status], '###MSG###' => 'Please Submit Valid Info', '###REASON###' => "Reason : " . $data['reject_reason']);
					} else {
						$info = array('###USER###' => $getDetail->consumer_name, '###TYPE###' => $type, '###STATUS###' => $sts[$status], '###MSG###' => 'You can proceed with transactions.', '###REASON###' => "");
					}
					$replace = array_merge($getSiteDetails, $info);
					$emaildata = array('content' => strtr($getEmail->template, $replace));

					$toDetails['useremail'] = $useremail;
					$toDetails['subject'] = $getEmail->subject;
					$toDetails['from'] = $getSiteDetails['contact_mail_id'];
					$toDetails['name'] = $getSiteDetails['site_name'];
					
					$sendEmail = Controller::sendEmail($emaildata, $toDetails);
					
					if (count(Mail::failures()) > 0) {
						Session::flash('error', 'Email sending failed.');
						return Redirect::back();
					} else {
						$add_msg = ($sts[$status] == "Rejected") ? "Submit Valid Proof" : "";
						$msg1 = $type . " has been " . $sts[$status] . " by Admin." . $add_msg;
						$notification['user_id'] = $user_id;
						$notification['type'] = "KYC";
						$notification['message'] = $msg1;
						$notification['status'] = "unread";
						UserNotification::create($notification);
						$msg = $type . " " . $sts[$status] . " successfully";
						Session::flash('success', $msg);
						return Redirect::back();
					}
				} else {
					Session::flash('error', 'Please try again.');
					return Redirect::back();
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function verifyUserStatus1() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$data = Input::all();
				$user_id = decrypText(strip_tags($data['user_id']));
				$stype = strip_tags($data['type']);

				$getSts = ConsumerVerification::where('user_id', $user_id)->where(['id_status' => 1, 'id_status1' => 1, 'addr_status' => 1])->first();
				if($getSts) {
					if($stype == 'verify') {
						$update = ConsumerVerification::where('user_id', $user_id)->update(['id_status' => 3, 'id_status1' => 3, 'addr_status' => 3]);
					} else {					
						$update = ConsumerVerification::where('user_id', $user_id)->update(['id_status' => 2, 'id_status1' => 2, 'addr_status' => 2]);
					}
					if ($update) {
						$getDetail = User::select('id', 'consumer_name', 'user_mail_id', 'unusual_user_key', 'referrer_id', 'country')->where('id', $user_id)
						->with(['verification' => function ($query) {
							return $query->select('user_id', 'id_status', 'addr_status', 'id_status1');
						}])
						->first();
						$kyc = $getDetail->verification;
						$referrer_id = $getDetail->referrer_id;
						$useremail = decrypText($getDetail->user_mail_id) . '@' . decrypText($getDetail->unusual_user_key);
						$getSiteDetails = Controller::getEmailTemplateDetails();

						if ($kyc->id_status == 3 && $kyc->id_status1 == 3 && $kyc->addr_status == 3) {
							User::where('id', $user_id)->update(["verified_status" => 3, "auto_with" => 1]);
						}

						if ($kyc->id_status == 2 || $kyc->id_status1 == 2 || $kyc->addr_status == 2) {
							User::where('id', $user_id)->update(["verified_status" => 2]);
						}

						if ($kyc->id_status == 2 || $kyc->id_status1 == 2) {
							ConsumerVerification::where('user_id', $user_id)->update(['id_num' => '']);
						}
						
						$getEmail = EmailTemplate::where('id', 3)->first();
						$sts = array('2' => 'Rejected', '3' => 'Verified');

						if ($stype == 'reject') {
							$info = array('###USER###' => $getDetail->consumer_name, '###TYPE###' => 'KYC', '###STATUS###' => "Rejected", '###MSG###' => 'Please Submit Valid Info', '###REASON###' => "Reason : " . $data['reject_reason']);
							$sts = "Rejected";
						} else {
							$info = array('###USER###' => $getDetail->consumer_name, '###TYPE###' => 'KYC', '###STATUS###' => "Verified", '###MSG###' => 'You can proceed with transactions.', '###REASON###' => "");
							$sts = "Verified";
						}
						$replace = array_merge($getSiteDetails, $info);
						$emaildata = array('content' => strtr($getEmail->template, $replace));

						$toDetails['useremail'] = $useremail;
						$toDetails['subject'] = $getEmail->subject;
						$toDetails['from'] = $getSiteDetails['contact_mail_id'];
						$toDetails['name'] = $getSiteDetails['site_name'];

						$sendEmail = Controller::sendEmail($emaildata, $toDetails);
						
						if (count(Mail::failures()) > 0) {
							$response = array('status' => '0', 'msg' => 'Email sending failed.');
							echo json_encode($response);exit;
						} else {
							$add_msg = ($stype == 'reject') ? "Submit Valid Proof" : "";
							$msg1 = "KYC has been " . $sts . " by Admin." . $add_msg;
							$notification['user_id'] = $user_id;
							$notification['type'] = "KYC";
							$notification['message'] = $msg1;
							$notification['status'] = "unread";
							UserNotification::create($notification);
							$msg = "KYC " . $sts . " successfully";
							$response = array('status' => '1', 'msg' => $msg);
							echo json_encode($response);exit;
						}
					} else {
						$response = array('status' => '0', 'msg' =>  'Please try again.');
						echo json_encode($response);exit;					
					}
				} else {
					$response = array('status' => '0', 'msg' =>  'Invalid request');
					echo json_encode($response);exit;
				}
			} else {
				$response = array('status' => '0', 'msg' =>  'Permission Denied!');
				echo json_encode($response);exit;
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function createVpa($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$user_id = strip_tags(decrypText($id));
				$getDetail = User::select('phone')->where('country', 'India')->where('id', $user_id)->where('cashfree_status', '!=', 1)->where('verified_status', '3')->first();
				if (count($getDetail) > 0) {
					$phone = ltrim($getDetail->phone, '0');
					$length = strlen($phone);
					if ($length == 10) {
						$cashfree_accnum = 'BITPI' . $phone;
						$cashfree_ifsc = 'ICIC0000200';
						$update = User::where('id', $user_id)->update(['cashfree_status' => '1', 'cashfree_accnum' => $cashfree_accnum, 'cashfree_ifsc' => $cashfree_ifsc]);
						if ($update) {
							Session::flash('success', 'Created Successfully');
						} else {
							User::where('id', $user_id)->update(['cashfree_status' => '2']);
							Session::flash('error', 'Please try again later');
						}
					} else {
						User::where('id', $user_id)->update(['cashfree_status' => '3']);
						Session::flash('error', 'Mobile number issue');
					}
				} else {
					Session::flash('error', 'Please try again.');
				}
				return Redirect::back();
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function resetUserStatus($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$user_id = decrypText($id);
				$userDetails = User::where('id', $user_id)->count();
				if($userDetails) {
					$update = User::where('id', $user_id)->update(['verified_status' => '0']);
					$update1 = ConsumerVerification::where('user_id', $user_id)->update(['id_proof' => NULL, 'id_status' => '0', 'id_proof1' => NULL, 'id_status1' => '0', 'addr_proof' => NULL, 'addr_status' => '0', 'id_num' => NULL]);
					if($update && $update1) {
						Session::flash('success', 'KYC Reseted Successfully');
						return Redirect::back();
					} else {
						Session::flash('error', 'Please try again.');
						return Redirect::back();
					}	
				} else {
					Session::flash('error', 'Something went wrong!');
					return Redirect::back();
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function viewHistory($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));

				if ($id) {
					$res = UserActivity::where('user_id', $id)->where('activity', 'Login')->orderBy('id', 'desc')->get();

					$data = User::where('id', $id)->select('consumer_name', 'id')->first();
					return view('admin.user.singleUserHistory')->with('userinfo', $data)->with('activity', $res)->with('redirectUrl', $this->Url);
				} else {
					Session::flash('error', 'Permission Denied!');
					return Redirect::to($this->Url);
				}
			}
			Session::flash('error', 'Session Expired');
			return Redirect::to($this->Url);
		}
	}

	//user balance
	public function viewUserBalance() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$all_cur = Currency::where('status','1')->select('currency_symbol')->get();
				return view('admin.user.userBalance')->with('mycur', $all_cur)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function userBalance() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$totalrecords = intval(Input::get('totalrecords'));
				$draw = Input::get('draw');
				$start = Input::get('start');
				$length = Input::get('length');
				$sorttype = Input::get('order');
				$sort_col = $sorttype['0']['column'];
				$sort_type = $sorttype['0']['dir'];
				$search = Input::get('search');
				$from_date = Input::get('from');
				$to_date = Input::get('to');
				$search = $search['value'];

				if ($sort_col == '1') {
					$sort_col = 'U.consumer_name';
				} else if ($sort_col == '2') {
					$sort_col = 'w.BTC';
				} else if ($sort_col == '3') {
					$sort_col = 'w.ETH';
				} else if ($sort_col == '4') {
					$sort_col = 'w.LTC';
				} else if ($sort_col == '5') {
					$sort_col = 'w.USDT';
				} else if ($sort_col == '6') {
					$sort_col = 'w.BCH';
				} else if ($sort_col == '7') {
					$sort_col = 'w.DASH';
				} else if ($sort_col == '8') {
					$sort_col = 'w.XRP';
				} else if ($sort_col == '17') {
					$sort_col = 'w.INR';
				} else {
					$sort_col = "w.id";
				}
				if ($sort_type == 'asc') {
					$sort_type = 'desc';
				} else {
					$sort_type = 'asc';
				}
				$data = $orders = array();
				$walHis = DB::table(WALLET.' as w')->leftjoin(USERINFO.' AS U', 'U.id', '=', 'w.user_id');
				$all_cur = Currency::where('status','1')->select('currency_symbol')->get();
				if ($search != '') {
					$walHis = $walHis->where(function ($q) use ($search) {
						$q->where('U.consumer_name', 'like', '%' . $search . '%')->orWhere('w.BTC', 'like', '%' . $search . '%')->orWhere('w.ETH', 'like', '%' . $search . '%')->orWhere('w.LTC', 'like', '%' . $search . '%')->orWhere('w.USDT', 'like', '%' . $search . '%')->orWhere('w.INR', 'like', '%' . $search . '%')->orWhere('w.BCH', 'like', '%' . $search . '%')->orWhere('w.DASH', 'like', '%' . $search . '%')->orWhere('w.XRP', 'like', '%' . $search . '%');}
					);
				}

				if ($from_date) {
					$walHis = $walHis->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
				}

				if ($to_date) {
					$walHis = $walHis->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
				}

				$walHis_count = $walHis->count();
				if ($walHis_count) {

					$walHis = $walHis->select('w.*', 'U.consumer_name');

					$orders = $walHis->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
				}

				$data = array();
				$no = $start + 1;

				if ($walHis_count) {
					foreach ($orders as $r) {
						$equiv_inr = 0;
						$userId = encrypText($r->user_id);
						$wallet = Wallet::where('user_id', $r->user_id)->first();
						$viewUrl = URL::to($this->Url.'/userDetail/'. $userId);
						$username = '<a href="'.$viewUrl.'">'.$r->consumer_name.'</a>';
						$wcwr = array($no,$username);
						foreach ($all_cur as $key => $value) {
							$cur = $value->currency_symbol;
							$bal = $wallet->$cur;
							$inorder = portfolioInorder($cur, $r->user_id);
							$total = $bal + $inorder;
							$wcwr[] = $bal;
						}
						array_push($data,$wcwr);
						$no++;
					}
					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $walHis_count, 'recordsFiltered' => $walHis_count, 'data' => $data));
				} else {
					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $walHis_count, 'recordsFiltered' => $walHis_count, 'data' => array()));
				}
			} 
		}
	}

	public function viewInorderHistory($uid = '') {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$userId = decrypText($uid);
				$cur = Currency::where('status', '1')->get();
				$userDetail = User::where('id', $userId)->select('consumer_name')->first();
				if(count($userDetail)) {
					$name = $userDetail->consumer_name;
					$wallet = Wallet::where('user_id', $userId)->select('BTC', 'ETH', 'LTC', 'USDT', 'BCH', 'DASH', 'XRP', 'INR')->get()->toArray();
					return view('admin.user.userInorder')->with('pairs', $wallet)->with('name', $name)->with('bcva', $uid)->with('redirectUrl', $this->Url);
				}  else {
					Session::flash('error', 'Please try again later');
					return Redirect::to($this->Url);
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}


	//user bank actions
	public function viewUserBank($new = '') {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				if($new == '') {
					$data = 1;
				} else {
					$data = $new;
				}
				return view('admin.user.userBank')->with('banks', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function bankHistory($new) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$totalrecords = intval(Input::get('totalrecords'));
				$draw = Input::get('draw');
				$start = Input::get('start');
				$length = Input::get('length');
				$sorttype = Input::get('order');
				$sort_col = $sorttype['0']['column'];
				$sort_type = $sorttype['0']['dir'];
				$search = Input::get('search');
				$from_date = Input::get('from');
				$to_date = Input::get('to');
				$search = $search['value'];

				if ($sort_col == '1') {
					$sort_col = 'U.consumer_name';
				} else if ($sort_col == '2') {
					$sort_col = 'B.currency';
				} else if ($sort_col == '3') {
					$sort_col = 'B.bank_name';
				} else if ($sort_col == '4') {
					$sort_col = 'B.acc_name';
				} else if ($sort_col == '5') {
					$sort_col = 'B.acc_number';
				} else if ($sort_col == '6') {
					$sort_col = 'B.bank_branch';
				} else if ($sort_col == '7') {
					$sort_col = 'B.status';
				} else {
					$sort_col = "B.id";
				}
				if ($sort_type == 'asc') {
					$sort_type = 'desc';
				} else {
					$sort_type = 'asc';
				}
				$data = $orders = array();

				if($new == 1) {
					$bankHis = DB::table(USERBANK.' as B')->leftjoin(USERINFO.' AS U', 'U.id', '=', 'B.user_id')->whereIn('B.status', ['1', '2', '3']); 
				} else if($new == 2) {
					$bankHis = DB::table(USERBANK.' as B')->leftjoin(USERINFO.' AS U', 'U.id', '=', 'B.user_id')->where('B.status', '2');
				} else {
					$bankHis = DB::table(USERBANK.' as B')->where('B.user_id', decrypText($new))->leftjoin(USERINFO.' AS U', 'U.id', '=', 'B.user_id');
				}

				if ($search != '') {
					$bankHis = $bankHis->where(function ($q) use ($search) {
						$q->where('U.consumer_name', 'like', '%' . $search . '%')->orWhere('B.currency', 'like', '%' . $search . '%')->orWhere('B.bank_name', 'like', '%' . $search . '%')->orWhere('B.acc_name', 'like', '%' . $search . '%')->orWhere('B.acc_number', 'like', '%' . $search . '%')->orWhere('B.bank_branch', 'like', '%' . $search . '%')->orWhere('B.status', 'like', '%' . $search . '%');}
					);
				}

				if ($from_date) {
					$bankHis = $bankHis->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
				}

				if ($to_date) {
					$bankHis = $bankHis->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
				}

				$bankHis_count = $bankHis->count();
				if ($bankHis_count) {

					$bankHis = $bankHis->select('B.id', 'B.currency', 'B.bank_name', 'B.acc_name', 'B.acc_number', 'B.bank_branch', 'B.status', 'B.beneId_status', 'U.consumer_name');

					$orders = $bankHis->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
				}

				$data = array();
				$no = $start + 1;

				if ($bankHis_count) {
					foreach ($orders as $r) {
						$bankId = encrypText($r->id);

						if ($r->status == '2') {
							$bankStatus = '<a class="clsCtlr clsDeactive">Pending</a>';
						} else if ($r->status == '1') {
							$bankStatus = '<a class="clsCtlr clsActive">Active</a>';
						} else if ($r->status == '3') {
							$bankStatus = '<a class="clsCtlr clsDeactive">Rejected</a>';
						} else if ($r->status == '0') {
							$bankStatus = '<a class="clsCtlr clsDeactive">Deactivated</a>';
						}

						if($r->beneId_status == 1) {
							$beneStatus = '<a class="clsCtlr clsActive">Active</a>';
						} else {
							$beneStatus = '<a class="clsCtlr clsNotVerify">Pending</a>';
						}

						$viewUrl = URL::to($this->Url.'/viewUserBankDetail/'.$bankId);
						$editUrl = URL::to($this->Url.'/editUserBankDetail/'.$bankId);
						$deleteUrl = URL::to($this->Url.'/userBankDelete/'.$bankId);
						$edit_icon = URL::to('public/admin_assets/images/edit-icon.png');
						$img = URL::to('public/admin_assets/images/delete-icon.png');
						$viewBank = '<a href="'.$viewUrl.'" class="editUser"><span class="glyphicon glyphicon-eye-open" style="color: #4f5259; vertical-align: middle;" title="View"></span></a>';
						$editBank = '<a href="'.$editUrl.'" class="editUser"><img src="'.$edit_icon.'"></a>';
						$deleteBank = '<a href="'.$deleteUrl.'" class="deleteUser"><img src="'.$img.'" title="Delete"  /></a>';
						array_push($data, array(
							$no,
							$r->consumer_name,
							$r->currency,
							$r->bank_name,
							$r->acc_name,
							$r->acc_number,
							$r->bank_branch,
							$bankStatus,
							$beneStatus,
							$viewBank.' ' .$editBank .' '.$deleteBank,
						));
						$no++;
					}

					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $bankHis_count, 'recordsFiltered' => $bankHis_count, 'data' => $data));
				} else {

					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $bankHis_count, 'recordsFiltered' => $bankHis_count, 'data' => array()));
				}
			} 
		}
	}

	public function viewUserBankDetail($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$id = decrypText($id);
				$data = UserBank::where('id', $id)->first();
				if ($data) {
					return view('admin.user.viewUserBank')->with('bank', $data)->with('redirectUrl', $this->Url);
				} else {
					return Redirect::to($this->Url);
				}

			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function editUserBankDetail($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$id = decrypText($id);
				$data = UserBank::where('id', $id)->first();
				if ($data) {
					return view('admin.user.editUserBank')->with('bank', $data)->with('redirectUrl', $this->Url);
				} else {
					return Redirect::to($this->Url);
				}

			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function verifyUserbankStatus() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$data = Input::all();
				$bankId = decrypText(strip_tags($data['bank_id']));
				$user_id = decrypText(strip_tags($data['user_id']));
				$type = strip_tags($data['type']);
				$status = strip_tags($data['status']);
				$bank_currency = strip_tags($data['bank_currency']);
				$type1 = strip_tags($data['type1']);
				$rej = array('id_status' => 'id_reject', 'id_status1' => 'id_reject1', 'selfie_status' => 'selfie_reject', 'bank_status' => 'bank_reject', 'addr_status' => 'addr_reject');

				($status == "3") ? $reject = $data['reject_reason'] : $reject = "";
				if ($status == "1") {$reject = "";}

				$update = UserBank::where('id', $bankId)->where('currency', $bank_currency)->update(['status' => $status]);
				if ($update) {
					$getDetail = User::select('id', 'consumer_name', 'user_mail_id', 'unusual_user_key')->where('id', $user_id)->first();
					$useremail = decrypText($getDetail->user_mail_id) . '@' . decrypText($getDetail->unusual_user_key);
					$getSiteDetails = Controller::getEmailTemplateDetails();
					$getEmail = EmailTemplate::where('id', 20)->first();
					$sts = array('3' => 'Rejected', '1' => 'Verified');

					if ($status == "3") {
						$info = array('###USER###' => $getDetail->consumer_name, '###TYPE###' => $type, '###STATUS###' => $sts[$status], '###MSG###' => 'Please Submit Valid Bank Information', '###REASON###' => "Reason : " . $data['reject_reason']);
					} else {
						$info = array('###USER###' => $getDetail->consumer_name, '###TYPE###' => $type, '###STATUS###' => $sts[$status], '###MSG###' => 'You can proceed with transactions.', '###REASON###' => "");
					}
					$replace = array_merge($getSiteDetails, $info);
					$emaildata = array('content' => strtr($getEmail->template, $replace));

					$toDetails['useremail'] = $useremail;
					$toDetails['subject'] = $getEmail->subject;
					$toDetails['from'] = $getSiteDetails['contact_mail_id'];
					$toDetails['name'] = $getSiteDetails['site_name'];

					$sendEmail = Controller::sendEmail($emaildata, $toDetails);

					if (count(Mail::failures()) > 0) {
						Session::flash('error', 'Email sending failed.');
						return Redirect::back();
					} else {
						$add_msg = ($sts[$status] == "Rejected") ? "Submit Valid Details" : "";
						$msg1 = $type . " has been " . $sts[$status] . " by Admin." . $add_msg;
						$notification['user_id'] = $user_id;
						$notification['type'] = "New Bank";
						$notification['message'] = $msg1;
						$notification['status'] = "unread";
						UserNotification::create($notification);
						$msg = $type . " " . $sts[$status] . " successfully";
						Session::flash('success', $msg);
						return Redirect::back();
					}
				} else {
					Session::flash('error', 'Please try again.');
					return Redirect::back();
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function userBankStatus($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$bankInfo = UserBank::where('id', $id)->first();
				$new_status = ($bankInfo->status == "active") ? "deactive" : "active";
				$update = UserBank::where('id', $id)->update(['status' => $new_status]);
				if ($update) {
					$user_id = $bankInfo->user_id;
					$getDetail = User::select('consumer_name', 'user_mail_id', 'unusual_user_key')->where('id', $user_id)->first();

					$useremail = decrypText($getDetail->user_mail_id) . '@' . decrypText($getDetail->unusual_user_key);
					$getSiteDetails = Controller::getEmailTemplateDetails();
					$getEmail = EmailTemplate::where('id', 20)->first();
					$type = "Bank";
					$new_stat = ($bankInfo->status == "active") ? "Deactivated" : "Activated";

					if ($new_status == "deactive") {
						$info = array('###USER###' => $getDetail->consumer_name, '###TYPE###' => $type, '###STATUS###' => $new_stat, '###MSG###' => 'Please Submit Valid Info', '###REASON###' => "");
					} else {
						$info = array('###USER###' => $getDetail->consumer_name, '###TYPE###' => $type, '###STATUS###' => $new_stat, '###MSG###' => $type . " Verified.", '###REASON###' => "");
					}
					$replace = array_merge($getSiteDetails, $info);
					$emaildata = array('content' => strtr($getEmail->template, $replace));

					$toDetails['useremail'] = $useremail;
					$toDetails['subject'] = $getEmail->subject;
					$toDetails['from'] = $getSiteDetails['contact_mail_id'];
					$toDetails['name'] = $getSiteDetails['site_name'];

					$sendEmail = Controller::sendEmail($emaildata, $toDetails);

					if (count(Mail::failures()) > 0) {
						Session::flash('error', 'Email sending failed.');
						return Redirect::back();
					} else {
						$add_msg = ($new_status == "deactive") ? "Submit Valid info" : "";
						$msg1 = $type . " has been " . $new_stat . " by Admin." . $add_msg;
						$notification['user_id'] = $user_id;
						$notification['type'] = "BANK";
						$notification['message'] = $msg1;
						$notification['status'] = "unread";
						UserNotification::create($notification);
					}

					$msg = "Bank detail " . $new_stat . " Successfully";
					Session::flash('success', $msg);
				} else {
					Session::flash('error', 'Please Try Again');
				}
				return Redirect::back();
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function bankUpdateuser() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				$data = Input::all();
				$currency = strip_tags($data['currency']);
				$bank_name = strip_tags($data['bank_name']);
				$acc_name = strip_tags($data['acc_name']);
				$acc_number = strip_tags($data['acc_number']);
				$bank_code = strip_tags($data['bank_code']);
				$bank_branch = strip_tags($data['bank_branch']);
				$bank_status = strip_tags($data['status']);
				$userId = strip_tags($data['userId']);

				$bankId = strip_tags($data['bankId']);

				$updata = array('currency' => $currency, 'bank_name' => $bank_name, 'acc_name' => $acc_name, 'acc_number' => $acc_number, 'bank_swift' => $bank_code, 'bank_branch' => $bank_branch, 'status' => $bank_status);

				$result = UserBank::where('user_id', decrypText($userId))->where('id', decrypText($bankId))->update($updata);
				$msg = 'Bank Updated successfully';
				if ($result) {
					Session::flash('success', $msg);
				} else {
					Session::flash('error', 'Failed to update.');
				}
				return redirect($this->Url.'/viewUserBank');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function userBankDelete($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 8);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$bankDetails = UserBank::where(['id' => $id])->select('user_id', 'acc_number', 'beneId_status')->first();
				if ($bankDetails) {
					$bankInfo = UserBank::where(['id' => $id])->delete();
					if ($bankInfo) {
						$msg1 = "Your bank detail with account number " . $bankDetails->acc_number . " has been deleted by Admin.";
						$notification['user_id'] = $bankDetails->user_id;
						$notification['type'] = "Delete Bank";
						$notification['message'] = $msg1;
						$notification['status'] = "unread";
						UserNotification::create($notification);
						Session::flash('success', "Bank information deleted Successfully");
					} else {
						Session::flash('error', 'Please Try Again');
					}
				} else {
					Session::flash('error', 'Please Try Again');
				}
				return Redirect::to($this->Url.'/viewUserBank');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}
	
	public function createBeneficiary($bankUser, $bankId) {
		if (session('adminId') != '') {
			 
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function viewNews() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				$data = News::orderBy('id','desc')->get();
				return view('admin.news.news')->with('newsList', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function NewsEdit($id = NULL) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				if ($id != "") {
					$id = decrypText(strip_tags($id));
					$data = News::where('id', $id)->first();
					$data['type'] = "edit";
				} else {
					$data['quote'] = "";
					$data['type'] = 'add';
				}
				return view('admin.news.newsEdit')->with('quote', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function NewsUpdate() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				$data = Input::all();
				$Validation = Validator::make($data, SubAdmin::$quoteRule);
				if ($Validation->fails()) {
					Session::flash('error', $Validation->messages());
					return Redirect::back();
				}

				if ($_FILES['author_pic']['name'] == "") {
					$image = strip_tags($data['author_pic_old']);
				} else if ($_FILES['author_pic']['name'] != "") {
					$fileExtensions = ['jpeg', 'jpg', 'png'];
					$fileName = $_FILES['author_pic']['name'];
					$fileType = $_FILES['author_pic']['type'];
					$explode = explode('.', $fileName);
					$extension = end($explode);
					$fileExtension = strtolower($extension);
					$mimeImage = mime_content_type($_FILES["author_pic"]['tmp_name']);
					$explode = explode('/', $mimeImage);

					if (!in_array($fileExtension, $fileExtensions)) {
						Session::flash('error', 'Invalid file type. Only image files are accepted.');
						return Redirect::back();
					} else {
						if ($explode[0] != "image") {
							Session::flash('error', 'Invalid file type. Only image files are accepted.');
							return Redirect::back();
						}
						$cloudUpload = \Cloudinary\Uploader::upload($_FILES["author_pic"]['tmp_name']);
						if ($cloudUpload) {
							$image = $cloudUpload['secure_url'];
						} else {
							Session::flash('error', $cloudUpload["error"]["message"]);
							return Redirect::back();
						}
					}
				}
				$quote['author'] = $data['author'];
				$quote['title'] = $data['designation'];
				$quote['content'] = $data['quote'];
				$quote['image'] = $image;
				$quote['status'] = 'active';

				if ($data['id'] != "") {
					$id = decrypText(strip_tags($data['id']));
					$result = News::where('id', $id)->update($quote);
					$msg = 'News updated successfully';
				} else {
					$result = News::create($quote);
					$msg = 'News added successfully';
				}
				if ($result) {
					Session::flash('success', $msg);
				} else {
					Session::flash('success', "Please try again!");
				}
				return Redirect::to($this->Url.'/viewNews');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function NewsDelete($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$quote = News::where(['id' => $id])->delete();
				if ($quote) {
					Session::flash('success', "News deleted Successfully");
				} else {
					Session::flash('error', 'Please Try Again');
				}
				return Redirect::to($this->Url.'/viewNews');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function viewsubscription() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				$data = Subscribe::where('status', '0')->get();
				return view('admin.subscription.subscription')->with('subscription', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function subscriptionDelete($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));

				$result = Subscribe::where('id', $id)->update(['status' => '1']);

				if ($result) {
					Session::flash('success', "Subscription  User deleted Successfully");
				} else {
					Session::flash('error', 'Please Try Again');
				}
				return Redirect::to($this->Url.'/viewsubscription');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//FAQ actions
	public function viewFaq() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 12);
			if ($permission == true) {
				$data = Faq::orderBy('id','desc')->get();
				return view('admin.faq.faq')->with('faq_list', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function faqEdit($id = NULL) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 12);
			if ($permission == true) {
				if ($id != "") {
					$id = decrypText(strip_tags($id));
					$data = Faq::where('id', $id)->first();
					$data['type'] = "edit";
				} else {
					$data['faq'] = "";
					$data['type'] = 'add';
				}
				return view('admin.faq.faqEdit')->with('faq', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function faqUpdate() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 12);
			if ($permission == true) {
				$data = Input::all();
				$Validation = Validator::make($data, SubAdmin::$faqRule);
				if ($Validation->fails()) {
					Session::flash('error', $Validation->messages());
					return Redirect::to($this->Url.'/viewfaq');
				}
				if (!empty($data)) {
					$faq['question'] = strip_tags($data['question']);
					$faq['description'] = $data['description'];
					$faq['status'] = 'active';
					$faqId = decrypText(strip_tags($data['id']));
					if ($data['id'] != "") {
						$result = Faq::where('id', $faqId)->update($faq);
					} else {
						$result = Faq::create($faq);
					}
					if ($result) {
						Session::flash('success', 'FAQ Updated Successfully');
					} else {
						Session::flash('error', 'Failed to update.');
					}
					return Redirect::to($this->Url.'/viewfaq');
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function faqStatus($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 12);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$faq = Faq::where('id', $id)->first();
				$new_status = ($faq->status == "active") ? "deactive" : "active";
				$update = Faq::where('id', $id)->update(['status' => $new_status]);
				if ($update) {
					$new_stat = ($faq->status == "active") ? "Deactivated" : "Activated";
					$msg = "FAQ " . $new_stat . " Successfully";
					Session::flash('success', $msg);
				} else {
					Session::flash('error', 'Please Try Again');
				}
				return Redirect::to($this->Url.'/viewfaq');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function faqDelete($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 12);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$faq = Faq::where(['id' => $id])->delete();
				if ($faq) {
					Session::flash('success', "FAQ deleted Successfully");
				} else {
					Session::flash('error', 'Please Try Again');
				}
				return Redirect::to($this->Url.'/viewfaq');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//Meta functions
	public function viewMeta() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				$data = MetaContent::all();
				return view('admin.meta.meta')->with('meta_list', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function metaEdit($id = NULL) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$data = MetaContent::where('id', $id)->first();
				return view('admin.meta.metaEdit')->with('meta', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function metaUpdate() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				$data = Input::all();
				$Validation = Validator::make($data, SubAdmin::$metaRule);
				if ($Validation->fails()) {
					Session::flash('error', $Validation->messages());
					return Redirect::to($this->Url.'/viewmeta');
				}
				if ($data == array_filter($data)) {
					$meta['title'] = strip_tags($data['title']);
					$meta['meta_keywords'] = strip_tags($data['meta_keywords']);
					$meta['meta_description'] = strip_tags($data['meta_description']);
					$meta['id'] = decrypText($data['id']);
					if (!empty($data['id'])) {
						$result = MetaContent::where('id', $meta['id'])->update(['title' => $meta['title'], 'meta_keywords' => $meta['meta_keywords'], 'meta_description' => $meta['meta_description']]);
					} else {
						$result = MetaContent::insert($meta);
					}
					if ($result) {
						Session::flash('success', 'Meta Content Updated Successfully');
					} else {
						Session::flash('error', 'Failed to update.');
					}
					return Redirect::to($this->Url.'/viewmeta');
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//admin bank actions
	public function viewAdminBank() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 8);
			if ($permission == true) {
				$data = AdminBank::all();
				return view('admin.adminbank.adminBank')->with('banks', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function bankuserEdit($id = NULL) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 8);
			if ($permission == true) {
				if ($id != "") {
					$id = decrypText(strip_tags($id));
					$bank = AdminBank::where('id', $id)->first();
					$type = "edit";
				} else {
					$country = Country::all();
					if ($country->isEmpty()) {$country = array();}
					$bank = "";
					$type = "add";
				}

				return view('admin.adminbank.viewSingleBankUser')->with('bank', $bank)->with('country', $country)->with('type', $type)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function bankEdit($id = NULL) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 8);
			if ($permission == true) {
				if ($id != "") {
					$id = decrypText(strip_tags($id));
					$bank = AdminBank::where('id', $id)->first();
					$type = "edit";
				} else {
					$bank = "";
					$type = "add";
				}
				return view('admin.adminbank.viewSingleBank')->with('bank', $bank)->with('type', $type)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function bankDelete($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 8);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$bankInfo = AdminBank::where(['id' => $id])->delete();
				if ($bankInfo) {
					Session::flash('success', "Bank information deleted Successfully");
				} else {
					Session::flash('error', 'Please Try Again');
				}
				return Redirect::to($this->Url.'/viewAdminBank');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function bankStatus($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 8);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$bankInfo = AdminBank::where('id', $id)->select('currency', 'status')->first();
				$new_status = ($bankInfo->status == "active") ? "deactive" : "active";
				$update = AdminBank::where('id', $id)->update(['status' => $new_status]);
				if ($update) {
					$new_stat = ($bankInfo->status == "active") ? "Deactivated" : "Activated";
					$msg = "Bank detail " . $new_stat . " Successfully";
					Session::flash('success', $msg);
				} else {
					Session::flash('error', 'Please Try Again');
				}
				return Redirect::to($this->Url.'/viewAdminBank');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function bankUpdate() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 8);
			if ($permission == true) {
				$data = Input::all();
				$Validation = Validator::make($data, SubAdmin::$bankRule);
				if ($Validation->fails()) {
					Session::flash('error', $Validation->messages());
					return Redirect::to($this->Url.'/viewAdminBank');
				}
				$currency = strip_tags($data['currency']);
				$bank_name = strip_tags($data['bank_name']);
				$acc_name = strip_tags($data['acc_name']);
				$acc_number = strip_tags($data['acc_number']);
				$bank_code = strip_tags($data['bank_code']);
				$bank_branch = strip_tags($data['bank_branch']);
				$bank_country = strip_tags($data['bank_country']);
				$bankId = strip_tags($data['id']);

				$updata = array('currency' => $currency, 'bank_name' => $bank_name, 'acc_name' => $acc_name, 'acc_number' => $acc_number, 'bank_code' => $bank_code, 'bank_branch' => $bank_branch, 'bank_country' => $bank_country);

				$id = decrypText($bankId);
				if ($bankId != "") {
					$getStatus = AdminBank::where('id', $id)->select('status')->first();
					$updata['status'] = $getStatus->status;
					$result = AdminBank::where('id', $id)->update($updata);
					$msg = 'Admin bank updated successfully';
				} else {
					$updata['status'] = 'active';
					$result = AdminBank::create($updata);
					$msg = 'Admin bank added successfully';
				}
				if ($result) {
					Session::flash('success', $msg);
				} else {
					Session::flash('error', 'Failed to update.');
				}
				return redirect($this->Url.'/viewAdminBank');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function viewtransaction() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$deposit = Deposit::orderBy('id', 'desc')->get();
				$withdraw = Withdraw::orderBy('id', 'desc')->get();
				return view('admin.user.transaction')->with('deposit', $deposit)->with('withdraw', $withdraw)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//Deposit functions
	public function viewDeposit() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$data = 1;
				return view('admin.deposit.deposit')->with('deposit', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function viewPendingDeposit() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$data = 2;
				return view('admin.deposit.deposit')->with('deposit', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function viewUnconfirmed() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				return view('admin.deposit.unconfirmed')->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function depositHistory($new) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$totalrecords = intval(Input::get('totalrecords'));
				$draw = Input::get('draw');
				$start = Input::get('start');
				$length = Input::get('length');
				$sorttype = Input::get('order');
				$sort_col = $sorttype['0']['column'];
				$sort_type = $sorttype['0']['dir'];
				$search = Input::get('search');
				$from_date = Input::get('from');
				$to_date = Input::get('to');
				$search = $search['value'];

				if ($sort_col == '1') {
					$sort_col = 'D.created_at';
				} else if ($sort_col == '2') {
					$sort_col = 'U.consumer_name';
				} else if ($sort_col == '3') {
					$sort_col = 'U.country';
				} else if ($sort_col == '4') {
					$sort_col = 'D.amount';
				} else if ($sort_col == '5') {
					$sort_col = 'D.currency';
				} else if ($sort_col == '6') {
					$sort_col = 'D.reference_no';
				} else if ($sort_col == '7') {
					$sort_col = 'D.status';
				} else {
					$sort_col = "D.id";
				}
				if ($sort_type == 'asc') {
					$sort_type = 'desc';
				} else {
					$sort_type = 'asc';
				}
				$data = $orders = array();
				if($new == 1) {
					$depositHis = DB::table(DEPOSIT.' as D')->leftjoin(USERINFO.' AS U', 'U.id', '=', 'D.user_id');
				} else {
					$depositHis = DB::table(DEPOSIT.' as D')->where('D.status', 'pending')->leftjoin(USERINFO.' AS U', 'U.id', '=', 'D.user_id');
				}
				if ($search != '') {
					$depositHis = $depositHis->where(function ($q) use ($search) {
						$q->where('D.created_at', 'like', '%' . $search . '%')->orWhere('U.consumer_name', 'like', '%' . $search . '%')->orWhere('U.country', 'like', '%' . $search . '%')->orWhere('D.amount', 'like', '%' . $search . '%')->orWhere('D.currency', 'like', '%' . $search . '%')->orWhere('D.reference_no', 'like', '%' . $search . '%')->orWhere('D.status', 'like', '%' . $search . '%')->orWhere('D.payment_type', 'like', '%' . $search . '%');}
					);
				}

				if ($from_date) {
					$depositHis = $depositHis->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
				}

				if ($to_date) {
					$depositHis = $depositHis->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
				}

				$depositHis_count = $depositHis->count();
				if ($depositHis_count) {

					$depositHis = $depositHis->select('D.id', 'D.user_id' ,'D.reference_no', 'D.currency', 'D.created_at', 'D.status', 'D.amount', 'D.payment_method', 'D.trans_type', 'U.consumer_name', 'U.country', 'D.payment_type');

					$orders = $depositHis->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
				}

				$txUrl = array(
					'BTC' => 'https://live.blockcypher.com/btc/tx/',
					'ETH' => 'https://etherscan.io/tx/',
					'USDT' => 'https://etherscan.io/tx/',
					'LTC' => 'https://live.blockcypher.com/ltc/tx/',
					'BCH' => 'https://explorer.bitcoin.com/bch/tx/',
					'DASH' => 'https://live.blockcypher.com/dash/tx/', 
					'XRP' => 'https://bithomp.com/explorer/', 
				);

				$data = array();
				$no = $start + 1;

				if ($depositHis_count) {
					foreach ($orders as $r) {
						$userId = encrypText($r->user_id);
						$depositId = encrypText($r->id);
						$curr = $r->currency;
						$digits = 8;
						$dtype = ($r->payment_method == 'bank') ? 'Bank' : 'Wallet';
						if ($r->reference_no != "") {
							$refNo = $r->reference_no;
							$refshort = substr($refNo, 0, 20);
							if (isset($txUrl[$curr])) {
								$redirect = $txUrl[$curr] . $refNo;
								$txId = '<a href="' . $redirect . '" target="_blank">' . $refshort . '...</a>';
							} else {
								$txId = $refshort;
							}
						} else {
							$txId = "--";
						}

						if ($r->status == "completed") {
							$stsCls = "clsActive";
							$resend = $confirm = $reject = '';
						} elseif ($r->status == "pending") {
							$stsCls = "clsNotVerify";
							$resendUrl = URL::to($this->Url.'/resendDepositEmail/'.$depositId);
							$resend = '<a class="editUser" href="'.$resendUrl.'"><span class="glyphicon glyphicon-repeat" style="color: #4f5259; vertical-align: middle;" title="Resend Email"></span></a>';
							$securl1 = URL::to($this->Url.'/confirmDeposit/' . $depositId . '/' . $userId);
							$securl2 = URL::to($this->Url.'/rejectDeposit/' . $depositId . '/' . $userId);
							$confirm = '<a href="'.$securl1.'" class="editUser enable"><span class="glyphicon glyphicon-ok" style="color: #4f5259; vertical-align: middle;" title="Confirm"></span></a>';
							$reject = '<a href="'.$securl2.'" class="editUser enable"><span class="glyphicon glyphicon-remove" style="color: #4f5259; vertical-align: middle;" title="Reject"></span></a>';
						} else {
							$stsCls = "clsDeactive";
							$resend = $confirm = $reject = '';
						}
						
						$memo = '';

						$status = '<a class="clsCtlr '.$stsCls .'">'.ucfirst($r->status).'</a>';
						$viewUrl = URL::to($this->Url.'/viewUserDeposit/'.$depositId);

						$viewUser = '<a href="'.$viewUrl.'" class="editUser"><span class="glyphicon glyphicon-eye-open" style="color: #4f5259; vertical-align: middle;" title="View"></span></a>';
						array_push($data, array(
							$no,
							$r->created_at,
							$r->consumer_name,
							$r->country,
							ucfirst($dtype),
							number_format($r->amount, $digits, '.', ''),
							$curr,	
							$txId.' '.$memo, 
							$status,
							$viewUser." ".$resend." ".$confirm." ".$reject,
						));
						$no++;
					}

					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $depositHis_count, 'recordsFiltered' => $depositHis_count, 'data' => $data));
				} else {

					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $depositHis_count, 'recordsFiltered' => $depositHis_count, 'data' => array()));
				}
			} 
		}
	}

	public function pendingdepositHistory() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$totalrecords = intval(Input::get('totalrecords'));
				$draw = Input::get('draw');
				$start = Input::get('start');
				$length = Input::get('length');
				$sorttype = Input::get('order');
				$sort_col = $sorttype['0']['column'];
				$sort_type = $sorttype['0']['dir'];
				$search = Input::get('search');
				$from_date = Input::get('from');
				$to_date = Input::get('to');
				$search = $search['value'];

				if ($sort_col == '1') {
					$sort_col = 'D.created_at';
				} else if ($sort_col == '2') {
					$sort_col = 'U.consumer_name';
				} else if ($sort_col == '3') {
					$sort_col = 'U.country';
				} else if ($sort_col == '4') {
					$sort_col = 'D.amount';
				} else if ($sort_col == '5') {
					$sort_col = 'D.currency';
				} else if ($sort_col == '6') {
					$sort_col = 'D.reference_no';
				} else if ($sort_col == '7') {
					$sort_col = 'D.status';
				} else {
					$sort_col = "D.id";
				}
				if ($sort_type == 'asc') {
					$sort_type = 'desc';
				} else {
					$sort_type = 'asc';
				}
				$data = $orders = array();
				$depositHis = DB::table(PENDINGDEPOSIT.' as D')->where('D.status', 'pending')->leftjoin(USERINFO.' AS U', 'U.id', '=', 'D.user_id');
				if ($search != '') {
					$depositHis = $depositHis->where(function ($q) use ($search) {
						$q->where('D.created_at', 'like', '%' . $search . '%')->orWhere('U.consumer_name', 'like', '%' . $search . '%')->orWhere('U.country', 'like', '%' . $search . '%')->orWhere('D.amount', 'like', '%' . $search . '%')->orWhere('D.currency', 'like', '%' . $search . '%')->orWhere('D.reference_no', 'like', '%' . $search . '%')->orWhere('D.status', 'like', '%' . $search . '%');}
					);
				}

				if ($from_date) {
					$depositHis = $depositHis->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
				}

				if ($to_date) {
					$depositHis = $depositHis->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
				}

				$depositHis_count = $depositHis->count();
				if ($depositHis_count) {

					$depositHis = $depositHis->select('D.id', 'D.user_id' ,'D.reference_no', 'D.currency', 'D.created_at', 'D.status', 'D.amount', 'D.payment_method', 'D.trans_type', 'D.block_confirm', 'U.consumer_name', 'U.country');

					$orders = $depositHis->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
				}

				$txUrl = array(
					'BTC' => 'https://live.blockcypher.com/btc/tx/',
					'ETH' => 'https://etherscan.io/tx/',
					'USDT' => 'https://etherscan.io/tx/',
					'LTC' => 'https://live.blockcypher.com/ltc/tx/',
					'BCH' => 'https://explorer.bitcoin.com/bch/tx/',
					'DASH' => 'https://live.blockcypher.com/dash/tx/', 
					'XRP' => 'https://bithomp.com/explorer/', 
				);

				$data = array();
				$no = $start + 1;

				if ($depositHis_count) {
					foreach ($orders as $r) {
						$userId = encrypText($r->user_id);

						$depositId = encrypText($r->id);
						$curr = $r->currency;
						$confirmations = Currency::where('currency_symbol', $curr)->select('confirmations')->first()->confirmations;				
						$digits = 8;
						if ($r->reference_no != "") {
							$refNo = $r->reference_no;
							$refshort = substr($refNo, 0, 20);
							if (isset($txUrl[$curr])) {
								$redirect = $txUrl[$curr] . $refNo;
								$txId = '<a href="' . $redirect . '" target="_blank">' . $refshort . '...</a>';
							} else {
								$txId = $refshort;
							}
						} else {
							$txId = "--";
						}

						if ($r->status == "completed") {
							$stsCls = "clsActive";
						} elseif ($r->status == "pending") {
							$stsCls = "clsNotVerify";
						} else {
							$stsCls = "clsDeactive";
						}
						
						$memo = '';

						$status = '<a class="clsCtlr '.$stsCls .'">'.ucfirst($r->status).'</a>';
						array_push($data, array(
							$no,
							$r->created_at,
							$r->consumer_name,
							number_format($r->amount, $digits, '.', ''),
							$curr,	
							$txId.' '.$memo, 
							$status,
							$r->block_confirm . '/' . $confirmations,
						));
						$no++;
					}

					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $depositHis_count, 'recordsFiltered' => $depositHis_count, 'data' => $data));
				} else {

					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $depositHis_count, 'recordsFiltered' => $depositHis_count, 'data' => array()));
				}
			} 
		}
	}

	//Deposit functions
	public function viewTransfer() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				return view('admin.deposit.transfer')->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function transferHistory() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$totalrecords = intval(Input::get('totalrecords'));
				$draw = Input::get('draw');
				$start = Input::get('start');
				$length = Input::get('length');
				$sorttype = Input::get('order');
				$sort_col = $sorttype['0']['column'];
				$sort_type = $sorttype['0']['dir'];
				$search = Input::get('search');
				$from_date = Input::get('from');
				$to_date = Input::get('to');
				$stype = Input::get('stype');
				$search = $search['value'];

				if ($sort_col == '1') {
					$sort_col = 'D.created_at';
				} else if ($sort_col == '2') {
					$sort_col = 'U.consumer_name';
				} else if ($sort_col == '3') {
					$sort_col = 'D.rec_user_name';
				} else if ($sort_col == '4') {
					$sort_col = 'D.amount';
				} else if ($sort_col == '5') {
					$sort_col = 'D.currency';
				} else if ($sort_col == '6') {
					$sort_col = 'D.status';
				}  else {
					$sort_col = "D.id";
				}
				if ($sort_type == 'asc') {
					$sort_type = 'desc';
				} else {
					$sort_type = 'asc';
				}
				$data = $orders = array();
				if($stype == 'transfer') {
					$transHis =  DB::table(TRANSFER.' as D')->leftjoin(USERINFO.' AS U', 'U.id', '=', 'D.user_id');
				} else {
					$transHis =  DB::table(TRANSFER.' as D')->leftjoin(USERINFO.' AS U', 'U.id', '=', 'D.rec_user_id');
				}

				if ($search != '') {
					$transHis = $transHis->where(function ($q) use ($search) {
						$q->where('D.currency', 'like', '%' . $search . '%')->orWhere('D.amount', 'like', '%' .  $search . '%')->orWhere('D.created_at', 'like', '%' .  $search . '%')->orWhere('D.rec_user_name', 'like', '%' .  $search . '%')->orWhere('D.status', 'like', '%' .  $search . '%')->orWhere('D.fees', 'like', '%' .  $search . '%')->orWhere('D.total', 'like', '%' .  $search . '%')->orWhere('U.consumer_name', 'like', '%' .  $search . '%');}
					);
				}

				if ($from_date) {
					$transHis = $transHis->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
				}

				if ($to_date) {
					$transHis = $transHis->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
				}

				$transHis_count = $transHis->count();
				if ($transHis_count) {

					$transHis = $transHis->select('D.id', 'D.user_id', 'D.rec_user_id', 'D.currency', 'D.amount', 'D.created_at', 'D.rec_user_name', 'D.status', 'D.fees', 'D.total', 'U.consumer_name', 'D.fee_per', 'D.fee_type', 'D.redemption_at');

					$orders = $transHis->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
				}

				$data = array();
				$no = $start + 1;

				if ($transHis_count) {
					foreach ($orders as $r) {
						$transId = encrypText($r->id);
						if ($r->status == "completed") {
							$stsCls = "clsActive";
							$action = '-';
						} elseif ($r->status == "pending") {
							$stsCls = "clsNotVerify";
							$delUrl = URL::to($this->Url.'/cancelTransfer/'.$transId);
							$action = '<a href="'.$delUrl.'" class="deleteUser" id="deleteUser"><i class="fa fa-times" aria-hidden="true"></i></a>';
						} else {
							$stsCls = "clsDeactive";
							$action = '-';
						}

						if($stype == 'transfer') {
							$fees = ($r->fees == 0) ?  '-' : $r->fees; 
							$total = ($r->total == 0) ?  '-' : $r->total; 

							$suserId = encrypText($r->user_id);
							$ruserId = encrypText($r->rec_user_id);
							$viewUrl1 = URL::to($this->Url.'/userDetail/'.$suserId);
							$viewUser1 = '<a href="'.$viewUrl1.'">'.$r->consumer_name.'</a>';
							$viewUrl2 = URL::to($this->Url.'/userDetail/'.$ruserId);
							$viewUser2 = '<a href="'.$viewUrl2.'">'.$r->rec_user_name.'</a>';

							$status = '<a class="clsCtlr '.$stsCls.'">'.ucfirst($r->status).'</span>';

							array_push($data, array(
								$no,
								$r->created_at,
								$viewUser1,
								$viewUser2,
								$r->amount,
								$fees,
								$total,
								$r->currency,
								$status,
								$action,
							));
							$no++;
						} else {
							$fees = $fee_amt = $r->fee_per;
							$fee_type = $r->fee_type;								
							$amount = $r->total;
							if($fees == 0) {
								$total = $amount = $r->amount;
							} else {
								if ($fee_type == 'amount') {
									$total = $amount - $fees;
								} else {
									$fee_amt = ($amount * $fees) / 100;
									$total = $amount - $fee_amt;
								}
							}

							$suserId = encrypText($r->user_id);
							$ruserId = encrypText($r->rec_user_id);
							$viewUrl1 = URL::to($this->Url.'/userDetail/'.$suserId);
							$viewUser1 = '<a href="'.$viewUrl1.'">'.getUserName($r->user_id).'</a>';
							$viewUrl2 = URL::to($this->Url.'/userDetail/'.$ruserId);
							$viewUser2 = '<a href="'.$viewUrl2.'">'.$r->rec_user_name.'</a>';

							$status = '<a class="clsCtlr '.$stsCls.'">'.ucfirst($r->status).'</span>';

							$total = number_format($total, 2, '.', '');
							$fee_amt = number_format($fee_amt, 2, '.', '');

							array_push($data, array(
								$no,
								$r->created_at,
								$viewUser1,
								$viewUser2,
								$amount,
								$fee_amt,
								$total,
								$r->currency,
								$status,
								$action,
							));
							$no++;
						}
					}
					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $transHis_count, 'recordsFiltered' => $transHis_count, 'data' => $data));
				} else {

					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $transHis_count, 'recordsFiltered' => $transHis_count, 'data' => array()));
				}
			} 
		}
	}

	public function cancelTransfer($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$now = date('Y-m-d H:i:s');
				$transId = decrypText($id);
				$transDetails = Transfer::where('id', $transId)->where('status', 'pending')->first();
				if($transDetails) {
					$user_id = $transDetails->user_id;
					$original = $transDetails->amount;
					$senduserBal = Wallet::where('user_id', $user_id)->select('INR')->first()->INR;
					$sendupBal = $senduserBal + $original;
					$updatesend = Wallet::where('user_id', $user_id)->update(['INR' => $sendupBal]);
					$update = Transfer::where('id', $transId)->update(['status' => 'cancelled',  'redemption_at' => $now, 'code' => '']);
					if($update) {
						Session::flash('success', 'Cancelled Successfully');
					} else {
						Session::flash('error', 'Please try again later');
					}
				} else {
					Session::flash('error', 'Something went wrong');					
				}
				return Redirect::back();
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function viewUserDeposit($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$id = decrypText($id);
				$data = Deposit::where('id', $id)->first();
				$txid = $data->reference_no;
				$currency = $data->currency;
				$trans_type = $data->trans_type;
				$block_confirm = $data->block_confirm;
				return view('admin.deposit.userDeposit')->with('deposit', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//confirmDeposit
	public function confirmDeposit($tid, $uid) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$tid = decrypText(strip_tags($tid));
				$uid = decrypText(strip_tags($uid));
				$checkStatus = Deposit::where('id', $tid)->where('user_id', $uid)->first();
				if ($checkStatus['status'] == "pending") {
					$otp = User::randomString(8);
					$encryptOtp = encrypText($otp);
					Deposit::where('id', $tid)->update(['confirm_code' => $encryptOtp]);

					$getDetail = User::getProfile($uid);

					$getEmail = EmailTemplate::where('id', 6)->first();
					$getSiteDetails = Controller::getEmailTemplateDetails();
					$info = array('###USER###' => $getDetail['user']->consumer_name, '###OTP###' => $otp, '###TYPE###' => 'deposit');
					$replace = array_merge($getSiteDetails, $info);

					$emaildata = array('content' => strtr($getEmail->template, $replace));
					$toDetails['useremail'] = $getSiteDetails['contact_mail_id'];
					$toDetails['subject'] = $getEmail->subject;
					$toDetails['from'] = $getSiteDetails['contact_mail_id'];
					$toDetails['name'] = $getSiteDetails['site_name'];
					$sendEmail = Controller::sendEmail($emaildata, $toDetails);
					if (count(Mail::failures()) > 0) {
						Session::flash('error', 'OTP sending failed.');
						return Redirect::to($this->Url.'/viewDeposit');
					} else {
						$confirmation = 0;
						return view('admin.deposit.userDeposit')->with('deposit', $checkStatus)->with('secure', 'confirm')->with('confirmation', $confirmation)->with('redirectUrl', $this->Url);
					}
				} else {
					Session::flash('error', 'Transaction already processed.');
					return Redirect::to($this->Url.'/viewDeposit');
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function rejectDeposit($tid, $uid) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$tid = decrypText(strip_tags($tid));
				$uid = decrypText(strip_tags($uid));
				$checkStatus = Deposit::where('id', $tid)->where('user_id', $uid)->first();
				if ($checkStatus['status'] == "pending") {
					$confirmation = 0;
					return view('admin.deposit.userDeposit')->with('deposit', $checkStatus)->with('secure', 'cancel')->with('confirmation', $confirmation)->with('redirectUrl', $this->Url);
				} else {
					Session::flash('error', 'Transaction already processed.');
					return Redirect::to($this->Url.'/viewDeposit');
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function updateReject() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$data = Input::all();
				$reason = strip_tags($data['reason']);

				$id = decrypText(strip_tags($data['ucode']));
				$userDeposit = Deposit::where('id', $id)->select('user_id', 'amount', 'currency', 'status', 'reference_no', 'address_info', 'payment_method')->first();

				if ($userDeposit->status == "pending") {
					$transactionData = array('user_id' => $userDeposit->user_id, 'type' => "Deposit", 'currency_name' => $userDeposit->currency, 'amount' => $userDeposit->amount, 'total' => $userDeposit->amount, 'method' => $userDeposit->payment_method, 'payment_method' => $userDeposit->payment_method, 't_status' => 'cancelled', 'transaction_id' => $userDeposit->reference_no);
					$createTransaction = Transaction::create($transactionData);

					$updateDeposit = Deposit::where('id', $id)->update(['status' => 'cancelled', 'reject_reason' => $reason, 'approve_date' => date('Y-m-d H:i:s')]);

					if ($updateDeposit == true) {
						$getUser = User::where('id', $userDeposit->user_id)->select('consumer_name', 'user_mail_id', 'unusual_user_key', 'notify_deposit')->first();
						$usermail = decrypText($getUser->user_mail_id) . '@' . decrypText($getUser->unusual_user_key);

						$msg1 = "Your Deposit request has been rejected by admin.For " . $reason;
						$insdata = array('user_id' => $userDeposit->user_id, 'type' => 'Deposit', 'message' => $msg1, 'status' => 'unread');
						UserNotification::create($insdata);

						$getEmail = EmailTemplate::where('id', 8)->first();
						$getSiteDetails = Controller::getEmailTemplateDetails();
						$info = array('###USER###' => $getUser->consumer_name, '###AMT###' => $userDeposit->amount . ' ' . $userDeposit->currency, '###REASON###' => $reason);
						$replace = array_merge($getSiteDetails, $info);

						$emaildata = array('content' => strtr($getEmail->template, $replace));
						$toDetails['useremail'] = $usermail;
						$toDetails['subject'] = $getEmail->subject;
						$toDetails['from'] = $getSiteDetails['contact_mail_id'];
						$toDetails['name'] = $getSiteDetails['site_name'];

						$sendEmail = Controller::sendEmail($emaildata, $toDetails);

						if (count(Mail::failures()) > 0) {
							Session::flash('error', 'Email sending failed.');
						} else {
							Session::flash('success', 'Transaction rejected successfully.');
						}
					}
				} else {
					Session::flash('error', 'Transaction already processed.');
				}
				return Redirect::to($this->Url.'/viewDeposit');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function checkActualAmount() {
		$amount = strip_tags($_GET['amount']);
		$id = decrypText($_GET['id']);
		$result = Deposit::where('id', $id)->select('amount')->first();
		if ($amount > $result->amount) {
			echo "false";
		} else {
			echo "true";
		}
	}

	public function checkConfirmCode() {
		$code = encrypText($_GET['confirm_code']);
		$id = decrypText($_GET['id']);
		$result = Deposit::where('id', $id)->where('confirm_code', $code)->where('status', 'pending')->count();
		echo ($result == 1) ? "true" : "false";
	}

	public function updateConfirm() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$data = Input::all();
				$Validation = Validator::make($data, SubAdmin::$depositRule);
				if ($Validation->fails()) {
					foreach ($Validation->messages()->getMessages() as $field => $message) {
						Session::flash('error', $message[0]);
						return Redirect::back();
					}
				}
				$code = strip_tags($data['confirm_code']);
				$id = strip_tags($data['ucode']);
				$reason = strip_tags($data['reason']);
				$actualAmount = strip_tags($data['actual_amount']);
				$checkConfirmation = Controller::verifyConfirmation($code, $id);
				if ($checkConfirmation == true) {
					$id = decrypText($id);
					$userDeposit = Deposit::where('id', $id)->select('user_id', 'amount', 'currency', 'status', 'reference_no', 'address_info', 'payment_method', 'fees')->first();
					$mailAmount = $depositAmount = $userDeposit->amount;
					if ($actualAmount > $depositAmount) {
						Session::flash('error', "Actual amount shouldn't higher than deposit amount.");
						return Redirect::back();
					}

					if ($userDeposit->status == "pending") {
						$updateAmount = Deposit::where('id', $id)->update(['reject_reason' => $reason, 'amount' => $actualAmount]);
						$depositAmount = $actualAmount;
						$transactionData = array('user_id' => $userDeposit->user_id, 'type' => "Deposit", 'currency_name' => $userDeposit->currency, 'amount' => $depositAmount, 'total' => $depositAmount, 'method' => $userDeposit->payment_method, 'payment_method' => $userDeposit->payment_method, 't_status' => 'completed', 'transaction_id' => $userDeposit->reference_no);
						$createTransaction = Transaction::create($transactionData);
						if($userDeposit->fees == 0) {
							$depSettings = DepositSettings::where('currency', $userDeposit->currency)->where('currency_type', 'Fiat')->select('fees', 'fee_type')->first();
							$dep_fee = $depSettings->fees;
							if($depSettings->fee_type == 'amount') {
								$fees = $dep_fee; 
							} else {
								$fees = $depositAmount * $dep_fee / 100;
							}
						} else {
							$fees = $userDeposit->fees;
						}
						$getCurrency = $userDeposit->currency;
						$getBalance = Wallet::where('user_id', $userDeposit->user_id)->first();
						$amt = $depositAmount - $fees;
						$total = $getBalance->$getCurrency + $amt;
						if ($getCurrency == "INR") {
							$total = number_format($total, 2, '.', '');
						} else {
							$total = number_format($total, 8, '.', '');
						}
						$update = Wallet::where('user_id', $userDeposit->user_id)->update([$userDeposit->currency => $total]);

						$userInfo = User::where('id', $userDeposit->user_id)->select('InrDeposit')->first();
						$InrDeposit = $userInfo->InrDeposit;
						if($userDeposit->currency == 'INR') {
							$equiv_inr =  $depositAmount;
						} else {
							$lastPrice = get_tradePrice($userDeposit->currency);
							$equiv_inr = $depositAmount * $lastPrice;
						}
						$inrDep = $InrDeposit + $equiv_inr;
						User::where('id', $userDeposit->user_id)->update(['InrDeposit' => $inrDep]);

						$updateDeposit = Deposit::where('id', $id)->update(['equiv_inr' => $equiv_inr, 'status' => 'completed', 'confirm_code' => '', 'approve_date' => date('Y-m-d H:i:s')]);

						if ($update == true && $updateDeposit == true) {

							$coinprofit_data = array(
								'user_id' => $userDeposit->user_id,
								'theftAmount' => $fees,
								'theftCurrency' => $userDeposit->currency,
								'type' => "Deposit",
							);	
							CoinProfit::create($coinprofit_data);

							$getUser = User::where('id', $userDeposit->user_id)->select('consumer_name', 'user_mail_id', 'unusual_user_key')->first();
							$usermail = decrypText($getUser->user_mail_id) . '@' . decrypText($getUser->unusual_user_key);

							$msg1 = "Your Deposit request has been approved by admin.your deposited amount " . $depositAmount . " " . $userDeposit->currency . " has been added to your  wallet";
							$insdata = array('user_id' => $userDeposit->user_id, 'type' => 'Deposit', 'message' => $msg1, 'status' => 'unread');
							UserNotification::create($insdata);

							if($getCurrency == 'INR') {
								$fees = number_format($fees, 2, '.', '');
								$message = 'Your '.$getCurrency.' deposit has been processed and your '.SITENAME.' account has been added with '.$getCurrency. ' '.$mailAmount.' You can check your '.$getCurrency.' balance by logging into your '.SITENAME.' account and heading over to the wallet. '.$fees.' rupees has been deducted as a service charge.';
							} else {
								$message = 'Your '.$getCurrency.' deposit has been processed and your '.SITENAME.' account has been added with '.$getCurrency. ' '.$mailAmount.' You can check your '.$getCurrency.' balance by logging into your '.SITENAME.' account and heading over to the wallet.';
							}

							$getEmail = EmailTemplate::where('id', 7)->first();
							$getSiteDetails = Controller::getEmailTemplateDetails();
							$info = array('###USER###' => $getUser->consumer_name, '###REF###' => $userDeposit->reference_no, '###AMT###' => $mailAmount . ' ' . $userDeposit->currency, '###TOTAL###' => $total . ' ' . $userDeposit->currency, '###ACTUAL###' => $depositAmount . ' ' . $userDeposit->currency, '###REASON###' => $reason, '###MESSAGE###' => $message);
							$replace = array_merge($getSiteDetails, $info);

							$emaildata = array('content' => strtr($getEmail->template, $replace));
							$toDetails['useremail'] = $usermail;
							$toDetails['subject'] = $getEmail->subject;
							$toDetails['from'] = $getSiteDetails['contact_mail_id'];
							$toDetails['name'] = $getSiteDetails['site_name'];

							$sendEmail = Controller::sendEmail($emaildata, $toDetails);

							if (count(Mail::failures()) > 0) {
								Session::flash('error', 'Email sending failed.');
							} else {
								Session::flash('success', 'Transaction approved successfully.');
							}
						}
					}
				} else {
					Session::flash('error', 'Please verify your OTP.');
				}
				return Redirect::to($this->Url.'/viewDeposit');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function resendDepositEmail($depositId) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$depositDetails =  DB::table(DEPOSIT.' as D')->leftjoin(USERINFO.' AS U', 'U.id', '=', 'D.user_id')->where('D.id', decrypText($depositId))->where('D.status','pending')->select('D.user_id', 'D.amount', 'D.reference_no', 'D.currency', 'U.consumer_name')->first();
				if ($depositDetails) {
					$uId = encrypText($depositDetails->user_id);
					$securl1 = URL::to($this->Url.'/confirmDeposit/' . $depositId . '/' . $uId);
					$securl2 = URL::to($this->Url.'/rejectDeposit/' . $depositId . '/' . $uId);

					$getEmail = EmailTemplate::where('id', 5)->first();
					$getSiteDetails = Controller::getEmailTemplateDetails();
					$info = array('###USER###' => $depositDetails->consumer_name, '###LINK1###' => $securl1, '###LINK2###' => $securl2, '###AMT###' => $depositDetails->amount . ' ' . $depositDetails->currency, '###REF###' => $depositDetails->reference_no, '###MESSAGE###' => '', '###ADDRESS###' => '', '###MESSAGE1###' => '');
					$replace = array_merge($getSiteDetails, $info);

					$emaildata = array('content' => strtr($getEmail->template, $replace));
					$toDetails['useremail'] = $getSiteDetails['contact_mail_id'];
					$toDetails['subject'] = $getEmail->subject;
					$toDetails['from'] = $getSiteDetails['contact_mail_id'];
					$toDetails['name'] = $getSiteDetails['site_name'];

					$sendEmail = Controller::sendEmail($emaildata, $toDetails);
					if (count(Mail::failures()) > 0) {
						Session::flash('error', trans('app_lang.Email sending failed.'));
					} else {
						Session::flash('success', $depositDetails->amount . " " . $depositDetails->currency . ' Deposit request sent to admin');
					}
					return Redirect::back();
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//withdraw functions
	public function viewWithdraw() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$data = 1;
				return view('admin.withdraw.withdraw')->with('withdraw', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function viewAdminWithdraw() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$data = 1;
				return view('admin.withdraw.adminWithdraw')->with('withdraw', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function viewPendingWithdraw() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$data = 2;
				return view('admin.withdraw.withdraw')->with('withdraw', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function withdrawHistory($new) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$totalrecords = intval(Input::get('totalrecords'));
				$draw = Input::get('draw');
				$start = Input::get('start');
				$length = Input::get('length');
				$sorttype = Input::get('order');
				$sort_col = $sorttype['0']['column'];
				$sort_type = $sorttype['0']['dir'];
				$search = Input::get('search');
				$from_date = Input::get('from');
				$to_date = Input::get('to');
				$search = $search['value'];

				if ($sort_col == '1') {
					$sort_col = 'W.created_at';
				} else if ($sort_col == '2') {
					$sort_col = 'U.consumer_name';
				} else if ($sort_col == '3') {
					$sort_col = 'U.country';
				} else if ($sort_col == '4') {
					$sort_col = 'W.amount';
				} else if ($sort_col == '5') {
					$sort_col = 'W.currency';
				} else if ($sort_col == '6') {
					$sort_col = 'W.reference_no';
				} else if ($sort_col == '7') {
					$sort_col = 'W.status';
				} else {
					$sort_col = "W.id";
				}

				if ($sort_type == 'asc') {
					$sort_type = 'desc';
				} else {
					$sort_type = 'asc';
				}
				$data = $orders = array();
				if($new == 1) {
					$withdrawHis = DB::table(WITHDRAW.' as W')->leftjoin(USERINFO.' AS U', 'U.id', '=', 'W.user_id');
				} else {
					$withdrawHis = DB::table(WITHDRAW.' as W')->where('W.status', 'pending')->leftjoin(USERINFO.' AS U', 'U.id', '=', 'W.user_id');
				}
				if ($search != '') {
					$withdrawHis = $withdrawHis->where(function ($q) use ($search) {
						$q->where('W.created_at', 'like', '%' . $search . '%')->orWhere('U.consumer_name', 'like', '%' . $search . '%')->orWhere('U.country', 'like', '%' . $search . '%')->orWhere('W.amount', 'like', '%' . $search . '%')->orWhere('W.currency', 'like', '%' . $search . '%')->orWhere('W.reference_no', 'like', '%' . $search . '%')->orWhere('W.status', 'like', '%' . $search . '%');}
					);
				}

				if ($from_date) {
					$withdrawHis = $withdrawHis->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
				}

				if ($to_date) {
					$withdrawHis = $withdrawHis->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
				}

				$withdrawHis_count = $withdrawHis->count();
				if ($withdrawHis_count) {

					$withdrawHis = $withdrawHis->select('W.id', 'W.user_id' ,'W.reference_no', 'W.currency', 'W.created_at', 'W.status', 'W.amount','W.payment_method', 'W.trans_type' , 'W.wallet_type' , 'W.limit_st' , 'U.consumer_name', 'U.country', 'W.instant');

					$orders = $withdrawHis->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
				}

				$txUrl = array(
					'BTC' => 'https://live.blockcypher.com/btc/tx/',
					'ETH' => 'https://etherscan.io/tx/',
					'USDT' => 'https://etherscan.io/tx/',
					'LTC' => 'https://live.blockcypher.com/ltc/tx/',
					'BCH' => 'https://explorer.bitcoin.com/bch/tx/',
					'DASH' => 'https://live.blockcypher.com/dash/tx/', 
					'XRP' => 'https://bithomp.com/explorer/', 
				);

				$data = array();
				$no = $start + 1;

				if ($withdrawHis_count) {
					foreach ($orders as $r) {
						$withdrawId = encrypText(strip_tags($r->id));
						$user_id = encrypText(strip_tags($r->user_id));
						$curr = $r->currency;
						$limit_st = $r->limit_st;
						$digits = 8;
						if ($r->reference_no != "") {
							$refNo = $r->reference_no;
							$refshort = substr($refNo, 0, 20);
							if (isset($txUrl[$curr])) {
								$redirect = $txUrl[$curr] . $refNo;
								$txId = '<a href="' . $redirect . '" target="_blank">' . $refshort . '...</a>';
							} else {
								$txId = $refshort;
							}
						} else {
							$txId = "--";
						}
						
						$wtype = ($r->payment_method == 'bank') ? 'Bank' : 'Wallet';

						if ($r->status == "completed") {
							$stsCls = "clsActive";
							$resend = $confirm = $reject = '';
						} elseif ($r->status == "pending") {
							$stsCls = "clsNotVerify";
							$resendUrl = URL::to($this->Url.'/resendWithdrawEmail/'.$withdrawId);
							$resend = '<a class="editUser" href="'.$resendUrl.'"><span class="glyphicon glyphicon-repeat" style="color: #4f5259; vertical-align: middle;" title="Resend Email"></span></a>';
							if($limit_st == 1) {
								$securl1 = URL::to($this->Url.'/confirmWithdraw/' . $withdrawId . '/' . $user_id);
								$securl2 = URL::to($this->Url.'/rejectWithdraw/' . $withdrawId . '/' . $user_id);
								$confirm = '<a href="'.$securl1.'" class="editUser enable"><span class="glyphicon glyphicon-ok" style="color: #4f5259; vertical-align: middle;" title="Confirm"></span></a>';
								$reject = '<a href="'.$securl2.'" class="editUser enable"><span class="glyphicon glyphicon-remove" style="color: #4f5259; vertical-align: middle;" title="Reject"></span></a>';
							} else {
								$confirm = $reject = '';
							}
						} else {
							$stsCls = "clsDeactive";
							$resend = $confirm = $reject = '';
						}

						
						$status = '<a class="clsCtlr '.$stsCls .'">'.ucfirst($r->status).'</a>';
						$viewUrl = URL::to($this->Url.'/viewUserWithdraw/'.$withdrawId);

						$viewUser = '<a href="'.$viewUrl.'" class="editUser"><span class="glyphicon glyphicon-eye-open" style="color: #4f5259; vertical-align: middle;" title="View"></span></a>';
						array_push($data, array(
							$no,
							$r->created_at,
							$r->consumer_name,
							$r->country,
							ucfirst($wtype),
							number_format($r->amount, $digits, '.', ''),
							$curr,	
							$txId, 
							$status,
							$viewUser." " . $resend." " . $confirm." " . $reject,
						));
						$no++;
					}

					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $withdrawHis_count, 'recordsFiltered' => $withdrawHis_count, 'data' => $data));
				} else {

					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $withdrawHis_count, 'recordsFiltered' => $withdrawHis_count, 'data' => array()));
				}
			} 
		}
	}

	public function adminwithdrawHistory() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$totalrecords = intval(Input::get('totalrecords'));
				$draw = Input::get('draw');
				$start = Input::get('start');
				$length = Input::get('length');
				$sorttype = Input::get('order');
				$sort_col = $sorttype['0']['column'];
				$sort_type = $sorttype['0']['dir'];
				$search = Input::get('search');
				$from_date = Input::get('from');
				$to_date = Input::get('to');
				$search = $search['value'];

				if ($sort_col == '1') {
					$sort_col = 'created_at';
				} else if ($sort_col == '2') {
					$sort_col = 'amount';
				} else if ($sort_col == '3') {
					$sort_col = 'currency';
				} else if ($sort_col == '4') {
					$sort_col = 'reference_no';
				} else if ($sort_col == '5') {
					$sort_col = 'status';
				} else {
					$sort_col = "id";
				}

				if ($sort_type == 'asc') {
					$sort_type = 'desc';
				} else {
					$sort_type = 'asc';
				}
				$data = $orders = array();

				$withdrawHis = DB::table(REMOSIS)->where('type', 'withdraw');
				
				if ($search != '') {
					$withdrawHis = $withdrawHis->where(function ($q) use ($search) {
						$q->where('created_at', 'like', '%' . $search . '%')->orWhere('amount', 'like', '%' . $search . '%')->orWhere('currency', 'like', '%' . $search . '%')->orWhere('reference_no', 'like', '%' . $search . '%')->orWhere('status', 'like', '%' . $search . '%');}
					);
				}

				if ($from_date) {
					$withdrawHis = $withdrawHis->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
				}

				if ($to_date) {
					$withdrawHis = $withdrawHis->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
				}

				$withdrawHis_count = $withdrawHis->count();
				if ($withdrawHis_count) {

					$withdrawHis = $withdrawHis->select('created_at', 'amount', 'currency', 'reference_no', 'status');

					$orders = $withdrawHis->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
				}

				$txUrl = array(
					'BTC' => 'https://live.blockcypher.com/btc/tx/',
					'ETH' => 'https://etherscan.io/tx/',
					'USDT' => 'https://etherscan.io/tx/',
					'LTC' => 'https://live.blockcypher.com/ltc/tx/',
					'BCH' => 'https://explorer.bitcoin.com/bch/tx/',
					'DASH' => 'https://live.blockcypher.com/dash/tx/', 
					'XRP' => 'https://bithomp.com/explorer/', 
				);

				$data = array();
				$no = $start + 1;

				if ($withdrawHis_count) {
					foreach ($orders as $r) {
						$refNo = $r->reference_no;
						$currency = $r->currency;
						if ($r->status == "completed") {
							$stsCls = "clsActive";
						} elseif ($r->status == "pending") {
							$stsCls = "clsNotVerify";
						} else {
							$stsCls = "clsDeactive";
						}
						$status = '<a class="clsCtlr '.$stsCls.'">'.ucfirst($r->status).'</a>';

						$redirect = $txUrl[$currency] . $refNo;
						$refshort = substr($refNo, 0, 20);
						$txId = '<a href="' . $redirect . '" target="_blank">' . $refshort . '...</a>';

						array_push($data, array(
							$no,
							$r->created_at,
							$r->amount,
							$r->currency,	
							$txId, 
							$status,
						));
						$no++;
					}

					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $withdrawHis_count, 'recordsFiltered' => $withdrawHis_count, 'data' => $data));
				} else {

					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $withdrawHis_count, 'recordsFiltered' => $withdrawHis_count, 'data' => array()));
				}
			} 
		}
	}

	public function viewUserWithdraw($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$id = decrypText($id);
				$data = Withdraw::where('id', $id)->first();
				return view('admin.withdraw.userWithdraw')->with('withdraw', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function resendWithdrawEmail($transid) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$txId = decrypText($transid);
				$status = Withdraw::where('id', $txId)->select('id', 'status', 'amount', 'currency', 'fees_amt', 'user_id')->first();
				if ($status && $status->status == "pending") {
					$currency = $status->currency;
					$amount = $status->amount;
					$uid = $status->user_id;
					$user_id = encrypText($uid);
					$fee = number_format($status->fees_amt, 8, '.', '');
					$getDetail = User::select('consumer_name')->where('id', $uid)->first();
					$url1 = URL::to($this->Url.'/confirmWithdraw/' . $transid . '/' . $user_id);
					$url2 = URL::to($this->Url.'/rejectWithdraw/' . $transid . '/' . $user_id);

					$getEmail = EmailTemplate::where('id', 10)->first();
					$getSiteDetails = Controller::getEmailTemplateDetails();
					$info = array('###USER###' => $getDetail->consumer_name, '###LINK1###' => $url1, '###LINK2###' => $url2, '###AMT###' => $amount . " " . $currency, '###FEE###' => $fee . " " . $currency, '###MESSAGE###' => '', '###ADDRESS###' => '', '###MESSAGE1###' => '');
					$replace = array_merge($getSiteDetails, $info);
					$emaildata = array('content' => strtr($getEmail->template, $replace));
					$toDetails['useremail'] = $getSiteDetails['contact_mail_id'];
					$toDetails['subject'] = $getEmail->subject;
					$toDetails['from'] = $getSiteDetails['contact_mail_id'];
					$toDetails['name'] = $getSiteDetails['site_name'];

					$sendEmail = Controller::sendEmail($emaildata, $toDetails);
					if (count(Mail::failures()) > 0) {
						Session::flash('error', "Email sending failed.");
					} else {
						Session::flash('success', $amount . " " . $currency . ' Withdraw email has been sent again');
					}
				} else {
					Session::flash('error', "Transaction not in pending!");
				}
				return Redirect::back();
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function checkConfirmCodeWithdraw() {
		$code = encrypText($_GET['confirm_code']);
		$id = decrypText($_GET['id']);
		$result = Withdraw::where('id', $id)->where('confirm_code', $code)->where('status', 'pending')->count();
		echo ($result == "1") ? json_encode(array('status'=>'success', 'msg'=>"true"))  : json_encode(array('status'=>'success', 'msg'=>"false"));
	}

	public function confirmWithdraw($id, $uid) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$uid = decrypText(strip_tags($uid));

				$checkStatus = Withdraw::where('id', $id)->where('user_id', $uid)->first();
				if ($checkStatus->status == "pending") {
					$otp = User::randomString(8);
					$encryptOtp = encrypText($otp);
					Withdraw::where('id', $id)->update(['confirm_code' => $encryptOtp]);

					$getDetail = User::getProfile($uid);

					$getEmail = EmailTemplate::where('id', 6)->first();
					$getSiteDetails = Controller::getEmailTemplateDetails();
					$info = array('###USER###' => $getDetail['user']->consumer_name, '###OTP###' => $otp, '###TYPE###' => 'withdraw');
					$replace = array_merge($getSiteDetails, $info);

					$emaildata = array('content' => strtr($getEmail->template, $replace));
					$toDetails['useremail'] = $getSiteDetails['contact_mail_id'];
					$toDetails['subject'] = $getEmail->subject;
					$toDetails['from'] = $getSiteDetails['contact_mail_id'];
					$toDetails['name'] = $getSiteDetails['site_name'];

					$sendEmail = Controller::sendEmail($emaildata, $toDetails, '', '');
					if (count(Mail::failures()) > 0) {
						Session::flash('error', 'OTP sending failed.');
						return Redirect::to($this->Url.'/viewWithdraw');
					} else {
						return view('admin.withdraw.userWithdraw')->with('withdraw', $checkStatus)->with('secure', 'confirm')->with('redirectUrl', $this->Url);
					}
				} else {
					Session::flash('error', 'Transaction already processed.');
					return Redirect::to($this->Url.'/viewWithdraw');
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function rejectWithdraw($tid, $uid) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$tid = decrypText(strip_tags($tid));
				$uid = decrypText(strip_tags($uid));
				$checkStatus = Withdraw::where('id', $tid)->where('user_id', $uid)->first();
				if ($checkStatus->status == "pending") {
					return view('admin.withdraw.userWithdraw')->with('withdraw', $checkStatus)->with('secure', 'cancel')->with('redirectUrl', $this->Url);
				} else {
					Session::flash('error', 'Transaction already processed.');
					return Redirect::to($this->Url.'/viewWithdraw');
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public static function returnAddressUser($currency, $address, $tag) {
		$currency = strtoupper($currency);
		if($currency == 'XRP'){
			$search_arr = ['currency' => $currency, 'secret' => $tag];
		} else {
			$search_arr = ['currency' => $currency, 'address' => $address];
		}
		$user_id = CoinAddress::where($search_arr)->select('user_id')->first();
		if ($user_id) {
			return $user_id->user_id;
		} else {
			return false;
		}
	}

	public function updateConfirmWithdraw() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$data = Input::all();
				$code = strip_tags($data['confirm_code']);
				$id = strip_tags($data['ucode']);
				if (isset($data['reference_no'])) {
					$referenceNumber = strip_tags($data['reference_no']);
				}

				if (isset($data['approved'])) {
					$approved_by = strip_tags($data['approved']);
				} else {
					$approved_by = '';
				}

				if (isset($data['phrase'])) {
					$phrase = strip_tags($data['phrase']);
				} else {
					$phrase = '';
				}

				$checkConfirmation = Controller::verifyWithdrawConfirmation($code, $id);
				if ($checkConfirmation == true) {
					$id = decrypText($id);

					$userWithdraw = Withdraw::where('id', $id)->select('user_id', 'amount', 'currency', 'status', 'total', 'reference_no', 'address_info', 'payment_method', 'destination_tag', 'conv_price', 'fees_amt', 'trans_type', 'instant', 'withdraw_bank_info', 'limit_st')->first();
					if($userWithdraw->currency == 'INR' || $userWithdraw->payment_method == 'bank') {
						if ($userWithdraw->status == "pending") {
							$currency = $userWithdraw->currency;
							$amount = $userWithdraw->total;
							$conv_price = $userWithdraw->conv_price;
							$instant = $userWithdraw->instant;
							$limit_st = $userWithdraw->limit_st;
							if($instant == 0) {
								$referenceNumber = strip_tags($data['reference_no']);
								$utr = '';
							} else {
								$withdraw_bank_info = json_decode($userWithdraw->withdraw_bank_info);
								$beneId_status = $withdraw_bank_info->beneId_status;
								if($beneId_status == 1 && $userWithdraw->instant != 0) {
									$beneId = $withdraw_bank_info->beneId; 
									$amount = number_format($userWithdraw->total, 2, '.', '');
									$sp_key = ($userWithdraw->instant == 1) ? 'NPN' : 'LPN';
									$payArr = array('sp_key' =>  $sp_key, 'external_ref' => randomInteger(6),'credit_account' => $withdraw_bank_info->acc_number,  'ifs_code' => strtoupper($withdraw_bank_info->bank_swift), 'credit_amount' => $amount, 'bene_name' => $beneId);
									$requestTransfer = InstantPay::paymentFunctions('bank',$payArr);
									if($requestTransfer['type'] == 'success' && ($requestTransfer['code'] == 'TXN' || $requestTransfer['code'] == 'TUP')) {	
										$referenceNumber = $requestTransfer['result']->ipay_id;
										$utr = '';
									} else {
										Session::flash('error', $requestTransfer['result']);
										return Redirect::to($this->Url.'/viewWithdraw');
									}
								} else {
									Session::flash('error', 'Please try again later');
									return Redirect::to($this->Url.'/viewWithdraw');
								}
							}

							$transactionData = array('user_id' => $userWithdraw->user_id, 'type' => "Withdraw", 'currency_name' => $currency, 'amount' => $userWithdraw->amount, 'total' => $userWithdraw->total, 'method' => $userWithdraw->payment_method, 'payment_method' => $userWithdraw->payment_method, 't_status' => 'completed', 'transaction_id' => $referenceNumber);
							$createTransaction = Transaction::create($transactionData);

							$updateWithdraw = Withdraw::where('id', $id)->update(['status' => 'completed', 'confirm_code' => '', 'approve_date' => date('Y-m-d H:i:s'), 'reference_no' => $referenceNumber, 'address_info' => $utr, 'approved_by' => $approved_by]);

							if ($updateWithdraw == true) {
								$getUser = User::where('id', $userWithdraw->user_id)->select('consumer_name', 'user_mail_id', 'unusual_user_key')->first();
								$usermail = decrypText($getUser->user_mail_id) . '@' . decrypText($getUser->unusual_user_key);

								$msg1 = "Your withdraw request has been approved by admin.your withdraw amount " . $userWithdraw->amount . " " . $currency . " has been debited from your ".SITENAME." wallet";
								$insdata = array('user_id' => $userWithdraw->user_id, 'type' => 'Withdraw', 'message' => $msg1, 'status' => 'unread');
								UserNotification::create($insdata);

								if($currency == 'INR') {
									$amount =  number_format($userWithdraw->amount, 2, '.', '');
									$total =  number_format($userWithdraw->total, 2, '.', '');
								} else {
									$amount =  number_format($userWithdraw->amount, 8, '.', '');
									$conv = $userWithdraw->total * $conv_price;
									$total =  number_format($conv, 2, '.', '');
								}

								$coinprofit_data = array(
									'user_id' => $userWithdraw->user_id,
									'theftAmount' => $userWithdraw->fees_amt,
									'theftCurrency' => $currency,
									'type' => "Withdraw",
								);
								$coinprofitquery = CoinProfit::create($coinprofit_data);

								$getEmail = EmailTemplate::where('id', 11)->first();
								$getSiteDetails = Controller::getEmailTemplateDetails();
								$info = array('###USER###' => $getUser->consumer_name, '###REF###' => $referenceNumber, '###AMT###' => $amount . "" . $currency, '###TOTAL###' => $total. "" . 'INR', '###MSG###' => $msg1);
								$replace = array_merge($getSiteDetails, $info);

								$emaildata = array('content' => strtr($getEmail->template, $replace));
								$toDetails['useremail'] = $usermail;
								$toDetails['subject'] = $getEmail->subject;
								$toDetails['from'] = $getSiteDetails['contact_mail_id'];
								$toDetails['name'] = $getSiteDetails['site_name'];

								$sendEmail = Controller::sendEmail($emaildata, $toDetails);

								if (count(Mail::failures()) > 0) {
									Session::flash('error', 'Email sending failed.');
								} else {
									Session::flash('success', 'Transaction approved successfully.');
								}
							} else {
								Session::flash('error', 'Failed to update!');
							}
						} else {
							Session::flash('error', 'Transaction already processed');
						}
					} else {
						if ($userWithdraw->status == "pending") {
							$currency = $userWithdraw->currency;
							$amount = $userWithdraw->total;
							$toaddress = $userWithdraw->address_info;
							$destiTag = $userWithdraw->destination_tag;
							$trans_type = $userWithdraw->trans_type;
							if($trans_type == 'Internal'){
								$receive_id = self::returnAddressUser($currency, $toaddress, $destiTag);
								if($receive_id){
									$userbalance = Wallet::where('user_id', $receive_id)->first();
									$balance = $userbalance->$currency;
									$updatebalance = $balance + $amount;
									$updatebalance = number_format($updatebalance, 8, '.', '');
									$update = Wallet::where('user_id', $receive_id)->update([$currency => $updatebalance]);
									$transaction_number = User::randomString(8);

									$lastPrice = get_tradePrice($currency);
									$equiv_inr = $amount * $lastPrice;
									$equiv_inr = number_format($equiv_inr, 2, '.', '');

									$depositData = array('amount' => $amount, 'equiv_inr' => $equiv_inr, 'address_info' => $toaddress, 'currency' => $currency, 'payment_method' => $currency . " Payment", 'reference_no' => $transaction_number, 'status' => 'completed', 'user_id' => $receive_id, 'currency_type' => 'crypto','ip_addr' => Controller::getIpAddress(), 'trans_type' => 'Internal');
									Deposit::create($depositData);
									$sendAmt['msg'] = 'success';
									$sendAmt['result'] = $transaction_number;
								} else {
									$sendAmt['msg'] = 'fail';
									$sendAmt['result'] = '';
								}
								$wtype = 1;
							} else {
								$wallet_type = strip_tags($data['wallet_type']);
								if ($wallet_type == 1) {
									$wtype  = 0;
									$sendAmt = CryptoAddress::sendCryptoAmount($currency, $toaddress, $amount, $destiTag, $phrase);
								} else {
									$wtype = 2;
									$sendAmt['msg'] = 'success';
									$sendAmt['result'] = strip_tags($data['reference_no1']);
								}
							}

							if ($sendAmt) {
								$status = $sendAmt['msg'];
								if ($status == 'success') {
									$referenceNumber = $sendAmt['result'];
								} else {
									$value = $sendAmt['result'];
									if ($value == '' || $value == null) {
										Session::flash('error', 'Withdraw is not available now . Please try again later.');
									} else {
										Session::flash('error', $value);
									}
									return Redirect::to($this->Url.'/viewWithdraw');

								}
							} else {
								Session::flash('error', 'Something went to wrong . Please try again later.');
								return Redirect::back();
							}
							$coinprofit_data = array(
								'user_id' => $userWithdraw->user_id,
								'theftAmount' => $userWithdraw->fees_amt,
								'theftCurrency' => $currency,
								'type' => "Withdraw",
							);
							$coinprofitquery = CoinProfit::create($coinprofit_data);

							$transactionData = array('user_id' => $userWithdraw->user_id, 'type' => "Withdraw", 'currency_name' => $currency, 'amount' => $userWithdraw->amount, 'total' => $userWithdraw->total, 'method' => $userWithdraw->payment_method, 'payment_method' => $userWithdraw->payment_method, 't_status' => 'completed', 'transaction_id' => $referenceNumber);
							$createTransaction = Transaction::create($transactionData);

							$updateWithdraw = Withdraw::where('id', $id)->update(['status' => 'completed', 'confirm_code' => '', 'approve_date' => date('Y-m-d H:i:s'), 'reference_no' => $referenceNumber, 'wallet_type' => $wtype, 'approved_by' => $approved_by]);

							if ($updateWithdraw == true) {
								$getUser = User::where('id', $userWithdraw->user_id)->select('consumer_name', 'user_mail_id', 'unusual_user_key')->first();
								$usermail = decrypText($getUser->user_mail_id) . '@' . decrypText($getUser->unusual_user_key);

								$msg1 = "Your withdraw request has been approved by admin.your withdraw amount " . $userWithdraw->amount . " " . $currency . " has been debited from your ".SITENAME." wallet";
								$insdata = array('user_id' => $userWithdraw->user_id, 'type' => 'Withdraw', 'message' => $msg1, 'status' => 'unread');
								UserNotification::create($insdata);

								if($currency == 'INR') {
									$amount =  number_format($userWithdraw->amount, 2, '.', '');
									$total =  number_format($userWithdraw->total, 2, '.', '');
								} else {
									$amount =  number_format($userWithdraw->amount, 8, '.', '');
									$total =  number_format($userWithdraw->total, 8, '.', '');
								}

								$getEmail = EmailTemplate::where('id', 11)->first();
								$getSiteDetails = Controller::getEmailTemplateDetails();
								$info = array('###USER###' => $getUser->consumer_name, '###REF###' => $referenceNumber, '###AMT###' => $amount . "" . $currency, '###TOTAL###' => $total. "" . $currency, '###MSG###' => $msg1);
								$replace = array_merge($getSiteDetails, $info);

								$emaildata = array('content' => strtr($getEmail->template, $replace));
								$toDetails['useremail'] = $usermail;
								$toDetails['subject'] = $getEmail->subject;
								$toDetails['from'] = $getSiteDetails['contact_mail_id'];
								$toDetails['name'] = $getSiteDetails['site_name'];

								$sendEmail = Controller::sendEmail($emaildata, $toDetails);

								if (count(Mail::failures()) > 0) {
									Session::flash('error', 'Email sending failed.');
								} else {
									Session::flash('success', 'Transaction approved successfully.');
								}
							} else {
								Session::flash('error', 'Failed to update!');
							}
						} else {
							Session::flash('error', 'Transaction already processed');
						}
					}
				} else {
					Session::flash('error', 'Please verify your OTP.');
				}
				return Redirect::to($this->Url.'/viewWithdraw');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function updateRejectWithdraw() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$data = Input::all();
				$reason = strip_tags($data['reason']);

				$id = decrypText(strip_tags($data['ucode']));
				$userWithdraw = Withdraw::where('id', $id)->select('user_id', 'amount', 'currency', 'status', 'total', 'reference_no', 'address_info', 'payment_method')->first();

				if ($userWithdraw->status == "pending") {
					$transactionData = array('user_id' => $userWithdraw->user_id, 'type' => "Withdraw", 'currency_name' => $userWithdraw->currency, 'amount' => $userWithdraw->amount, 'total' => $userWithdraw->total, 'method' => $userWithdraw->payment_method, 'payment_method' => $userWithdraw->payment_method, 't_status' => 'cancelled');
					$createTransaction = Transaction::create($transactionData);

					$currency = $userWithdraw->currency;
					$balance = Wallet::where('user_id', $userWithdraw->user_id)->first();
					$usrbal = $balance->$currency;
					$updatebalance = $usrbal + $userWithdraw->amount;
					if ($currency == "INR") {
						$updatebalance = number_format($updatebalance, 2, '.', '');
					} else {
						$updatebalance = number_format($updatebalance, 8, '.', '');
					}

					$updatWallet = Wallet::where('user_id', $userWithdraw->user_id)->update([$currency => $updatebalance]);

					$updateWithdraw = Withdraw::where('id', $id)->update(['status' => 'cancelled', 'reject_reason' => $reason, 'approve_date' => date('Y-m-d H:i:s'), 'equiv_inr' => '0']);

					if ($updateWithdraw == true) {
						$getUser = User::where('id', $userWithdraw->user_id)->select('consumer_name', 'user_mail_id', 'unusual_user_key')->first();
						$usermail = decrypText($getUser->user_mail_id) . '@' . decrypText($getUser->unusual_user_key);

						$msg1 = "Your Withdraw request has been rejected by admin.For " . $reason;
						$insdata = array('user_id' => $userWithdraw->user_id, 'type' => 'Withdraw', 'message' => $msg1, 'status' => 'unread');
						UserNotification::create($insdata);

						$getEmail = EmailTemplate::where('id', 12)->first();
						$getSiteDetails = Controller::getEmailTemplateDetails();
						$info = array('###USER###' => $getUser->consumer_name, '###AMT###' => $userWithdraw->amount . " " . $currency, '###REASON###' => $reason);
						$replace = array_merge($getSiteDetails, $info);

						$emaildata = array('content' => strtr($getEmail->template, $replace));
						$toDetails['useremail'] = $usermail;
						$toDetails['subject'] = $getEmail->subject;
						$toDetails['from'] = $getSiteDetails['contact_mail_id'];
						$toDetails['name'] = $getSiteDetails['site_name'];

						$sendEmail = Controller::sendEmail($emaildata, $toDetails);

						if (count(Mail::failures()) > 0) {
							Session::flash('error', 'Email sending failed.');
						} else {
							Session::flash('success', 'Transaction rejected successfully.');
						}
					} else {
						Session::flash('error', 'Failed to update!');
					}
				} else {
					Session::flash('error', 'Transaction already processed.');
				}
				return Redirect::to($this->Url.'/viewWithdraw');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//deposit settings actions
	public function viewDepositSettings() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$data = DepositSettings::orderBy('id')->get();
				return view('admin.deposit.viewDepositSettings')->with('depositSettings', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function depositSettingsEdit($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$id = decrypText($id);
				$data = DepositSettings::where('id', $id)->first();
				return view('admin.deposit.depositSettingsEdit')->with('settings', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function updateDepositSettings() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$data = Input::all();
				$status = strip_tags($data['status']);
				$min = isset($data['min']) ? strip_tags($data['min']) : 0;
				$max = isset($data['max']) ? strip_tags($data['max']) : 0;
				$fees = isset($data['fees']) ? strip_tags($data['fees']) : 0;
				$fee_type = isset($data['fee_type']) ? strip_tags($data['fee_type']) : 'amount';
				$dep_limit = isset($data['dep_limit']) ? strip_tags($data['dep_limit']) : 0;

				$id = decrypText(strip_tags($data['id']));

				$updata = array('min' => $min, 'max' => $max, 'status' => $status, 'fees' => $fees, 'fee_type' => $fee_type, 'dep_limit' => $dep_limit);
				$result = DepositSettings::where('id', $id)->update($updata);
				if ($result) {
					Session::flash('success', 'Deposit settings updated succeesfully');
				} else {
					Session::flash('error', 'Failed to update deposit settings!');
				}
				return Redirect::to($this->Url.'/viewDepositSettings');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//withdraw settings actions
	public function viewWithdrawSettings() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$data = WithdrawSettings::orderBy('id')->get();
				return view('admin.withdraw.viewWithdrawSettings')->with('withdrawSettings', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function withdrawSettingsEdit($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 2);
			if ($permission == true) {
				$id = decrypText($id);
				$data = WithdrawSettings::where('id', $id)->first();
				$cur = Currency::where('currency_symbol', $data->currency)->select('gaslimit', 'gasprice', 'wallet_limit', 'move_limit')->first();
				return view('admin.withdraw.withdrawSettingsEdit')->with('settings', $data)->with('currency', $cur)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function updateWithdrawSettings() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				$data = Input::all();
				$min = strip_tags($data['min']);
				$max = strip_tags($data['max']);
				$withdraw_limit_day = strip_tags($data['withdraw_limit_day']);
				$fee = strip_tags($data['fee']);
				$fee_type = strip_tags($data['fee_type']);
				$status = strip_tags($data['status']);
				$instant = isset($data['instant']) ?  strip_tags($data['instant']) : 0;
				$standard = isset($data['standard']) ?  strip_tags($data['standard']) : 0;
				$neft = isset($data['neft']) ?  strip_tags($data['neft']) : 0;
				$neft_min = isset($data['neft_min']) ?  strip_tags($data['neft_min']) : 0;
				$neft_max = isset($data['neft_max']) ?  strip_tags($data['neft_max']) : 0;
				$instant_min = isset($data['instant_min']) ?  strip_tags($data['instant_min']) : 0;
				$instant_max = isset($data['instant_max']) ?  strip_tags($data['instant_max']) : 0;
				$auto_with = strip_tags($data['auto_with']);
				$currency = strip_tags($data['currency']);
				if($fee_type == 'amount') {
					if ($fee > $min) {
						Session::flash('error', 'Please enter fee less than minimum amount');
						return Redirect::to($this->Url.'/viewWithdrawSettings');

					} else if ($min > $max) {
						Session::flash('error', 'Please enter min less than maximum amount');
						return Redirect::to($this->Url.'/viewWithdrawSettings');

					}
				}

				$gasprice = isset($data['gasprice']) ? strip_tags($data['gasprice']) : 0;
				$gaslimit = isset($data['gasprice']) ? strip_tags($data['gaslimit']) : 0;
				$wallet_limit = isset($data['wallet_limit']) ? strip_tags($data['wallet_limit']) : 0;
				$move_limit = isset($data['move_limit']) ? strip_tags($data['move_limit']) : 0;

				Currency::where('currency_symbol', $currency)->update(['gasprice' => $gasprice, 'gaslimit' => $gaslimit, 'wallet_limit' => $wallet_limit, 'move_limit' => $move_limit]);
				$id = decrypText($data['id']);

				$updata = array('min' => $min, 'max' => $max, 'withdraw_limit_day' => $withdraw_limit_day, 'fee' => $fee, 'status' => $status, 'instant' => $instant, 'standard' => $standard, 'fee_type' => $fee_type, 'auto_with' => $auto_with, 'neft' => $neft,'neft_min' => $neft_min, 'neft_max' => $neft_max, 'instant_min' => $instant_min, 'instant_max' => $instant_max);
				$result = WithdrawSettings::where('id', $id)->update($updata);
				if ($result) {
					Session::flash('success', 'Withdraw settings updated succeesfully');
				} else {
					Session::flash('error', 'Failed to update withdraw settings!');
				}
				return Redirect::to($this->Url.'/viewWithdrawSettings');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//Subadmin Actions
	public function checkUsernameExists(Request $request) {
		$getCount = SubAdmin::where('admin_username', strip_tags($request['username']))->count();
		echo ($getCount == 1) ? "false" : "true";
	}

	public function checkEmailExists(Request $request) {
		$email = explode('@', strip_tags(strtolower($request['email_addr'])));
		$first = encrypText($email[0]);
		$second = encrypText($email[1]);
		$getCount = SubAdmin::where('admin_desc', $first)->where('admin_sub_key', $second)->count();
		echo ($getCount == 1) ? "false" : "true";
	}

	public function loginHistory() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				$data = AdminActivity::where('activity', '!=', 'login')
				->where('activity', '!=', 'logout')->orderBy('id', 'desc')->limit(100)->get();
				return view('admin.common.history')->with('history', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function viewSubadmin() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				$data = SubAdmin::where('admin_role', '!=', 'admin')->orderBy('id', 'desc')->get();
				return view('admin.subadmin.subadmin')->with('subadmin', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function subadminStatus($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				if ($id != session('adminId')) {
					$admin = SubAdmin::where('id', $id)->first();
					$new_status = ($admin->status == "active") ? "deactive" : "active";
					$update = SubAdmin::where('id', $id)->update(['status' => $new_status]);
					if ($update) {
						$new_stat = ($admin->status == "active") ? "Deactivated" : "Activated";
						$msg = "Sub Admin " . $new_stat . " Successfully";
						Session::flash('success', $msg);
					} else {
						Session::flash('error', 'Please Try Again');
					}
				} else {
					Session::flash('error', 'You could not change your activity status.');
				}
				return Redirect::to($this->Url.'/viewSubadmin');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function addSubadmin() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				$data['type'] = "add";
				return view('admin.subadmin.addSubadmin')->with('subadmin', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function subadminEdit($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				$id = decrypText($id);
				$data = SubAdmin::where('id', $id)->first();
				$data['type'] = "edit";
				return view('admin.subadmin.addSubadmin')->with('subadmin', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function updateSubadmin() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				$data = Input::all();
				$Validation = Validator::make($data, SubAdmin::$addSubadminRule);
				if ($Validation->fails()) {
					Session::flash('error', $Validation->messages());
					return Redirect::to($this->Url);
				}
				if ($data['type'] == "add") {
					unset($data['id']);
				}
				if ($data['type'] == "edit") {
					$id = decrypText(strip_tags($data['id']));
					$getAdminPwd = SubAdmin::select('admin_key')->where('id', $id)->first();
					$password = $getAdminPwd->admin_key;
				}
				if ($data['password'] != "") {
					$password = encrypText(strip_tags($data['password']));
				}
				$data['password'] = $password;
				if ($data == array_filter($data)) {
					$permission = implode(',', $data['permission']);
					$email = explode('@', strip_tags($data['email_addr']));
					$first = encrypText($email[0]);
					$second = encrypText($email[1]);

					$getSiteDetails = Controller::getEmailTemplateDetails();
					$getEmail = EmailTemplate::where('id', 17)->first();
					$getAdminCtrl = SubAdmin::select('admin_ctrl', 'admin_pass', 'admin_key')
					->where('id', 1)->first();

					$securl = $this->Url;
					if (isset($id) && $id != "") {
						$result = SubAdmin::where('id', $id)->update(['admin_permission' => $permission, 'admin_desc' => $first, 'admin_sub_key' => $second, 'admin_key' => $password, 'admin_pattern' => encrypText(strip_tags($data['pattern_code']))]);
						$st = "Updated";
						$user_data = SubAdmin::where('id', $id)->first();

						$info = array('###USER###' => $user_data->admin_username, '###EMAIL###' => $data['email_addr'], '###PWD###' => decrypText($user_data->admin_key), '###PATT###' => decrypText($user_data->admin_pattern), '###URL###' => $securl);
						$replace = array_merge($getSiteDetails, $info);
						$emaildata = array('content' => strtr($getEmail->template, $replace));
					} else {
						$getCount = SubAdmin::where('admin_desc', $first)->where('admin_sub_key', $second)->count();
						if ($getCount == 0) {
							$subadd['admin_pattern'] = encrypText($data['pattern_code']);
							$subadd['admin_key'] = $password;
							$subadd['admin_desc'] = $first;
							$subadd['admin_sub_key'] = $second;
							$subadd['admin_username'] = $data['username'];
							$subadd['admin_permission'] = $permission;
							$subadd['admin_role'] = 'subadmin';
							$subadd['ip_address'] = "192";
							$subadd['status'] = "active";
							$result = SubAdmin::create($subadd);
							$st = "Added";

							$info = array('###USER###' => $data['username'], '###EMAIL###' => $data['email_addr'], '###PWD###' => decrypText($password), '###PATT###' => $data['pattern_code'], '###URL###' => $securl);
							$replace = array_merge($getSiteDetails, $info);
							$emaildata = array('content' => strtr($getEmail->template, $replace));
						} else {
							Session::flash('error', 'Email Already exists.');
							return Redirect::back();
						}
					}

					if ($result) {
						$toDetails['useremail'] = strip_tags($data['email_addr']);
						$toDetails['subject'] = $getEmail->subject;
						$toDetails['from'] = $getSiteDetails['contact_mail_id'];
						$toDetails['name'] = $getSiteDetails['site_name'];
						if ($data['type'] == "add") {
							$sendEmail = Controller::sendEmail($emaildata, $toDetails);
						}
						Session::flash('success', 'Subadmin ' . $st . ' Succeesfully');
						return Redirect::to($this->Url.'/viewSubadmin');
					}
				} else {
					Session::flash('error', 'Failed to add Subadmin.');
					return Redirect::back();
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function deleteSubadmin($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				$id = decrypText($id);
				if ($id != session('adminId')) {
					$delete = SubAdmin::where(['id' => $id])->delete();
					if ($delete) {
						Session::flash('success', "SubAdmin deleted Successfully");
					} else {
						Session::flash('error', 'Please Try Again');
					}
					return Redirect::back();
				} else {
					Session::flash('error', 'You can not delete your own account.');
					return Redirect::back();
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//Block IP actions
	public function viewBlockIp() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 9);
			if ($permission == true) {
				return view('admin.blockip.blockIp')->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function blockHistory() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 9);
			if ($permission == true) {
				$totalrecords = intval(Input::get('totalrecords'));
				$draw = Input::get('draw');
				$start = Input::get('start');
				$length = Input::get('length');
				$sorttype = Input::get('order');
				$sort_col = $sorttype['0']['column'];
				$sort_type = $sorttype['0']['dir'];
				$search = Input::get('search');
				$from_date = Input::get('from');
				$to_date = Input::get('to');
				$search = $search['value'];

				if ($sort_col == '1') {
					$sort_col = 'ip_addr';
				} else if ($sort_col == '2') {
					$sort_col = 'status';
				} else if ($sort_col == '3') {
					$sort_col = 'created_at';
				} else {
					$sort_col = "id";
				}

				if ($sort_type == 'asc') {
					$sort_type = 'desc';
				} else {
					$sort_type = 'asc';
				}
				$data = $orders = array();

				$blockHis = BlockIP::where('status', '!=', '');
				
				if ($search != '') {
					$blockHis = $blockHis->where(function ($q) use ($search) {
						$q->where('ip_addr', 'like', '%' . $search . '%')->orWhere('status', 'like', '%' . $search . '%')->orWhere('created_at', 'like', '%' . $search . '%');}
					);
				}

				if ($from_date) {
					$blockHis = $blockHis->where('created_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
				}

				if ($to_date) {
					$blockHis = $blockHis->where('created_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
				}

				$blockHis_count = $blockHis->count();
				if ($blockHis_count) {

					$blockHis = $blockHis->select('ip_addr', 'status', 'created_at', 'id');

					$orders = $blockHis->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
				}

				$data = array();
				$no = $start + 1;

				if ($blockHis_count) {
					foreach ($orders as $r) {
						$id = encrypText($r['id']);

						if ($r['status'] == "active") {
							$stsCls = "clsActive";
						} elseif ($r['status'] == "deactive") {
							$stsCls = "clsDeactive";
						}

						$removeIcon = URL::to('public/admin_assets/images/remove-user-icon.png');
						$deleteIcon = URL::to('public/admin_assets/images/delete-icon.png');
						$removeUrl = URL::to($this->Url.'/ipAddrStatus/'.$id);
						$deleteUrl = URL::to($this->Url.'/ipAddrDelete/'.$id);

						$status = '<a href="#" class="clsCtlr '.$stsCls.'">'.ucfirst($r['status']).'</a>';
						$status1 = '<a href="'.$removeUrl.'" class="userRemove"><img src="'.$removeIcon.'" title="Change Status" /></a>';
						$status2 = '<a href="'.$deleteUrl.'" class="deleteUser"><img src="'.$deleteIcon.'" title="Delete"  /></a>';

						array_push($data, array(
							$no,
							$r['ip_addr'],
							$status,
							$status1." ".$status2,
						));
						$no++;
					}

					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $blockHis_count, 'recordsFiltered' => $blockHis_count, 'data' => $data));
				} else {

					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $blockHis_count, 'recordsFiltered' => $blockHis_count, 'data' => array()));
				}
			} 
		}
	}

	public function ipAddrStatus($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 9);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$ipAddr = BlockIP::where('id', $id)->first();
				$new_status = ($ipAddr->status == "active") ? "deactive" : "active";
				if($new_status == 'deactive') {
					LoginAttempt::where('ip_address', $ipAddr->ip_addr)->where('status', 'new')->update(['status' => 'old']);	
				}
				$update = BlockIP::where('id', $id)->update(['status' => $new_status]);
				if ($update) {
					$new_stat = ($ipAddr->status == "active") ? "Deactivated" : "Activated";
					$msg = "IP address " . $new_stat . " Successfully";
					Session::flash('success', $msg);
				} else {
					Session::flash('error', 'Please Try Again');
				}
				return Redirect::to($this->Url.'/viewBlockIp');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function ipAddrDelete($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 9);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$faq = BlockIP::where(['id' => $id])->delete();
				if ($faq) {
					Session::flash('success', "IP Address deleted Successfully");
				} else {
					Session::flash('error', 'Please Try Again');
				}
				return Redirect::to($this->Url.'/viewBlockIp');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function addIpAddress() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 9);
			if ($permission == true) {
				$data = Input::all();
				if ($data == array_filter($data)) {
					$data['ip_addr'] = trim($data['ip_addr']);
					$data['ip_addr'] = strip_tags($data['ip_addr']);
					$checkIp = BlockIP::where('ip_addr', $data['ip_addr'])->count();
					if ($checkIp == 0) {
						$insdata = array('ip_addr' => $data['ip_addr'], 'status' => 'active');
						$createIp = BlockIP::create($insdata);
						if ($createIp) {
							Session::flash('success', 'IP Address added successfully');
						} else {
							Session::flash('error', 'IP address already added.');
						}
					} else {
						Session::flash('error', 'Failed to add IP address.');
					}
				} else {
					Session::flash('error', 'Please enter IP address.');
				}
				return Redirect::to($this->Url.'/viewBlockIp');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//Whitelist IP actions
	public function viewWhitelistIp() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 4);
			if ($permission == true) {
				$data = WhitelistIP::orderBy('id','desc')->get();
				return view('admin.whitelistip.blockIp')->with('ip', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function whitelistipAddrStatus($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 4);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$ipAddr = WhitelistIP::where('id', $id)->first();
				$new_status = ($ipAddr->status == "active") ? "deactive" : "active";
				$update = WhitelistIP::where('id', $id)->update(['status' => $new_status]);
				if ($update) {
					$new_stat = ($ipAddr->status == "active") ? "Deactivated" : "Activated";
					$msg = "IP address " . $new_stat . " Successfully";
					Session::flash('success', $msg);
				} else {
					Session::flash('error', 'Please Try Again');
				}
				return Redirect::to($this->Url.'/viewWhitelistIp');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function whitelistipAddrDelete($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 4);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$faq = WhitelistIP::where(['id' => $id])->delete();
				if ($faq) {
					Session::flash('success', "IP Address deleted Successfully");
				} else {
					Session::flash('error', 'Please Try Again');
				}
				return Redirect::to($this->Url.'/viewWhitelistIp');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function whitelistaddIpAddress() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 4);
			if ($permission == true) {
				$data = Input::all();
				if ($data == array_filter($data)) {
					$data['ip_addr'] = trim($data['ip_addr']);
					$data['ip_addr'] = strip_tags($data['ip_addr']);
					$checkIp = WhitelistIP::where('ip_addr', $data['ip_addr'])->count();
					if ($checkIp == 0) {
						$insdata = array('ip_addr' => $data['ip_addr'], 'status' => 'active');
						$createIp = WhitelistIP::create($insdata);
						if ($createIp) {
							Session::flash('success', 'IP Address added successfully');
						} else {
							Session::flash('error', 'IP address already added.');
						}
					} else {
						Session::flash('error', 'Failed to add IP address.');
					}
				} else {
					Session::flash('error', 'Please enter IP address.');
				}
				return Redirect::to($this->Url.'/viewWhitelistIp');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function KabXGLxeDWmea5tj() {
		return view('admin.user.userBal')->with('redirectUrl', $this->Url);
	}

	public function updateBalUser() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$data = Input::all();
				$username = strip_tags($data['username']);
				$email = explode('@', strip_tags(strtolower($data['email'])));
				$first = encrypText($email[0]);
				$second = encrypText($email[1]);
				$result = User::where('consumer_name', $username)->where('user_mail_id', $first)->where('unusual_user_key', $second)->select('id')->first();
				if($result) {
					$userId = encrypText($result->id); 
					session(['userBalId' => $userId]);
					return Redirect::to($this->Url.'/UserBalanceEdit/'.$userId);
				} else {
					Session::flash('error', 'Invalid user');
					return Redirect::back();
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		} else {
			Session::flash('error', 'Session Expired');
			return Redirect::to($this->Url);
		}
	}

	public function UserBalanceEdit($id = NULL) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				if(session('userBalId') != '') {
					$id = decrypText(strip_tags($id));
					$user_id = $id;
					$userBalId = session('userBalId');
					if($id == decrypText($userBalId)) {
						$name = User::where('id', $id)
						->select('consumer_name')->first()->consumer_name;
						$wallet = Wallet::where('user_id', $id)->first();
						if ($wallet) {
							$wallet = Wallet::where('user_id', $id)->get()->toArray();
						} else {
							$wallet = array();
						}
						return view('admin.user.UserBalanceEdit')->with('pairs', $wallet)->with('name', $name)->with('user_id', $id)->with('redirectUrl', $this->Url);
					} else {
						Session::flash('error', 'Invalid request');
						return Redirect::to($this->Url.'/KX7TyPxAhRWpjAbf');
					}
				} else {
					Session::flash('error', 'User Session Expired');
					return Redirect::to($this->Url.'/KX7TyPxAhRWpjAbf');
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function UserBalancePairUpdate() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 3);
			if ($permission == true) {
				if(session('userBalId') != '') {
					$data = Input::all();
					$ip = Controller::getIpAddress();
					$id = decrypText(strip_tags($data['re']));
					$userBalId = session('userBalId');
					if($id == decrypText($userBalId)) {
						$updata = array();
						$valshow = '';
						$remarks = strip_tags($data['remarks']);
						foreach ($data as $key => $value) {

							if (!in_array($key, array('updated_at', 'created_at', 're', '_token', 'value', 'remarks'))) {
								if (is_numeric($value)) {
									$updata[$key] = $value;
									$updata['remarks'] = "Manually updated";
									$valshow .= $key .'='. $value . '--';
								} else {
									Session::flash('error', 'Please enter valid amount ' . $key);
									return Redirect::to($this->Url.'/KX7TyPxAhRWpjAbf');
								}
							}
						}

						$result = Wallet::where('user_id', $id)->update($updata);

						$insdata = array('user_id' => $id, 'comments' => $valshow, 'remarks' => $remarks, 'ip' => $ip);
						ManuProcess::create($insdata);
						if ($result) {
							session()->forget('userBalId');
							Session::flash('success', 'Details has been updated successfully');
						} else {
							Session::flash('error', 'Failed to update!');
						}
					} else {
						Session::flash('error', 'Invalid request');
					}
					return Redirect::to($this->Url.'/viewUserBalance');
				} else {
					Session::flash('error', 'User Session Expired');
					return Redirect::to($this->Url.'/KX7TyPxAhRWpjAbf');
				}
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//view admin profit
	public function viewAdminProfit() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				$currency_profit = Currency::where('status', '1')->select('currency_symbol')->orderBy('id', 'desc')->get();
				foreach ($currency_profit as $cur_pro) {
					$first_label = $cur_pro['currency_symbol'];
					$secound_lable = $first_label . "_profit";
					$profit[$secound_lable] = Controller::adminProfit($first_label);
				}
				return view('admin.coinprofit.coinProfit')->with('profit', $profit)->with('currency_profit',$currency_profit)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function profitHistory() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$totalrecords = intval(Input::get('totalrecords'));
				$draw = Input::get('draw');
				$start = Input::get('start');
				$length = Input::get('length');
				$sorttype = Input::get('order');
				$sort_col = $sorttype['0']['column'];
				$sort_type = $sorttype['0']['dir'];
				$search = Input::get('search');
				$from_date = Input::get('from');
				$to_date = Input::get('to');
				$search = $search['value'];

				if ($sort_col == '1') {
					$sort_col = 'u.consumer_name';
				} else if ($sort_col == '2') {
					$sort_col = 'cp.theftAmount';
				} else if ($sort_col == '3') {
					$sort_col = 'cp.theftCurrency';
				} else if ($sort_col == '4') {
					$sort_col = 'cp.type';
				} else if ($sort_col == '5') {
					$sort_col = 'cp.created_at';
				}  else {
					$sort_col = "cp.id";
				}
				if ($sort_type == 'asc') {
					$sort_type = 'desc';
				} else {
					$sort_type = 'asc';
				}
				$data = $orders = array();

				$profitHis = DB::table(COINPROFIT.' as cp')->leftjoin(USERINFO.' as u', 'u.id', '=', 'cp.user_id')->where('theftAmount', '!=', '0')->where('u.pro_user', '0');

				if ($search != '') {
					$profitHis = $profitHis->where(function ($q) use ($search) {
						$q->where('u.consumer_name', 'like', '%' . $search . '%')->orWhere('cp.type', 'like', '%' . $search . '%')->orWhere('cp.theftAmount', 'like', '%' . $search . '%')->orWhere('cp.theftCurrency', 'like', '%' . $search . '%')->orWhere('cp.created_at', 'like', '%' . $search . '%');}
					);
				}

				if ($from_date) {
					$profitHis = $profitHis->where('cp.updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
				}

				if ($to_date) {
					$profitHis = $profitHis->where('cp.updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
				}

				$profitHis_count = $profitHis->count();
				if ($profitHis_count) {

					$profitHis = $profitHis->select('u.consumer_name', 'cp.*');

					$orders = $profitHis->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
				}

				$data = array();
				$no = $start + 1;

				if ($profitHis_count) {
					foreach ($orders as $r) {
						$digits = 8;
						array_push($data, array(
							$no,
							$r->consumer_name,
							number_format($r->theftAmount, $digits, '.', ''),
							$r->theftCurrency,
							$r->type,
							$r->created_at,
						));
						$no++;
					}
					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $profitHis_count, 'recordsFiltered' => $profitHis_count, 'data' => $data));
				} else {

					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $profitHis_count, 'recordsFiltered' => $profitHis_count, 'data' => array()));
				}
			} 
		}
	}

	public function overallprofitHistory() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$totalrecords = intval(Input::get('totalrecords'));
				$draw = Input::get('draw');
				$start = Input::get('start');
				$length = Input::get('length');
				$sorttype = Input::get('order');
				$sort_col = $sorttype['0']['column'];
				$sort_type = $sorttype['0']['dir'];
				$search = Input::get('search');
				$from_date = Input::get('from');
				$to_date = Input::get('to');
				$search = $search['value'];

				if ($sort_col == '1') {
					$sort_col = 'c.currency_symbol';
				} else {
					$sort_col = "c.id";
				}
				if ($sort_type == 'asc') {
					$sort_type = 'desc';
				} else {
					$sort_type = 'asc';
				}
				$data = $orders = array();
				$profitHis = DB::table(CURRENCY.' as c')->leftjoin(COINPROFIT.' as cp', 'c.currency_symbol', '=', 'cp.theftCurrency')->where('cp.theftAmount', '!=', '0')->where('cp.user_id', '!=', '0')->where('c.status', '1');

				if ($search != '') {
					$profitHis = $profitHis->where(function ($q) use ($search) {
						$q->where('cp.theftCurrency', 'like', '%' . $search . '%');}
					);
				}

				if ($from_date) {
					$profitHis = $profitHis->where('cp.updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
				}

				if ($to_date) {
					$profitHis = $profitHis->where('cp.updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
				}

				$profitHis_count = $profitHis->count();
				if ($profitHis_count) {

					$profitHis = $profitHis->select(DB::raw('SUM(theftAmount) as total'), 'cp.theftCurrency');

					$orders_Count = $profitHis->orderBy($sort_col, $sort_type)->groupBy('c.currency_symbol')->get()->toArray();
					$orders = $profitHis->skip($start)->take($length)->orderBy($sort_col, $sort_type)->groupBy('c.currency_symbol')->get()->toArray();
				}

				$data = array();
				$no = $start + 1;

				if ($profitHis_count) {
					foreach ($orders as $r) {
						$digits = 8;
						array_push($data, array(
							$no,
							$r->theftCurrency,
							number_format($r->total, $digits, '.', ''),
						));
						$no++;
					}
					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => count($orders_Count), 'recordsFiltered' => count($orders_Count), 'data' => $data));
				} else {
					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => count($orders_Count), 'recordsFiltered' => count($orders_Count), 'data' => array()));
				}
			} 
		}
	}

	//Profile Actions
	public function viewProfile() {
		if (session('adminId') != '') {
			$data = SubAdmin::where('id', session('adminId'))->first();
			$first = decrypText($data['admin_desc']);
			$second = decrypText($data['admin_sub_key']);
			$useremailid = $first . "@" . $second;

			require_once app_path('Model/Googleauthenticator.php');
			$googleAuth = new Googleauthenticator();
			if ($data->secret == "" && $data->tfa_url == "") {
				$secret = $googleAuth->createSecret();
				$tfaUrl = $googleAuth->getQRCodeGoogleUrl(SITENAME."(" . $useremailid . ")", $secret);
				SubAdmin::where('id', session('adminId'))->update(['secret' => $secret, 'tfa_url' => $tfaUrl, 'tfa_status' => 'disable']);
				$data['secret'] = $secret;
				$data['tfa_url'] = $tfaUrl;
			}
			return view('admin.common.profile')->with('profile', $data)->with('redirectUrl', $this->Url);
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function updateProfile() {
		if (session('adminId') != '') {
			$adminId = session('adminId');
			$data = Input::all();
			$Validation = Validator::make($data, SubAdmin::$profileRule);
			if ($Validation->fails()) {
				Session::flash('error', $Validation->messages());
				return Redirect::to($this->Url.'/profile');
			}
			if ($_FILES['admin_profile']['name'] == "") {
				$image = strip_tags($data['admin_profile_old']);
			} else {
				$fileExtensions = ['jpeg', 'jpg', 'png'];
				$fileName = $_FILES['admin_profile']['name'];
				$fileType = $_FILES['admin_profile']['type'];
				$explode = explode('.', $fileName);
				$extension = end($explode);
				$fileExtension = strtolower($extension);
				$mimeImage = mime_content_type($_FILES["admin_profile"]['tmp_name']);
				$explode = explode('/', $mimeImage);

				if (!in_array($fileExtension, $fileExtensions)) {
					Session::flash('error', 'Invalid file type. Only image files are accepted.');
					return Redirect::to($this->Url.'/profile');
				} else {
					if ($explode[0] != "image") {
						Session::flash('error', 'Invalid file type. Only image files are accepted.');
						return Redirect::to($this->Url.'/profile');
					}
					$cloudUpload = \Cloudinary\Uploader::upload($_FILES["admin_profile"]['tmp_name']);
					if ($cloudUpload) {
						$image = $cloudUpload['secure_url'];
					} else {
						Session::flash('error', $cloudUpload["error"]["message"]);
						return Redirect::to($this->Url.'/profile');
					}
				}
			}

			$email = explode('@', strip_tags('admin@bitpaisaa.com'));
			$first = encrypText($email[0]);
			$second = encrypText($email[1]);

			$result = SubAdmin::where('id', $adminId)->update(['admin_username' => strip_tags($data['admin_username']), 'admin_profile' => $image, 'admin_phone' => strip_tags($data['admin_phno']), 'admin_address' => strip_tags($data['admin_address']), 'admin_city' => strip_tags($data['admin_city']), 'admin_state' => strip_tags($data['admin_state']), 'admin_postal' => strip_tags($data['admin_postal']), 'country' => strip_tags($data['country']), 'admin_desc' => strip_tags($first), 'admin_sub_key' => strip_tags($second)]);
			if ($result) {
				Session::flash('success', 'Profile Updated Successfully');
			} else {
				Session::flash('error', 'Failed to update.');
			}
			return Redirect::to($this->Url.'/profile');
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function enableDisableTFa() {
		if (session('adminId') != '') {
			$adminId = session('adminId');
			$data = Input::all();
			$getUserDetails = SubAdmin::where('id', $adminId)->select('admin_desc', 'admin_sub_key','tfa_status')->first();
			$first = decrypText($getUserDetails['admin_desc']);
			$second = decrypText($getUserDetails['admin_sub_key']);
			$useremailid = $first . "@" . $second;

			require_once app_path('Model/Googleauthenticator.php');
			$googleAuth = new Googleauthenticator();
			if ($googleAuth->verifyCode($data['secret_code'], $data['auth_key'], 1)) {
				if ($data['tfa_status'] == "disable") {
					$updateData = array('secret' => $data['secret_code'], 'tfa_url' => $data['tfa_url'], 'tfa_status' => 'enable');
					$msg = trans('app_lang.TFA enabled successfully');
					$type = 'TFA enabled';
					$notf_msg3 = 'You have enabled 2FA';
				} else {
					$secret = $googleAuth->createSecret();
					$tfaUrl = $googleAuth->getQRCodeGoogleUrl(SITENAME."(" . $useremailid . ")", $secret);
					$updateData = array('secret' => $secret, 'tfa_url' => $tfaUrl, 'tfa_status' => 'disable');
					$type = 'TFA disabled';
					$msg = trans('app_lang.TFA disabled successfully');
					$notf_msg3 = 'You have disabled 2FA';
				}
				$result = SubAdmin::where('id', $adminId)->update($updateData);
				if ($result) {
					$notf_msg1 = trans('app_lang.hi');
					$msg1 = $notf_msg1 . " ," . $notf_msg3 . "!";
					Session::flash('success', $msg);
				} else {
					Session::flash('error', trans('app_lang.Failed to update TFA verification.'));
				}
				self::logout();
				return Redirect::back();
			} else {
				Session::flash('error', trans('app_lang.Invalid 6-digit Authentication Code'));
				return Redirect::back();
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function checkPassword() {
		if (session('adminId') != '') {
			$pwd = encrypText($_GET['current_pwd']);
			$getCount = SubAdmin::where('id', session('adminId'))->where('admin_key', $pwd)->count();
			echo ($getCount == 1) ? "true" : "false";
		} else {
			echo "false";
		}
	}

	public function changePassword() {
		if (session('adminId') != '') {
			$data = Input::all();
			$adminId = session('adminId');
			$Validation = Validator::make($data, SubAdmin::$pwdRule);
			if ($Validation->fails()) {
				Session::flash('error', $Validation->messages());
				return Redirect::to($this->Url.'/profile');
			}
			if ($data == array_filter($data)) {
				$new_pwd = strip_tags($data['new_pwd']);
				$confirm_pwd = strip_tags($data['confirm_pwd']);
				$pwd = encrypText(strip_tags($data['current_pwd']));
				$getCount = SubAdmin::where('id', $adminId)->where('admin_key', $pwd)->count();
				if ($getCount == 1) {
					if ($new_pwd == $confirm_pwd) {
						$updateData = encrypText($confirm_pwd);
						$result = SubAdmin::where('id', $adminId)->update(['admin_key' => $updateData]);
					}
				}
				if ($result) {
					Session::flash('success', 'password Updated Successfully');
				} else {
					Session::flash('error', 'Failed to update.');
				}
				self::logout();
				return Redirect::to($this->Url.'/profile');
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//site settings action
	public function adminSettings() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				$data = SiteSettings::first();			
				return view('admin.common.settings')->with('adminsettings', $data)->with('redirectUrl', $this->Url);
			} 
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function updateSite() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 0);
			if ($permission == true) {
				$adminId = session('adminId');
				$data = Input::all();
				$Validation = Validator::make($data, SubAdmin::$siteRule);
				if ($Validation->fails()) {
					Session::flash('error', $Validation->messages());return Redirect::back();
				}
				if ($_FILES['site_logo']['name'] == "") {
					$image = strip_tags($data['site_logo_old']);
				} else if ($_FILES['site_logo']['name'] != "") {
					$fileExtensions = ['jpeg', 'jpg', 'png'];
					$fileName = $_FILES['site_logo']['name'];
					$fileType = $_FILES['site_logo']['type'];
					$explode = explode('.', $fileName);
					$extension = end($explode);
					$fileExtension = strtolower($extension);
					$mimeImage = mime_content_type($_FILES["site_logo"]['tmp_name']);
					$explode = explode('/', $mimeImage);

					if (!in_array($fileExtension, $fileExtensions)) {
						Session::flash('error', 'Invalid file type. Only image files are accepted.');
						return Redirect::to($this->Url.'/settings');
					} else {
						if ($explode[0] != "image") {
							Session::flash('error', 'Invalid file type. Only image files are accepted.');
							return Redirect::to($this->Url.'/settings');
						}
						$cloudUpload = \Cloudinary\Uploader::upload($_FILES["site_logo"]['tmp_name']);
						if ($cloudUpload) {
							$image = $cloudUpload['secure_url'];
						} else {
							Session::flash('error', $cloudUpload["error"]["message"]);
							return Redirect::to($this->Url.'/settings');
						}
					}
				}
				if ($_FILES['site_favicon']['name'] == "") {
					$favimage = strip_tags($data['site_favicon_old']);
				} else if ($_FILES['site_favicon']['name'] != "") {
					$fileExtensions = ['jpeg', 'jpg', 'png'];
					$fileName = $_FILES['site_favicon']['name'];
					$fileType = $_FILES['site_favicon']['type'];
					$explode = explode('.', $fileName);
					$extension = end($explode);
					$fileExtension = strtolower($extension);
					$mimeImage = mime_content_type($_FILES["site_favicon"]['tmp_name']);
					$explode = explode('/', $mimeImage);

					if (!in_array($fileExtension, $fileExtensions)) {
						Session::flash('error', 'Invalid file type. Only image files are accepted.');
						return Redirect::to($this->Url.'/settings');
					} else {
						if ($explode[0] != "image") {
							Session::flash('error', 'Invalid file type. Only image files are accepted.');
							return Redirect::to($this->Url.'/settings');
						}
						$cloudUpload = \Cloudinary\Uploader::upload($_FILES["site_favicon"]['tmp_name']);
						if ($cloudUpload) {
							$favimage = $cloudUpload['secure_url'];
						} else {
							Session::flash('error', $cloudUpload["error"]["message"]);
							return Redirect::to($this->Url.'/settings');
						}
					}
				}

				$siteData = array(
					'site_name' => strip_tags($data['site_name']),
					'maintenance_text' => strip_tags($data['maintenance_text']),
					'site_status' => strip_tags($data['site_status']),
					'site_logo' => $image,
					'site_favicon' => $favimage,
					'mail_img' => $image,
					// 'add_coin_status' => strip_tags($data['add_coin_status']),
					'mail_logo' => $image,
					'contact_number' => strip_tags($data['contact_no']),
					'contact_address' => strip_tags($data['contact_address']),
					'city' => strip_tags($data['city']),
					'state' => strip_tags($data['state']),
					'country' => strip_tags($data['country']),
					'copy_right_text' => strip_tags($data['copy_right_text']),
					'fb_url' => strip_tags($data['facebook_url']),
					'twitter_url' => strip_tags($data['twitter_url']),
					'tele_url' => strip_tags($data['tele_url']),
					'youtube_url' => strip_tags($data['youtube_url']),
					'postal' => strip_tags($data['postal']),
					// 'add_coin_fee_amount' => strip_tags($data['coin_fee']),
				);
				$result = SiteSettings::where('id', 1)->update($siteData);
				if ($result) {
					Session::flash('success', 'Site Updated Successfully');
				} else {
					Session::flash('error', 'Failed to update.');
				}
				return Redirect::back();
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	//NEWSLETTER
	public function news_letter() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 17);
			if ($permission == true) {
				return view('admin.newsletter.news_letter')->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function news_letteredit() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 17);
			if ($permission == true) {
				$data = Input::all();

				if (!empty($data['all_user']) || !empty($data['sub_user'])) {
					$email['selectaudience'] = strip_tags($data['selectaudience']);
					if ($data['selectaudience'] == 'alluser') {
						$emailgloballist = $data['all_user'];
					} else if ($data['selectaudience'] == 'allsubscr') {
						$emailgloballist = $data['sub_user'];
					}

					$email['subject'] = strip_tags($data['subject']);
					$email['template'] = $data['template'];

					foreach ($emailgloballist as $emaillist) {
						$getEmail = EmailTemplate::where('id', 21)->first();
						$getSiteDetails = Controller::getEmailTemplateDetails();
						$info = array('###SUBJECT###' => $data['subject']);
						$replace = array_merge($getSiteDetails, $info);
						$emaildata = array('content' => strtr($getEmail->template, $replace));
						$toDetails['useremail'] = $emaillist;
						$toDetails['subject'] = $data['subject'];
						$toDetails['from'] = $getSiteDetails['contact_mail_id'];
						$toDetails['name'] = $getSiteDetails['site_name'];
						$sendEmail = Controller::sendEmail($emaildata, $toDetails);						
					}

					if (count(Mail::failures()) > 0) {
						Session::flash('error', 'News Letter Sent failed.');
						return Redirect::to($this->Url.'/news_letter');
					} else {
						Session::flash('success', 'News Letter Sent Successfully.');
						return Redirect::to($this->Url.'/news_letter');
					}

				} else {
					Session::flash('error', 'Please Select any one of users!');
					return Redirect::to($this->Url.'/news_letter');
				}

			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	function getLocation() {
		$ip = Controller::getIpAddress();
		try {
			$reader = new Reader(app_path('Model/GeoLite2-City.mmdb'));
			$record = $reader->city($ip);
			$country = $record->country->name;
			$city = ($record->city->name == "") ? $country : $record->city->name;
			$result = $country . "##" . $city;
		} catch (\Exception $e) {
			$result = "India##Madurai";
		}
		return $result;
	}

	public function viewreferral() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 7);
			if ($permission == true) {
				$data = User::orderBy('id','desc')->get();
				return view('admin.referral.viewreferral')->with('banks', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function referralHistory() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$totalrecords = intval(Input::get('totalrecords'));
				$draw = Input::get('draw');
				$start = Input::get('start');
				$length = Input::get('length');
				$sorttype = Input::get('order');
				$sort_col = $sorttype['0']['column'];
				$sort_type = $sorttype['0']['dir'];
				$search = Input::get('search');
				$from_date = Input::get('from');
				$to_date = Input::get('to');
				$search = $search['value'];

				if ($sort_col == '1') {
					$sort_col = 'user_mail_id';
				} else if ($sort_col == '1') {
					$sort_col = 'unusual_user_key';
				} else if ($sort_col == '2') {
					$sort_col = 'consumer_name';
				}  else {
					$sort_col = "id";
				}
				if ($sort_type == 'asc') {
					$sort_type = 'desc';
				} else {
					$sort_type = 'asc';
				}
				$data = $orders = array();

				$refHis = User::where('refer_id', '!=', '');

				if ($search != '') {
					$refHis = $refHis->where(function ($q) use ($search) {
						$q->where('user_mail_id', 'like', '%' . encrypText($search) . '%')->orWhere('unusual_user_key', 'like', '%' . encrypText($search) . '%')->orWhere('consumer_name', 'like', '%' . $search . '%');}
					);
				}

				if ($from_date) {
					$refHis = $refHis->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
				}

				if ($to_date) {
					$refHis = $refHis->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
				}

				$refHis_count = $refHis->count();
				if ($refHis_count) {

					$refHis = $refHis->select('user_mail_id', 'consumer_name', 'unusual_user_key', 'id');

					$orders = $refHis->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
				}

				$data = array();
				$no = $start + 1;

				if ($refHis_count) {
					foreach ($orders as $r) {
						$userId = encrypText($r['id']);
						$viewUrl = URL::to($this->Url.'/userDetail/'.$userId);
						$viewUser = '<a href="'.$viewUrl.'">'.$r['consumer_name'].'</a>';
						$refUrl = URL::to($this->Url.'/ReferralUserWiseShowAll/'.$userId);
						$refUser = '<a class="userRemove" href="'.$refUrl.'"><span class="glyphicon glyphicon-eye-open" style="color: #4f5259; vertical-align: middle;" title="View"></span></a>';
						array_push($data, array(
							$no,
							decrypText($r['user_mail_id']) . '@' . decrypText($r['unusual_user_key']),
							$viewUser,
							$refUser,
						));
						$no++;
					}
					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $refHis_count, 'recordsFiltered' => $refHis_count, 'data' => $data));
				} else {

					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $refHis_count, 'recordsFiltered' => $refHis_count, 'data' => array()));
				}
			} 
		}
	}

	public function viewReferralBalance(){
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 7);
			if ($permission == true) {
				$data = DB::table(WALLET.' as w')->leftjoin(USERINFO.' AS U', 'U.id', '=', 'w.user_id')->where('w.clear_bal','!=',0)->where('w.clear_bal','>=',500)->select('w.clear_bal', 'w.user_id','U.consumer_name')->orderBy('w.id','desc')->get();
				return view('admin.referral.referralbal')->with('payout', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function ReferralUserWiseShow($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$re = decrypText($id);
				$referrralCommission = ReferralCommision::where('refer_by_id', $re)->orderBy('refer_com_id', 'desc')->get();
				if ($referrralCommission->isEmpty()) {
					$referrralCommission = array();
				}
				$tfaDetails = User::where('id', $re)->select('consumer_name')->first();
				return view('admin.referral.viewreferraluserwiseshow')->with('referrralCommission', $referrralCommission)->with('consumer_name', $tfaDetails->consumer_name)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function ReferralUserWiseShowAll($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 1);
			if ($permission == true) {
				$listUsers = array();
				$re = decrypText($id);

				$refer = User::where('id', $re)->select('refer_id')->first();

				$listUsers = User::where('referrer_id', $refer->refer_id)->select('user_mail_id', 'unusual_user_key', 'created_at', 'status', 'consumer_name', 'refer_amount')->orderBy('id', 'desc')->get();

				$referrralCommission = array();
				$referrralCommission = ReferralCommision::where('refer_by_id', $re)->orderBy('refer_com_id', 'desc')->get();
				$refer_id = $re;
				return view('admin.referral.viewreferraluserwiseshowall', compact('refer_id', 'listUsers', 'referrralCommission'))->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	/* Manage Token */
	public function managetoken(Request $request) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 15);
			if ($permission == true) {
				$data = Tokendetail::orderBy('id','desc')->get();
				return view('admin.token.managetoken')->with('data', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		} else {
			Session::flash('error', 'Session Expired');
			return Redirect::to($this->Url);
		}
	}

	/* Add Token Page */

	public function addtoken(Request $request) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 15);
			if ($permission == true) {
				$data = array();
				return view('admin.token.addtoken')->with('data', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		} else {
			Session::flash('error', 'Session Expired');
			return Redirect::to($this->Url);
		}
	}

	/* Token Unique Validation */
	public function tokennamecheck(Request $request) {
		$token_name = strip_tags($request['token_name']);
		$type = strip_tags($request['type']);
		if ($type == 'name') {
			$getCount = Currency::where('currency_name', $token_name)->count();
		} else {
			$getCount = Currency::where('currency_symbol', $token_name)->count();
		}
		echo ($getCount > 0) ? "false" : "true";
	}

	public function update_tokendata($id) {
		$id = decrypText(trim($id));
		$permission = Controller::checkPermission(session('adminId'), 15);
		if ($permission == true) {
			$rec = Tokendetail::where('id', $id)->select('token_status', 'token_name', 'token_symbol')->first();
			if ($rec) {
				if ($rec->token_status == 1) {
					$result = DB::transaction(function () use ($id, $rec) {
						Tokendetail::where('id', $id)->update(array('token_status' => 0));
						Currency::where('currency_name', $rec->token_name)->update(array('status' => 0));
						return TradePairs::where('from_symbol', $rec->token_symbol)->update(array('site_status' => 0));

					});
					if ($result) {
						Session::flash('success', 'Token updated Successfully.');
						return Redirect::to($this->Url.'/managetoken');
					}
				} else {
					$result = DB::transaction(function () use ($id, $rec) {
						Tokendetail::where('id', $id)->update(array('token_status' => 1));
						Currency::where('currency_name', $rec->token_name)->update(array('status' => 1));
						return TradePairs::where('from_symbol', $rec->token_symbol)->update(array('site_status' => 1));

					});
					if ($result) {
						Session::flash('success', 'Token updated Successfully.');
						return Redirect::to($this->Url.'/managetoken');
					}
				}
			}
		} else {
			Session::flash('error', 'Permission Denied!');
			return Redirect::to($this->Url);
		}
		Session::flash('error', 'Unable to update token');
		return Redirect::to($this->Url.'/managetoken');
	}

	/* Add Token Process */
	public function addtoken_data(Request $request) {
		$permission = Controller::checkPermission(session('adminId'), 15);
		if ($permission == true) {
			$tokenname = $request['token_name'];
			$contract_address = $request['contract_address'];
			$token_symbol = $request['token_symbol'];
			$base_coin = 'ETH';
			$token_decimal = $request['token_decimal'];
			$token_status = $request['token_status'];
			$token_linkedin = $request['token_linkedin'];
			$token_telegram = $request['token_telegram'];
			$token_facebookin = $request['token_facebookin'];
			$token_twitter = $request['token_twitter'];
			$token_bitcointalk = $request['token_bitcointalk'];
			$token_githublink = $request['token_githublink'];
			$select_market = $request['markets'];

			if (!empty($select_market)) {
				$markets = implode(',', $select_market);
			} else {
				$markets = 'BTC';
			}

			$filename = "";
			$uploadedFile = $request->file('token_slogo');
			if (!empty($uploadedFile)) {
				$cloudUpload = \Cloudinary\Uploader::upload($_FILES["token_slogo"]['tmp_name']);
				if ($cloudUpload) {
					$filename = $cloudUpload['secure_url'];
				}
			}

			$token_info['token_name'] = $tokenname;
			$token_info['token_symbol'] = $token_symbol;
			$token_info['contract_address'] = $contract_address;
			$token_info['decimal_places'] = $token_decimal;
			$token_info['base_coin'] = $base_coin;
			$token_info['token_logo'] = $token_symbol;
			$token_info['currency_pairs'] = $markets;
			$token_info['token_logo'] = $filename;
			$token_info['linkedin'] = $token_linkedin;
			$token_info['telegram'] = $token_telegram;
			$token_info['facebook'] = $token_facebookin;
			$token_info['twitter'] = $token_twitter;
			$token_info['bitcointalk'] = $token_bitcointalk;
			$token_info['github'] = $token_githublink;
			$token_info['token_status'] = $token_status;
			$token_details = Tokendetail::create($token_info);
			$token_id = $token_details->id;
			/* Added In Currency */
			$currency_info['currency_name'] = $tokenname;
			$currency_info['currency_symbol'] = $token_symbol;
			$currency_info['image'] = $filename;
			$currency_info['currency_type'] = 'Crypto';
			$currency_info['status'] = '1';
			$currency_info['created_time'] = date('Y-m-d H:i:s');
			$currency_add = Currency::create($currency_info);
			$currency_id = $currency_add->id;
			$type = 'string';
			$length = 20;
			$fieldName = $token_symbol;
			$table = 'wallet';

			/* Deposit Setting */
			$dep_setting_arr['currency'] = $token_symbol;
			$dep_setting_arr['min'] = '1.00000000';
			$dep_setting_arr['max'] = '100.00000000';
			$dep_setting_arr['currency_type'] = 'Crypto';
			$dep_setting_arr['status'] = '1';
			$dep_info_details = DepositSettings::create($dep_setting_arr);

			/* Withdraw Setting */
			$with_arr['currency'] = $token_symbol;
			$with_arr['currency_type'] = 'Crypto';
			$with_arr['min'] = '0.5';
			$with_arr['max'] = '100';
			$with_arr['withdraw_limit_day'] = '10';
			$with_arr['fee'] = '0.1';
			$with_arr['status'] = '1';
			$dep_info_details = WithdrawSettings::create($with_arr);

			/* Added Trade Pairs */
			if (!empty($select_market)) {
				foreach ($select_market as $skey => $sval) {
					$csymbol = Currency::where('currency_symbol', $sval)->select('id')->first();
					if (!empty($csymbol)) {
						$fid = $csymbol->id;
						$pair_name = $token_symbol . '/' . $sval;
						$trading_pair = $token_symbol . '_' . $sval;
						$to_symbol = $sval;
						$from_symbol = $token_symbol;
						$pair_info['pair_name'] = $pair_name;
						$pair_info['trading_pair'] = $trading_pair;
						$pair_info['to_symbol'] = $to_symbol;
						$pair_info['from_symbol'] = $from_symbol;
						$pair_info['site_status'] = 0;
						$pair_info['refer_commision_per'] = 0;
						$pair_info['change'] = 0;
						TradePairs::create($pair_info);
					}
				}
				Session::flash('success', 'Token Send Successfully.');
				return Redirect::to($this->Url.'/managetoken');
			}
		} else {
			Session::flash('error', 'Permission Denied!');
			return Redirect::to($this->Url);
		}
	}

	public function coin_details($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 16);
			if ($permission == true) {
				$id = decrypText($id);
				$data = AddCoins::where('addcoin_id', $id)->first();
				return view('admin.coin.coininfo')->with('coininfo', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function downld($id) {
		$id = decrypText($id);
		$data = AddCoins::where('addcoin_id', $id)->select('coin_log_upload', 'addcoin_id', 'image_type')->first();
		$img = $data->coin_log_upload;
		$id = $data->addcoin_id;
		$type = $data->image_type;

		$fil = explode("/", $type);

		$filename = 'new_coin' . '.' . $fil[1];
		$tempImage = tempnam(sys_get_temp_dir(), $filename);
		copy($img, $tempImage);
		return response()->download($tempImage, $filename);
	}

   
		//To generate apikey 
	protected function generateCode() {
		return Keygen::bytes()->generate(
			function($key) {
            // Generate a random numeric key
				$random = Keygen::numeric()->generate();

            // Manipulate the random bytes with the numeric key
				return substr(md5($key . $random . strrev($key)), mt_rand(0,8), 32);
			},
			function($key) {
            // Add a (-) after every fourth character in the key
				return join('-', str_split($key, 6));
			},
			'strtoupper'
		);
	}

	function csv($table){   
       // User List
		if($table == 'userlist'){
			header('Content-type: application/ms-excel');
			header('Content-Disposition: attachment; filename=user_list_' . date('Y-m-d') . '.csv');
			$fp = fopen("php://output", "w");

			$transactions = User::select('id', 'user_mail_id', 'unusual_user_key', 'status', 'consumer_name', 'country', 'created_at', 'verified_status', 'tfa_status', 'phone', 'cashfree_status', 'auto_with', 'auto_trade')->orderBy('id', 'desc')->get();
			fputcsv($fp, array("Id", "Username","Email", "Country", "Phone", "Status", "TFA Status", "KYC Status", "VPA Status", "Auto Withdraw Status", "Auto Trade Status", "Create Date"));
			$v_status = array('0' => 'Not Verified', '1' => 'Pending', '2' => 'Rejected', '3' => 'Verified');
			$vpa_status = array('0' => 'Pending', '1' => 'Verified', '2' => 'Pending');
			$estatus = array('1' => 'Enable', '0' => 'Disable');

			if (count($transactions)) {
				$i = 1;
				foreach ($transactions as $res) {
					$email       = decrypText($res->user_mail_id) . '@' . decrypText($res->unusual_user_key);
					$td = array($i, $res->consumer_name, $email, $res->country, $res->phone, $res->status, $res->tfa_status, $v_status[$res->verified_status], $vpa_status[$res->cashfree_status], $estatus[$res->auto_with], $estatus[$res->auto_trade], $res->created_at);
					fputcsv($fp, $td);
					$i++;
				}
			}
		} else if($table == 'userbank'){
			header('Content-type: application/ms-excel');
			header('Content-Disposition: attachment; filename=user_bank_' . date('Y-m-d') . '.csv');
			$fp = fopen("php://output", "w");

			$transactions = DB::table(USERBANK. ' as B')->leftjoin(USERINFO. ' AS U', 'U.id', '=', 'B.user_id')->whereIn('B.status', ['1', '2', '3'])->select('B.id', 'B.currency', 'B.bank_name', 'B.acc_name', 'B.acc_number', 'B.bank_branch', 'B.status', 'B.beneId_status', 'U.consumer_name')->orderBy('B.id', 'desc')->get();
			fputcsv($fp, array("Id", "Username","Currency", "Bank Name", "Account Name", "Account Number", "Bank Branch", "Status", "Bene Status"));
			if (count($transactions)) {
				$i = 1;
				foreach ($transactions as $res) {
					$v_status = array('0' => 'Deactivated', '1' => 'Active', '2' => 'Pending', '3' => 'Reject');
					$bene = array('0' => 'Pending', '1' => 'Active', '');
					if($res->beneId_status == 1) {
						$beneSts = 'Active';
					} else if($res->beneId_status == 0) {
						$beneSts = 'Pending';
					} else {
						$beneSts = '';
					}
					$td = array($i, $res->consumer_name, $res->currency, $res->bank_name, $res->acc_name, $res->acc_number, $res->bank_branch, $v_status[$res->status], $beneSts);
					fputcsv($fp, $td);
					$i++;
				}
			}
		} else if($table == 'userbalance'){
			header('Content-type: application/ms-excel');
			header('Content-Disposition: attachment; filename=user_balance_' . date('Y-m-d') . '.csv');
			$fp = fopen("php://output", "w");

			$transactions = DB::table(WALLET.' as w')->leftjoin(USERINFO.' AS U', 'U.id', '=', 'w.user_id')->select('w.*', 'U.consumer_name', 'U.country')->orderBy('w.id', 'desc')->get();
			array();
			fputcsv($fp, array("Id", "Username", "Country","BTC", "ETH", "LTC", "USDT", "BCH", "DASH", "XRP", "INR"));
			if (count($transactions)) {
				$i = 1;
				foreach ($transactions as $res) {
					$td = array($i, $res->consumer_name, $res->country, $res->BTC, $res->ETH, $res->LTC, $res->USDT, $res->BCH, $res->DASH, $res->XRP, $res->INR);
					fputcsv($fp, $td);
					$i++;
				}
			}
		} else if($table == 'userapi'){
			header('Content-type: application/ms-excel');
			header('Content-Disposition: attachment; filename=user_api_' . date('Y-m-d') . '.csv');
			$fp = fopen("php://output", "w");

			$transactions = User::where('api_status', '!=', '0')->select('id', 'user_mail_id', 'unusual_user_key', 'api_status')->orderBy('id', 'desc')->get();
			fputcsv($fp, array("Id", "Email","API Status"));
			if (count($transactions)) {
				$i = 1;
				foreach ($transactions as $res) {
					$email       = decrypText($res->user_mail_id) . '@' . decrypText($res->unusual_user_key);
					$v_status = array('0' => 'Disabled', '1' => 'Verified', '2' => 'Pending', '3' => 'Disabled');

					$td = array($i, $email,$v_status[$res->api_status]);
					fputcsv($fp, $td);
					$i++;
				}
			}
		} else if($table == 'deposit'){
			header('Content-type: application/ms-excel');
			header('Content-Disposition: attachment; filename=user_deposit_' . date('Y-m-d') . '.csv');
			$fp = fopen("php://output", "w");

			$transactions = DB::table(DEPOSIT.' as D')->leftjoin(USERINFO. ' AS U', 'U.id', '=', 'D.user_id')->select('D.id', 'D.user_id' ,'D.reference_no', 'D.currency', 'D.created_at', 'D.status', 'D.amount', 'D.payment_method', 'D.trans_type', 'D.payment_type', 'U.consumer_name', 'U.country')->orderBy('D.id', 'desc')->get();
			fputcsv($fp, array("Id","Deposited On", "User", "Country", "Payment Type", "Amount", "Currency", "Reference Number", "Status"));
			if (count($transactions)) {
				$i = 1;
				foreach ($transactions as $res) {
					$digits = 8;
					$dtype = '-';
					$td = array($i, $res->created_at,$res->consumer_name, $res->country, ucfirst($dtype), number_format($res->amount, $digits, '.', ''), $res->currency, $res->reference_no, $res->status);
					fputcsv($fp, $td);
					$i++;
				}
			}
		} else if($table == 'pendingdeposit') {
			header('Content-type: application/ms-excel');
			header('Content-Disposition: attachment; filename=user_unconfirmed_deposit_' . date('Y-m-d') . '.csv');
			$fp = fopen("php://output", "w");

			$transactions = DB::table(PENDINGDEPOSIT.' as D')->leftjoin(USERINFO. ' AS U', 'U.id', '=', 'D.user_id')->select('D.id', 'D.user_id' ,'D.reference_no', 'D.currency', 'D.created_at', 'D.status', 'D.amount', 'D.payment_method', 'D.trans_type',  'D.block_confirm', 'U.consumer_name')->orderBy('D.id', 'desc')->get();
			fputcsv($fp, array("Id","Deposited On", "User", "Amount", "Currency", "Reference Number", "Status", "Confirmations"));
			if (count($transactions)) {
				$i = 1;
				foreach ($transactions as $res) {
					$digits = 8;
					$td = array($i, $res->created_at,$res->consumer_name, number_format($res->amount, $digits, '.', ''), $res->currency, $res->reference_no, $res->status, $res->block_confirm);
					fputcsv($fp, $td);
					$i++;
				}
			}
		} else if($table == 'withdraw'){
			header('Content-type: application/ms-excel');
			header('Content-Disposition: attachment; filename=user_withdraw_' . date('Y-m-d') . '.csv');
			$fp = fopen("php://output", "w");

			$transactions = DB::table(WITHDRAW.' as W')->leftjoin(USERINFO. ' AS U', 'U.id', '=', 'W.user_id')->select('W.id', 'W.reference_no', 'W.currency', 'W.created_at', 'W.status', 'W.amount','W.payment_method', 'W.trans_type' , 'W.wallet_type' , 'U.consumer_name')->orderBy('W.id', 'desc')->get();
			fputcsv($fp, array("Id","Initiated On", "User", "Amount", "Currency", "Reference Number", "Status"));
			if (count($transactions)) {
				$i = 1;
				foreach ($transactions as $res) {
					$digits = 8;
					$td = array($i, $res->created_at,$res->consumer_name, number_format($res->amount, $digits, '.', ''), $res->currency, $res->reference_no, $res->status);
					fputcsv($fp, $td);
					$i++;
				}
			}
		} else if($table == 'orders'){
			header('Content-type: application/ms-excel');
			header('Content-Disposition: attachment; filename=user_orders_' . date('Y-m-d') . '.csv');
			$fp = fopen("php://output", "w");

			$names = array('active', 'partially', 'stoporder', 'stoplimit');			
			$transactions = CoinOrder::whereIn('status', $names)->select('*')->orderBy('id', 'desc')->get();
			fputcsv($fp, array("Id", "Ordered On", "Pair", "User", "Type", "Price", "Amount", "Total", "Status"));
			if (count($transactions)) {
				$i = 1;
				foreach ($transactions as $res) {
					$tradeuserId = $res->user_id;
					$admin_st = $res->admin_st;
					$tradePrice = $res->Price;
					$tradeAmount = $res->Amount;
					$tradeType = $res->Type;
					$tradeTotal = $res->Total;
					$fees = $res->Fee;
					$firstCurrency = $res->firstCurrency;
					$secondCurrency = $res->secondCurrency;
					$orderDate = $res->orderDate;
					$orderTime = $res->orderTime;
					$status = $res->status;
					$ts = $orderDate . " " . $orderTime;
					if($admin_st == 0) {
						$getUser = User::getProfile($tradeuserId);
						$username = $getUser['user']['consumer_name'];
					} else {
						$username = 'Admin';
					}
					$amount = $tradeAmount;
					$pair = $firstCurrency . "/" . $secondCurrency;
					if ($status == "partially") {
						$activefilledAmount = TradeModel::checkFilledAmount1($res->id, $tradeType);
						$partial_date = TradeModel::checkFilledAmount_date($res->id, $tradeType);
						if ($activefilledAmount) {
							$fee_per = $res->fee_per;
							$amount = $tradeAmount - $activefilledAmount;

							$fees = ($amount * $tradePrice) * $fee_per / 100;

							$total = ($amount * $tradePrice);
							$amount = $amount;
							$total = $total;
						}
						$ts = $partial_date;
					} else {
						$total = $tradeTotal;
					}
					if ($ts == "0000-00-00 00:00:00" || $ts == NULL || $ts == "") {
						$ts = $res->datetime;
					}

					$digits = 8;

					$td = array($i,	$ts, $pair, $username, $tradeType, number_format($tradePrice, $digits, '.', ''), number_format($amount, 8, '.', ''), number_format($total, $digits, '.', ''), ucfirst($status));
					fputcsv($fp, $td);
					$i++;
				}
			}
		} else if($table == 'trade'){
			header('Content-type: application/ms-excel');
			header('Content-Disposition: attachment; filename=user_trade_' . date('Y-m-d') . '.csv');
			$fp = fopen("php://output", "w");

			$transactions = OrderTemp::orderBy('id', 'desc')->get();
			fputcsv($fp, array("Id", "Traded On", "Pair", "Buyer", "Seller", "Price", "Amount", "Buy Fees", "Sell Fees", "Total", "Status"));
			if (count($transactions)) {
				$i = 1;
				foreach ($transactions as $res) {
					$tempPair = $res->pair;
					$buyerUserId = $res->buyerUserId;
					$sellerUserId = $res->sellerUserId;
					$firstCurrency = $res->firstCurrency;
					$secondCurrency = $res->secondCurrency;

					$buyerUserorderId = $res->buyorderId;
					$sellerUserorderId = $res->sellorderId;

					$datetime = $res->datetime;
					$filledAmount = $res->filledAmount;
					$askPrice = $res->askPrice;
					$cancel_id = $res->cancel_id;
					$id_res = $res->id;
					if ($cancel_id != '') {
						$status = "cancelled";
					} else {
						$status = "Filled";
					}

					$digits = 8;
					$buyfees = $res->buy_fee;
					$buytotal = $res->buy_total;
					$sellfees = $res->sell_fee;

					if($buyerUserId != 0) {
						$buyuser = getUserName($buyerUserId);
					} else {
						$buyuser = '-';
					}

					if($sellerUserId != 0) {
						$selluser = getUserName($sellerUserId);
					} else {
						$selluser = '-';
					}

					if($filledAmount > 0) {
						$td = array($i, $datetime, $tempPair, $buyuser, $selluser, number_format($askPrice, $digits, '.', ''), number_format($filledAmount, 8, '.', ''), number_format($buyfees, 8, '.', ''), number_format($sellfees, 8, '.', ''), number_format($buytotal, $digits, '.', ''), ucfirst($status));
						fputcsv($fp, $td);
						$i++;
					}
				}
			}
		}   else if($table == 'swap'){
			header('Content-type: application/ms-excel');
			header('Content-Disposition: attachment; filename=user_swap_' . date('Y-m-d') . '.csv');
			$fp = fopen("php://output", "w");

			$transactions = DB::table(EXCHANGE.' as E')->leftjoin(USERINFO.' AS U', 'U.id', '=', 'E.user_id')->select('E.id', 'E.user_id', 'E.from_symbol', 'E.to_symbol', 'E.type', 'E.amount', 'E.status', 'E.created_at', 'U.consumer_name')->orderBy('E.id', 'desc')->get();
			fputcsv($fp, array("Id", "Username","Type", "Pair", "Amount", "Status", "Date"));
			if (count($transactions)) {
				$i = 1;
				foreach ($transactions as $res) {
					$digits = 8;
					$td = array($i, $res->consumer_name, $res->type, $res->from_symbol .'/'. $res->to_symbol, number_format($res->amount, $digits, '.', ''), $res->status, $res->created_at);
					fputcsv($fp, $td);
					$i++;
				}
			}
		} else if($table == 'profit'){
			header('Content-type: application/ms-excel');
			header('Content-Disposition: attachment; filename=admin_profit' . date('Y-m-d') . '.csv');
			$fp = fopen("php://output", "w");

			$transactions = DB::table(COINPROFIT.' as cp')->leftjoin(USERINFO.' as u', 'u.id', '=', 'cp.user_id')->where('theftAmount', '!=', '0')->where('u.pro_user', '0')->select('u.consumer_name', 'cp.*')->orderBy('cp.id','desc')->get();
			fputcsv($fp, array("Id", "Username","Profit Amount", "Currency", "Type", "Date"));
			if (count($transactions)) {
				$i = 1;
				foreach ($transactions as $res) {
					$td = array($i, $res->consumer_name,$res->theftAmount,$res->theftCurrency,$res->type, $res->created_at);
					fputcsv($fp, $td);
					$i++;
				}
			}
		} 
	}

	//logout
	public function logout() {
		if (session('adminId') != '') {
			$ip = Controller::getIpAddress();
			$activity['ip_address'] = $ip;
			$activity['browser_name'] = Controller::getBrowser();
			$activity['os'] = Controller::getPlatform();
			$activity['activity'] = "Logged out";
			$activity['admin_id'] = session('adminId');
			AdminActivity::create($activity);
			Session::flush();
			Session::flash('error', 'Logged out!');
			return Redirect::to($this->Url);
		} else {
			Session::flash('error', 'Logged out!');
			return Redirect::to($this->Url);
		}
	}

	//To view all currencies
	public function viewCurrency($search = '') {
		if (trim($search) == '') {
			$currency_list = Currency::paginate(10);
		} else {
			$currency_list = Currency::where('symbol', 'like', '%' . $search . '%')->orWhere('name', 'like', '%' . $search . '%')->paginate(10);
		}
		return view('admin.currency.currency')->with('currency_list', $currency_list)->with('redirectUrl', $this->Url)->with('search', $search);
	}

	//To return currency details for edit
	public function editCurrency($id = NULL, $page) {
		$id = decrypText(strip_tags($id));
		$data = Currency::where('id', $id)->first();
		$data['types'] = "edit";
		$data['page'] = $page;
		return view('admin.currency.currencyEdit')->with('currency', $data)->with('redirectUrl', $this->Url);
	}

	//To load a page to create new currency
	public function addcurrency() {
		$data['types'] = "add";
		$data['page'] = 1;
		return view('admin.currency.currencyEdit')->with('currency', $data)->with('redirectUrl', $this->Url);
	}

	//To update the changes in corespoding currency
	public function currencyUpdate() {
		$data = Input::all();

		if (!empty($data)) {
			if(isset($_FILES['image']['name'])) {
						if ($_FILES['image']['name'] == "") {
							$image = strip_tags($data['cms_old']);
						} elseif ($_FILES['image']['name'] != "") {
							$fileExtensions = ['jpeg', 'jpg', 'png'];
							$fileName = $_FILES['image']['name'];
							$fileType = $_FILES['image']['type'];
							$explode = explode('.', $fileName);
							$extension = end($explode);
							$fileExtension = strtolower($extension);
							$mimeImage = mime_content_type($_FILES["image"]['tmp_name']);
							$explode = explode('/', $mimeImage);

							if (!in_array($fileExtension, $fileExtensions)) {
								Session::flash('error', 'Invalid file type. Only image files are accepted.');
								return Redirect::back();
							} else {
								if ($explode[0] != "image") {
									Session::flash('error', 'Invalid file type. Only image files are accepted.');
									return Redirect::back();
								}
								$cloudUpload = \Cloudinary\Uploader::upload($_FILES["image"]['tmp_name']);
								if ($cloudUpload) {
									$image = $cloudUpload['secure_url'];
								} else {
									Session::flash('error', $cloudUpload["error"]["message"]);
									return Redirect::back();
								}
							}
						}
					} else {
						$image = "";
					}

			 
			$page = $data['page'];
		 
			$updata['currency_name'] = strip_tags($data['name']);
			$updata['currency_symbol'] = strip_tags($data['symbol']);
			$updata['currency_type'] = strip_tags($data['type']); 
			$updata['image'] = $image;
 
			$id = $data['id'];
			if ($id != "") {
				$id = decrypText(strip_tags($id));
				$result = Currency::where('id', $id)->update($updata);
				$msg = 'Currency Updated Successfully';
			} else {
				$result = Currency::create($updata);
				$msg = 'Currency Added Successfully';
			}
			if ($result) {
				Session::flash('success', $msg);
			} else {
				Session::flash('error', 'Failed to update.');
			}
			return ($page == '--' || $page == '' || $page == NULL) ? Redirect::to($this->Url . '/viewcurrency') : Redirect::to($this->Url . '/viewcurrency/?page=' . $page);
		}
	}

	//To update currency status to active or deactive
	public function currencyStatus($id) {
		$id = decrypText(strip_tags($id));
		$currency = Currency::where('id', $id)->select('status', 'currency_name')->first();
		$new_status = ($currency->status == "1") ? "0" : "1";

		$arrcurrency = Currency::where('id', '!=',$id)->where('status', '1')->count();
		if($arrcurrency){ 
		$update = Currency::where('id', $id)->update(['status' => $new_status]);
		if ($update) {
			$new_stat = ($currency->status == "1") ? "Deactivated" : "Activated";
			$name = $currency->currency_name;
			$msg = $name . " " . $new_stat . " Successfully";
			Session::flash('success', $msg);
		} else {
			Session::flash('error', 'Please Try Again');
		}
		}else{
			Session::flash('error', 'Atleast one currency must be active');
		}
		return Redirect::back();
	}

	public function deleteuserdetails($user_id) {

		
		/*$arrr =  DB::table('sellers')->where('ip_address','51.91.67.153')->get(); 
		if($arrr){
			foreach ($arrr as $key => $value) {
				$user_id = $value->id;*/
			 
		$arrorder = DB::select(DB::raw("SELECT id FROM BP_PaBiiIstaa_co WHERE  user_id = '" . $user_id . "' "));
		if($arrorder){
			foreach ($arrorder as $ord) {
				$tid = $ord->id;
				$arrtemp = DB::select(DB::raw("SELECT id FROM BP_PaBiiIstaa_ot WHERE (sellorderId='".$tid."' or buyorderId='".$tid."') "));
				foreach ($arrtemp as $tmp) {
					$tempId = $tmp->id; 
					DB::table('PaBiiIstaa_ot')->where('id',$tempId)->delete();  
				}
				DB::table('PaBiiIstaa_co')->where('id',$tid)->delete(); 
			}
		}

		DB::table('coin_profit')->where('user_id',$user_id)->delete(); 
        DB::table('consumer_verification')->where('user_id',$user_id)->delete(); 
        DB::table('deposit')->where('userid',$user_id)->delete(); 
        DB::table('exchange')->where('user_id',$user_id)->delete(); 
        DB::table('help_centre')->where('user_id',$user_id)->delete();

        DB::table('PaBiiIstaa_aw')->where('user_id',$user_id)->delete(); 
        DB::table('PaBiiIstaa_ca')->where('user_id',$user_id)->delete(); 
        DB::table('PaBiiIstaa_co')->where('user_id',$user_id)->delete(); 
        DB::table('PaBiiIstaa_de')->where('user_id',$user_id)->delete(); 
         

        DB::table('PaBiiIstaa_wa')->where('user_id',$user_id)->delete(); 
        DB::table('PaBiiIstaa_wi')->where('user_id',$user_id)->delete(); 
        DB::table('pair_favorite')->where('user_id',$user_id)->delete(); 
        DB::table('paytm_deposit')->where('user_id',$user_id)->delete(); 
        DB::table('pending_deposit')->where('user_id',$user_id)->delete(); 

        DB::table('referral_commision_info')->where('user_id',$user_id)->delete(); 
        DB::table('saved_address')->where('user_id',$user_id)->delete(); 
        DB::table('service')->where('user_id',$user_id)->delete(); 
        DB::table('transactions')->where('user_id',$user_id)->delete(); 
        DB::table('transfer')->where('user_id',$user_id)->delete(); 

        DB::table('tron')->where('user_id',$user_id)->delete(); 
        DB::table('user_activity')->where('user_id',$user_id)->delete(); 
        DB::table('user_balance_audit')->where('user_id',$user_id)->delete(); 
        DB::table('user_bank_details')->where('user_id',$user_id)->delete(); 
        DB::table('user_notification')->where('user_id',$user_id)->delete();  

        DB::table('PaBiiIstaa_us')->where('id',$user_id)->delete(); 
   /* }
}*/


	}
}
