<?php

namespace App\Http\Controllers;

use App\Model\CoinProfit;
use App\Model\ContactUs;
use App\Model\Deposit;
use App\Model\SiteSettings;
use App\Model\SubAdmin;
use App\Model\Transaction;
use App\Model\Withdraw;
use Config;
use DB;
use GeoIp2\Database\Reader;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Mail;
use Redirect;
use Session;
use URL;

class Controller extends BaseController {
	use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

	public function __construct() {
		$this->Url = ADMINURL;
	}

	public static function checkPermission($id, $per) {
		if ($id != "") {
			$admin = SubAdmin::where('id', $id)->select('admin_permission', 'admin_role')->first();
			if ($admin->admin_role == "admin") {
				return true;
			} else if ($admin->admin_role == "subadmin") {
				$permission = explode(',', strip_tags($admin->admin_permission));
				if (in_array($per, $permission)) {
					return true;
				} else {
					Session::flash('error', 'Authorization Failed!');
					return Redirect::to(ADMINURL)->send();
				}
			}
		} else {
			Session::flash('error', 'Session Expired!');
			return Redirect::to(ADMINURL);
		}
	}

	public static function getIpAddress() {
		$remote = !empty($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '127.0.0.1';
		$ip = !empty($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $remote;
		return $ip;
	}

	public static function getBrowser() {
		$user_agent = $_SERVER['HTTP_USER_AGENT'];
		$browser = "Unknown Browser";
		$browser_array = array('/msie/i' => 'Internet Explorer',
			'/firefox/i' => 'Firefox',
			'/safari/i' => 'Safari',
			'/chrome/i' => 'Chrome',
			'/edge/i' => 'Edge',
			'/opera/i' => 'Opera',
			'/netscape/i' => 'Netscape',
			'/maxthon/i' => 'Maxthon',
			'/konqueror/i' => 'Konqueror',
			'/mobile/i' => 'Handheld Browser');

		foreach ($browser_array as $regex => $value) {
			if (preg_match($regex, $user_agent)) {
				$browser = $value;
			}
		}
		return $browser;
	}

	public static function getPlatform() {
		$user_agent = $_SERVER['HTTP_USER_AGENT'];
		$platform = 'Unknown';
		if (preg_match('/linux/i', $user_agent)) {
			$platform = 'linux';
		} elseif (preg_match('/macintosh|mac os x/i', $user_agent)) {
			$platform = 'mac';
		} elseif (preg_match('/windows|win32/i', $user_agent)) {
			$platform = 'windows';
		}
		return $platform;
	}

	public static function getEmailTemplateDetails() {
		
		$site = SiteSettings::select('contact_mail_id', 'site_name', 'mail_img', 'mail_logo', 'copy_right_text', 'mail_thump_image', 'fb_image', 'gp_image', 'fb_url', 'twitter_url', 'googleplus_url', 'tw_image')->where('id', 1)->first();

		$gp_image = URL::to('public/frontend/img/'.$site->gp_image);
		$fb_image = URL::to('public/frontend/img/'.$site->fb_image);
		$tw_image = URL::to('public/frontend/img/'.$site->tw_image); 


		$replace = array('###mail###' => $site->mail_img, '###logo###' => $site->mail_logo, '###email_thump###' => $site->mail_thump_image, '###fbimage###' => $fb_image, '###twimage###' => $tw_image, '###gbimage###' => $gp_image, '###fblink###' => $site->fb_url, '###twlink###' => $site->twitter_url, '###gblink###' => $site->googleplus_url, '###COPY###' => $site->copy_right_text, 'contact_mail_id' => $site->contact_mail_id, 'site_name' => $site->site_name, 'staff' => decrypText($site->staff));
		return $replace;
	}

	public static function verifyConfirmation($code, $id) {
		$code = encrypText($code);
		$id = decrypText($id);
		$result = Deposit::where('id', $id)->where('confirm_code', $code)->where('status', 'pending')->count();
		return ($result == "1") ? "true" : "false";
	}

	public static function verifyWithdrawConfirmation($code, $id) {
		$code = encrypText($code);
		$id = decrypText($id);
		$result = Withdraw::where('id', $id)->where('confirm_code', $code)->where('status', 'pending')->count();
		return ($result == "1") ? "true" : "false";
	}

	//admin profit for individual currency
	public static function adminProfit($currency) {
		$query = CoinProfit::select(DB::raw('SUM(theftAmount) as Amount'))
			->where('theftCurrency', $currency)->first();

		$digits = "8";

		$empty_result = "0.00";
		if ($query->count() == 0) {
			return number_format($empty_result, $digits, '.', '');
		} else {
			if ($query->Amount != "") {
				return number_format($query->Amount, $digits, '.', '');
			} else {
				return number_format($empty_result, $digits, '.', '');
			}
		}
	}

	//deposit withdraw chart function
	public static function userTransactionDetails($type, $start, $end, $currency) {
		$chart = Transaction::select(DB::raw('SUM(amount) as amount'))
			->whereDate('created_at', '>=', $start)
			->whereDate('created_at', '<=', $end)
			->where('type', $type)->where('t_status', 'completed')
			->where('currency_name', $currency)->first();
		if ($chart->count() == 0) {
			return "0";
		} else {
			if ($chart->amount != "") {
				return $chart->amount;
			} else {
				return "0";
			}
		}
	}

	//profit chart function
	public static function getProfitDetails($start, $end, $currency) {
		$query = CoinProfit::select(DB::raw('SUM(theftAmount) as Amount'))
			->where('theftCurrency', $currency)
			->whereDate('created_at', '>=', $start)
			->whereDate('created_at', '<=', $end)->first();
		if ($query->count() == 0) {
			return "0";
		} else {
			if ($query->Amount != "") {
				return $query->Amount;
			} else {
				return "0";
			}
		}
	}

	public static function sendEmail($emaildata, $toDetails, $ccEmail = '', $bcc = '') {
		$getFile = file_get_contents(app_path('Model/duDERvPhnA.php'));
		$data = explode(" || ", $getFile);

		Config::set('mail.host', decrypText($data[0]));
		Config::set('mail.port', decrypText($data[1]));
		Config::set('mail.username', decrypText($data[2]));
		Config::set('mail.password', decrypText($data[3]));
		Config::set('mail.encryption', 'tls');

		if ($toDetails['from'] == $toDetails['useremail']) {
			$toDetails['useremail'] = decrypText($toDetails['useremail']);
		}

		$toDetails['from'] = decrypText(FROMMAILID);
		if (!empty($ccEmail) && !empty($bcc)) {
			$toDetails['cc'] = $ccEmail;
			$toDetails['bcc'] = $bcc;
			$sendEmail = Mail::send('email.template', $emaildata, function ($message) use ($toDetails) {
				$message->to($toDetails['useremail']);
				$message->cc($toDetails['cc']);
				$message->bcc($toDetails['bcc']);
				$message->subject($toDetails['subject']);
				$message->from($toDetails['from'], $toDetails['name']);
			});
		} else if (!empty($ccEmail)) {
			$toDetails['cc'] = $ccEmail;
			$sendEmail = Mail::send('email.template', $emaildata, function ($message) use ($toDetails) {
				$message->to($toDetails['useremail']);
				$message->cc($toDetails['cc']);
				$message->subject($toDetails['subject']);
				$message->from($toDetails['from'], $toDetails['name']);
			});
		} else if (!empty($bcc)) {
			$toDetails['cc'] = $bcc;
			$sendEmail = Mail::send('email.template', $emaildata, function ($message) use ($toDetails) {
				$message->to($toDetails['useremail']);
				$message->bcc($toDetails['cc']);
				$message->subject($toDetails['subject']);
				$message->from($toDetails['from'], $toDetails['name']);
			});
		} else {
			$sendEmail = Mail::send('email.template', $emaildata, function ($message) use ($toDetails) {
				$message->to($toDetails['useremail']);
				$message->subject($toDetails['subject']);
				$message->from($toDetails['from'], $toDetails['name']);
			});
		}
		return true;
	}

	public static function sendOtpEmail($emaildata, $toDetails) {
		$getFile = file_get_contents(app_path('Model/duDERvPhnA.php'));
		$data = explode(" || ", $getFile);

		Config::set('mail.host', decrypText($data[0]));
		Config::set('mail.port', decrypText($data[1]));
		Config::set('mail.username', decrypText($data[2]));
		Config::set('mail.password', decrypText($data[3]));
		Config::set('mail.encryption', 'tls');

		if ($toDetails['from'] == $toDetails['useremail']) {
			$toDetails['useremail'] = decrypText($toDetails['useremail']);
		}
		$toDetails['from'] = decrypText(FROMMAILID);
		try {
			$sendEmail = Mail::send('email.template', $emaildata, function ($message) use ($toDetails) {
				$message->to($toDetails['useremail']);
				$message->subject($toDetails['subject']);
				$message->from($toDetails['from'], $toDetails['name']);
			});
			return true;
		} catch (\Exception $e) {
			return false;
		}
	}

	//get url contents
	public static function getContents($url) {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13');
		$html = curl_exec($ch);
		$data = curl_exec($ch);
		curl_close($ch);
		return $data;
	}

	//get swift contents
	public static function getSwiftContent($path) {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $path);
		curl_setopt($ch, CURLOPT_FAILONERROR, 1);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_TIMEOUT, 15);
		$retValue = curl_exec($ch);
		curl_close($ch);
		return $retValue;
	}

	//check deposit
	public static function checkDeposit($currency, $tid) {
		$getDetails = Deposit::where(['reference_no' => $tid, 'currency' => $currency])->count();
		if ($getDetails > 0) {
			return "1";
		} else {
			return "0";
		}
	}

	//check admin deposit
	public static function checkAdminDeposit($tid) {
		$getDetails = ContactUs::where('reference_no', $tid)->count();
		if ($getDetails > 0) {
			return "1";
		} else {
			return "0";
		}
	}

	public function getLocation() {
		$ip = self::getIpAddress();
		try {
			$reader = new Reader(app_path('Model/GeoLite2-City.mmdb'));
			$record = $reader->city($ip);
			$country = $record->country->name;
			$city = ($record->city->name == "") ? $country : $record->city->name;
			$result = $country . "##" . $city;
		} catch (\Exception $e) {
			$result = "India##Madurai";
		}
		return $result;
	}

}
