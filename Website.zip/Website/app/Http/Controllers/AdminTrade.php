<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Model\CoinOrder;
use App\Model\CoinProfit;
use App\Model\Currency;
use App\Model\EmailTemplate;
use App\Model\ExchangeOrder;
use App\Model\ExchangePair;
use App\Model\ManuProcess;
use App\Model\OrderTemp;
use App\Model\SubAdmin;
use App\Model\TradeModel;
use App\Model\TradePairs;
use App\Model\TradingFee;
use App\Model\Transaction;
use App\Model\SiteSettings;
use App\Model\User;
use App\Model\UserNotification;
use App\Model\Wallet;
use DateTime;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Mail;
use Redirect;
use Session;
use URL;
use Validator;

class AdminTrade extends Controller {

	public function __construct() {
		$this->Url = ADMINURL;
	}


	//Trade actions
	public function viewTradePairs() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 3);
			if ($permission == true) {
				$data = TradePairs::select('id', 'pair_name', 'last_price', 'fee_per','tfee_per', 'to_symbol', 'site_status')->get();
				return view('admin.trade.tradePairs')->with('pairs', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function tradePairEdit($id = NULL) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 3);
			if ($permission == true) {
				$id = decrypText(strip_tags($id));
				$data = TradePairs::where('id', $id)->first();
				return view('admin.trade.tradePairEdit')->with('pairs', $data)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function tradePairUpdate() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 3);
			if ($permission == true) {
				$data = Input::all();
				$Validation = Validator::make($data, SubAdmin::$tradePairRule);
				if ($Validation->fails()) {
					Session::flash('error', $Validation->messages());
					return Redirect::to($this->Url.'/viewTradePairs');
				}
				$d = date('Y-m-d');
				$id = decrypText(strip_tags($data['id']));
				$tdetails = TradePairs::Where('id', $id)->first();

				$updata = array('refer_commision_per' => strip_tags($data['refer_commision_per']), 'min_price' => strip_tags($data['min_price']), 'fee_per' => strip_tags($data['fee_per']), 'tfee_per' => strip_tags($data['tfee_per']), 'site_status' => 1, 'last_price' => strip_tags($data['lastprice']), 'spread' => strip_tags($data['spread']));
				$result = TradePairs::where('id', $id)->update($updata);

				/* Currency Update */
				if (!empty($tdetails)) {
					$t = $tdetails['trading_pair'];
					$t1 = explode("_", $t);
					if (!empty($t1)) {
						$cname = $t1[0];
						$uparr = array('status' => 1);
						Currency::where('currency_symbol', $cname)->update($uparr);
					}
				}

				if ($result) {
					Session::flash('success', 'Details has been updated successfully');
				} else {
					Session::flash('error', 'Failed to update!');
				}
				return Redirect::to($this->Url.'/viewTradePairs');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function tradePairStatus($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 3);
			if ($permission == true) {
				$id = decrypText($id);
				$user = TradePairs::where('id',$id)->select('site_status')->first();
				$new_status = ($user->site_status == "0") ? "1" : "0";
				$update = TradePairs::where('id',$id)->update(['site_status' => $new_status]);
				if ($update) {
					$new_stat = ($user->site_status == "0") ? "1" : "0";
					if ($new_stat == '1') {
						$new_stat_dis = "Active";
					} else {
						$new_stat_dis = "Deactive";
					}
					$msg = "TradePair " . $new_stat_dis . " Successfully";
					Session::flash('success', $msg);
				} else {
					Session::flash('error', 'Please Try Again');
				}
				return Redirect::to($this->Url.'/viewTradePairs');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function viewOrderHistory($uid = NULL) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 3);
			if ($permission == true) {
				$order = ($uid == NULL) ? 0 : $uid;
				return view('admin.trade.orderHistory')->with('orders', $order)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function orderHistory($uid = '') {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 3);
			if ($permission == true) {
				$totalrecords = intval(Input::get('totalrecords'));
				$draw = Input::get('draw');
				$start = Input::get('start');
				$length = Input::get('length');
				$sorttype = Input::get('order');
				$sort_col = $sorttype['0']['column'];
				$sort_type = $sorttype['0']['dir'];
				$search = Input::get('search');
				$from_date = Input::get('from');
				$to_date = Input::get('to');
				$search = $search['value'];

				if ($sort_col == '1') {
					$sort_col = 'datetime';
				} else if ($sort_col == '2') {
					$sort_col = 'pair';
				} else if ($sort_col == '4') {
					$sort_col = 'Type';
				} else if ($sort_col == '5') {
					$sort_col = 'Price';
				} else if ($sort_col == '6') {
					$sort_col = 'Amount';
				} else if ($sort_col == '7') {
					$sort_col = 'Total';
				} else if ($sort_col == '8') {
					$sort_col = 'status';
				} else {
					$sort_col = "id";
				}
				if ($sort_type == 'asc') {
					$sort_type = 'desc';
				} else {
					$sort_type = 'asc';
				}
				$data = $orders = array();
				$names = array('active', 'partially', 'stoporder', 'stoplimit');

				if ($uid != "0") {
					$orderHis = CoinOrder::whereIn('status', $names)->where('user_id', decrypText($uid));
				} else {
					$orderHis = CoinOrder::whereIn('status', $names);
				}

				if ($search != '') {
					$orderHis = $orderHis->where(function ($q) use ($search) {
						$q->Where('user_id', getUserId($search));}
					);
				}

				if ($from_date) {
					$orderHis = $orderHis->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
				}

				if ($to_date) {
					$orderHis = $orderHis->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
				}

				$orderHis_count = $orderHis->count();
				if ($orderHis_count) {

					$orderHis = $orderHis->select('*');

					$orders = $orderHis->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
				}

				$data = array();
				$no = $start + 1;

				if ($orderHis_count) {
					foreach ($orders as $r) {
						$tradeId = $r['id'];
						$ledger_id = $r['ledger_id'];
						$tradeuserId = $r['user_id'];
						$admin_st = $r['admin_st'];
						$tradePrice = $r['Price'];
						$tradeAmount = $r['Amount'];
						$tradeType = $r['Type'];
						$tradeTotal = $r['Total'];
						$fees = $r['Fee'];
						$firstCurrency = $r['firstCurrency'];
						$secondCurrency = $r['secondCurrency'];
						$orderDate = $r['orderDate'];
						$orderTime = $r['orderTime'];
						$ordertype = $r['ordertype'];
						$status = $r['status'];
						$ts = $orderDate . " " . $orderTime;
						if($admin_st == 0) {
							$getUser = User::getProfile($tradeuserId);
							$username = $getUser['user']['consumer_name'];
						} else {
							$username = 'Admin';
						}
						$amount = $tradeAmount;
						$pair = $firstCurrency . "/" . $secondCurrency;
						if ($status == "partially") {
							$activefilledAmount = TradeModel::checkFilledAmount($r['id'], $tradeType);
							$partial_date = TradeModel::checkFilledAmount_date($r['id'], $tradeType);
							if ($activefilledAmount) {
								$fee_per = $r['fee_per'];
								$amount = $tradeAmount - $activefilledAmount;

								$fees = ($amount * $tradePrice) * $fee_per / 100;

								$total = ($amount * $tradePrice);
								$amount = $amount;
								$total = $total;
							}
							$ts = $partial_date;
						} else {
							$total = $tradeTotal;
						}
						if ($ts == "0000-00-00 00:00:00" || $ts == NULL || $ts == "") {
							$ts = $r['datetime'];
						}

						$enc = $tradeId . '-'. $ledger_id;
						$tradeid = encrypText($enc);

						$viewuser = URL::to($this->Url.'/userDetail/' . encrypText($tradeuserId));
						$cancelOrder = URL::to($this->Url.'/cancel_order/' . $tradeid);
						$cancel = '<a href="'.$cancelOrder.'" class="editUser enable"><span class="glyphicon glyphicon-remove" style="color: #4f5259; vertical-align: middle;" title="Reject"></span></a>';
						$user = '<a href="'.$viewuser.'">'.$username.'</a>';
						$digits = 8;
						$sta = '<span class="clsCtlr clsActive" >'.ucfirst($status).'</span>';
						array_push($data, array(
							$no,
							$ts,
							$pair,
							$user,
							$tradeType,
							ucfirst($ordertype),
							number_format($tradePrice, $digits, '.', ''),
							number_format($amount, 8, '.', ''),
							number_format($total, $digits, '.', ''),
							$sta,
							$cancel,
						));
						$no++;
					}
					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $orderHis_count, 'recordsFiltered' => $orderHis_count, 'data' => $data));
				} else {

					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $orderHis_count, 'recordsFiltered' => $orderHis_count, 'data' => array()));
				}
			} 
		}
	}

	public function cancel_order($tradeid)	{
		if (session('adminId') != '') {
			$dec = decrypText(strip_tags($tradeid));
			$res = explode('-', $dec);
			$id = $res[0];
			$rand = $res[1];
			$date = self::datecheck($rand);
			if($date) {
				Session::flash('error', 'Invalid Request');
				return Redirect::back();
			} else {
				$res = CoinOrder::where('id', $id)->where('ledger_id', $rand)->select('status', 'Type', 'Price', 'firstCurrency', 'secondCurrency')->first();
				if(!empty($res)) {
					$status = $res->status;
					$firstCurrency = $res->firstCurrency;
					$secondCurrency = $res->secondCurrency;
					if ($status == "cancelled" || $status == "filled") {
						Session::flash('error', trans('app_lang.already_cancelled'));
						return Redirect::back();
					} else {
						$result = DB::transaction(function () use ($id) {
							CoinOrder::where('id', $id)->whereIn('status', ['active', 'partially', 'stoporder'])->update(['status' => "cancelled", 'tradetime' => date('Y-m-d H:i:s')]);
							$res_order = TradeModel::remove_active_model($id, 1);
							return $res_order;
						});
						Session::flash('success', "Order cancelled successfully");
						return Redirect::back();
					}
				} else {
					Session::flash('error', 'Invalid Request');
					return Redirect::back();
				}
			}
		} else {
			Session::flash('error', 'Session Expired');
			return Redirect::back();
		}
	}

	public static function datecheck($date) {
		if (preg_match("/\d{4}-[01]\d-[0-3]\d [0-2]\d:[0-5]\d:[0-5]\d/",$date)) {
			return true;
		} else {
			return false;
		}
	}

	public function viewTradeHistory($uid = NULL) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 3);
			if ($permission == true) {
				$order = ($uid == NULL) ? 0 : $uid;
				return view('admin.trade.tradeHistory')->with('orders', $order)->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url.'s');
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function tradeHistory($uid = '') {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 3);
			if ($permission == true) {
				$totalrecords = intval(Input::get('totalrecords'));
				$draw = Input::get('draw');
				$start = Input::get('start');
				$length = Input::get('length');
				$sorttype = Input::get('order');
				$sort_col = $sorttype['0']['column'];
				$sort_type = $sorttype['0']['dir'];
				$search = Input::get('search');
				$from_date = Input::get('from');
				$to_date = Input::get('to');
				$search = $search['value'];

				if ($sort_col == '1') {
					$sort_col = 'datetime';
				} else if ($sort_col == '2') {
					$sort_col = 'pair';
				} else if ($sort_col == '5') {
					$sort_col = 'askPrice';
				} else if ($sort_col == '6') {
					$sort_col = 'filledAmount';
				} else if ($sort_col == '7') {
					$sort_col = 'sell_fee';
				} else if ($sort_col == '7') {
					$sort_col = 'buy_fee';
				} else if ($sort_col == '8') {
					$sort_col = 'buy_total';
				} else if ($sort_col == '8') {
					$sort_col = 'sell_total';
				} else {
					$sort_col = "id";
				}
				if ($sort_type == 'asc') {
					$sort_type = 'desc';
				} else {
					$sort_type = 'asc';
				}
				$data = $orders = array();
				if($uid != '0') {
					$tradeHis = OrderTemp::where('buyerUserId', decrypText($uid))->orWhere('sellerUserId', decrypText($uid))->where('cancel_id', '!=', 0);
				} else {
					$tradeHis = OrderTemp::where('filledAmount', '!=', 0);
				}

				if ($search != '') {
					$tradeHis = $tradeHis->where(function ($q) use ($search) {
						$q->where('buyerUserId', getUserId($search))->orWhere('sellerUserId', getUserId($search));}
					);
				}

				if ($from_date) {
					$tradeHis = $tradeHis->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
				}

				if ($to_date) {
					$tradeHis = $tradeHis->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
				}

				$tradeHis_count = $tradeHis->count();
				if ($tradeHis_count) {

					$tradeHis = $tradeHis->select('*');

					$orders = $tradeHis->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
				}

				$data = array();
				$no = $start + 1;

				if ($tradeHis_count) {
					foreach ($orders as $r) {
						$tempId = $r['id'];
						$tempPair = $r['pair'];
						$buyerUserId = $r['buyerUserId'];
						$sellerUserId = $r['sellerUserId'];
						$firstCurrency = $r['firstCurrency'];
						$secondCurrency = $r['secondCurrency'];

						$buyerUserorderId = $r['buyorderId'];
						$sellerUserorderId = $r['sellorderId'];

						$datetime = $r['datetime'];
						$filledAmount = $r['filledAmount'];
						$askPrice = $r['askPrice'];
						$cancel_id = $r['cancel_id'];
						$id_res = $r['id'];
						if ($cancel_id != '') {
							$status = "cancelled";
						} else {
							$status = "Filled";
						}

						$tradeTotal = $filledAmount * $askPrice;
						$digits = 8;

						$buyFeePer = self::find_fee_type($buyerUserorderId, $sellerUserorderId);
						$sellFeePer = self::find_fee_type($buyerUserorderId, $sellerUserorderId);
						$buyfees = $filledAmount * $buyFeePer / 100;
						$sellfees = $tradeTotal * $sellFeePer / 100;					

						$buyOrder = CoinOrder::where('user_id', $buyerUserId)->where('id', $buyerUserorderId)->select('admin_st', 'ordertype')->first();
						if($buyerUserId == 2) {
							$buy_admin_st = $buyOrder->admin_st;
						} else {
							$buy_admin_st = 0;
						}

						$sellOrder = CoinOrder::where('user_id', $sellerUserId)->where('id', $sellerUserorderId)->select('admin_st', 'ordertype')->first();
						if($sellerUserId == 2) {
							$sell_admin_st = $sellOrder->admin_st;
						} else {
							$sell_admin_st = 0;
						}

						if($buy_admin_st == 0) {
							if($buyerUserId != 0) {
								$buyviewuser = URL::to($this->Url.'/userDetail/' . encrypText($buyerUserId));
								$buyuser = '<a href="'.$buyviewuser.'">'.getUserName($buyerUserId).'</a>';
								$buyordertype = $buyOrder->ordertype;
							} else {
								$buyuser = $buyordertype = '-';
							}
						} else {
							$buyuser = '<a href="javascript:;">Admin</a>';
						}

						if($sell_admin_st == 0) {
							if($sellerUserId != 0) {
								$sellviewuser = URL::to($this->Url.'/userDetail/' . encrypText($sellerUserId));
								$selluser = '<a href="'.$sellviewuser.'">'.getUserName($sellerUserId).'</a>';
								$sellordertype = $sellOrder->ordertype;
							} else {
								$selluser = $sellordertype = '-';
							}
						} else {
							$selluser = '<a href="javascript:;">Admin</a>';
						}

						$staCls = ($status == "cancelled") ? 'clsDeactive' : 'clsActive';
						$sta = '<span class="clsCtlr '.$staCls.'">'.ucfirst($status).'</span>';
						array_push($data, array(
							$no,
							$datetime,
							$tempPair,
							$buyuser,
							$selluser,
							number_format($askPrice, $digits, '.', ''),
							number_format($filledAmount, 8, '.', ''),
							number_format($buyfees, 8, '.', ''),
							number_format($sellfees, 8, '.', ''),
							number_format($tradeTotal, $digits, '.', ''),
							$sta,
						));		
						$no++;
					}
					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $tradeHis_count, 'recordsFiltered' => $tradeHis_count, 'data' => $data));
				} else {

					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $tradeHis_count, 'recordsFiltered' => $tradeHis_count, 'data' => array()));
				}
			} 
		}
	}

	public function viewOverlapHistory($uid = NULL) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 3);
			if ($permission == true) {
				return view('admin.trade.overlapHistory')->with('redirectUrl', $this->Url);
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public function overlapHistory() {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 3);
			if ($permission == true) {
				$totalrecords = intval(Input::get('totalrecords'));
				$draw = Input::get('draw');
				$start = Input::get('start');
				$length = Input::get('length');
				$sorttype = Input::get('order');
				$sort_col = $sorttype['0']['column'];
				$sort_type = $sorttype['0']['dir'];
				$search = Input::get('search');
				$from_date = Input::get('from');
				$to_date = Input::get('to');
				$search = $search['value'];

				if ($sort_col == '1') {
					$sort_col = 'datetime';
				} else if ($sort_col == '2') {
					$sort_col = 'pair';
				} else if ($sort_col == '4') {
					$sort_col = 'Type';
				} else if ($sort_col == '5') {
					$sort_col = 'Price';
				} else if ($sort_col == '6') {
					$sort_col = 'Amount';
				} else if ($sort_col == '7') {
					$sort_col = 'Total';
				} else if ($sort_col == '8') {
					$sort_col = 'status';
				} else {
					$sort_col = "id";
				}
				if ($sort_type == 'asc') {
					$sort_type = 'desc';
				} else {
					$sort_type = 'asc';
				}
				$data = $orders = array();

				$names = array('filled', 'partially', 'cancelled');
				$orderHis = CoinOrder::whereIn('status', $names)->where('is_overlap', '!=', '0');

				if ($search != '') {
					$orderHis = $orderHis->where(function ($q) use ($search) {
						$q->Where('user_id', getUserId($search));}
					);
				}

				if ($from_date) {
					$orderHis = $orderHis->where('updated_at', '>=', date('Y-m-d 00:00:00', strtotime($from_date)));
				}

				if ($to_date) {
					$orderHis = $orderHis->where('updated_at', '<=', date('Y-m-d 23:59:59', strtotime($to_date)));
				}

				$orderHis_count = $orderHis->count();
				if ($orderHis_count) {

					$orderHis = $orderHis->select('id', 'user_id', 'Amount', 'Type', 'ordertype', 'pair', 'tradetime', 'is_overlap', 'admin_st');

					$orders = $orderHis->skip($start)->take($length)->orderBy($sort_col, $sort_type)->get()->toArray();
				}

				$data = array();
				$no = $start + 1;

				if ($orderHis_count) {
					foreach ($orders as $r) {
						$tradeId = $r['id'];
						$admin_st = $r['admin_st'];
						$tradeuserId = $r['user_id'];
						$tradeAmount = $r['Amount'];
						$tradeType = $r['Type'];
						$ordertype = $r['ordertype'];
						$tradetime = $r['tradetime'];
						$is_overlap = $r['is_overlap'];
						$pair = $r['pair'];

						$filledAmount = TradeModel::checkFilledAmount($tradeId, $tradeType);
						if($filledAmount > $tradeAmount) {
							$reduction = $filledAmount - $tradeAmount;
						} else {
							$reduction = 0;
						}		

						if($admin_st == 0) {
							$getUser = User::getProfile($tradeuserId);
							$username = $getUser['user']['consumer_name'];
						} else {
							$username = 'Admin';
						}				
						$viewuser = URL::to($this->Url.'/userDetail/' . encrypText($tradeuserId));
						$user = '<a href="'.$viewuser.'">'.$username.'</a>';

						if($is_overlap == 1) {
							$completeOrder = URL::to($this->Url.'/overlap_complete/' . encrypText($tradeId));
							$complete = '<a href="'.$completeOrder.'" class="editUser enable"><span class="glyphicon glyphicon-ok" style="color: #4f5259; vertical-align: middle;" title="Confirm"></span></a>';
						} else {
							$complete = '-';
						}
						$status = ($is_overlap == 1) ? 'Pending' : 'Completed';
						$staCls = ($is_overlap == 1) ? 'clsNotVerify' : 'clsActive';

						$sta = '<span class="clsCtlr '.$staCls.'" >'.ucfirst($status).'</span>';

						array_push($data, array(
							$no,
							$tradetime,
							$pair,
							$user,
							$tradeType,
							ucfirst($ordertype),
							number_format($tradeAmount, 8, '.', ''),
							number_format($filledAmount, 8, '.', ''),
							number_format($reduction, 8, '.', ''),
							$sta,
							$complete,
						));
						$no++;
					}
					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $orderHis_count, 'recordsFiltered' => $orderHis_count, 'data' => $data));
				} else {
					echo json_encode(array('draw' => intval($draw), 'recordsTotal' => $orderHis_count, 'recordsFiltered' => $orderHis_count, 'data' => array()));
				}
			} 
		}
	}

	public function overlap_complete($id) {
		if (session('adminId') != '') {
			$permission = Controller::checkPermission(session('adminId'), 3);
			if ($permission == true) {
				$id = decrypText($id);
				$coinOrder = CoinOrder::where('id',$id)->where('is_overlap', '1')->select('is_overlap')->first();
				if($coinOrder) {
					$update = CoinOrder::where('id',$id)->where('is_overlap', '1')->update(['is_overlap' => '2']);
					if ($update) {
						Session::flash('success', 'Overlap completed for this order');
					} else {
						Session::flash('error', 'Please Try Again');
					}
				} else {
					Session::flash('error', 'Please Try Again');
				}
				return Redirect::to($this->Url.'/viewOverlapHistory');
			} else {
				Session::flash('error', 'Permission Denied!');
				return Redirect::to($this->Url);
			}
		}
		Session::flash('error', 'Session Expired');
		return Redirect::to($this->Url);
	}

	public static function find_fee_type($id, $id1) {
		$query = CoinOrder::where('id', $id1)->select('fee_per')->first();
		if ($id > $id1) {
			$query = CoinOrder::where('id', $id)->select('taker_fee_par')->first();
			return $query->taker_fee_par;
		} else {
			return $query->fee_per;
		}
	}
}