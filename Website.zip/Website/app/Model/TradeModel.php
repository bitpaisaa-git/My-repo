<?php

namespace App\Model;

use DB;
use URL;
use App\Model\AdminOrderTemp;
use App\Model\Wallet;
use Illuminate\Database\Eloquent\Model;

class TradeModel extends Model {

	public static function fetchuserbalancebyId($id, $currency) {
		return Wallet::where('user_id', $id)->select($currency)->first()->$currency;
	}

	//mapping
	public static function mapping($lastId, $lastPrice, $socket = '') {
		$tenPer = ($lastPrice * 10) / 100;
		$maxPrice = $lastPrice + $tenPer;
		$minPrice = $lastPrice - $tenPer;
		$orderArr = array();
		$order = CoinOrder::where('id', $lastId)->whereIn('status', ['active', 'partially'])->select('user_id', 'Price', 'Amount', 'Fee', 'status', 'Type', 'Total', 'ordertype', 'fee_per', 'firstCurrency', 'secondCurrency', 'pair', 'liquidity_order')->first();
		if ($order) {
			$orderId = $lastId;
			$userId = $order->user_id;
			$Price = $order->Price;
			$Amount = $order->Amount;
			$Fee = $order->Fee;
			$FeePer = $order->fee_per;
			$Status = $order->status;
			$Total = $order->Total;
			$orderType = $order->ordertype;
			$Type = $order->Type;
			$firstCurr = $order->firstCurrency;
			$secondCurr = $order->secondCurrency;
			$pair = $order->pair;
			$liquidity_order = $order->liquidity_order;
			if ($Type == 'Buy') {
				$getSellOrders = self::getSellOrders($Price, $userId, $firstCurr, $secondCurr, $liquidity_order);
				if ($getSellOrders) {
					foreach ($getSellOrders as $sell) {
						$sellorderId = $sell->id;
						$selluserId = $sell->user_id;
						$sellPrice = $sell->Price;
						$sellAmount = $sell->Amount;
						$sellfirstCurrency = $firstCurr;
						$sellsecondCurrency = $secondCurr;
						$sellFee = $sell->Fee;
						$sellFeePer = $sell->fee_per;
						$sellTotal = $sell->Total;
						$sellFilled = ($sell->filledAmount == "") ? 0 : $sell->filledAmount;
						$approxiAmount = $sellAmount - $sellFilled;
						$approxiAmount = number_format($approxiAmount, 8, '.', '');
						$buySumamount = self::checkFilledAmount($orderId, 'Buy');
						if ($buySumamount) {
							$buySumamount = $Amount - $buySumamount;
							$buySumamount = number_format($buySumamount, 8, '.', '');
						} else {
							$buySumamount = $Amount;
						}
						$amount = (trim($approxiAmount) >= trim($buySumamount)) ? $buySumamount : $approxiAmount;
						if (trim($approxiAmount) > 0 && trim($amount) > 0) {
							if (trim($buySumamount) > 0) {
								$inserted = self::insertTempData($sellorderId, $selluserId, $sellAmount, $sellPrice, $amount, $orderId, $userId, $firstCurr, $secondCurr, $FeePer, $sellFeePer);
								if ($inserted) {
									$pairData['last_price'] = $sellPrice;
									if ($sellPrice <= $minPrice) {
										$pairData['change_status'] = 1;
										$pairData['change_symbol'] = '-';
										$pairData['change_key'] = SITENAME . rand() . time();
									} else if ($sellPrice >= $maxPrice) {
										$pairData['change_status'] = 1;
										$pairData['change_symbol'] = '+';
										$pairData['change_key'] = SITENAME . rand() . time();
									} else {
										$pairData['change_status'] = 0;
									}
									TradePairs::where('from_symbol', $firstCurr)->where('to_symbol', $secondCurr)->update($pairData);

									array_push($orderArr, encrypText($inserted));
									$orderArr['price'][] = str_replace('.', '_', $sellPrice);
									if (trim($Price) > trim($sellPrice)) {
										$theftprice = ($amount * $Price) - ($amount * $sellPrice);
										self::returnBal($theftprice, $userId, $secondCurr, $FeePer, $firstCurr);
									}
										//update sell
									if (trim($approxiAmount) == trim($amount)) {
										self::updateOrder($sellorderId, $orderId, $inserted, "Sell", $sellfirstCurrency, $sellsecondCurrency, $selluserId, $amount, $sellPrice, $sellFeePer, "filled");
										$msg1 = "Your sell order of " . $amount . " " . $sellfirstCurrency . " has been traded successfully";
									} else {
										self::updateOrder($sellorderId, $orderId, $inserted, "Sell", $sellfirstCurrency, $sellsecondCurrency, $selluserId, $amount, $sellPrice, $sellFeePer, "partially");
										$msg1 = "Your sell order of " . $amount . " " . $sellfirstCurrency . " has been traded partially";
									}
									
									//update buy
									if (trim($approxiAmount) >= trim($buySumamount)) {
										self::updateOrder($orderId, $sellorderId, $inserted, "Buy", $firstCurr, $secondCurr, $userId, $amount, $sellPrice, $FeePer, "filled");
										$msg2 = "Your buy order of " . $amount . " " . $firstCurr . " has been traded successfully";
									} else {
										self::updateOrder($orderId, $sellorderId, $inserted, "Buy", $firstCurr, $secondCurr, $userId, $amount, $sellPrice, $FeePer, "partially");
										$msg2 = "Your buy order of " . $amount . " " . $firstCurr . " has been traded partially";
									}

									if($socket != '') {
										$trigger['trigger_id'] =	encrypText($userId);
										$trigger['pair'] =	$pair;
										trigger_socket($trigger,'emitOrder');
									}
									self::checkStopOrder($firstCurr, $secondCurr, $sellPrice);
								}
							} else {
								break;
							}
						}
					}
				} 		
			} else if ($Type == 'Sell') {
				$getBuyOrders = self::getBuyOrders($Price, $userId, $firstCurr, $secondCurr, $liquidity_order);
				if ($getBuyOrders) {
					foreach ($getBuyOrders as $buy) {
						$buyorderId = $buy->id;
						$buyuserId = $buy->user_id;
						$buyPrice = $buy->Price;
						$buyAmount = $buy->Amount;
						$buyfirstCurrency = $firstCurr;
						$buysecondCurrency = $secondCurr;
						$buyFee = $buy->Fee;
						$buyFeePer = $buy->fee_per;
						$buyTotal = $buy->Total;
						$buyFilled = ($buy->filledAmount == "") ? 0 : $buy->filledAmount;
						$approxiAmount = $buyAmount - $buyFilled;
						$approxiAmount = number_format($approxiAmount, 8, '.', '');
						$sellSumamount = self::checkFilledAmount($orderId, 'Sell');
						if ($sellSumamount) {
							$sellSumamount = $Amount - $sellSumamount;
							$sellSumamount = number_format($sellSumamount, 8, '.', '');
						} else {
							$sellSumamount = $Amount;
						}
						$amount = (trim($approxiAmount) >= trim($sellSumamount)) ? $sellSumamount : $approxiAmount;
						if (trim($approxiAmount) > 0 && trim($amount) > 0) {
							if (trim($sellSumamount) > 0) {
								$inserted = self::insertTempData($orderId, $userId, $Amount, $buyPrice, $amount, $buyorderId, $buyuserId, $firstCurr, $secondCurr, $buyFeePer, $FeePer);
								if ($inserted) {
									$pairData['last_price'] = $buyPrice;
									if ($Price <= $minPrice) {
										$pairData['change_status'] = 1;
										$pairData['change_symbol'] = '-';
										$pairData['change_key'] = SITENAME . rand() . time();
									} else if ($Price >= $maxPrice) {
										$pairData['change_status'] = 1;
										$pairData['change_symbol'] = '+';
										$pairData['change_key'] = SITENAME . rand() . time();
									} else {
										$pairData['change_status'] = 0;
									}
									TradePairs::where('from_symbol', $firstCurr)->where('to_symbol', $secondCurr)->update($pairData);

									array_push($orderArr, encrypText($inserted));
									$orderArr['price'][] = str_replace('.', '_', $Price);
									if (trim($buyPrice) > trim($Price)) {
										$theftprice = ($amount * $buyPrice) - ($amount * $Price);
										self::returnBal($theftprice, $buyuserId, $secondCurr, $buyFeePer, $firstCurr);
									}
									
									//update sell
									if (trim($approxiAmount) == trim($amount)) {
										self::updateOrder($buyorderId, $orderId, $inserted, "Buy", $buyfirstCurrency, $buysecondCurrency, $buyuserId, $amount, $buyPrice, $buyFeePer, "filled");
										$msg1 = "Your buy order of " . $amount . " " . $buyfirstCurrency . " has been traded successfully";
									} else {
										self::updateOrder($buyorderId, $orderId, $inserted, "Buy", $buyfirstCurrency, $buysecondCurrency, $buyuserId, $amount, $buyPrice, $buyFeePer, "partially");
										$msg1 = "Your buy order of " . $amount . " " . $buyfirstCurrency . " has been traded partially";
									}
									
									//update buy
									if (trim($approxiAmount) >= trim($sellSumamount)) {
										self::updateOrder($orderId, $buyorderId, $inserted, "Sell", $firstCurr, $secondCurr, $userId, $amount, $buyPrice, $FeePer, "filled");
										$msg2 = "Your sell order of " . $amount . " " . $firstCurr . " has been traded successfully";
									} else {
										self::updateOrder($orderId, $buyorderId, $inserted, "Sell", $firstCurr, $secondCurr, $userId, $amount, $buyPrice, $FeePer, "partially");
										$msg2 = "Your sell order of " . $amount . " " . $firstCurr . " has been traded partially";
									}

									if($socket != '') {
										$trigger['trigger_id'] =	encrypText($userId);
										$trigger['pair'] =	$pair;
										trigger_socket($trigger,'emitOrder');
									}
									self::checkStopOrder($firstCurr, $secondCurr, $buyPrice);
								}
							} else {
								break;
							}
						}
					}
				} 			
			}
		}
		return $orderArr;
	}

	//market order mapping
	public static function marketMapping($lastId, $lastPrice) {
		$tenPer = ($lastPrice * 10) / 100;
		$maxPrice = $lastPrice + $tenPer;
		$minPrice = $lastPrice - $tenPer;
		$orderArr = array();
		$order = CoinOrder::where('id', $lastId)->where('status', 'market')->select('user_id', 'Price', 'Amount', 'Fee', 'status', 'Type', 'Total', 'ordertype', 'fee_per', 'firstCurrency', 'secondCurrency', 'pair', 'liquidity_order')->first();
		if ($order) {
			$orderId = $lastId;
			$userId = $order->user_id;
			$Price = $order->Price;
			$Amount = $order->Amount;
			$Fee = $order->Fee;
			$FeePer = $order->fee_per;
			$Status = $order->status;
			$Total = $order->Total;
			$orderType = $order->ordertype;
			$Type = $order->Type;
			$firstCurr = $order->firstCurrency;
			$secondCurr = $order->secondCurrency;
			$pair = $order->pair;
			$liquidity_order = $order->liquidity_order;
			$tradeFirstCurr = $firstCurr;
			$tradeSecondCur = $secondCurr;
			if ($Type == 'Buy') {
				$sellTradePrice = 0;
				$getSellOrders = self::getMarketSellOrders($userId, $firstCurr, $secondCurr, $liquidity_order);
				if ($getSellOrders) {
					foreach ($getSellOrders as $sell) {
						$sellorderId = $sell->id;
						$selluserId = $sell->user_id;
						$sellPrice = $sell->Price;
						$sellAmount = $sell->Amount;
						$sellfirstCurrency = $firstCurr;
						$sellsecondCurrency = $secondCurr;
						$sellFee = $sell->Fee;
						$sellFeePer = $sell->fee_per;
						$sellTotal = $sell->Total;
						$sellFilled = ($sell->filledAmount == "") ? 0 : $sell->filledAmount;
						$approxiAmount = $sellAmount - $sellFilled;
						$approxiAmount = number_format($approxiAmount, 8, '.', '');
						$buySumamount = $checkBuyTemp = self::checkFilledAmount($orderId, 'Buy');
						if ($buySumamount) {
							$buyFilled = $buySumamount;
							$buySumamount = $Amount - $buySumamount;
							if ($buySumamount <= 0) {CoinOrder::where('id', $lastId)->update(['status' => 'filled', 'Amount' => $buyFilled]);return $orderArr;}
						} else {
							$buyFilled = 0;
							$buySumamount = $Amount;
						}
						$buySumamount = number_format($buySumamount, 8, '.', '');
						$amount = (trim($approxiAmount) >= trim($buySumamount)) ? $buySumamount : $approxiAmount;

						$sBalance = self::fetchuserbalancebyId($userId, $tradeSecondCur);
						$sellTotal = $amount * $sellPrice;
						$tradeFee = 0;
						$marketTotal = $sellTotal;
						if ($sBalance < $marketTotal) {
							if ($sBalance > 0) {
								$calFee = $sBalance * $FeePer / 100;
								$checkBal = $sBalance - $calFee;
								$minAmt = TradePairs::where('from_symbol', $firstCurr)->where('to_symbol', $secondCurr)->select('min_price')->first()->min_price;
								$tradeFee = 0;
								$calAmount = $sBalance / $sellPrice;
								$finalAmount = $calAmount * $sellPrice;
								$calAmount = number_format($calAmount, 8, '.', '');
								$tradeFee = number_format($tradeFee, 8, '.', '');
								$finalAmount = number_format($finalAmount, 8, '.', '');
								if ($calAmount <= $minAmt) {
									if ($checkBuyTemp) {CoinOrder::where('id', $lastId)->update(['status' => 'filled', 'Amount' => $checkBuyTemp]);}return $orderArr;
								}
								$trdAmount = $calAmount + $buyFilled;
								$trdAmount = number_format($trdAmount, 8, '.', '');
								$updateCoinOrder = CoinOrder::where('id', $lastId)->update(['Price' => $sellPrice, 'Amount' => $trdAmount, 'Fee' => $tradeFee, 'Total' => $finalAmount, 'status' => 'active']);
								$remainBal = $sBalance - $finalAmount;
								$remarks = 'Buy market order placed for '. $finalAmount . ' ' . $tradeSecondCur . ' Old balance: '. $sBalance;
								Wallet::where('user_id', $userId)->update(array($tradeSecondCur => $remainBal, 'remarks' => $remarks));
								$normalMap = self::mapping($lastId, $sellPrice);
								$orderArr = array_merge($orderArr, $normalMap);
							}
							return $orderArr;
						} else {
							$remainBal = $sBalance - $marketTotal;
							$remarks = 'Buy market order placed for '. $marketTotal . ' ' . $tradeSecondCur . ' Old balance: '. $sBalance;
							Wallet::where('user_id', $userId)->update(array($tradeSecondCur => $remainBal, 'remarks' => $remarks));
						}
						if (trim($approxiAmount) > 0 && trim($amount) > 0) {
							if (trim($buySumamount) > 0) {
								$inserted = self::insertTempData($sellorderId, $selluserId, $sellAmount, $sellPrice, $amount, $orderId, $userId, $firstCurr, $secondCurr, $FeePer, $sellFeePer);
								if ($inserted) {
									$pairData['last_price'] = $sellPrice;
									if ($sellPrice <= $minPrice) {
										$pairData['change_status'] = 1;
										$pairData['change_symbol'] = '-';
										$pairData['change_key'] = SITENAME . rand() . time();
									} else if ($sellPrice >= $maxPrice) {
										$pairData['change_status'] = 1;
										$pairData['change_symbol'] = '+';
										$pairData['change_key'] = SITENAME . rand() . time();
									} else {
										$pairData['change_status'] = 0;
									}
									TradePairs::where('from_symbol', $firstCurr)->where('to_symbol', $secondCurr)->update($pairData);

									$sellTradePrice = $sellPrice;
									array_push($orderArr, encrypText($inserted));
									$orderArr['price'][] = str_replace('.', '_', $sellPrice);
									//update sell
									if (trim($approxiAmount) == trim($amount)) {
										self::updateOrder($sellorderId, $orderId, $inserted, "Sell", $sellfirstCurrency, $sellsecondCurrency, $selluserId, $amount, $sellPrice, $sellFeePer, "filled");
										$msg1 = "Your sell order of " . $amount . " " . $sellfirstCurrency . " has been traded successfully";
									} else {
										self::updateOrder($sellorderId, $orderId, $inserted, "Sell", $sellfirstCurrency, $sellsecondCurrency, $selluserId, $amount, $sellPrice, $sellFeePer, "partially");
										$msg1 = "Your sell order of " . $amount . " " . $sellfirstCurrency . " has been traded partially";
									}
									//update buy
									if (trim($approxiAmount) >= trim($buySumamount)) {
										self::updateOrder($orderId, $sellorderId, $inserted, "Buy", $firstCurr, $secondCurr, $userId, $amount, $sellPrice, $FeePer, "filled");
										$msg2 = "Your buy order of " . $amount . " " . $firstCurr . " has been traded successfully";
									} else {
										self::updateOrder($orderId, $sellorderId, $inserted, "Buy", $firstCurr, $secondCurr, $userId, $amount, $sellPrice, $FeePer, "partially");
										$msg2 = "Your buy order of " . $amount . " " . $firstCurr . " has been traded partially";
									}
								}
							} else {break;}
						}
					}
					if ($sellTradePrice > 0) {
						self::checkStopOrder($firstCurr, $secondCurr, $sellPrice);
					}
				}
			} else if ($Type == 'Sell') {
				$buyTradePrice = 0;
				$getBuyOrders = self::getMarketBuyOrders($userId, $firstCurr, $secondCurr, $liquidity_order);
				if ($getBuyOrders) {
					foreach ($getBuyOrders as $buy) {
						$buyorderId = $buy->id;
						$buyuserId = $buy->user_id;
						$buyPrice = $buy->Price;
						$buyAmount = $buy->Amount;
						$buyfirstCurrency = $firstCurr;
						$buysecondCurrency = $secondCurr;
						$buyFee = $buy->Fee;
						$buyFeePer = $buy->fee_per;
						$buyTotal = $buy->Total;
						$buyFilled = ($buy->filledAmount == "") ? 0 : $buy->filledAmount;
						$approxiAmount = $buyAmount - $buyFilled;
						$approxiAmount = number_format($approxiAmount, 8, '.', '');
						$sellSumamount = self::checkFilledAmount($orderId, 'Sell');
						if ($sellSumamount) {
							$sellSumamount = $Amount - $sellSumamount;
							if ($sellSumamount <= 0) {CoinOrder::where('id', $lastId)->update(['status' => 'filled']);return $orderArr;}
						} else {
							$sellSumamount = $Amount;
						}
						$sellSumamount = number_format($sellSumamount, 8, '.', '');
						$amount = (trim($approxiAmount) >= trim($sellSumamount)) ? $sellSumamount : $approxiAmount;

						$fBalance = self::fetchuserbalancebyId($userId, $tradeFirstCurr);
						if (trim($approxiAmount) < trim($sellSumamount)) {
							$remainBal = $fBalance - $approxiAmount;
							$remarks = 'Sell market order placed for '. $approxiAmount . ' ' . $tradeFirstCurr . ' Old balance: '. $fBalance;
							Wallet::where('user_id', $userId)->update(array($tradeFirstCurr => $remainBal, 'remarks' => $remarks));
						} else {
							$remainBal = $fBalance - $sellSumamount;
							$remarks = 'Sell market order placed for '. $sellSumamount . ' ' . $tradeFirstCurr . ' Old balance: '. $fBalance;
							Wallet::where('user_id', $userId)->update(array($tradeFirstCurr => $remainBal, 'remarks' => $remarks));
						}
						if (trim($approxiAmount) > 0 && trim($amount) > 0) {
							if (trim($sellSumamount) > 0) {
								$inserted = self::insertTempData($orderId, $userId, $Amount, $buyPrice, $amount, $buyorderId, $buyuserId, $firstCurr, $secondCurr, $buyFeePer, $FeePer);
								if ($inserted) {
									$pairData['last_price'] = $buyPrice;
									if ($buyPrice <= $minPrice) {
										$pairData['change_status'] = 1;
										$pairData['change_symbol'] = '-';
										$pairData['change_key'] = SITENAME . rand() . time();
									} else if ($buyPrice >= $maxPrice) {
										$pairData['change_status'] = 1;
										$pairData['change_symbol'] = '+';
										$pairData['change_key'] = SITENAME . rand() . time();
									} else {
										$pairData['change_status'] = 0;
									}
									TradePairs::where('from_symbol', $firstCurr)->where('to_symbol', $secondCurr)->update($pairData);

									$buyTradePrice = $buyPrice;
									array_push($orderArr, encrypText($inserted));
									$orderArr['price'][] = str_replace('.', '_', $buyPrice);
									//update sell
									if (trim($approxiAmount) == trim($amount)) {
										self::updateOrder($buyorderId, $orderId, $inserted, "Buy", $buyfirstCurrency, $buysecondCurrency, $buyuserId, $amount, $buyPrice, $buyFeePer, "filled");
										$msg1 = "Your buy order of " . $amount . " " . $buyfirstCurrency . " has been traded successfully";
									} else {
										self::updateOrder($buyorderId, $orderId, $inserted, "Buy", $buyfirstCurrency, $buysecondCurrency, $buyuserId, $amount, $buyPrice, $buyFeePer, "partially");
										$msg1 = "Your buy order of " . $amount . " " . $buyfirstCurrency . " has been traded partially";
									}
									//update buy
									if (trim($approxiAmount) >= trim($sellSumamount)) {
										self::updateOrder($orderId, $buyorderId, $inserted, "Sell", $firstCurr, $secondCurr, $userId, $amount, $buyPrice, $FeePer, "filled");
										$msg2 = "Your sell order of " . $amount . " " . $firstCurr . " has been traded successfully";
									} else {
										self::updateOrder($orderId, $buyorderId, $inserted, "Sell", $firstCurr, $secondCurr, $userId, $amount, $buyPrice, $FeePer, "partially");
										$msg2 = "Your sell order of " . $amount . " " . $firstCurr . " has been traded partially";
									}
								}
							} else {break;}
						}
					}
					if ($buyTradePrice > 0) {
						self::checkStopOrder($firstCurr, $secondCurr, $buyTradePrice);
					}
				} 
			}
		}
		CoinOrder::where('ordertype', 'instant')->whereIn('status', ['active', 'partially'])->update(['status' => 'filled']);
		return $orderArr;
	} 

	public static function returnBal($price, $userId, $secondCurr, $feeper, $firstCurr) {
		$getBal = Wallet::where('user_id', $userId)->select($secondCurr)->first();
		$secondBal = $getBal->$secondCurr;
		$tradeFee = $price * $feeper / 100;
		$remainingBal = $secondBal + $price + $tradeFee;
		$query = Wallet::where('user_id', $userId)->update([$secondCurr => $remainingBal]);
		return ($query) ? true : false;
	}

	//Check if any Stop order
	public static function checkStopOrder($first, $second, $marketPrice) {
		$update = false;
		$sellStopOrders = CoinOrder::where('Price', '>=', $marketPrice)->where(['firstCurrency' => $first, 'secondCurrency' => $second, 'Type' => 'Sell'])->whereIn('status', ['stoporder', 'stoplimitorder'])->select('id', 'status', 'trigger_price')->get();
		if (!$sellStopOrders->isEmpty()) {
			foreach ($sellStopOrders as $sellOrder) {
				$id = $sellOrder->id;
				$price = $sellOrder->trigger_price;
				$status = $sellOrder->status;
				if ($status == 'stoporder') {
					$update = CoinOrder::where('id', $id)->update(['status' => 'active']);
				} else if ($status == 'stoplimitorder') {
					$update = CoinOrder::where('id', $id)->update(['status' => 'active', 'Price' => $price]);
				}
				if ($update) {
					self::mapping($id, $price);
				}
			}
		}
		$buyStopOrders = CoinOrder::where('Price', '<=', $marketPrice)->where(['firstCurrency' => $first, 'secondCurrency' => $second, 'Type' => 'Buy'])->whereIn('status', ['stoporder', 'stoplimitorder'])->select('id', 'status', 'trigger_price')->get();
		if (!$buyStopOrders->isEmpty()) {
			foreach ($buyStopOrders as $buyOrder) {
				$id = $buyOrder->id;
				$price = $buyOrder->trigger_price;
				$status = $buyOrder->status;
				if ($status == 'stoporder') {
					$update = CoinOrder::where('id', $id)->update(['status' => 'active']);
				} else if ($status == 'stoplimitorder') {
					$update = CoinOrder::where('id', $id)->update(['status' => 'active', 'Price' => $price]);
				}
				if ($update) {
					self::mapping($id, $price);
				}
			}
		}
		return true;
	}

	public static function insertTempData($sellorderId, $selluserId, $sellAmount, $sellPrice, $amount, $buyorderId, $buyuserId, $firstCurrency, $secondCurrency, $buyFees, $sellFees, $time ='') {
		$datetime = date("Y-m-d H:i:s");
		$pair = $firstCurrency . "/" . $secondCurrency;
		if ($amount > 0) {
			$total = $amount * $sellPrice;
			$buyFeeAmt = ($amount * $buyFees) / 100;
			$sellFeeAmt = ($total * $sellFees) / 100;
			$takerType = ($sellorderId > $buyorderId) ? "sell" : "buy";
			$comboId = ($sellorderId > $buyorderId) ? $sellorderId : $buyorderId;
			$combo = round(microtime(true) * 1000) . $comboId;
			$tempData = [
				'sellorderId' => $sellorderId,
				'sellerUserid' => $selluserId,
				'askAmount' => $sellAmount,
				'askPrice' => $sellPrice,
				'firstCurrency' => $firstCurrency,
				'secondCurrency' => $secondCurrency,
				'filledAmount' => $amount,
				'buyorderId' => $buyorderId,
				'buyerUserid' => $buyuserId,
				'sellerStatus' => "inactive",
				'buyerStatus' => "inactive",
				"buy_total" => $total,
				"sell_total" => $total,
				'buy_fee' => $buyFeeAmt,
				'sell_fee' => $sellFeeAmt,
				"pair" => $pair,
				"datetime" => $datetime,
				"taker_type" => $takerType,
				"binance_time" => $time,
				"combo" => $combo,
			];
			$insid = OrderTemp::create($tempData);
			return $insid->id;
		} else {
			return false;
		}
	} 

	public static function updateOrder($id, $id1, $inserted, $type, $firstCurr, $secondCurr, $userId, $amount, $price, $feePer, $status) {
		$requestTime = date("Y-m-d H:i:s");
		$feePer = self::find_fee_type($id,$id1);
		
		CoinOrder::where('id', $id)->update(array('status' => $status, 'tradetime' => $requestTime));
		$pair_name = $firstCurr . '/' . $secondCurr;

		self::updateProfit($userId, $type, $amount, $price, $feePer, $firstCurr, $secondCurr, $id);

		if ($type == "Buy") {
			$userbalance = self::fetchuserbalancebyId($userId, $firstCurr);
			
			$tradeFee = $amount * $feePer / 100;
			$tradeAmount = $amount - $tradeFee;
			$buyBal = $userbalance + $tradeAmount;
			$buyBal = number_format($buyBal, 8, '.', '');

			$remarks = 'BuyOrder completed for '. $tradeAmount . ' ' . $firstCurr . ' Old balance: '. $userbalance;
			Wallet::where('user_id', $userId)->update(array($firstCurr => $buyBal, 'remarks' => $remarks));
			OrderTemp::where('id', $inserted)->update(array('buy_fee' => $tradeFee));

			$type = "Trade Buy";
			$data = array('user_id' => $userId, 'theftAmount' => $tradeFee, 'theftCurrency' => $firstCurr, 'type' => $type);
			CoinProfit::create($data);
		} else {			
			$userbalance = self::fetchuserbalancebyId($userId, $secondCurr);

			$tradeFee = ($amount * $price) * $feePer / 100;
			$tradeTotal = ($amount * $price) - $tradeFee;
			$sellBal = $userbalance + $tradeTotal;
			$sellBal = number_format($sellBal, 8, '.', '');

			$remarks = 'SellOrder completed for '. $tradeTotal . ' ' . $secondCurr . ' Old balance: '. $userbalance;
			Wallet::where('user_id', $userId)->update(array($secondCurr => $sellBal, 'remarks' => $remarks));
			OrderTemp::where('id', $inserted)->update(array('sell_fee' => $tradeFee));

			$type = "Trade Sell";
			$data = array('user_id' => $userId, 'theftAmount' => $tradeFee, 'theftCurrency' => $secondCurr, 'type' => $type);
			CoinProfit::create($data);
		}
		return true;
	}

	public static function updateProfit($userId, $type, $amount, $price, $feePer, $firstCurrency, $secondCurrency, $id) {
		$checkReferStatus = check_referralstatus($userId);
		if ($checkReferStatus) {
			$fee = referralcommision_update($userId, $type, $amount, $price, $feePer, $firstCurrency, $secondCurrency, $checkReferStatus, $id);
			$fee = number_format($fee, 8, '.', '');
			$currency = $secondCurrency;
		} else {
			$fee = (($amount * $price) * $feePer) / 100;
			$fee = number_format($fee, 8, '.', '');
			$currency = $secondCurrency;
		}
		return true;
	}	

	public static function checkFilledAmount($id, $type) {
		if ($type == "Buy") {
			$query = OrderTemp::where('buyorderId', $id)->select(DB::raw('SUM(filledAmount) as totalamount'))->first();
		} else {
			$query = OrderTemp::where('sellorderId', $id)->select(DB::raw('SUM(filledAmount) as totalamount'))->first();
		}
		return (!is_null($query)) ? $query->totalamount : false;
	}

	public static function remove_active_model($id, $adm_cancel = '') {
		$order = CoinOrder::where('id', $id)->where('status','cancelled')->first();
		if (!empty($order)) {
			if ($order) {
				$userId = $order->user_id;
				$Type = $order->Type;
				$tradepair = $order->pair;
				$activeAmount = $order->Amount;
				$activeTradeid = $order->id;
				$Total = $order->Total;
				$fee = $order->Fee;
				$pair = $order->pair;
				$fee_per = $order->fee_per;
				$ordertype = $order->ordertype;
				$tradesecondCurrency = $order->secondCurrency;
				$tradefirstCurrency = $order->firstCurrency;
				if ($ordertype == "stoplimitorder") {
					$activePrice = $order->trigger_price;
				} else {
					$activePrice = $order->Price;
				}

				$tradeFirstCurr = $tradefirstCurrency;
				$tradeSecondCur = $tradesecondCurrency;
				$digits = 8;

				$activefilledAmount = self::checkFilledAmount($activeTradeid, $Type);
				if ($activefilledAmount) {
					$activefilledAmount = $activeAmount - $activefilledAmount;
				} else {
					$activefilledAmount = $activeAmount;
				}

				if ($Type == "Buy") {
					$activeCalcTotal = $activefilledAmount * $activePrice;
					$feess = ($activeCalcTotal * $fee_per) / 100;

					$currentbalance = self::fetchuserbalancebyId($userId, $tradeSecondCur);
					$updatebalance = $currentbalance + $activeCalcTotal;
					
					$upCur = $tradeSecondCur;
					$updatebalance = number_format($updatebalance, $digits, '.', '');
					$remarks = 'BuyOrder cancelled for '. $activeCalcTotal . ' ' . $upCur . ' Old balance: '. $currentbalance;
				} else if ($Type == "Sell") {
					$activetot = ($activefilledAmount * $activePrice);
					$feess = ($activefilledAmount * $fee_per) / 100;
					
					$currentbalance = self::fetchuserbalancebyId($userId, $tradeFirstCurr);
					$updatebalance = $currentbalance + $activefilledAmount;
					
					$upCur = $tradeFirstCurr;
					$updatebalance = number_format($updatebalance, 8, '.', '');
					$remarks = 'SellOrder cancelled for '. $activefilledAmount . ' ' . $upCur . ' Old balance: '. $currentbalance;
				}
				
				// fetch order details
				$tradetradeId = $order->id;
				$tradeuserId = $order->user_id;
				$tradePrice = $order->Price;
				$tradeAmount = $order->Amount;
				$tradeFee = $order->Fee;
				$tradeFeePer = $order->fee_per;
				$tradeType = $order->Type;
				$tradeTotal = $order->Total;
				$tradefirstCurrency = $order->firstCurrency;
				$tradesecondCurrency = $order->secondCurrency;
				$orderDate = $order->orderDate;
				$orderTime = $order->orderTime;

				$datetime = date("Y-m-d H:i:s");
				$sum = ($activefilledAmount * $tradePrice);
				$fee_amt = ($activefilledAmount * $tradeFeePer) / 100;
				$comboId = time() . $tradetradeId;
				if($activefilledAmount > 0) {
					$data = array(
						'askAmount' => $tradeAmount,
						'askPrice' => $tradePrice,
						'firstCurrency' => $tradefirstCurrency,
						'secondCurrency' => $tradesecondCurrency,
						'filledAmount' => $activefilledAmount,
						'sellerStatus' => "active",
						'buyerStatus' => "inactive",
						"buy_total" => $sum,
						"sell_total" => $sum,
						"buy_fee" => $fee,
						"sell_fee" => $fee,
						"pair" => $pair,
						"datetime" => $datetime,
						"cancel_id" => $userId,
						"combo" => $comboId,
					);
					if ($tradeType == "Buy") {
						$data['buyorderId'] = $tradetradeId;
						$data['buyerUserid'] = $tradeuserId;
						$data['sellorderId'] = 0;
						$data['sellerUserid'] = 0;
					} else {
						$data['buyorderId'] = 0;
						$data['buyerUserid'] = 0;
						$data['sellorderId'] = $tradetradeId;
						$data['sellerUserid'] = $tradeuserId;
					}
					$createOrderTemp = OrderTemp::create($data);

					if($adm_cancel == 1) {
						$createAdminOrderTemp = AdminOrderTemp::create($data);
					}

					if($createOrderTemp) {
						Wallet::where('user_id', $userId)->update([$upCur => $updatebalance, 'remarks' => $remarks]);
					}
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		}
	}

	public static function getSellOrders($price, $userId, $first, $second, $liquidity_order) {
		$query = 'SELECT CO.id as id, CO.user_id as user_id, CO.Price as Price, CO.Amount as Amount, CO.Fee as Fee, CO.fee_per as fee_per, CO.Total as Total, CO.status as status, SUM(OT.filledAmount) as filledAmount FROM '.PREFIX.COINORDER.' as CO LEFT JOIN '.PREFIX.ORDERTEMP.' as OT on OT.sellorderId = CO.id where CO.firstCurrency = "' . $first . '" and CO.secondCurrency = "' . $second . '" and CO.Type = "Sell" and CO.Price <= ' . $price . ' and CO.status in ("active", "partially") and CO.user_id != ' . $userId . ' group by CO.id order by CO.Price asc, CO.created_at';
		$result = DB::select(DB::raw($query));
		return (!is_null($result)) ? $result : false;
	}

	public static function getBuyOrders($price, $userId, $first, $second, $liquidity_order) {
		$query = 'SELECT CO.id as id, CO.user_id as user_id, CO.Price as Price, CO.Amount as Amount, CO.Fee as Fee, CO.fee_per as fee_per, CO.Total as Total, CO.status as status, SUM(OT.filledAmount) as filledAmount FROM '.PREFIX.COINORDER.' as CO LEFT JOIN '.PREFIX.ORDERTEMP.' as OT on OT.buyorderId = CO.id where CO.firstCurrency = "' . $first . '" and CO.secondCurrency = "' . $second . '" and CO.Type = "Buy" and CO.Price >= ' . $price . ' and CO.status in ("active", "partially") and CO.user_id != ' . $userId . ' group by CO.id order by CO.Price desc, CO.created_at';	
		$result = DB::select(DB::raw($query));
		return (!is_null($result)) ? $result : false;
	}

	public static function getMarketBuyOrders($userId, $first, $second, $liquidity_order) {
		$query = 'SELECT CO.id as id, CO.user_id as user_id, CO.Price as Price, CO.Amount as Amount, CO.Fee as Fee, CO.fee_per as fee_per, CO.Total as Total, CO.status as status, SUM(OT.filledAmount) as filledAmount FROM '.PREFIX.COINORDER.' as CO LEFT JOIN '.PREFIX.ORDERTEMP.' as OT on OT.buyorderId = CO.id where CO.firstCurrency = "' . $first . '" and CO.secondCurrency = "' . $second . '" and CO.Type = "Buy" and CO.status in ("active", "partially") and CO.user_id != ' . $userId . ' group by CO.id order by CO.Price desc, CO.created_at';
		$result = DB::select(DB::raw($query));
		return (!is_null($result)) ? $result : false;
	}

	public static function getMarketSellOrders($userId, $first, $second, $liquidity_order) {
		$query = 'SELECT CO.id as id, CO.user_id as user_id, CO.Price as Price, CO.Amount as Amount, CO.Fee as Fee, CO.fee_per as fee_per, CO.Total as Total, CO.status as status, SUM(OT.filledAmount) as filledAmount FROM '.PREFIX.COINORDER.' as CO LEFT JOIN '.PREFIX.ORDERTEMP.' as OT on OT.sellorderId = CO.id where CO.firstCurrency = "' . $first . '" and CO.secondCurrency = "' . $second . '" and CO.Type = "Sell" and CO.status in ("active", "partially") and CO.user_id != ' . $userId . ' group by CO.id order by CO.Price asc, CO.created_at';
		$result = DB::select(DB::raw($query));
		return (!is_null($result)) ? $result : false;
	}

	public static function find_fee_type($id, $id1) {
		$query = CoinOrder::where('id', $id1)->select('fee_per')->first();
		if ($id > $id1) {
			$query = CoinOrder::where('id', $id)->select('taker_fee_par')->first();
			return $query->taker_fee_par;
		} else {
			return $query->fee_per;
		}
	}

	public static function checkFilledAmount_date($id, $type) {
		if ($type == "Buy") {
			$query = OrderTemp::where('buyorderId', $id)->first();
		} else {
			$query = OrderTemp::where('sellorderId', $id)->first();
		}
		if ($query == null) {
			return false;
		}
		if ($query->count() == 0) {
			return false;
		} else {
			return $query->datetime;
		}
	}
}