<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CoinTheft extends Model
{
    protected $table = 'quotes_list';

    protected $guarded = [];
}
