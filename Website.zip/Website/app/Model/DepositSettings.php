<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DepositSettings extends Model
{
    protected $table = 'deposit_settings';

    protected $guarded = [];
}
