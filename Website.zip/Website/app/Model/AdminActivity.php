<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AdminActivity extends Model
{
    protected $table = 'admin_activity';

    protected $guarded = [];
}
