<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Allowed_ips extends Model
{
    //

    protected $table = 'allowed_ips';
}
