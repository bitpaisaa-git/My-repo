<?php

namespace App\Model;
use DateTime;
use DateTimeZone;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable {
	use Notifiable;

	protected $table = 'PaBiiIstaa_us';

	protected $guarded = [];

	public static function randomString($length) {
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}

	public static function randomReferNumber($length) {
		$characters = '0123456789';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}

	//validation rules

	public static $adminLoginRule = array(
		'username' => array('required', 'email', 'indisposable'),
		'user_pwd' => 'required',
		'pattern_code' => 'required',
	);

	public static $userSignupRule = array(
		'first_name' => 'required',
		'email' => array('required', 'email', 'unique_email', 'indisposable'),
		'agree' => 'required',
		'pwd' => 'required',
		'confirm_pwd' => 'required',
		'phone' => 'required',
	);

	public static $userSignupMsg = array(
		'email.unique_email' => "Email address already exits",
		'email.email' => "Enter valid email",
	);

	public static $userLoginRule = array(
		'password' => 'required',
	);

	public static $forgotRule = array(
		'email' => array('required', 'indisposable'),
	);

	public static $resetRule = array(
		'pwd' => 'required',
		'confirm_pwd' => 'required',
	);

	public static $passwordRule = array(
		'new_pwd' => 'required',
		'cnfirm_pwd' => 'required',
	);

	public static $changePasswordRule = array(
		'current_pwd' => 'required',
		'new_pwd' => 'required',
		'confirm_pwd' => 'required',
	);

	public static $profileRule = array(
		'firstname' => 'required',
		'lastname' => 'required',
		'phone' => 'required',
		'address' => 'required',
		'city' => 'required',
		'dob' => 'required',
		'country' => 'required',
	);

	public static $depositRule = array(
		'deposit_amount' => array('required', 'numeric'),
		'transaction_ref' => 'required',
		'receipt_ref' => 'required',
	);

	public static $withdrawBankRule = array(
		'fiat_currency' => 'required',
		'withdraw_amount' => array('required', 'numeric'),
	);

	public static $withdrawCryptoRule = array(
		'crypto_currency' => 'required',
		'coin_address' => 'required',
		'crypto_amount' => array('required', 'numeric'),
		'with_pass' => 'required',
	);

	public static $withdrawFiatRule = array(
		'fiat_currency' => 'required',
		'user_bank' => 'required',
		'withdraw_amount' => array('required', 'numeric'),
		'fiat_with_pass' => 'required',
	);

	public static $bankRule = array(
		'acc_name' => 'required',
		'acc_number' => array('required', 'numeric'),
		'bank_name' => 'required',
		'bank_branch' => 'required',
		'bank_swift' => 'required',
		'country' => 'required',
	);

	public static $contactRule = array(
		'username' => 'required',
		'useremail' => array('required', 'email'),
		'subject' => 'required',
		'message' => 'required',
		'mobile_number' => 'required',
	);

	public static $helpRule = array(
		'subject' => 'required',
		'description' => 'required',
	);

	public static $queryRule = array(
		'description' => 'required',
		'reference_proof' => 'max:1024',
	);

	//get user profile picture for header
	public static function getProfile($id) {
		$profilePicture['user'] = User::where('id', $id)
			->select('profile_picture', 'consumer_name', 'user_mail_id', 'unusual_user_key', 'phone', 'verified_status', 'created_at', 'tfa_status')->first();
		return $profilePicture;
	}

	//get wallet balance for sidebar
	public static function getWallet($id) {
		$getBalance = Wallet::where('user_id', $id)->first();
		return $getBalance;
	}

	//get site details for footer
	public static function getSiteDetails() {
		$getSiteDetails = SiteSettings::where('id', 1)->select('contact_email', 'contact_number', 'contact_address', 'city', 'state', 'country', 'fb_url', 'twitter_url', 'linkedin_url', 'googleplus_url', 'copy_right_text', 'skype_id')->first();
		return $getSiteDetails;
	}

	//get site logo for header
	public static function getSiteLogo() {
		$getSiteDetails = SiteSettings::where('id', 1)->select('site_logo', 'site_favicon')->first();
		return $getSiteDetails;
	}

	//get copy right for footer
	public static function getCopyRight() {
		$getSiteDetails = SiteSettings::where('id', 1)->select('copy_right_text')->first();
		return $getSiteDetails;
	}

	//get footer content and image
	public static function getStaticContent($id) {
		$getSiteDetails = Cms::where('id', $id)->first();
		return $getSiteDetails;
	}

	//get meta details
	public static function getMetaDetails() {
		$currentRoute = \Route::getCurrentRoute()->getActionName();
		$explodeRoute = explode('@', $currentRoute);
		$uri = $explodeRoute[1];
		if ($uri == "depositPaypalSubmit") {
			$uri = "deposit";
		}
		return MetaContent::where('link', $uri)->first();
	}

	//get user notification
	public static function getNotification($id, $type = '') {
		if ($type == 'count') {
			return UserNotification::where('user_id', $id)->where('status', 'unread')->count();
		} else {
			$getDetails = UserNotification::where('user_id', $id)->where('status', 'unread')->orderBy('id', 'desc')->limit(10)->get();
			if ($getDetails->isEmpty()) {
				return "";
			} else {
				return $getDetails;
			}
		}

	}

	//get btc address of the user
	public static function getAddress($id, $coin) {
		$getAddress = CoinAddress::where('user_id', $id)->where('currency', $coin)->select('address')->orderBy('id', 'desc')->first();
		if ($getAddress->count() == 0) {
			return "";
		} else {
			return $getAddress->address;
		}
	}

	//retrieve country list
	public static function getCountry() {
		return Country::all();
	}

	//Associations
	//associte with user activities
	public function activity() {
		return $this->hasMany('App\Model\UserActivity');
	}

	//associte with user bank
	public function bank() {
		return $this->hasMany('App\Model\UserBank');
	}

	//associte with user verification
	public function verification() {
		return $this->hasOne('App\Model\ConsumerVerification');
	}

	//associate with wallet
	public function wallet() {
		return $this->hasOne('App\Model\Wallet');
	}

	//associate with transactions
	public function transactions() {
		return $this->hasMany('App\Model\Transaction');
	}

	//associate with deposit
	public function deposits() {
		return $this->hasMany('App\Model\Deposit');
	}

	//associate with withdraw
	public function withdraws() {
		return $this->hasMany('App\Model\Withdraw');
	}
	public static function CurrencyCategory($type) {
		$reslult_val = Currency::WHERE('currency_type', $type)->select('currency_symbol')->get();
		$result = array();
		foreach ($reslult_val as $r) {
			$result[] = $r['currency_symbol'];
		}
		return $result;
	}
	public static function CurrencyCategoryResult($type) {
		$reslult_val = Currency::WHERE('currency_symbol', $type)->select('currency_name')->get();
		$result = array();
		foreach ($reslult_val as $r) {
			$result[] = $r['currency_name'];
		}
		return $result;
	}

	//associate with coin address
	public function coinAddress() {
		return $this->hasMany('App\Model\CoinAddress');
	}
	public static function getlanguage($var) {
		if ($var != '') {
			$languages = Session::get('languagefiles');
			if (isset($languages[$var])) {
				return $languages[$var];
			} else {
				return $var;
			}
		} else {
			return '';
		}
	}
	public static function getLocalTime($time, $fromTz = 'UTC', $toTz = 'Asia/Kolkata') {
		$date = new DateTime($time, new DateTimeZone($fromTz));
		$date->setTimezone(new DateTimeZone($toTz));
		$time = $date->format('Y-m-d H:i:s');
		return $time;
	}

}
