<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ReferralCommision extends Model
{
    protected $table = 'referral_commision_info';

    protected $guarded = [];
}
