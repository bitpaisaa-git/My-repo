<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class PaymentGateway extends Model
{
    protected $table = 'PaBiiIstaa_pg';

    protected $guarded = [];

    public static function getCaptcha() {
    	$getCaptcha = PaymentGateway::where('id',1)->select('sub_key')->first();
    	return $getCaptcha->sub_key;
    }
}
