<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Wallet extends Model{
    protected $table = 'PaBiiIstaa_wa';

    protected $guarded = [];

    public function user() {
        return $this->belongsTo('App\Model\User', 'user_id');
    }

    public static $adminLoginRule = array(
        'username' => array('required', 'email'),
        'user_pwd' => 'required',
        'pattern_code' => 'required',
        'key_code' => 'required'
    );

    public static $withdrawRule = array(
        'currency' => 'required',
        'address' => 'required',
        'amount' => 'required',
        'password' => 'required',
        'confirm_code' => 'required'
    );

    public static function getBalance($id, $currency = '') {
        if($currency == '') {
            $wallet = Wallet::where('user_id', $id)->first();
        } else {
            $wallet = Wallet::where('user_id', $id)->select($currency)->first();
        }
        return $wallet;
    }

    public static function updateBalance($id, $currency, $balance = 0, $remarks) {
        $wallet = Wallet::where('user_id', $id)->select($currency)->first();
        if ($wallet) {
            $upd = array();
            Wallet::where('user_id', $id)->update([$currency => $balance, 'remarks' => $remarks]);
        }
        return true;
    }
}
