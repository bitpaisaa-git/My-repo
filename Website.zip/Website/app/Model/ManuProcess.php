<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ManuProcess extends Model
{
    protected $table = 'manuvally_maintance_process';

    protected $guarded = [];
}
