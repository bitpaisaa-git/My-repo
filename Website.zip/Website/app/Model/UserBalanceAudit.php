<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class UserBalanceAudit extends Model {
	protected $table = 'user_balance_audit';

	protected $guarded = [];
}
