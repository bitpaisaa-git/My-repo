<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SiteWallet extends Model
{
    protected $table = 'PaBiiIstaa_swa';

    protected $guarded = [];
}
