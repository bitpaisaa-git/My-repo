<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class WithdrawSettings extends Model
{
    protected $table = 'withdraw_settings';

    protected $guarded = [];
}
