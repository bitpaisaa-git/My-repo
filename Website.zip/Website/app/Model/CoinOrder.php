<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CoinOrder extends Model
{
    protected $table = 'PaBiiIstaa_co';

    protected $guarded = [];
}
