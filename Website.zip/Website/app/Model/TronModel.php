<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class TronModel extends Model
{
    protected $table = 'tron';

    protected $guarded = [];
}
