<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AddCoins extends Model
{
    protected $table = 'add_coin';

    protected $guarded = [];
}
