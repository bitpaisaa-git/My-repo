<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SavedAddress extends Model
{
    protected $table = 'saved_address';

    protected $guarded = [];
}
