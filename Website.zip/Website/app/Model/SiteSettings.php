<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SiteSettings extends Model
{
    protected $table = 'PaBiiIstaa_ss';

    protected $guarded = [];

    
}
