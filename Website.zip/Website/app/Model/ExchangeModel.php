<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ExchangeModel extends Model
{
    protected $table = 'exchange';

    protected $guarded = [];
}
