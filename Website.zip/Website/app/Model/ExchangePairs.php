<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ExchangePairs extends Model
{
    protected $table = 'exchange_pairs';

    protected $guarded = [];
}
