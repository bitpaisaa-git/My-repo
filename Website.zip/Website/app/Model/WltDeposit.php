<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class WltDeposit extends Model
{
    protected $table = 'wallet_deposit';
    protected $guarded = [];

}
