<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Helpcategory extends Model
{
    protected $table = 'help_category';

    protected $guarded = [];
}
