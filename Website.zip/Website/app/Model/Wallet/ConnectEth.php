<?php

namespace App\Model\Wallet;
use Illuminate\Database\Eloquent\Model;
use App\Model\SiteWallet;

use Config;

class ConnectEth extends Model {
	public static function ethFunctions($method, $data = array()) {
		$encrypt = encrypText('ETH');
		$getFile = file_get_contents(app_path('Model/BfuiSGvKthvPYsVa/'.$encrypt.'.php'));
		$filedata = explode(" || ", $getFile);
		$ip = decrypText($filedata[0]);
		$port = decrypText($filedata[1]);
		$url = $ip . ":" . $port;
		if ($method == "blockCount") {
			$output = shell_exec('curl -X POST -H "Content-Type: application/json" --data \'{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":83}\' ' . $url);
			$res = json_decode($output);
			$count = hexdec($res->result);
			$response = array('type' => 'success', 'result' => $count);
		} else if ($method == "createAddr") {
			$key = decrypText(Config::get('cookie.ETH_USR.key'));

			if ($key != "") {
				$output = shell_exec('curl -H "Content-Type: application/json" -X POST --data \'{"jsonrpc":"2.0","method":"personal_newAccount","params":["' . $key . '"],"id":1}\' ' . $url);
				$res = json_decode($output);
				$address = $res->result;
				$response = array('type' => 'success', 'result' => $address);
			} else {
				$response = array('type' => 'fail', 'result' => "Invalid key");
			}
		} else if ($method == "getBlockTransactions") {
			$oldBlock = $data['block'];
			$transactions = array();
			$output = shell_exec('curl -X POST -H "Content-Type: application/json" --data \'{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":83}\' ' . $url);
			$res = json_decode($output, true);
			$hexCount = $res['result'];
			$count = hexdec($hexCount);
			$maxBlock = $count - 12;
			if ($maxBlock > $oldBlock) {
				for ($i = $oldBlock; $i <= $maxBlock; $i++) {
					$blockNum = ($i == $maxBlock) ? $hexCount : "0x" . dechex($i);
					$ch = curl_init();
					curl_setopt($ch, CURLOPT_URL, $url);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
					curl_setopt($ch, CURLOPT_POSTFIELDS, "{\"jsonrpc\":\"2.0\",\"method\":\"eth_getBlockByNumber\",\"params\":[\"" . trim($blockNum) . "\", true],\"id\":1}");
					curl_setopt($ch, CURLOPT_POST, 1);
					$headers = array();
					$headers[] = "Content-Type: application/json";
					curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
					$result = curl_exec($ch);
					if (curl_errno($ch)) {
						echo 'Error:' . curl_error($ch);
					}
					curl_close($ch);
					$decodeResult = json_decode($result, true);
					$transactions[] = $decodeResult['result']['transactions'];
				}
				$response = array('type' => 'success', 'result' => $transactions, 'block' => $maxBlock);
			} else {
				$response = array('type' => 'fail', 'block' => $maxBlock);
			}
		} else if ($method == "checkReceipt") {
			$hash = trim($data['hash']);
			$output = shell_exec('curl -X POST -H "Content-Type: application/json" --data \'{"jsonrpc":"2.0","method":"eth_getTransactionReceipt","params":["' . $hash . '"],"id":1}\' ' . $url);
			$res = json_decode($output, true);
			return array('type' => 'fail', 'result' => $res);

			if (!isset($res['error'])) {
				$receipt = $res['result'];
				if (!empty($receipt)) {
					$response = array('type' => 'success', 'result' => $receipt);
				} else {
					$response = array('type' => 'fail', 'result' => "Invalid txid");
				}
			} else {
				$response = array('type' => 'fail', 'result' => "Invalid txid error");
			}
		} else if ($method == "checkBalance") {
			$address = $data['address'];
			$getBal = shell_exec('curl -X POST -H "Content-Type: application/json" --data \'{"jsonrpc":"2.0","method":"eth_getBalance","params":["' . $address . '", "latest"],"id":2}\' ' . $url);
			$decodeBal = json_decode($getBal, true);
			if(isset($decodeBal['result'])) {
				$userBal = bchexdec($decodeBal['result']);
				$balance = $userBal / 1000000000000000000;
			} else {
				$balance = 0;
			}
			$response = array('type' => 'success', 'result' => $balance);
		} else if ($method == "tokenBalance") {
			$address = $data['adminaddress']; 
			$contract = $data['contract'];
			$address = "0x70a08231000000000000000000000000" . substr($address, 2);
			$getBal = shell_exec('curl -X POST -H "Content-Type: application/json" --data \'{"jsonrpc":"2.0","method":"eth_call","params":[{"to":"' . $contract . '", "data":"' . $address . '"}, "latest"],"id":2}\' ' . $url);
			$decodeBal = json_decode($getBal, true);
			if(isset($decodeBal['result'])) {
				$userBal = bchexdec($decodeBal['result']);
			} else {
				$userBal = 0;
			}
			$response = array('type' => 'success', 'result' => $userBal);
		} else if ($method == "moveBalanceToAdmin") {
			$key = $data['key'];
			$adminAddr = $data['adminaddress'];
			$userAddr = $data['useraddress'];

			$getBal = shell_exec('curl -X POST -H "Content-Type: application/json" --data \'{"jsonrpc":"2.0","method":"eth_getBalance","params":["' . $userAddr . '", "latest"],"id":2}\' ' . $url);
			$decodeBal = json_decode($getBal, true);
			if (isset($decodeBal['result'])) {
				$userBal = bchexdec($decodeBal['result']);
				if ($userBal > 100000000000) {
					$output1 = array();
					$return_var1 = -1;
					$balance = $userBal / 1000000000000000000;

					$result = exec('cd /var/www/html/public/eth; node singleAdminTransfer.js ' . trim($adminAddr) . ' ' . trim($userAddr) . ' ' . trim($key) . ' ' . trim($balance) . ' ' . trim($url) . ' ', $output1, $return_var1);
					if (!empty($output1)) {
						if ($output1[0] == 'success') {
							$response = array('type' => 'success', 'result' => $output1[1]);
						} else {
							$response = array('type' => 'fail', 'result' => $output1[1]);
						}
					} else {
						$response = array('type' => 'fail', 'result' => "Not transferred");
					}
				} else {
					$response = array('type' => 'fail', 'result' => "Low balance");
				}
			} else {
				$response = array('type' => 'fail', 'result' => "Balance error");
			}
		} else if ($method == "moveFundsToAdmin") {
			$key = $data['key'];
			$adminAddr = $data['adminaddress'];
			$userAddr = $data['useraddress'];
			$gasPrice = trim($data['gasPrice']);
			$gasLimit = trim($data['gasLimit']);

			$getBal = shell_exec('curl -X POST -H "Content-Type: application/json" --data \'{"jsonrpc":"2.0","method":"eth_getBalance","params":["' . $userAddr . '", "latest"],"id":2}\' ' . $url);
			$decodeBal = json_decode($getBal, true);
			if (isset($decodeBal['result'])) {
				$userBal = bchexdec($decodeBal['result']);
				if ($userBal > 100000000000) {
					$balance = $userBal / 1000000000000000000;
					$fee = bcmul($gasPrice, $gasLimit);
					$transAmount = bcsub($userBal, $fee);
					$gasPrice = '0x' . dechex($gasPrice);
					$gasLimit = '0x' . dechex($gasLimit);
					$nonce = '0x0';
					$amount = '';
					do {
						$last = bcmod($transAmount, 16);
						$amount = dechex($last) . $amount;
						$transAmount = bcdiv(bcsub($transAmount, $last), 16);
					} while ($transAmount > 0);
					if ($amount == '0') {
						return array('type' => 'fail', 'result' => "Invalid amount");
					}
					$amount = '0x' . $amount;

					$unlockAddr = shell_exec('curl -X POST -H "Content-Type: application/json" --data \'{"jsonrpc":"2.0","method":"personal_unlockAccount","params":["' . $userAddr . '","' . $key . '",null],"id":1}\' ' . $url);
					$unlockRes = json_decode($unlockAddr, true);
					if (!isset($unlockRes['error'])) {
						$unlockEth = $unlockRes['result'];
						if ($unlockEth == 1 || $unlockEth == "true" || $unlockEth == true) {
							$get_peer = shell_exec('curl -X POST -H "Content-Type: application/json" --data \'{"jsonrpc":"2.0","method":"net_peerCount","params":[],"id":74}\' ' . $url);
							$peerCount = json_decode($get_peer, true);
							if (!isset($peerCount['error'])) {
								$count = hexdec($peerCount['result']);
								if($count > 2) {
									$output = shell_exec('curl -X POST -H "Content-Type: application/json" --data \'{"jsonrpc":"2.0","method":"eth_sendTransaction","params":[{"from":"' . $userAddr . '","to":"' . $adminAddr . '","gas":"' . $gasLimit . '","gasPrice":"' . $gasPrice . '","value":"' . $amount . '"}],"id":22}\' ' . $url);
									$result = json_decode($output, true);
									if (!isset($result['error'])) {
										$res = $result['result'];
										if ($res == '' || $res == null) {
											$response = array('type' => 'fail', 'result' => "Failed to transfer.");
										} else {
											$response = array('type' => 'success', 'result' => $res);
										}
									} else {
										$response = array('type' => 'fail', 'result' => $result['error']['message']);
									}
								} else {
									$response = array('type' => 'fail', 'result' => 'Please wait for peercount to reach 3');
								}
							} else {
								$response = array('type' => 'fail', 'result' => $peerCount['error']['message']);
							}
						} else {
							$response = array('type' => 'fail', 'result' => "Invalid passsword!");
						}
					} else {
						$response = array('type' => 'fail', 'result' => $unlockRes['error']['message']);
					}
				} else {
					$response = array('type' => 'fail', 'result' => "Low balance");
				}
			} else {
				$response = array('type' => 'fail', 'result' => "Balance error");
			}
		} else if ($method == "sendEthereum") {
			$fromaddress = strtolower($data['from']);
			$toaddress = strtolower($data['to']);
			$amount = trim($data['amount']);
			$key = trim($data['key']);
			$gasPrice = trim($data['gasPrice']);
			$gasLimit = trim($data['gasLimit']);
			$transAmount = bcmul($amount, 1000000000000000000);

			$gasPrice = '0x' . dechex($gasPrice);
			$gasLimit = '0x' . dechex($gasLimit);

			$amount = '';
			do {
				$last = bcmod($transAmount, 16);
				$amount = dechex($last) . $amount;
				$transAmount = bcdiv(bcsub($transAmount, $last), 16);
			} while ($transAmount > 0);
			$amount1 = '0x' . $amount;

			$amount = '"' . trim($amount1) . '"';
			$fromaddress = '"' . trim($fromaddress) . '"';
			$toaddress = '"' . trim($toaddress) . '"';
			$unlockAddr = shell_exec('curl -X POST -H "Content-Type: application/json" --data \'{"jsonrpc":"2.0","method":"personal_unlockAccount","params":[' . $fromaddress . ',"' . $key . '",null],"id":1}\' ' . $url);
			$unlockRes = json_decode($unlockAddr, true);
			if (!isset($unlockRes['error'])) {
				$unlockEth = $unlockRes['result'];
				if ($unlockEth == 1 || $unlockEth == "true" || $unlockEth == true) {
					$get_peer = shell_exec('curl -X POST -H "Content-Type: application/json" --data \'{"jsonrpc":"2.0","method":"net_peerCount","params":[],"id":74}\' ' . $url);
					$peerCount = json_decode($get_peer, true);
					if (!isset($peerCount['error'])) {
						$count = hexdec($peerCount['result']);
						if($count > 2) {
							$output = shell_exec('curl -X POST -H "Content-Type: application/json" --data \'{"jsonrpc":"2.0","method":"eth_sendTransaction","params":[{"from":' . $fromaddress . ',"to":' . $toaddress . ',"gas":"' . $gasLimit . '","gasPrice":"' . $gasPrice . '","value":' . $amount . '}],"id":22}\' ' . $url);
							$result = json_decode($output, true);
							if (!isset($result['error'])) {
								$res = $result['result'];
								if ($res == '' || $res == null) {
									$response = array('type' => 'fail', 'result' => "Failed to transfer ETH.");
								} else {
									$response = array('type' => 'success', 'result' => $res);
								}
							} else {
								$response = array('type' => 'fail', 'result' => $result['error']['message']);
							}
						} else {
							$response = array('type' => 'fail', 'result' => 'Please wait for peercount to reach 3');
						}
					} else {
						$response = array('type' => 'fail', 'result' => $peerCount['error']['message']);
					}
				} else {
					$response = array('type' => 'fail', 'result' => "Invalid passsword!");
				}
			} else {
				$response = array('type' => 'fail', 'result' => $unlockRes['error']['message']);
			}
		} else if ($method == 'sendToken') {
			$fromaddress = strtolower($data['account']);
			$touseraddress = strtolower($data['toaddress']);
			$contract_address = strtolower($data['contract']);
			$amount = trim($data['amount']);
			$key = trim($data['key']);
			$gasPrice = trim($data['gasPrice']);
			$gasLimit = trim($data['gasLimit']);
			$gasLimit = '0x' . dechex($gasLimit);
			$gasLimit = '"' . trim($gasLimit) . '"';
			$gasPrice = '0x' . dechex($gasPrice);
			$gasPrice = '"' . trim($gasPrice) . '"';
			$amount = str_pad($amount, 64, '0', STR_PAD_LEFT);
			$touseraddress = substr($touseraddress, 2);
			$input = '0xa9059cbb000000000000000000000000' . $touseraddress . $amount;
			$input = '"' . trim($input) . '"';
			$fromaddress = '"' . trim($fromaddress) . '"';
			$toaddress = '"' . trim($contract_address) . '"';
			$unlockAddr = shell_exec('curl -X POST -H "Content-Type: application/json" --data \'{"jsonrpc":"2.0","method":"personal_unlockAccount","params":[' . $fromaddress . ',"' . $key . '",null],"id":1}\' '. $url);
			$unlockRes = json_decode($unlockAddr, true);
			if (!isset($unlockRes['error'])) {
				$unlockEth = $unlockRes['result'];
				if ($unlockEth == 1 || $unlockEth == "true" || $unlockEth == true) {
					$get_peer = shell_exec('curl -X POST -H "Content-Type: application/json" --data \'{"jsonrpc":"2.0","method":"net_peerCount","params":[],"id":74}\' ' . $url);
					$peerCount = json_decode($get_peer, true);
					if (!isset($peerCount['error'])) {
						$count = hexdec($peerCount['result']);
						if($count > 2) {
							$output = shell_exec('curl -X POST -H "Content-Type: application/json" --data \'{"jsonrpc":"2.0","method":"eth_sendTransaction","params":[{"from":' . $fromaddress . ',"to":' . $toaddress . ',"gas":' . $gasLimit . ',"gasPrice":' . $gasPrice . ',"data":' . $input . '}],"id":22}\'  '. $url);
							$result = json_decode($output, true);
							if (!isset($result['error'])) {
								$res = $result['result'];
								if ($res == '' || $res == null) {
									$response = array('type' => 'fail', 'result' => "Failed to transfer.");
								} else {
									$response = array('type' => 'success', 'result' => $res);
								}
							} else {
								$response = array('type' => 'fail', 'result' => $result['error']['message'] . ' ' . $input);
							}
						} else {
							$response = array('type' => 'fail', 'result' => 'Please wait for peercount to reach 3');
						}
					} else {
						$response = array('type' => 'fail', 'result' => $peerCount['error']['message']);
					}
				} else {
					$response = array('type' => 'fail', 'result' => "Invalid passsword!");
				}
			} else {
				$response = array('type' => 'fail', 'result' => $unlockRes['error']['message']);
			}			
		} else if ($method == "peerCount") {
			$output = shell_exec('curl -X POST -H "Content-Type: application/json" --data \'{"jsonrpc":"2.0","method":"net_peerCount","params":[],"id":74}\' ' . $url);
			$res = json_decode($output);
			$count = hexdec($res->result);
			$response = array('type' => 'success', 'result' => $res);
		} else if ($method == "poolStatus") {
			$output = shell_exec('curl -X POST -H "Content-Type: application/json" --data \'{"jsonrpc":"2.0","method":"txpool_status","params":[],"id":74}\' ' . $url);
			$res = json_decode($output);
			$response = array('type' => 'success', 'result' => $res);
		} else if ($method == "txList") {
			$output = shell_exec('curl -X POST -H "Content-Type: application/json" --data \'{"jsonrpc":"2.0","method":"eth_pendingTransactions","params":[],"id":74}\' ' . $url);
			$res = json_decode($output);
			$response = array('type' => 'success', 'result' => $res);
		} else {
			$response = array('type' => 'fail', 'result' => "Invalid method");
		}
		return $response;
		
	}

}