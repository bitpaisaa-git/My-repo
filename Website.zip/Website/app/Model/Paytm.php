<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Paytm extends Model
{
    protected $table = 'paytm_deposit';

    protected $guarded = []; 
}
