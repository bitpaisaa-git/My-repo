<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ExchangeOrder extends Model
{
    protected $table = 'exchange_order';

    protected $guarded = [];
}
