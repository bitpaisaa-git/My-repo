<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class BlockIP extends Model
{
    protected $table = 'block_ip';

    protected $guarded = [];
}
