<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ExchangePair extends Model
{
    protected $table = 'exchange_pair';

    protected $guarded = [];

    public static $exchangeRule = array(
        'from_amt' => array('required', 'numeric'),
        'to_amt' => array('required', 'numeric'),
        'from_symbol' => 'required',
        'to_symbol' => 'required',
        //'receive_method' => 'required'
    );

    public static $walletRule = array(
        'receive_email' => array('required','email')
    );

    public static $bankRule = array(
        'acc_name' => 'required',
        'acc_number' => array('required', 'numeric'),
        'bank_name' => 'required',
        'bank_branch' => 'required',
        'bank_iban' => 'required',
        'bank_swift' => 'required',
        'bank_addr' => 'required',
        'bank_trans' => 'required'
    );
}
