<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AdminTransfer extends Model {
	protected $table = 'admin_transfer';

	protected $guarded = [];
}
