<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Tokendetail extends Model {
	protected $table = 'token_details';

	protected $guarded = [];
}