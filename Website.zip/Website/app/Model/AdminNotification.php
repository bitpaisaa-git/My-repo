<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AdminNotification extends Model
{
    protected $table = 'admin_notification';

    protected $guarded = [];
}
