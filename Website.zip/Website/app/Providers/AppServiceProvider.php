<?php

namespace App\Providers;

use App\Model\User;
use Illuminate\Support\ServiceProvider;
use Validator;
use URL;

class AppServiceProvider extends ServiceProvider {
	/**
	 * Bootstrap any application services.
	 *
	 * @return void
	 */
	public function boot() {

		// check_hosts();
		if ($_SERVER['HTTP_HOST'] != "localhost") {
			URL::forceScheme('https');
		}

		Validator::extend('unique_email', function ($attribute, $value, $parameters) {
			$email = explode('@', $value);
			$first = encrypText($email[0]);
			$second = encrypText($email[1]);
			$getCount = User::where('user_mail_id', $first)
				->where('unusual_user_key', $second)->count();
			if ($getCount > 0) {
				return false;
			} else {
				return true;
			}

		});
	}

	/**
	 * Register any application services.
	 *
	 * @return void
	 */
	public function register() {
		//
	}
}
