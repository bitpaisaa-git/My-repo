var CryptoJS = require("crypto-js");
var key = "BvWxTvvmrywwRAGaM";
var iv  = "BWqUpnTPNpTxasmUA";

key = CryptoJS.enc.Base64.parse(key);
iv  = CryptoJS.enc.Base64.parse(iv);

module.exports = {
	encrypt : function(txt){
		return CryptoJS.AES.encrypt(txt, key,{iv:iv}).toString();
	},
	decrypt : function(txt){
		var bytes  = CryptoJS.AES.decrypt(txt.toString(), key, {iv:iv});
		return bytes.toString(CryptoJS.enc.Utf8);
	}
}