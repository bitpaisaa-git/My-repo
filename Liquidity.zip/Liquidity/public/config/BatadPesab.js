module.exports = { 
	database : {
		host: 'Fk3as29CW5jxdcQ0DzK6CQ==',
		user: 'RsAKJF6hiWcdndr6z5PtbgTdJPuigdu92lKo1f5NhOk=',
		password: '2RIGwW7lJisyfOO2M6ZZ64CaILuAHfOC+9ruj/3H6RI=',
		database: 'aO2fSEHKW8M4RBLYoXfn1I4PZhk1IdTs063HxLKmeLc='
	}
}
