module.exports = { 
	domain : {
		url: ['bitpaisaa.com'],
	}
}