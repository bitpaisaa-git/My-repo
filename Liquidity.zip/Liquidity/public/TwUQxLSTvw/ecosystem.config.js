module.exports = {
  apps : [{
    name   : "app",
    script : "wwusgJrtDw.js",
    watch :true,
    error_file : "../../storage/logs/err.log",
    out_file : "../../storage/logs/out.log",
    ignore_watch : ["../../storage/logs/err.log","../../storage/logs/out.log","../../storage/logs/laravel.log"],
  }]
}