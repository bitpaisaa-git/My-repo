var express		= require('express');
var app 		= express();
var fs 			= require('fs');
var https 		= require('https');
// var http		= require('http');
var request 	= require('request');
var cron 		= require('cron');
var cron1 		= require('node-cron');
var mysql 		= require('mysql');
var cors 		= require('cors');
var bodyParser  = require('body-parser');
var path = require('path');
var mysql = require('mysql');
var tech = require('../config/BpiDFddfY');
var config_wcwr = require('../config/BPdmn');
var site = require('../config/BatadPesab');

 
var history = book = orders_sell = orders_buy = sell_arr = buy_arr = items = result = tickers = prevDay = binTrds = tradeArr = tickers = [];
var inr_price = spread = inr = 0; 
var depthCache = tradeHis = {};
var options = {
	key: fs.readFileSync(path.join(__dirname,"bitPas.key")).toString(),
	cert: fs.readFileSync(path.join(__dirname,"bitPas.crt")).toString(),
	NPNProtocols: ['http/2.0', 'spdy', 'http/1.1', 'http/1.0']
};


var server = https.createServer(options, app);
// var server = require('http').Server(app);

var io     = require('socket.io')(server, { origins: '*:*'});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors({origin: config_wcwr.domain.url}));
var url_hit ='';
var result = tickers = prevDay = asksArr = bidsArr = binTrds =[];
var depthCache = {};

app.get('/', function (req, res) {
 var urlPath = path.join(__dirname,'../binance/')+req.query.path;
 fs.readFile(urlPath,'utf8', function(err, data) {
  if(!err && data){
   res.json(JSON.parse(data));
  }else{
   res.json({err : err, msg : 'Not success'});
  }
 });
});

const WebSocket = require('ws')
const APIKEY = '';
const binance = require('node-binance-api')().options({
	APIKEY: 'swFMK9c2aQVNZ6thL24hPWfWmLtO2A5dwQQzz3On78kOaXEgixp2r0ENiMSXfCwi',
	APISECRET: 'Y2af4ckPrjNqnddaqQi1FUFF9vChZ7aI9RQbT8jujrGF012t4F4YNrPeenBEmXZP',
	useServerTime: true, 
});


var dbhost = tech.decrypt(site.database.host);
var dbuser = tech.decrypt(site.database.user);
var dbpassword = tech.decrypt(site.database.password);
var dbdatabase = tech.decrypt(site.database.database);

var con = mysql.createConnection({
	host: dbhost,
	user: dbuser,
	password: dbpassword,
	database: dbdatabase
}); 
con.connect(function(err) {
	if (err) throw err;
	console.log("Connected!");
});

var myArray = ['LTCBTC', 'ETHBTC', 'BCHBTC', 'DASHBTC', 'XRPBTC', 'BTCUSDT', 'LTCUSDT', 'BCHUSDT', 'DASHUSDT', 'ETHUSDT', 'XRPUSDT', 'LTCETH','DASHETH','XRPETH']
 

const obj1 = {'LTCBTC': 'LTC_BTC', 'ETHBTC':'ETH_BTC', 'BCHBTC':'BCH_BTC', 'DASHBTC':'DASH_BTC', 'XRPBTC':'XRP_BTC', 'BTCUSDT':'BTC_USDT','LTCUSDT':'LTC_USDT','BCHUSDT':'BCH_USDT','DASHUSDT':'DASH_USDT','ETHUSDT':'ETH_USDT','XRPUSDT':'XRP_USDT','LTCETH':'LTC_ETH','DASHETH':'DASH_ETH','XRPETH':'XRP_ETH'};

const obj2 = {'LTCBTC': 'LTC/BTC', 'ETHBTC':'ETH/BTC', 'BCHBTC':'BCH/BTC', 'DASHBTC':'DASH/BTC', 'XRPBTC':'XRP/BTC', 'BTCUSDT':'BTC/USDT','LTCUSDT':'LTC/USDT','BCHUSDT':'BCH/USDT','DASHUSDT':'DASH/USDT','ETHUSDT':'ETH/USDT','XRPUSDT':'XRP/USDT','LTCETH':'LTC/ETH','DASHETH':'DASH/ETH','XRPETH':'XRP/ETH'};

io.on('connection', function(socket){
	socket.on('receiverequest',function(val){
		io.sockets.in(val.recPair).emit('getpairdata',{'msg':'1','pair':val.recPair,'ordertype':val.recType,'order':val.recOrder,'trade':val.recTrade, 'wcwr_id':''});
	});

	socket.on('receivewindow', function (val) {
		io.sockets.emit('getwindow',{'msg':'1','wcwr':val.recId,'btype':val.recType});

	});

	socket.on('join_room', function (val) {
		socket.join(val.id);
	});

	app.post('/restrictwindow',function (req,res) {
		var parameter   =   req.body;
		var trigger_id =   parameter.trigger_id;
		var btype       =   parameter.type
		io.sockets.emit('window',{'msg':'1','wcwr':trigger_id, 'btype':btype});
		res.end();
	});
});

binance.websockets.depthCache(['LTCBTC', 'ETHBTC', 'BCHBTC', 'DASHBTC', 'XRPBTC', 'BTCUSDT', 'LTCUSDT', 'BCHUSDT', 'DASHUSDT', 'ETHUSDT', 'XRPUSDT', 'LTCETH','DASHETH','XRPETH'], (symbol, depth) => {
	let max = 10;
	let asks = binance.sortAsks(depth.asks,max);
	let bids = binance.sortBids(depth.bids,max);
	key = obj2[symbol];
	depthCache[key] = {'asks' : asks, 'bids' : bids};
},20);

cron1.schedule('*/10 * * * * *', () => { 
	binanceOrders('ETH/BTC');
	binanceOrders('LTC/BTC');
	binanceOrders('BCH/BTC');
	binanceOrders('DASH/BTC');
	binanceOrders('XRP/BTC');
	binanceOrders('BTC/USDT');
	binanceOrders('LTC/USDT');
	binanceOrders('BCH/USDT');
	binanceOrders('DASH/USDT');
	binanceOrders('ETH/USDT');
	binanceOrders('XRP/USDT');
	binanceOrders('LTC/ETH');
	binanceOrders('DASH/ETH');
	binanceOrders('XRP/ETH');

});

function getDecimal(num) {
	num = num.toString();
	if (num.indexOf('.') !== -1) {
		return parseFloat(num.split(".")[1].length);
	} else {
		return 0;
	}
}

function toDecimals(num, length) {
	if (isNaN(num))
		return 0;
	var length1 = parseFloat(length) + 1;
	num = num.toString(); 
	if(num.indexOf(".")>-1){
		num = num.slice(0, (num.indexOf(".")) + parseFloat(length1));
		if (Math.abs(num) < 1.0) {
			var e = parseInt(num.toString().split('e-')[1]);
			if (e) {
				num *= Math.pow(10, e - 1);
				num = '0.' + (new Array(e)).join('0') + num.toString().substring(2);
			}
		} else {
			var e = parseInt(num.toString().split('+')[1]);
			if (e > 20) {
				e -= 20;
				num /= Math.pow(10, e);
				num += (new Array(e + 1)).join('0');
			}
		}
		return num;
	} else {
		return num;
	}
}


function binanceOrders(pair) {
	if(depthCache[pair] != undefined) {
		split = pair.split('/');
		pairs = split[0] + '_' + split[1];
		var buyOr = sellOr = [];

		buyorder = Object.keys(depthCache[pair].bids).map(function(key){
			return {price: parseFloat(key).toFixed(8), amount: parseFloat(depthCache[pair]['bids'][key]).toFixed(8)};
		});

		sellorder = Object.keys(depthCache[pair].asks).map(function(key){
			return {price: parseFloat(key).toFixed(8), amount: parseFloat(depthCache[pair]['asks'][key]).toFixed(8)};
		});	 		

		buyOr = buyorder;
		sellOr = sellorder;
		buy_Order(0, buyOr, pairs);
		sell_Order(0, sellOr, pairs);
		if(split[1]=='USDT'){

			buyorder_inr = Object.keys(depthCache[pair].bids).map(function(key){
				var ii = parseFloat(key)*parseFloat(inr_price);
				return {price: parseFloat(ii).toFixed(8), amount: parseFloat(depthCache[pair]['bids'][key]).toFixed(8)};
			});

			sellorder_inr = Object.keys(depthCache[pair].asks).map(function(key){
				var ii = parseFloat(key)*parseFloat(inr_price);			
				return {price: parseFloat(ii).toFixed(8), amount: parseFloat(depthCache[pair]['asks'][key]).toFixed(8)};
			});	 

			var pairs1 = split[0] + '_INR';
			var buyOr_inr = sellOr = [];
			buyOr_inr = buyorder_inr;
			sellOr_inr = sellorder_inr;

			buy_Order(0, buyOr_inr, pairs1);
			sell_Order(0, sellOr_inr, pairs1);
		}

		// io.sockets.in(pair).emit('depthbook',{'msg':'1','pair':pair,'buy':buyorder,'sell':sellorder});
	}
}

cron1.schedule('* * * * * *', () => {
	myArray.forEach(function(value){
		binance.recentTrades(value, (error, trades,symbol) => {
			try{
				if(error) { 
					stopbin=true;
					let ers=error.toString();
					let errs={
						"error":ers
					}
				}else{
					key = obj2[value];
					let tradedata=[];
					for(var i in trades){
						tradedata.push(trades [i]);
					}

					var tradehis=JSON.parse(JSON.stringify(tradedata));
					for(let i=0;i<tradehis.length;i++){
						if(tradehis[i]['isBuyerMaker'] == true) {
							clsName = 'class="text_green_1"';
						} else {
							clsName = 'class="text_red_1"';
						}
						dates = new Date(tradehis[i]['time']).toString();
						split = dates.split(' ');
						tradehis[i] = {
							"price":tradehis[i]['price'],
							"amount":tradehis[i]['qty'],
							"isBuyerMaker":tradehis[i]['isBuyerMaker'],
							"datetime":split[4],
							"time":tradehis[i]['time'],
							"clsName":clsName
						}
					} 
					var tradeH = [];
					psplit = key.split('/');
					pairs = psplit[0] + '_' + psplit[1];
					tradeH = tradehis.reverse();

					trade_history(0, tradeH, pairs);

					if(psplit[1]=='USDT'){

							 
							var pairs1 = psplit[0] + '_INR';
							var tradeH_inr = []; 

							var tradehis_inr=JSON.parse(JSON.stringify(tradedata));
							for(let i=0;i<tradehis_inr.length;i++){
								if(tradehis_inr[i]['isBuyerMaker'] == true) {
									clsName = 'class="text_green_1"';
								} else {
									clsName = 'class="text_red_1"';
								}
								dates = new Date(tradehis_inr[i]['time']).toString();
								split = dates.split(' ');
								var pr = tradehis_inr[i]['price']*inr_price;
								tradehis_inr[i] = {
									"price":pr.toString(),
									"amount":tradehis_inr[i]['qty'],
									"isBuyerMaker":tradehis_inr[i]['isBuyerMaker'],
									"datetime":split[4],
									"time":tradehis_inr[i]['time'],
									"clsName":clsName
								}
							} 

							tradeH_inr = tradehis_inr.reverse();
							trade_history(0, tradeH_inr, pairs1);
					}

				}
			}catch(e){
				console.log("bin_trades_emit_err",e);
			}
		},20);
	});
});

binance.websockets.prevDay(['LTCBTC', 'ETHBTC', 'BCHBTC', 'DASHBTC', 'XRPBTC', 'BTCUSDT', 'LTCUSDT', 'BCHUSDT', 'DASHUSDT', 'ETHUSDT', 'XRPUSDT', 'LTCETH','DASHETH','XRPETH'], (error, response) => {
	if(response.eventType == '24hrTicker') {
		if(response.symbol != undefined) {
			pairs = obj1[response.symbol];
			if(tickers[pairs] != undefined) {
				delete tickers[pairs];
				tickers[pairs] = response;
			} else {
				tickers[pairs] = response;
			}
		}
	}
	if(error != null) {
		if(pairs) {
			disable_pair(pairs);
		}
	}
});

cron1.schedule('*/10 * * * * *', () => { 

	pairs = Object.keys(tickers);
	length = pairs.length;
	let pairsArr=[];
	if(length > 0) {
		for (var i = 0; i < length; i++) {
			var pair = pairs[i];
			split = pair.split('_');
			from = split[0];
			to = split[1];
			high = tickers[pair].high;
			low = tickers[pair].low;
			lastprice = tickers[pair].close;
			volume = tickers[pair].quoteVolume;
			changeper = tickers[pair].percentChange;
			/*request('http://localhost/bitpaisa_stag/update_lastprice/'+pair+'/'+lastprice+'/'+high+'/'+low+'/'+changeper+'/'+volume, function(error, response, body1) { 
			});

			io.sockets.emit('ticker',{'msg':'1','pair':pair,'lastprice':lastprice,'high':high,'low':low,'changeper':changeper,'volume':volume});*/

			pairArr = {
				"to_symbol":to,
				"trading_pair":pair,
				"last_price":lastprice,
			}

			pairsArr.push(pairArr);

			lastpriceUpdate(from, to, lastprice);
			tickers_data(0, high, low, lastprice, volume, changeper, pair);	


			if(split[1]=='USDT'){
					 
					var pairs1 = split[0] + '_INR';
					var high_inr = tickers[pair].high * inr_price;
					var low_inr = tickers[pair].low * inr_price;
					var lastprice_inr = tickers[pair].close * inr_price;
					high_inr = high_inr.toString();
					low_inr = low_inr.toString();
					lastprice_inr = lastprice_inr.toString();

					tickers_data(0, high_inr, low_inr, lastprice_inr, volume, changeper, pairs1);	 
			}


		}
	}	
});

cron1.schedule('*/1 * * * *', () => {
		// io.sockets.emit('depthchart',{'msg':'1'});
		binancedepthchart('ETH/BTC');
		binancedepthchart('LTC/BTC');
		binancedepthchart('BCH/BTC');
		binancedepthchart('DASH/BTC');
		binancedepthchart('XRP/BTC');
		binancedepthchart('BTC/USDT');
		binancedepthchart('LTC/USDT');
		binancedepthchart('BCH/USDT');
		binancedepthchart('DASH/USDT');
		binancedepthchart('ETH/USDT');
		binancedepthchart('XRP/USDT');
		binancedepthchart('LTC/ETH');
		binancedepthchart('DASH/ETH');
		binancedepthchart('XRP/ETH'); 
});

function binancedepthchart(pair) {
	var split = pair.split('/');
	var pairs1 = split[0] + '_' + split[1];
	if(depthCache[pair] != undefined) {
		buyorder = Object.keys(depthCache[pair].bids).map(function(key){
			return {price: parseFloat(key).toFixed(8), amount: parseFloat(depthCache[pair]['bids'][key]).toFixed(8)};
		});

		sellorder = Object.keys(depthCache[pair].asks).map(function(key){
			return {price: parseFloat(key).toFixed(8), amount: parseFloat(depthCache[pair]['asks'][key]).toFixed(8)};
		});	 
			var leng=8;
			if (buyorder != '' && buyorder != 0) {
     	   buy_orders_lenght = buyorder.length;
         	
            var orders = buyorder;
            var add_orders = 0,
            add_orders = 0;
            var highchartdata ='';
            var highchartdatasell ='';
            var highchartdata_inr ='';
            var highchartdatasell_inr ='';
            var place_amount =0;
            var place_amountbuy =0;
            var pricebuy =0;

            var place_amountbuy_inr =0;
            var pricebuy_inr =0;

            for (var i in orders) {
                var ret = orders[i].price; 
                if (getDecimal(ret)) {
                    ret = toDecimals(parseFloat(ret), leng);
                }
                if (ret != 0) {
                    if(ret > 0){
                        if (add_orders != 0) {
                            updated = 0;
                            add_orders.forEach(function(index,value){ 
                                if (parseFloat(value.price) == parseFloat(ret)) {
                                    updated = 1;
                                    add_orders[index].amount = parseFloat(value.amount) + parseFloat(orders[i].amount);
                                }
                            });
                            if (updated == 0) {
                               var obj2 = {
                                    price: ret,
                                    amount: orders[i].amount,
                                    total: ret * orders[i].amount
                                }
                                add_orders.push(obj2);
                            }
                        } else {
                            add_orders = new Array();
                            var obj = {
                                price: ret,
                                amount: orders[i].amount,
                                total: ret * orders[i].amount
                            };
                            add_orders.push(obj);
                        }
                    }
                }
            }
             if(add_orders){
                add_orders.sort(function(a, b) {
                    return parseFloat(b.total) - parseFloat(a.total);
                });

                var rev = {};        
                add_orders.forEach(function(i,value){    
                    pri = parseFloat(value.price);
                    rev[pri] = i;
                });

                add_orders.sort(function(a, b) {
                    return parseFloat(b.price) - parseFloat(a.price);
                });
                add_orders.forEach(function(value){  
                    ret = parseFloat(value.price);
                    amt = parseFloat(value.amount).toFixed(8);
                    place_amount = parseFloat(value.amount)+parseFloat(place_amount); 
                    if (!isNaN(ret)) {
                        price = parseFloat(ret).toFixed(leng);      
                        pricebuy = price;
                        pricebuy_inr = price * inr_price;
                        place_amountbuy = place_amount;            
                        highchartdata = highchartdata + '['+price+','+place_amount+'],';   
                        if(split[1]=='USDT'){
                        	price_inr = price * inr_price;
                        	highchartdata_inr = highchartdata_inr + '['+price_inr+','+place_amount+'],'; 
                        } 
                    }
                });
            }
              
    }
    if (sellorder != '' && sellorder != 0) {
		sell_orders_lenght = sellorder.length; 
			orders = sellorder;
			var add_orders = 0,
			add_orders1 = 0;
			var place_amount = 0;
			var place_amountsell = 0;
			var pricesell = 0;
			for (var i in orders) {
				var ret = orders[i].price;
				if (getDecimal(ret)) {
					ret = toDecimals(parseFloat(ret), leng);
				}
				if (ret != 0) {
					if(ret > 0){
						if (add_orders != 0) {
							updated = 0;
							add_orders.forEach(function(index,value){   

								if (parseFloat(value.price) == parseFloat(ret)) {
									updated = 1;

									add_orders[index].amount = parseFloat(value.amount) + parseFloat(orders[i].amount);
								}
							});
							if (updated == 0) {
								obj2 = {
									price: ret,
									amount: orders[i].amount,
									total : ret * orders[i].amount
								}
								add_orders.push(obj2);
							}
						} else {
							add_orders = new Array();
							obj = {
								price: ret,
								amount: orders[i].amount,
								total : ret * orders[i].amount
							};
							add_orders.push(obj);
						}
					}
				}
			}
			if(add_orders){
				add_orders.sort(function(a, b) {
					return parseFloat(b.total) - parseFloat(a.total);
				});

				var rev = {};	
				add_orders.forEach(function(i,value){  		 
					pri = parseFloat(value.price);
					rev[pri] = i;
				});


				add_orders.sort(function(a, b) {
					return parseFloat(a.price) - parseFloat(b.price);
				});
				add_orders.forEach(function(value){    
					ret = parseFloat(value.price);
					amt = parseFloat(value.amount).toFixed(8);
					place_amount = parseFloat(value.amount)+parseFloat(place_amount);
					if (!isNaN(ret)) {
						price = parseFloat(ret).toFixed(leng);
						place_amountsell= place_amount;
						pricesell= price;
						pricesell_inr= price*inr_price;
 						highchartdatasell = highchartdatasell + '['+price+','+place_amount+'],'; 
 						 if(split[1]=='USDT'){
                        	price_inr = price * inr_price;
                        	highchartdatasell_inr = highchartdatasell_inr + '['+price_inr+','+place_amount+'],'; 
                        } 

 					}
				});
			}

 	
	} 

     	highchartdata = highchartdata+'['+pricebuy+','+place_amountbuy+']';
     	highchartdatasell = highchartdatasell+'['+pricesell+','+place_amountsell+']';

     	if(fs.existsSync(path.join(__dirname,"../binance/depthjson/"+split[0]+split[1]+"/depth_buy.json"))) {
			fs.readFile(path.join(__dirname,"../binance/depthjson/"+split[0]+split[1]+"/depth_buy.json"),'utf8', function(err){
				fs.writeFile(path.join(__dirname,"../binance/depthjson/"+split[0]+split[1]+"/depth_buy.json"),highchartdata, function(err){
				}); 
			});
		} else {
			fs.appendFile(path.join(__dirname,"../binance/depthjson/"+split[0]+split[1]+"/depth_buy.json"),highchartdata, function(err){
			});
		}
		if(fs.existsSync(path.join(__dirname,"../binance/depthjson/"+split[0]+split[1]+"/depth_sell.json"))) {
			fs.readFile(path.join(__dirname,"../binance/depthjson/"+split[0]+split[1]+"/depth_sell.json"),'utf8', function(err){
				fs.writeFile(path.join(__dirname,"../binance/depthjson/"+split[0]+split[1]+"/depth_sell.json"),highchartdatasell, function(err){
				}); 
			});
		} else {
			fs.appendFile(path.join(__dirname,"../binance/depthjson/"+split[0]+split[1]+"/depth_sell.json"),highchartdatasell, function(err){
			});
		}
		
		if(split[1]=='USDT'){
			highchartdata_inr = highchartdata_inr+'['+pricebuy_inr+','+place_amountbuy+']';
	     	highchartdatasell_inr = highchartdatasell_inr+'['+pricesell_inr+','+place_amountsell+']';

	     	if(fs.existsSync(path.join(__dirname,"../binance/depthjson/"+split[0]+"INR/depth_buy.json"))) {
				fs.readFile(path.join(__dirname,"../binance/depthjson/"+split[0]+"INR/depth_buy.json"),'utf8', function(err){
					fs.writeFile(path.join(__dirname,"../binance/depthjson/"+split[0]+"INR/depth_buy.json"),highchartdata_inr, function(err){
					}); 
				});
			} else {
				fs.appendFile(path.join(__dirname,"../binance/depthjson/"+split[0]+"INR/depth_buy.json"),highchartdata_inr, function(err){
				});
			}
			if(fs.existsSync(path.join(__dirname,"../binance/depthjson/"+split[0]+"INR/depth_sell.json"))) {
				fs.readFile(path.join(__dirname,"../binance/depthjson/"+split[0]+"INR/depth_sell.json"),'utf8', function(err){
					fs.writeFile(path.join(__dirname,"../binance/depthjson/"+split[0]+"INR/depth_sell.json"),highchartdatasell_inr, function(err){
					}); 
				});
			} else {
				fs.appendFile(path.join(__dirname,"../binance/depthjson/"+split[0]+"INR/depth_sell.json"),highchartdatasell_inr, function(err){
				});
			} 

		} 
 	}
}


function lastpriceUpdate(from, to, lastprice) {
	if(lastprice > 0) {
		if(to == 'BTC') { 
			var sql1 = "UPDATE BP_trade_pairs SET last_price = '"+lastprice+"' WHERE from_symbol = '"+from+"' AND to_symbol = '"+to+"'";
			con.query(sql1, function (err, result) {
				if (err) throw err;
			});
		} else {
			var from = (from == 'USDC') ? 'USDT' : from;
			var sql2 = "UPDATE BP_trade_pairs SET last_price = '"+lastprice+"' WHERE from_symbol = '"+from+"' AND to_symbol = '"+to+"'";
			con.query(sql2, function (err, result) {
				if (err) throw err;
			}); 
			if(inr_price > 0) {
				sql3 = "SELECT * FROM BP_trade_pairs WHERE from_symbol = '"+from+"' AND to_symbol = 'INR'";
				con.query(sql3, function (err, result, fields) {
					if (err) throw err;
					var spread = result[0].spread;
					var pair = from + '_INR';
					spread_data(0, spread, pair);
				});

				var inrlastprice = ( lastprice * inr_price ) + spread;
				var sql4 = "UPDATE BP_trade_pairs SET last_price = '"+inrlastprice+"' WHERE from_symbol = '"+from+"' AND to_symbol = 'INR'";
				con.query(sql4, function (err, result) {
					if (err) throw err;
				});

			}
		}
	}
}

function disable_pair(pair) {
	var sql7 = "UPDATE BP_trade_pairs SET site_status = '0' WHERE trading_pair = '"+pair+"'";
	con.query(sql7, function (err, result) {
		if (err) throw err;
	});
}

function buy_Order(i, list, key) {
	if (i < list.length) {
		var trds = JSON.stringify(list);
		if(fs.existsSync(path.join(__dirname,"../binance/orderHistory/buyOrders/"+key+".json"))) {
			fs.readFile(path.join(__dirname,"../binance/orderHistory/buyOrders/"+key+".json"),'utf8', function(err){
				fs.writeFile(path.join(__dirname,"../binance/orderHistory/buyOrders/"+key+".json"),trds, function(err){
				});
				i++;
			});
		} else {
			fs.appendFile(path.join(__dirname,"../binance/orderHistory/buyOrders/"+key+".json"),trds, function(err){
			});
		}
	}
}

function sell_Order(i, list, key) {
	if (i < list.length) {
		var trds1 = JSON.stringify(list);
		if(fs.existsSync(path.join(__dirname,"../binance/orderHistory/sellOrders/"+key+".json"))) {
			fs.readFile(path.join(__dirname,"../binance/orderHistory/sellOrders/"+key+".json"),'utf8', function(err){
				fs.writeFile(path.join(__dirname,"../binance/orderHistory/sellOrders/"+key+".json"),trds1, function(err){
				});
				i++;
			});
		} else {
			fs.appendFile(path.join(__dirname,"../binance/orderHistory/sellOrders/"+key+".json"),trds1, function(err){
			});
		}
	}
}

function trade_history(i, list, key) {
	if (i < list.length) {
		var trds2 = JSON.stringify(list);
		if(fs.existsSync(path.join(__dirname,"../binance/tradeHistory/"+key+".json"))) {
			fs.readFile(path.join(__dirname,"../binance/tradeHistory/"+key+".json"),'utf8', function(err){
				fs.writeFile(path.join(__dirname,"../binance/tradeHistory/"+key+".json"),trds2, function(err){
				});
				i++;
			});
		} else {
			fs.appendFile(path.join(__dirname,"../binance/tradeHistory/"+key+".json"),trds2, function(err){
			});
		}
	}
}

function tickers_data(i, high, low, lastprice, volume, changeper, key) {
	tickersArr1 = [];
	tickersArr1[i] = {
		"pair":key,
		"high":high,
		"low":low,
		"lastprice":lastprice,
		"volume":volume,
		"changeper":changeper
	}
	list = tickersArr1;
	if (i < list.length) {
		var trds3 = JSON.stringify(list);
		if(fs.existsSync(path.join(__dirname,"../binance/tickers/"+key+".json"))) {
			fs.readFile(path.join(__dirname,"../binance/tickers/"+key+".json"),'utf8', function(err){
				fs.writeFile(path.join(__dirname,"../binance/tickers/"+key+".json"),trds3, function(err){
				});
				i++;
			});
		} else {
			fs.appendFile(path.join(__dirname,"../binance/tickers/"+key+".json"),trds3, function(err){
			});
		}
	}
}

function spread_data(i, spread, key) {
	spreadArr = [];
	spreadArr[i] = {
		"spread":spread,
	}
	var list = spreadArr;
	if (i < list.length) {
		var sprd = JSON.stringify(list);
		if(fs.existsSync(path.join(__dirname,"../binance/spread/"+key+".json"))) {
			fs.readFile(path.join(__dirname,"../binance/spread/"+key+".json"),'utf8', function(err){
				fs.writeFile(path.join(__dirname,"../binance/spread/"+key+".json"),sprd, function(err){
				});
				i++;
			});
		} else {
			fs.appendFile(path.join(__dirname,"../binance/spread/"+key+".json"),sprd, function(err){
			});
		}
	}
}

cron1.schedule('*/5 * * * * *', () => {
	inr_sql = "SELECT inr_enable FROM BP_PaBiiIstaa_ss WHERE id = '1'";
	con.query(inr_sql, function (err, result, fields) {
		if (err) throw err;
		var inr_enable = result[0].inr_enable;
		inr_sql = "SELECT inr_value, admin_inr_value FROM BP_currency WHERE currency_symbol = 'USDT'";
		con.query(inr_sql, function (err, result, fields) {
			if (err) throw err;
			var inr_value = parseFloat(result[0].inr_value).toFixed(2);
			var admin_inr_value = parseFloat(result[0].admin_inr_value).toFixed(2);
			if(inr_enable == 1) {
				inr_price = inr = inr_value;
			} else {
				inr_price = inr = admin_inr_value;
			}
			inrValue(inr);
		});
	});
});

function inrValue(inr) {
	inr_price = inr;
}

server.listen(2053, function(){
	console.log('listening on *:2053');
});
